package com.ssc.sshz.peg.ptaf.inspection.analysis;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ssc.peg.cnav.analysis.AnalyzerManager;
import com.ssc.peg.cnav.analysis.bean.AnalysisProperty;
import com.ssc.peg.cnav.analysis.bean.AnalysisResult;
import com.ssc.peg.cnav.analysis.constant.SummaryHeaders;
import com.ssc.peg.cnav.analysis.generator.HTMLGenerator;
import com.ssc.peg.cnav.analysis.graph.GraphDataCollection;
import com.ssc.peg.cnav.analysis.util.CollectionTransformer;
import com.ssc.peg.cnav.analysis.util.FileUtil;
import com.ssc.peg.cnav.analysis.util.PropertyGenerator;
import com.ssc.peg.cnav.analysis.util.SymbolUtil;
import com.ssc.sshz.peg.ptaf.inspection.bean.Report;
import com.ssc.sshz.peg.ptaf.inspection.constants.AutoAnalysisStatus;
import com.ssc.sshz.peg.ptaf.inspection.service.ReportService;
import com.statestr.gcth.cloud.deploy.tool.AutoDeploymentTool;

public class LogAnalysisThread
{
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final Logger logger = Logger.getLogger(LogAnalysisThread.class);

	public void doAutoAnalysis(final String[] args, final String htmlPath, final Report report, final String username,
			final String password, final boolean isIaas, final boolean deleteTempPath, final ReportService<Report> rsService)
	{
		Thread thread = new Thread(new Runnable()
		{

			@Override
			public void run()
			{
				long current = System.currentTimeMillis();
				try
				{
					String logTempPath = "C:/apms_log/" + current;
					String analysisTempPath = "C:/apms_analysis/" + current;
					doDownload(logTempPath, report, username, password, isIaas, rsService);
					doAnalysis(args, logTempPath, htmlPath, analysisTempPath, report, rsService);
					if (deleteTempPath)
						doClear(logTempPath, analysisTempPath);
					int percentage = 100;
					report.setExecutePercentage(percentage);
					rsService.updateExecutePercent(report);
				}
				catch (Exception e)
				{
					// update
					report.setAnalysisStatus(AutoAnalysisStatus.EXCEPTION);
					rsService.updateByStatus(report);
					logger.error(e.getMessage(), e);
					return;
				}
				report.setAnalysisStatus(AutoAnalysisStatus.COMPLETE);
				rsService.updateByStatus(report);
			}
		});

		thread.start();

	}

	private void doAnalysis(String[] args, String logTempPath, String htmlPath, String tempPath, Report report,
			ReportService<Report> rsService) throws IOException, ParseException
	{
		// update
		report.setAnalysisStatus(AutoAnalysisStatus.ANALYZE);
		rsService.updateByStatus(report);

		String propPath = tempPath + "/analysis.properties";
		String fgLogPath = logTempPath + "/fg/";
		String bgLogPath = logTempPath + "/bg/";
		String cpuLogPath = logTempPath + "/cpu/";

		Map<String, String> map = FileUtil.arrayToMap(args);
		AnalysisProperty propValues = new AnalysisProperty();
		propValues.setFgLogFolderPath(fgLogPath);
		propValues.setBgLogFolderPath(bgLogPath);
		propValues.setCpuLog(cpuLogPath);
		propValues.setRowDatapath(tempPath + "/data.csv");
		propValues.setRowDataBKPath(tempPath + "/data_bk.csv");
		propValues.setSummaryPath(tempPath + "/summary.csv");
		propValues.setTempFolderPath(tempPath);
		propValues.setRuntimeStart(sdf.format(report.getStartTime()));
		propValues.setRuntimeEnd(sdf.format(report.getEndTime()));
		propValues.setDurationMillSec("10000");

		PropertyGenerator.createProperties(propPath, propValues);

		AnalyzerManager la = new AnalyzerManager();
		boolean analyzeOver = la.doAnalyze(propPath);

		AnalysisResult ar = la.getResult();
		generateReport(map, ar, htmlPath, tempPath, analyzeOver);
		
	}

	private void doDownload(String logTempPath, Report report, String uesrname, String password, boolean isIaas,
			ReportService<Report> rsService) throws Exception
	{
		// update
		report.setAnalysisStatus(AutoAnalysisStatus.DOWNLOAD);
		rsService.updateByStatus(report);

		// long current = System.currentTimeMillis();
		String fgLogPath = logTempPath + "/fg/";
		String bgLogPath = logTempPath + "/bg/";
		String cpuLogPath = logTempPath + "/cpu/";

		List<Date> logTimeList = getLogTimes(report.getStartTime(), report.getEndTime());
		
		String[] bgSysNames = report.getBgSystemName().split(",");
		String[] bgContexts = report.getBgContext().split(",");
		String[] bgEnvs = report.getBgEnv().split(",");
		
		int percentage = 0;
		int totalDownloadCount = (1+ bgEnvs.length) * logTimeList.size() + bgEnvs.length;
		int oneCountPercentage = (int)(((double)1/totalDownloadCount * 0.95) * 100);
		/*
		 * foreground
		 */
		try
		{
			for (int i = 0; i < logTimeList.size(); i++)
			{
				Date startTime = logTimeList.get(i);
				Date endTime = null;
				if ((i + 1) <= logTimeList.size() - 1)
					endTime = logTimeList.get(i + 1);
				else if (logTimeList.size() >= 2)
					break;
				String[] fgArgs =
				{ "--Fetch", "Y", "--appCode", report.getFgSystemName(), "--Context", report.getFgContext(), "--env", report.getFgEnv(),
						"--Path", fgLogPath, "--LogName", "FAW_l4j", "--Approvers", "-P", uesrname + "/" + password };
				AutoDeploymentTool.fetchLogs(fgArgs, true, isIaas, startTime, endTime);
				
				percentage = percentage + oneCountPercentage;
				report.setExecutePercentage(percentage);
				rsService.updateExecutePercent(report);
				//update the percentage to database
			}
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			throw e;
		}

	
		try
		{
			for (int i = 0; i < bgSysNames.length; i++)
			{
				
				for (int j = 0; j < logTimeList.size(); j++)
				{
					Date startTime = logTimeList.get(j);
					Date endTime = null;
					if ((j + 1) <= logTimeList.size() - 1)
						endTime = logTimeList.get(j + 1);
					else if (logTimeList.size() >= 2)
						break;
    				/*
    				 * background
    				 */
    				String[] bgArgs =
    				{ "--Fetch", "Y", "--appCode", bgSysNames[i], "--Context", bgContexts[i], "--env", bgEnvs[i], "--Path", bgLogPath,
    						"--LogName", "FAW_l4j", "--Approvers", "-P", uesrname + "/" + password };
    				AutoDeploymentTool.fetchLogs(bgArgs, true, isIaas, startTime, endTime);
    				
    				percentage = percentage + oneCountPercentage;
    				report.setExecutePercentage(percentage);
    				rsService.updateExecutePercent(report);
    				//update the percentage to database
				}
				/*
				 * cpu
				 */
				String[] cpuArgs =
				{ "--Fetch", "Y", "--appCode", bgSysNames[i], "--Context", bgContexts[i], "--env", bgEnvs[i], "--Path", cpuLogPath,
						"--Approvers", "-P", uesrname + "/" + password };

				Date endDate = report.getEndTime();
				endDate.setDate(endDate.getDate() + 1);
				AutoDeploymentTool.fetchCPULog(cpuArgs, report.getStartTime(), endDate);
				endDate.setDate(endDate.getDate() - 1);
				
				percentage = percentage + oneCountPercentage;
				report.setExecutePercentage(percentage);
				rsService.updateExecutePercent(report);
				//update the percentage to database
			}
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			throw e;
		}

	}

	private void generateReport(Map<String, String> args, AnalysisResult ar, String htmlPath, String tempPath, boolean analyzeOver)
			throws IOException
	{
		File desFile = new File(htmlPath);
		HTMLGenerator generator = new HTMLGenerator();
		if (!analyzeOver)
		{
			logger.info("Generating HTML report file with path:" + htmlPath);
			generator.generateEmptyHTML(desFile);
			Set<String> names = args.keySet();
			for (String name : names)
			{
				generator.modifyFile(name, args.get(name), desFile);
			}
			return;
		}
		Map<String, Double[]> map = null;
		try
		{

			// map =
			// GraphDataCollection.getInstance().getDataCollection("C:\\cnav_analysis\\1409039472403"
			// + "/summary.csv");
			map = GraphDataCollection.getInstance().getDataCollection(tempPath + "/summary.csv", 3);

		}
		catch (IOException e)
		{
			throw e;
		}
		try
		{
			args.put("${request_num}", String.valueOf(map.get(SummaryHeaders.REQUESTNUM)[0].intValue()));
			args.put("${cpu_usage}", String.valueOf(map.get(SummaryHeaders.AVGCPUUSAGE)[0]));
			args.put("${avg_tps}", String.valueOf(map.get(SummaryHeaders.AVGTPS)[0]));
			args.put("${vm_count}", String.valueOf(map.get(SummaryHeaders.VMCOUNT)[0].intValue()));
			args.put("${tps_per_vm}", String.valueOf(map.get(SummaryHeaders.AVGTPSPERVM)[0]));
			args.put("${afc_count}", String.valueOf(map.get(SummaryHeaders.AVGAFCCNT)[0]));
			args.put("${db_count}", String.valueOf(map.get(SummaryHeaders.AVGDBCNT)[0]));
			args.put("${cal_count}", String.valueOf(map.get(SummaryHeaders.AVGCALCNT)[0]));
		}
		catch (NullPointerException e)
		{
		}

		Map<String, String> params = new HashMap<String, String>();
		GraphDataCollection gc = GraphDataCollection.getInstance();
		Map<String, String> bgmap = CollectionTransformer.List2Map(ar.getBackRespList());
		String bgRespTime = gc.transformDataSetInHTML(bgmap, "bg_resp_time");
		String fgRespTime = GraphDataCollection.getInstance().transformDataSetInHTML(
				CollectionTransformer.List2Map(ar.getForeRespList()), "fg_resp_time");
		String totalrespTime = GraphDataCollection.getInstance().transformDataSetInHTML(
				CollectionTransformer.List2Map(ar.getTotalRespList()), "total_resp_time");
		String totalTps = GraphDataCollection.getInstance().transformDataSetInHTML(
				CollectionTransformer.List2Map(ar.getTotalTPSList()), "total_tps");
		String bgTps = GraphDataCollection.getInstance().transformDataSetInHTML(
				CollectionTransformer.List2Map(ar.getBackTPSList()), "bg_tps");
		String fgTps = GraphDataCollection.getInstance().transformDataSetInHTML(
				CollectionTransformer.List2Map(ar.getForeTPSList()), "fg_tps");

		Set<String> vms = ar.getCpuMapWide().keySet();
		for (String vm : vms)
		{
			String vmDataset = GraphDataCollection.getInstance().transformDataSetInHTML(
					CollectionTransformer.List2Map(ar.getCpuMapWide().get(vm)), vm);
			String name = SymbolUtil.commaToUnderline(vm);
			params.put(name, vmDataset);
		}

		String respTimRateData = GraphDataCollection.getInstance().showResTimeRateData(map);
		String loadRateVar = GraphDataCollection.getInstance().showLoadVar(map);
		String rateBarName = GraphDataCollection.getInstance().showBarName();
		String loadRateFunc = GraphDataCollection.getInstance().showFunctionName();
		String RateBarColor = GraphDataCollection.getInstance().showBarColor();
		String summaryTabledata = GraphDataCollection.getInstance().showTableData(map, tempPath + "/summary.csv");
		String avgTimeData = GraphDataCollection.getInstance().showAvgTimeDataStr(map);
		String rateBarLoad = GraphDataCollection.getInstance().getRateBarLoad(map);
		String barXVxisValue = GraphDataCollection.getInstance().showRateBarXAxisValue(map);
		int xAxisValueCount = GraphDataCollection.getInstance().getXAxisValueCount(map);

		params.put("bar_name", rateBarName);
		params.put("rate_dataset", respTimRateData);
		params.put("load_vars", loadRateVar);
		params.put("load_function", loadRateFunc);
		params.put("bar_color", RateBarColor);
		params.put("resp_time_table", summaryTabledata);
		params.put("bg_resp_time", bgRespTime);
		params.put("fg_resp_time", fgRespTime);
		params.put("total_resp_time", totalrespTime);
		params.put("total_tps", totalTps);
		params.put("bg_tps", bgTps);
		params.put("fg_tps", fgTps);
		params.put("avg_time_data", avgTimeData);
		params.put("rate_bar_load", rateBarLoad);
		params.put("xAxisValueCount", String.valueOf(xAxisValueCount));
		params.put("BarXVxisValue", String.valueOf(barXVxisValue));

		logger.info("Generating HTML report file with path:" + htmlPath);
		generator.generateHTML(params, desFile);
		Set<String> names = args.keySet();
		for (String name : names)
		{
			generator.modifyFile(name, args.get(name), desFile);
		}

	}

	private List<Date> getLogTimes(Date start, Date end)
	{
		Calendar cld = Calendar.getInstance();
		ArrayList<Date> logTimeStrings = new ArrayList<Date>();
		Date current;
		if (start == null || end == null)
		{
			logTimeStrings.add(new Date());
		}
		else
		{
			current = new Date(start.getTime());
			while (current.before(end) || current.equals(end))
			{

				logTimeStrings.add(current);
				current.setHours(current.getHours() + 1);
			}
		}

		return logTimeStrings;
	}

	private void doClear(String logTempPath, String analysisTempPath)
	{
		File logFolder = new File(logTempPath);
		File analyFolder = new File(analysisTempPath);
		if (logFolder.exists())
			com.ssc.sshz.peg.ptaf.inspection.util.FileUtil.getInstance().delFolder(logFolder);
		if (analyFolder.exists())
			com.ssc.sshz.peg.ptaf.inspection.util.FileUtil.getInstance().delFolder(analyFolder);

	}

}
