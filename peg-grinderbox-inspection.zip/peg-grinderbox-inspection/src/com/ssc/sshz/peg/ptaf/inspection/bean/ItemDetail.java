package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;

@Entity
public class ItemDetail implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int detailId;
	private int itemId;
	private String itemName;
	private int briefId;
	private int planId;
	private double responseTime;
	private int vuId;
	private Date startTime;
	private int thread;
	public int getThread()
	{
		return thread;
	}
	public void setThread(int thread)
	{
		this.thread = thread;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public int getDetailId()
	{
		return detailId;
	}
	public void setDetailId(int detailId)
	{
		this.detailId = detailId;
	}
	public int getItemId()
	{
		return itemId;
	}
	public void setItemId(int itemId)
	{
		this.itemId = itemId;
	}
	public String getItemName()
	{
		return itemName;
	}
	public void setItemName(String itemName)
	{
		this.itemName = itemName;
	}
	public int getBriefId()
	{
		return briefId;
	}
	public void setBriefId(int briefId)
	{
		this.briefId = briefId;
	}
	public int getPlanId()
	{
		return planId;
	}
	public void setPlanId(int planId)
	{
		this.planId = planId;
	}
	public double getResponseTime()
	{
		return responseTime;
	}
	public void setResponseTime(double responseTime)
	{
		this.responseTime = responseTime;
	}
	public int getVuId()
	{
		return vuId;
	}
	public void setVuId(int vuId)
	{
		this.vuId = vuId;
	}
	
}
