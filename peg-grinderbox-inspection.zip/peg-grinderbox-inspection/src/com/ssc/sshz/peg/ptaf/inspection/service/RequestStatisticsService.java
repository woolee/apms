package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface RequestStatisticsService<T>
{
	public List<T> getAllRequestStatistics() throws DataAccessException;
	public List<T> getAllRequestStatisticsByItemId(int itemId) throws DataAccessException;
	public List<T> getAllRequestStatisticsByBriefId(int briefId) throws DataAccessException;
	public List<T> getAllRequestStatisticsByItemIdAndBriefId(T entity) throws DataAccessException;
	public T getRequestStatistics(T entity) throws DataAccessException;
	public boolean addRequestStatistics(T entity) throws DataAccessException;
	public boolean updateRequestStatistics(T entity) throws DataAccessException;
}
