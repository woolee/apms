package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface ItemStatisticsService<T>
{
	public List<T> getAllItemStatistics() throws DataAccessException;
	public List<T> getItemStitisticsByBriefId(int briefId) throws DataAccessException;
	public List<T> getItemStitisticsByPlanIdAndItemId(T entity) throws DataAccessException;
	public T getItemStatistics(T entity) throws DataAccessException;
	public boolean addItemStatistics(T entity) throws DataAccessException;
	public boolean updateItemStatistics(T entity) throws DataAccessException;
}
