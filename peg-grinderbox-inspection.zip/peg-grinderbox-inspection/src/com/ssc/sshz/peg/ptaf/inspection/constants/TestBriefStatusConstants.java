package com.ssc.sshz.peg.ptaf.inspection.constants;

public class TestBriefStatusConstants
{
	public static final String UPLOADSUCCESS = "upload success";
	public static final String PREPARERUN = "preparing run";
	public static final String STARTGENERATEASSET = "start generate asset..."; 
	public static final String GENERATEASSETOVER = "generate asset over";
	public static final String STARTRUN = "start run engine...";
	public static final String RUN = "running...";
	public static final String RUNOVER = "run over";
	public static final String STARTANALYZE = "start analyzing...";
//	public static final String ANALYZE = "analying";
	public static final String ANALYZEOVER = "analyze over";
	public static final String TESTCOMPLETED = "test completed";
	public static final String TESTEXCEPTION = "exception";
}
