package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.QTMLogScan;
import com.ssc.sshz.peg.ptaf.inspection.dao.QTMLogScanDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.QTMLogScanMapper;

@Repository
public class QTMLogScanDaoImpl<T extends QTMLogScan> implements QTMLogScanDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private QTMLogScanMapper mapper;

	@Override
	public List<T> getAllQTMLogScan() {
		List<T> object = null;
		try{
		object =  (List<T>) mapper.getAllQTMLogScan();
		}
		catch(Exception e)
		{
			logger.error("Exception while get all QTMLogScan from database",e);
			throw new DaoException("Exception while get all QTMLogScan from database",e);
		}
		return object;
	}

	@Override
	public T getQTMLogScanById(int id) {
		T object = null;
		try{
		object = (T) mapper.getQTMLogScanById(id);
		}
		catch(Exception e)
		{
			logger.error("Exception while get QTMLogScan from database",e);
			throw new DaoException("Exception while get QTMLogScan from database",e);
		}
		return object;
	}

	@Override
	public boolean addQTMLogScan(T scan) {
		boolean flag = false;
		try
		{
			mapper.addQTMLogScan(scan);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add QTMLogScan to database",e);
			throw new DaoException("Exception while add QTMLogScan to database",e);
		}
		return flag;
		
	}

	@Override
	public boolean delQTMLogScanById(int id) {
		boolean flag = false;
		try
		{
			mapper.delQTMLogScanById(id);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while delete QTMLogScan from database",e);
			throw new DaoException("Exception while delete QTMLogScan from database",e);
		}
		return flag;
	}


	@Override
	public boolean updateQTMLogScanFile(byte[] errorFile, int scanId) {
		boolean flag = false;
		try
		{
			mapper.updateQTMLogScanFile(errorFile, scanId);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while update QTMLogScan to database",e);
			throw new DaoException("Exception while update QTMLogScan to database",e);
		}
		return flag;
	}

	@Override
	public boolean updateQTMLogScanProgress(int executePercentage, int scanId) {
		boolean flag = false;
		try
		{
			mapper.updateQTMLogScanProgress(executePercentage, scanId);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while update QTMLogScan to database",e);
			throw new DaoException("Exception while update QTMLogScan to database",e);
		}
		return flag;
	}


	

}
