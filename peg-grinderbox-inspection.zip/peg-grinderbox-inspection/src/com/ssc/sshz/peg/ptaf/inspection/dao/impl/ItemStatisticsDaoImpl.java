package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.ItemStatistics;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemStatisticsDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ItemStatisticsMapper;

@Repository
// @Named
public class ItemStatisticsDaoImpl<T extends ItemStatistics> implements ItemStatisticsDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private ItemStatisticsMapper mapper;

	@Override
	public boolean addItemStatistics(T entity) throws DataAccessException
	{
		boolean flag = false;
		try
		{
			mapper.addItemStatistics(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add ItemStatistics to database",e);
			throw new DaoException("Exception while add ItemStatistics to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllItemStatistics() throws DataAccessException
	{
		List<T> object = null;
		try{
		object = (List<T>) mapper.getAllItemStatistics();
		}
		catch(Exception e)
		{
			logger.error("Exception while get all ItemStatistics from database",e);
			throw new DaoException("Exception while get all ItemStatistics from database",e);
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getItemStatistics(T entity) throws DataAccessException
	{
		T object = null;
		try{
		object = (T) mapper.getItemStitistics(entity);
		}
		catch(Exception e)
		{
			logger.error("Exception while get ItemStatistics from database",e);
			throw new DaoException("Exception while get ItemStatistics from database",e);
		}
		return object;
		
	}

	@Override
	public boolean updateItemStatistics(T entity) throws DataAccessException
	{
		boolean flag = false;
		try
		{
			mapper.updateItemStitistics(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while update ItemStatistics to database",e);
			throw new DaoException("Exception while update ItemStatistics to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllItemStatisticsByBriefId(int briefId) throws DataAccessException
	{
		List<T> object = null;
		try{
		object = (List<T>) mapper.getItemStitisticsByBriefId(briefId);
		}
		catch(Exception e)
		{
			logger.error("Exception while get itemDetail list by test brief id from database",e);
			throw new DaoException("Exception while get itemDetail list by test brief id from database",e);
		}
		return object;
	}

	@Override
	public List<T> getAllItemStatisticsByPlanIdAndItemId(T entity)
			throws DataAccessException {
		List<T> object = null;
		try{
		object = (List<T>) mapper.getAllItemStatisticsByPlanIdAndItemId(entity);
		}
		catch(Exception e)
		{
			logger.error("Exception while get itemDetail list by test brief id from database",e);
			throw new DaoException("Exception while get itemDetail list by test brief id from database",e);
		}
		return object;
	}

}
