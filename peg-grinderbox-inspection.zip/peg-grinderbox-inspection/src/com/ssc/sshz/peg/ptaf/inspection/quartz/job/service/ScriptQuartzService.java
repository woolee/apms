package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ScriptMapper;

public class ScriptQuartzService<T extends Script>
{
	private Logger logger = Logger.getLogger(getClass());

	// private SqlSession session = ConnectionFactory.openSession();
	// private ScriptMapper mapper = session.getMapper(ScriptMapper.class);

	@SuppressWarnings("unchecked")
	public List<T> getAllScripts() throws Exception
	{
		List<T> object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ScriptMapper mapper = session.getMapper(ScriptMapper.class);
			object = (List<T>) mapper.getAllScript();
		}
		catch (Exception e)
		{
			logger.error("exception while get all script",e);
			throw new Exception("exception while get all script", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	public T getScript(T entity) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ScriptMapper mapper = session.getMapper(ScriptMapper.class);
			object = (T) mapper.getScript(entity);
		}
		catch (Exception e)
		{
			logger.error("exception while get script object from databse",e);
			throw new Exception("exception while get script object from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;

	}

	public boolean addScript(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ScriptMapper mapper = session.getMapper(ScriptMapper.class);
			mapper.addScript(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while add script to database",e);
			throw new Exception("exception while add script to database", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	public boolean delScriptById(int id) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ScriptMapper mapper = session.getMapper(ScriptMapper.class);
			mapper.delScriptById(id);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while delete script by script id from database",e);
			throw new Exception("exception while delete script by script id from database", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	public T getScriptById(int id) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ScriptMapper mapper = session.getMapper(ScriptMapper.class);
			object = (T) mapper.getScriptById(id);
		}
		catch (Exception e)
		{
			logger.error("exception while get script object by script id from databse",e);
			throw new Exception("exception while get script object by script id from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	public boolean updateScript(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ScriptMapper mapper = session.getMapper(ScriptMapper.class);
			mapper.updateScript(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while update script ",e);
			throw new Exception("exception while update script ", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}
}
