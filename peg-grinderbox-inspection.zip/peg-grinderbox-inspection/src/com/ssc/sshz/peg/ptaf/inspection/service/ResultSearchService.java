package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.ResultSearchBean;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;

public interface ResultSearchService
{
	public List<ResultSearchBean> getResultSearchByProject(List<Project> projectList,Plan plan) throws DataAccessException;
	
}
