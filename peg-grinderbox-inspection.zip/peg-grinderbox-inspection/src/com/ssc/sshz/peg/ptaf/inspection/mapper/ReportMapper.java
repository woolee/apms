package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;
import java.util.Map;

import com.ssc.sshz.peg.ptaf.inspection.bean.Report;

public interface ReportMapper extends SqlMapper
{
	
	public List<Report> getAllReport();
	public void addReport(Report report);
	public void updateByStatus(Report report);
	public void updateExecutePercent(Report report);
	public void deleteReportByUUID(String reportUUID);
	public List<Report> getPagingReprot(Map<String, Integer> pageparm);
	public List<Report> getDownloadPercentList();
	public Report getReportByUUID(String uuid);
}
