package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface RequestStatisticsDao<T> {
	public boolean addRequestStatistics(T entity) throws DataAccessException;
	public List<T> getAllRequestStatistics()throws DataAccessException;
	public List<T> getAllRequestStatisticsByItemId(int itemId)throws DataAccessException;
	public List<T> getAllRequestStatisticsByBriefId(int briefId)throws DataAccessException;
	public List<T> getAllRequestStatisticsByItemIdAndBriefId(T entity)throws DataAccessException;
	public T getRequestStatistics(T entity)throws DataAccessException;
	public boolean updateRequesttatistics(T entity)throws DataAccessException;
}
