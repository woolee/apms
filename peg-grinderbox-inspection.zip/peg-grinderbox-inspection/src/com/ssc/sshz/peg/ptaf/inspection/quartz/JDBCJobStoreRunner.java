package com.ssc.sshz.peg.ptaf.inspection.quartz;

import static org.quartz.JobBuilder.newJob;
import static org.quartz.SimpleScheduleBuilder.simpleSchedule;
import static org.quartz.TriggerBuilder.newTrigger;
import static org.quartz.impl.matchers.EverythingMatcher.allJobs;
import static org.quartz.impl.matchers.EverythingMatcher.allTriggers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.GroupMatcher;

import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.ScheduleRuntime;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.PerformanceRunJob;
import com.ssc.sshz.peg.ptaf.inspection.quartz.listener.PerformanceJobListener;
import com.ssc.sshz.peg.ptaf.inspection.quartz.listener.PerformanceSchedulerListener;
import com.ssc.sshz.peg.ptaf.inspection.quartz.listener.PerformanceTriggerListener;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;

public class JDBCJobStoreRunner
{
	private static Scheduler scheduler;
	private static final Logger logger = Logger.getLogger(JDBCJobStoreRunner.class);
	private static SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final String GROUPNAME = "performanceRunGroup";
	private static final String JOBNAME = "job";
	private static final String TRIGGERNAME = "trigger";

	private JDBCJobStoreRunner()
	{
	};

	public static void init() throws SchedulerException
	{
		try
		{
			JDBCJobStoreRunner.startScheduler();
		}
		catch (SchedulerException e)
		{
			logger.error(e.getMessage(), e);
			throw new SchedulerException(e.getMessage(), e);
		}
	}

	public static String getInstanceName() throws SchedulerException
	{
		String instanceName = null;
		try
		{
			instanceName = scheduler.getSchedulerName();
		}
		catch (SchedulerException e)
		{
			throw e;
		}

		return instanceName;
	}

	/**
	 * add job listener, trigger listener, scheduler listener start the
	 * scheduler instance
	 * 
	 * @throws SchedulerException
	 */
	public static void startScheduler() throws SchedulerException
	{
		try
		{
			scheduler = StdSchedulerFactory.getDefaultScheduler();
			scheduler.getListenerManager().addJobListener(new PerformanceJobListener(), allJobs());
			scheduler.getListenerManager().addSchedulerListener(new PerformanceSchedulerListener());
			scheduler.getListenerManager().addTriggerListener(new PerformanceTriggerListener(), allTriggers());
			scheduler.start();
		}
		catch (SchedulerException e)
		{
			logger.error(e.getMessage(), e);
			throw new SchedulerException("exception while start scheduler", e);
		}
	}

	/**
	 * 
	 * @param startTime
	 *            (can be null if start now)
	 * @param endTime
	 *            (can be null)
	 * @param intervalSeconds
	 * @param repeatTime
	 * @param data
	 * @param isServiceCall
	 * @param collection
	 * @param startNow
	 * @return
	 * @throws Exception
	 */
	public static RuntimeTrigger schedule(Date startTime, Date endTime, int intervalSeconds, int repeatTime, JobData data,
			boolean isServiceCall, TestBeanCollection collection, boolean startNow, RuntimeTrigger rt) throws Exception
	{
		long current = java.lang.System.currentTimeMillis();
		String jobName = JOBNAME + current;
		String triggerName = TRIGGERNAME + current;
		String startTimeStamp = null;
		String endTimeStamp = null;
		if (startTime != null)
			startTimeStamp = format.format(startTime);

		if (endTime != null)
			endTimeStamp = format.format(endTime);

		logger.info("Instance " + getInstanceName() + " new job[" + jobName + "] start at:" + startTimeStamp + "; end at: "
				+ endTimeStamp);
		ScheduleRuntime runtime = new ScheduleRuntime(startTime, endTime, intervalSeconds, repeatTime);
		rt = scheduleNewJob(jobName, triggerName, GROUPNAME, runtime, data, isServiceCall, collection, startNow, rt);
		return rt;
	}

	/**
	 * 
	 * @param startTime
	 * @param endTime
	 * @param intervalSeconds
	 * @param repeatTime
	 * @param data
	 * @param isServiceCall
	 * @param collection
	 * @param startNow
	 * @param rt
	 * @return
	 * @throws Exception
	 */
	public static RuntimeTrigger reBundleTigger(Date startTime, Date endTime, int intervalSeconds, int repeatTime, JobData data,
			boolean isServiceCall, TestBeanCollection collection, boolean startNow, RuntimeTrigger rt) throws Exception
	{
		long current = java.lang.System.currentTimeMillis();
		String jobName = JOBNAME + current;
		String triggerName = TRIGGERNAME + current;
		String startTimeStamp = null;
		String endTimeStamp = null;
		if (startTime != null)
			startTimeStamp = format.format(startTime);
		else
			return null;
		if (endTime != null)
			endTimeStamp = format.format(endTime);

		try
		{
			removeTigger(rt.getTriggerName());
			ScheduleRuntime runtime = new ScheduleRuntime(startTime, endTime, intervalSeconds, repeatTime);
			rt = scheduleNewJob(jobName, triggerName, GROUPNAME, runtime, data, isServiceCall, collection, startNow, rt);
			logger.info("Instance " + getInstanceName() + " schedule job[" + jobName + "] with new Trigger. Start at:"
					+ startTimeStamp + "; end at: " + endTimeStamp);
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			throw new Exception(e.getMessage(), e);
		}
		return rt;
	}

	/**
	 * @param triggerName
	 * @return
	 * @throws SchedulerException
	 */
	public static boolean removeTigger(String triggerName) throws SchedulerException
	{
		boolean isRemoved = false;
		try
		{
			Set<TriggerKey> keys = scheduler.getTriggerKeys(GroupMatcher.triggerGroupEquals(GROUPNAME));
			for (TriggerKey key : keys)
			{
				if (triggerName.equals(key.getName()))
					scheduler.unscheduleJob(key);
			}
			isRemoved = true;
			logger.info("Remove Trigger " + GROUPNAME + "." + triggerName);
		}
		catch (SchedulerException e)
		{
			isRemoved = false;
			logger.error(e.getMessage(), e);
			throw new SchedulerException(e.getMessage(), e);
		}
		return isRemoved;
	}

	/**
	 * reschedule all jobs in DB table QRTZ_JOB_DETAILS;
	 * 
	 * @throws SchedulerException
	 */
	public static void rescheduleStoredJob() throws SchedulerException
	{

		try
		{
			List<String> tiggerNames = scheduler.getTriggerGroupNames();
			for (String name : tiggerNames)
			{

				Set<TriggerKey> keys = scheduler.getTriggerKeys(GroupMatcher.triggerGroupEquals(name));
				for (TriggerKey key : keys)
				{
					scheduler.rescheduleJob(key, scheduler.getTrigger(key));
				}
			}
		}
		catch (SchedulerException e)
		{
			logger.error(e.getMessage(), e);
			throw new SchedulerException("Exception while reschedule jobs", e);
		}
	}

	/**
	 * delete all jobs in DB table QRTZ_JOB_DETAILS
	 * 
	 * @return
	 * @throws SchedulerException
	 */
	public static boolean deleteAllJobs() throws SchedulerException
	{
		boolean isCanceled = false;
		try
		{
			List<String> jobGruopNames = scheduler.getJobGroupNames();
			for (String name : jobGruopNames)
			{
				Set<JobKey> jobKeys = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(name));
				List<JobKey> jobKeyList = new ArrayList<JobKey>();
				jobKeyList.addAll(jobKeys);
				scheduler.deleteJobs(jobKeyList);
			}
			isCanceled = true;
		}
		catch (SchedulerException e)
		{
			isCanceled = false;
			logger.error(e.getMessage(), e);
			throw new SchedulerException("Exception while cancel all jobs", e);
		}
		return isCanceled;
	}

	/**
	 * delete jobs in DB table QRTZ_JOB_DETAILS;
	 * 
	 * @param runtimeJobList
	 * @return if the jobs are deleted
	 * @throws SchedulerException
	 */
	public static boolean deleteJobs(List<RuntimeTrigger> runtimeJobList) throws SchedulerException
	{
		boolean isCanceled = false;
		try
		{
			for (RuntimeTrigger runtimeJob : runtimeJobList)
			{
				String jobName = runtimeJob.getJobName();
				String groupName = runtimeJob.getJobGroupName();
				Set<JobKey> jobKeys = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName));
				for (JobKey jobKey : jobKeys)
				{
					if (jobKey.getName().equals(jobName))
						scheduler.deleteJob(jobKey);
				}
			}
			isCanceled = true;
		}
		catch (SchedulerException e)
		{
			isCanceled = false;
			logger.error(e.getMessage(), e);
			throw new SchedulerException("Exception while cancel jobs", e);
		}
		return isCanceled;
	};

	/**
	 * pause all triggers
	 * 
	 * @return if pause successfully
	 * @throws SchedulerException
	 */
	public static boolean pauseAll() throws SchedulerException
	{
		boolean isPaused = false;
		try
		{
			scheduler.pauseAll();
			isPaused = true;
		}
		catch (SchedulerException e)
		{
			isPaused = false;
			logger.error(e.getMessage(), e);
			throw new SchedulerException(e.getMessage(), e);
		}
		return isPaused;
	}

	/**
	 * pause the specify triggers
	 * 
	 * @param runtimeJobList
	 * @return if pause successfully
	 * @throws SchedulerException
	 */
	public static boolean pauseTiggers(List<RuntimeTrigger> runtimeJobList) throws SchedulerException
	{
		boolean isPaused = false;
		try
		{
			for (RuntimeTrigger runtimeTrigger : runtimeJobList)
			{
				String triggerName = runtimeTrigger.getTriggerName();
				Set<TriggerKey> keys = scheduler.getTriggerKeys(GroupMatcher.triggerGroupEquals(GROUPNAME));
				for (TriggerKey triggerKey : keys)
				{
					if(triggerName.equals(triggerKey.getName()))
						scheduler.pauseTrigger(triggerKey);
				}
			}
			isPaused = true;
		}
		catch (SchedulerException e)
		{
			isPaused = false;
			logger.error(e.getMessage(), e);
			throw new SchedulerException(e.getMessage(), e);
		}
		return isPaused;
	}

	/**
	 * pause the specify trigger
	 * 
	 * @param triggerName
	 * @return if pause successfully
	 * @throws SchedulerException
	 */
	public static boolean pauseTigger(String triggerName) throws SchedulerException
	{
		boolean isPaused = false;
		try
		{
			Set<TriggerKey> keys = scheduler.getTriggerKeys(GroupMatcher.triggerGroupEquals(GROUPNAME));
			for (TriggerKey triggerKey : keys)
			{
				if(triggerName.equals(triggerKey.getName()))
					scheduler.pauseTrigger(triggerKey);
			}
			isPaused = true;
		}
		catch (SchedulerException e)
		{
			isPaused = false;
			logger.error(e.getMessage(), e);
			throw new SchedulerException(e.getMessage(), e);
		}
		return isPaused;
	}

	/**
	 * resume all triggers
	 * 
	 * @return if resume successfully
	 * @throws SchedulerException
	 */
	public static boolean resumeAll() throws SchedulerException
	{
		boolean isResumed = false;
		try
		{
			scheduler.resumeAll();
			isResumed = true;
		}
		catch (SchedulerException e)
		{
			isResumed = false;
			logger.error(e.getMessage(), e);
			throw new SchedulerException(e.getMessage(), e);
		}
		return isResumed;
	}

	/**
	 * resume the specify list of triggers
	 * 
	 * @param runtimeJobList
	 * @return if resume successfully
	 * @throws SchedulerException
	 */
	public static boolean resumeTriggers(List<RuntimeTrigger> runtimeJobList) throws SchedulerException
	{
		boolean isResumed = false;
		try
		{
			for (RuntimeTrigger runtimeTrigger : runtimeJobList)
			{
				String triggerName = runtimeTrigger.getTriggerName();
				Set<TriggerKey> keys = scheduler.getTriggerKeys(GroupMatcher.triggerGroupEquals(GROUPNAME));
				for (TriggerKey triggerKey : keys)
				{
					if(triggerName.equals(triggerKey.getName()))
						scheduler.resumeTrigger(triggerKey);
				}
			}
			isResumed = true;
		}
		catch (SchedulerException e)
		{
			isResumed = false;
			logger.error(e.getMessage(), e);
			throw new SchedulerException(e.getMessage(), e);
		}
		return isResumed;
	}

	/**
	 * resume the specify trigger
	 * 
	 * @param trigger name
	 * @return if resume successfully
	 * @throws SchedulerException
	 */
	public static boolean resumeTrigger(String triggerName) throws SchedulerException
	{
		boolean isResumed = false;
		try
		{
			Set<TriggerKey> keys = scheduler.getTriggerKeys(GroupMatcher.triggerGroupEquals(GROUPNAME));
			for (TriggerKey triggerKey : keys)
			{
				if(triggerName.equals(triggerKey.getName()))
					scheduler.resumeTrigger(triggerKey);
			}
			isResumed = true;
		}
		catch (SchedulerException e)
		{
			isResumed = false;
			logger.error(e.getMessage(), e);
			throw new SchedulerException(e.getMessage(), e);
		}
		return isResumed;
	}

	private static RuntimeTrigger scheduleNewJob(String jobName, String triggerName, String group, ScheduleRuntime runtime,
			JobData data, boolean isFromService, TestBeanCollection collection, boolean startNow, RuntimeTrigger rt)
			throws Exception
	{
		Date scheduleDate = null;
		try
		{
			JobDetail job = null;
			/*
			 * service call which run once as schedule time, no repeat
			 */
			if (isFromService)
			{
				JobDataMap jobDataMap = new JobDataMap();
				jobDataMap.put("jobData", data);
				jobDataMap.put("collection", collection);
				job = newJob(PerformanceRunJob.class).withIdentity(jobName, group).usingJobData(jobDataMap).requestRecovery(true)
						.build();

				TriggerBuilder<SimpleTrigger> triggerBuilder = newTrigger().withIdentity(triggerName, group)
						.withSchedule(simpleSchedule().withRepeatCount(runtime.getRepeatCount())).startAt(runtime.getStartTime());
				Trigger trigger = triggerBuilder.build();
				scheduleDate = scheduler.scheduleJob(job, trigger);
			}
			else
			{
				JobBuilder jobBuilder = newJob(PerformanceRunJob.class);
				jobBuilder = jobBuilder.withIdentity(jobName, group).requestRecovery(true);
				JobDataMap jobDataMap = new JobDataMap();
				jobDataMap.put("jobData", data);
				jobDataMap.put("collection", collection);
				job = jobBuilder.usingJobData(jobDataMap).build();

				/*
				 * run once and start now while user click the execute button
				 */
				if (startNow)
				{
					TriggerBuilder<SimpleTrigger> triggerBuilder = newTrigger().withIdentity(triggerName, group)
							.withSchedule(simpleSchedule().withRepeatCount(0)).startNow();
					Trigger trigger = triggerBuilder.build();
					scheduleDate = scheduler.scheduleJob(job, trigger);
				}
				else if (runtime.getStartTime() != null)
				{
					/*
					 * repeat forever with specify interval
					 */
					if (runtime.getEndTime() == null && runtime.getRepeatCount() < 0 && runtime.getIntervalInSecond() > 0)
					{
						TriggerBuilder<SimpleTrigger> triggerBuilder = newTrigger()
								.withIdentity(triggerName, group)
								.withSchedule(simpleSchedule().withIntervalInSeconds(runtime.getIntervalInSecond()).repeatForever())
								.startAt(runtime.getStartTime());
						Trigger trigger = triggerBuilder.build();
						scheduleDate = scheduler.scheduleJob(job, trigger);
					}
					/*
					 * no repeat, run once
					 */
					else if (runtime.getEndTime() == null && runtime.getRepeatCount() == 0)
					{
						TriggerBuilder<SimpleTrigger> triggerBuilder = newTrigger().withIdentity(triggerName, group)
								.withSchedule(simpleSchedule().withRepeatCount(runtime.getRepeatCount()))
								.startAt(runtime.getStartTime());
						Trigger trigger = triggerBuilder.build();
						scheduleDate = scheduler.scheduleJob(job, trigger);
					}
					/*
					 * repeat several count with specify interval
					 */
					else if (runtime.getIntervalInSecond() > 0)
					{
						Trigger trigger = null;

						if (runtime.getEndTime() != null && runtime.getEndTime().getTime() > runtime.getStartTime().getTime())
						{
							TriggerBuilder<SimpleTrigger> triggerBuilder = newTrigger()
									.withIdentity(triggerName, group)
									.withSchedule(
											simpleSchedule().withIntervalInSeconds(runtime.getIntervalInSecond()).withRepeatCount(
													-1)).startAt(runtime.getStartTime()).endAt(runtime.getEndTime());
							trigger = triggerBuilder.build();
						}
						else if (runtime.getRepeatCount() >= 1)
						{
							TriggerBuilder<SimpleTrigger> triggerBuilder = newTrigger()
									.withIdentity(triggerName, group)
									.withSchedule(
											simpleSchedule().withIntervalInSeconds(runtime.getIntervalInSecond()).withRepeatCount(
													runtime.getRepeatCount())).startAt(runtime.getStartTime());
							trigger = triggerBuilder.build();
						}
						else
						{
							throw new Exception("Invaild runtime");
						}
						scheduleDate = scheduler.scheduleJob(job, trigger);
					}
					else
					{
						throw new Exception("Invaild runtime");
					}
				}
				else
				{
					throw new Exception("Invaild runtime");
				}
			}
		}
		catch (SchedulerException e)
		{
			logger.error(e.getMessage(), e);
			throw new SchedulerException("Exception while schedule new job", e);
		}
		catch (ParseException e)
		{
			logger.error(e.getMessage(), e);
			throw new ParseException("Exception while parse String to Date", 0);
		}
		if (scheduleDate != null && rt != null)
		{
			rt.setJobGroupName(GROUPNAME);
			rt.setJobName(jobName);
			rt.setTriggerName(triggerName);
			rt.setTiggerGroupName(GROUPNAME);
			rt.setSchedulerInsName(scheduler.getSchedulerName());
		}

		return rt;
	}

	/**
	 * shut down current scheduler instance
	 * 
	 * @throws SchedulerException
	 */
	public static void shutDown() throws SchedulerException
	{
		try
		{
			scheduler.shutdown();
			logger.warn("Scheduler instance: " + getInstanceName() + " has been shut down");
		}
		catch (SchedulerException e)
		{
			logger.error(e.getMessage(), e);
			throw new SchedulerException("Scheduler instance: " + getInstanceName() + " shut down error", e);
		}
	}

}
