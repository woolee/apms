package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.PlanMapper;

@Repository
public class PlanDaoImpl<T extends Plan> implements PlanDao<T>{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private PlanMapper mapper;

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllPlan() throws DataAccessException {
		List<T> allPlanList=null;
		try{ 
			allPlanList =(List<T>) mapper.getAllPlan();
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all plans from database",e);
			throw new DaoException("Exception while get all plans from database",e);
		}
		return allPlanList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getPlanById(Integer id) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getPlanById(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get plan by id from database",e);
			throw new DaoException("Exception while get plan by id database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getPlanByName(String name) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getPlanByName(name);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get plan by name from database",e);
			throw new DaoException("Exception while get plan by name database",e);
		}
		return entity;
	}

	@Override
	public boolean addPlan(T entity) throws DataAccessException {
		boolean flag = false;
		try {
			mapper.addPlan(entity); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while add plan to database",e);
			throw new DaoException("Exception while add plan to database",e);
		}
		return flag;
	}

	@Override
	public boolean delPlanById(Integer id) throws DataAccessException {
		boolean flag = false;
		try {
			mapper.delPlanById(id); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while delete plan from database",e);
			throw new DaoException("Exception while delete plan from database",e);
		}
		return flag;
	}

	@Override
	public boolean delPlanByName(String name) throws DataAccessException {
		boolean flag = false;
		try {
			mapper.delPlanByName(name); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while delete plan from database",e);
			throw new DaoException("Exception while delete plan from database",e);
		}
		return flag;
	}

	@Override
	public List<T> getPlanBySystemId(int systemId) throws DataAccessException {
		List<T> allPlanList=null;
		try{ 
			allPlanList =(List<T>) mapper.getPlanBySystemId(systemId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all plans from database",e);
			throw new DaoException("Exception while get all plans from database",e);
		}
		return allPlanList;
	}

	@Override
	public T getPlanBySystemIdPlanName(Plan plan) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getPlanBySystemIdPlanName(plan);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get plan by systemId and PlanName from database",e);
			throw new DaoException("Exception while get plan by systemId and PlanName from database",e);
		}
		return entity;
	}


	

}
