package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.GroupRight;
import com.ssc.sshz.peg.ptaf.inspection.dao.GroupRightDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.GroupRightMapper;

@Repository
public class GroupRightDaoImpl<T extends GroupRight> implements GroupRightDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private GroupRightMapper mapper;


	@Override
	public boolean addGroupRight(T entity) throws DataAccessException
	{
		boolean flag = false;
		try
		{
			mapper.addGroupRight(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add GroupRight to database",e);
			throw new DaoException("Exception while add GroupRight to database",e);
		}
		return flag;
	}


	@Override
	public List<T> getAllGroupRight() throws DataAccessException
	{
		List<T> list = null;
		try
		{
			list = (List<T>) mapper.getAllGroupRight();
		}
		catch (Exception e)
		{
			logger.error("Exception while get all GroupRight from database",e);
			throw new DaoException("Exception while get all GroupRight from database",e);
		}
		return list;
	}

	@Override
	public List<T> getGroupRightByGroupName(String groupName) throws DataAccessException
	{
		List<T> list = null;
		try
		{
			list = (List<T>) mapper.getGroupRightByGroupName(groupName);
		}
		catch (Exception e)
		{
			logger.error("Exception while get GroupRight by group name from database",e);
			throw new DaoException("Exception while get GroupRight by group name from database",e);
		}
		return list;
	}
	
	
	

}
