package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.Right;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RightMapper;

@Repository
public class RightDaoImpl<T extends Right> implements RightDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RightMapper mapper;


	@Override
	public boolean addRight(T entity) throws DataAccessException
	{
		boolean flag = false;
		try
		{
			mapper.addRight(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add right to database",e);
			throw new DaoException("Exception while add right to database",e);
		}
		return flag;
	}

	@Override
	public T getRightByRightName(String rightName) throws DataAccessException
	{
		T entity = null;
		try
		{
			entity = (T) mapper.getRightByRightName(rightName);
		}
		catch (Exception e)
		{
			logger.error("Exception while get right by right name to database",e);
			throw new DaoException("Exception while get right by right name to database",e);
		}
		return entity;
	}
	
}
