package com.ssc.sshz.peg.ptaf.inspection.constants;

public enum StrategyType
{
	Infinite,
	Once,
	Sometime
}
