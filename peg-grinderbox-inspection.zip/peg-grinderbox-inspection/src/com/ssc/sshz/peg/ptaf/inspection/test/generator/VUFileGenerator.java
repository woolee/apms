package com.ssc.sshz.peg.ptaf.inspection.test.generator;

import java.io.File;
import java.io.IOException;

import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;

public class VUFileGenerator
{
	 /**
     * 
     * @param source the file names need to be generated
     * @param paramFolder from
     * @param assetFolder to 
     * @return the generated files
     * @throws IOException
     */
    public File generateParamFile(File source, File assetFolder) throws IOException
    {

	File destFile = new File(assetFolder, TestAssetContants.VUCSV);

	
	FileUtil.getInstance().copyFile(source, destFile);
	    
	return destFile;

    }

}
