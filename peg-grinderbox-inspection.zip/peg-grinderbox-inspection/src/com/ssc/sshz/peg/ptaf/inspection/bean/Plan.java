package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;


//@Component
@Entity
public class Plan implements Serializable{
	@Override
	public String toString() {
		return "Plan [planId=" + planId + ", planName=" + planName
				+ ", systemId=" + systemId + ", plancreatorId=" + plancreatorId
				+ ", isEnabled=" + isEnabled + ", lastExecutorId="
				+ lastExecutorId + ", lastExecutorName=" + lastExecutorName
				+ ", lastExecutionTime=" + lastExecutionTime
				+ ", executionCount=" + executionCount + ", isDeleted="
				+ isDeleted + ", deleteTime=" + deleteTime
				+ ", planDescription=" + planDescription + "]";
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = -102171662021079733L;
	private Integer planId;
	private String planName;
	private Integer systemId;
	private Integer plancreatorId;
	private boolean isEnabled;
	private Integer lastExecutorId;
	private String lastExecutorName;
	private Timestamp  lastExecutionTime;
	private Integer executionCount ;
	private boolean isDeleted;
	private Timestamp deleteTime;
	private String planDescription;
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public Integer getSystemId() {
		return systemId;
	}
	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}
	public Integer getPlancreatorId() {
		return plancreatorId;
	}
	public void setPlancreatorId(Integer plancreatorId) {
		this.plancreatorId = plancreatorId;
	}
	public boolean isEnabled() {
		return isEnabled;
	}
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	public Integer getLastExecutorId() {
		return lastExecutorId;
	}
	public void setLastExecutorId(Integer lastExecutorId) {
		this.lastExecutorId = lastExecutorId;
	}
	public String getLastExecutorName() {
		return lastExecutorName;
	}
	public void setLastExecutorName(String lastExecutorName) {
		this.lastExecutorName = lastExecutorName;
	}
	public Timestamp getLastExecutionTime() {
		return lastExecutionTime;
	}
	public void setLastExecutionTime(Timestamp lastExecutionTime) {
		this.lastExecutionTime = lastExecutionTime;
	}
	public Integer getExecutionCount() {
		return executionCount;
	}
	public void setExecutionCount(Integer executionCount) {
		this.executionCount = executionCount;
	}
	public boolean isDeleted() {
		return isDeleted;
	}
	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Timestamp getDeleteTime() {
		return deleteTime;
	}
	public void setDeleteTime(Timestamp deleteTime) {
		this.deleteTime = deleteTime;
	}
	public String getPlanDescription() {
		return planDescription;
	}
	public void setPlanDescription(String planDescription) {
		this.planDescription = planDescription;
	}
	
	
	
	
	
	
	
	
	
	
	
	


}
