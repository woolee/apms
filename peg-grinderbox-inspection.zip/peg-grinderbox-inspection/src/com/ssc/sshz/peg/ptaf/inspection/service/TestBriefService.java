package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;


public interface TestBriefService<T>
{
	public List<T> getAllTestBreif() throws DataAccessException;
	public List<T> getTestBreifByPlanId(int planId) throws DataAccessException;
	public List<T> getTestBriefByPlanIdStartTimeEndTime(T entity) throws DataAccessException;
	public T getTestBreif(T entity) throws DataAccessException;
	public T getTestBreifBybreifId(int breifId) throws DataAccessException;
	public List<T> getLatestTestBriefByExecutorId(int executorId) throws DataAccessException;
	public boolean addTestBreif(T entity) throws DataAccessException;
	public boolean updateTestBreif(T entity) throws DataAccessException;
	public boolean updateTestBreifStatus(T entity) throws DataAccessException;
	public T getTestBriefBySystemuuid(String systemuuid);
	public boolean checkTestBriefExsitBySummaryId(String summaryId);
	public List<T> getTestBriefByGroup(List<? extends GrantedAuthority> groupList);
	public List<T> getTestBriefByRight(String username);
}
