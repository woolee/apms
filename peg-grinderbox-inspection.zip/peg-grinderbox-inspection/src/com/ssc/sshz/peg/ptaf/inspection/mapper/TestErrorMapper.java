package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;

public interface TestErrorMapper extends SqlMapper
{
	public void addTestError(TestError error);
	
	public TestError getTestError(TestError error);
	
	public List<TestError> getAllTestError();
	
	public List<TestError> getTestErrorByBriefId(int breifId);
	
	public List<TestError> getTestErrorByBriefAndType(TestError error);
}
