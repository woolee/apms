package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.ItemStatistics;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemStatisticsDao;
import com.ssc.sshz.peg.ptaf.inspection.service.ItemStatisticsService;
@Service

public class ItemStatisticsServiceImp<T extends ItemStatistics> implements ItemStatisticsService<T>
{
	@Inject
	private ItemStatisticsDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllItemStatistics() throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getAllItemStatistics();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getItemStatistics(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getItemStatistics(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addItemStatistics(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addItemStatistics(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateItemStatistics(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.updateItemStatistics(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getItemStitisticsByBriefId(int briefId)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllItemStatisticsByBriefId(briefId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getItemStitisticsByPlanIdAndItemId(T entity)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllItemStatisticsByPlanIdAndItemId(entity);
	}


	
}
