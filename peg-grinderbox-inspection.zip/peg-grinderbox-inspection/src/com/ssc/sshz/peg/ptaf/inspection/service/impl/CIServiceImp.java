package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import static com.ssc.sshz.peg.ptaf.inspection.constants.ErrorType.INSIDE;
import static com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants.ASSETTMEPPATH;
import static com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants.CIDEBU;
import static com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants.CIOUTPUTTEMPPATH;
import static com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants.DELAY_TIME;
import static com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants.RUNCOUNT;
import static com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants.THREADNUM;
import static com.ssc.sshz.peg.ptaf.inspection.constants.TestBriefStatusConstants.PREPARERUN;
import static com.ssc.sshz.peg.ptaf.inspection.constants.TestBriefStatusConstants.TESTEXCEPTION;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.ScheduleData;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.cloud.CloudSignOn;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.constants.TestType;
import com.ssc.sshz.peg.ptaf.inspection.dao.CIConfigDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanStrategyDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeTriggerDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.TestBriefDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.TestErrorDao;
import com.ssc.sshz.peg.ptaf.inspection.quartz.QuartzManager;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.service.CIService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;
import com.ssc.sshz.peg.ptaf.inspection.util.CSVReader;
import com.ssc.sshz.peg.ptaf.inspection.util.MD5Util;
import com.ssc.sshz.peg.ptaf.inspection.util.ReadXMLUtil;

@Service
public class CIServiceImp implements CIService
{

	private static final Logger logger = Logger.getLogger(CIServiceImp.class);

	@Inject
	private ItemDao<Item> itemDao;

	@Inject
	private RequestDao<Request> requestDao;

	@Inject
	private PlanDao<Plan> planDao;

	@Inject
	private PlanItemDao<PlanItem> planItemDao;

	@Inject
	private RuntimeDao<Runtime> runtimeDao;

	@Inject
	private PlanStrategyDao<PlanStrategy> planStrategyDao;

	@Inject
	private TestBriefDao<TestBrief> testBriefDao;

	@Inject
	private TestErrorDao<TestError> testErrorDao;

	@Inject
	private CIConfigDao<CIConfig> ciConfigDao;
	
	@Inject
	private RuntimeTriggerDao<RuntimeTrigger> runtimeTriggerDao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public String ReadXMLWriteToDB(Project project, System system, Item item, Request request, Plan plan, User user,
			PlanItem planItem, String configTempPath, PlanStrategy planStrategy, Runtime runtime, TestBrief testBrief,
			String configZipPath, String summaryId, TestError testError, CIConfig ciConfig, RuntimeTrigger runtimeTrigger) throws Exception
	{
		String errorPage = null;
		// User user = userDao.getUserByName(tempUser.getUserName());
		if(!checkConfigFileVaild(configTempPath))
			return "../Error/configZipError.jsp";
		ReadXMLUtil xmlReader = new ReadXMLUtil();
		long name = java.lang.System.currentTimeMillis();

		List<String> requestURL = xmlReader.getRequestURL(configTempPath);
		String url = requestURL.get(0);
		List<String> appcode = xmlReader.getAppcode(configTempPath);
		List<String> requestName = xmlReader.getRequestName(configTempPath);
		List<String> threadNumList = xmlReader.getThreadNum(configTempPath);
		List<String> runCountList = xmlReader.getRunCount(configTempPath);
		List<String> thinktimeList = xmlReader.getThinkTime(configTempPath);
		
		String threadNum = FilePathConstants.THREADNUM;
		String runCount = FilePathConstants.RUNCOUNT;
		String thinkTime = FilePathConstants.THINKTIME;
		if(threadNumList.size() != 0)
			threadNum = threadNumList.get(0);
		if(runCountList.size() != 0)
			runCount = runCountList.get(0);
		if(thinktimeList.size() != 0)
			thinkTime = thinktimeList.get(0);
			
		String userDat = configTempPath + "/user.csv";
		File userFile = new File(userDat);
		List<String[]> lines = null;
		try
		{
			lines = CSVReader.getInstance().getCSVLines(userFile);
		}
		catch (IOException e)
		{
			logger.error(e.getMessage());
			throw new IOException(e.getMessage(), e);
		}
		String username = null;
		String password = null;
		if(lines.size() != 0)
		{
		username = lines.get(0)[0];
		password = lines.get(0)[1];
		}

		errorPage = CloudSignOn.getInstance().checkServer(url, username, password);
		if (errorPage != null)
			return errorPage;
		
		// add CI config to database
		MD5Util md5Util = new MD5Util();
		String md5Num = md5Util.fileMD5CheckSum(configZipPath);
		File configZipFile = new File(configZipPath);
		byte[] zipByte = new byte[(int) configZipFile.length()];
		FileInputStream zipIn;
		zipIn = new FileInputStream(configZipFile);
		zipIn.read(zipByte);
		if(zipIn != null)
			zipIn.close();
		ciConfig.setConfigFileMd5(md5Num);
		ciConfig.setConfigFile(zipByte);
		ciConfig.setConfigName(configZipFile.getName());
		ciConfig.setCreatedBy(user.getUserId());
		ciConfig.setSummaryId(summaryId);
		CIConfig configBySysUUID = ciConfigDao.getCIConfigBySystemuuid(system.getSystemuuid());
		if( configBySysUUID == null)
		{ 
			ciConfigDao.addCIConfig(ciConfig);
			ciConfig = ciConfigDao.getCIConfig(ciConfig);
		}
		else{
			ciConfig = configBySysUUID;
		}
		
		plan.setSystemId(system.getSystemId());// to do
		plan.setEnabled(true);
		plan.setPlanName("planName" + name);
		plan.setDeleted(false);
		plan.setPlancreatorId(user.getUserId());
		planDao.addPlan(plan);

		int planId = planDao.getPlanBySystemId(plan.getSystemId()).get(0).getPlanId();
		Plan tempPlan = planDao.getPlanById(planId);
		logger.info("[" + summaryId + "] Add new plan with plan id:" + planId);

		TestBrief tempTestBrief = addAndGetTestBrief(testBrief, user, tempPlan, summaryId);

		List<Item> itemList = new ArrayList<Item>();
		Map<Integer, List<Request>> requestMapByItemId = new HashMap<Integer, List<Request>>();

		for (int i = 0; i < requestName.size(); i++)
		{
			item.setItemName(requestName.get(i));
			item.setSystemId(system.getSystemId());
			item.setDeleted(false);
			itemDao.addItem(item);
			Item tempItem = itemDao.getItemBySystemIdItemName(item);
			logger.info("[" + summaryId + "] Add new item with itemId:[" + tempItem.getItemId() + "] itemName:["
					+ tempItem.getItemName() + "]");
			int itemid = tempItem.getItemId();
			itemList.add(tempItem);

			planItem.setItemId(itemid);
			planItem.setItemName(requestName.get(i));
			planItem.setPlanId(planId);
			planItem.setPlanName("planName" + name);
			planItem.setItemIsValid(true);
			planItemDao.addPlanItem(planItem);

			request.setRequestUrl(requestURL.get(0));
			request.setRequestName(requestName.get(i));
			request.setItemName(requestName.get(i));
			request.setItemId(itemid);
			request.setPlanId(planId);
			requestDao.addRequest(request);

			Request tempRequest = requestDao.getRequestsByItemId(itemid).get(0);
			logger.info("[" + summaryId + "] Add new request with requestId:[" + tempRequest.getRequestId() + "] requestName:["
					+ tempRequest.getRequestName() + "]");
			List<Request> requestList = new ArrayList<Request>();
			requestList.add(tempRequest);
			requestMapByItemId.put(itemid, requestList);
		}

		planStrategy.setPlanId(planId);
		planStrategy.setStrategyLoad(Integer.parseInt(THREADNUM));
		planStrategy.setStrategyName("StrategyName" + name);
		planStrategy.setLoopCount(Integer.parseInt(RUNCOUNT));
		planStrategyDao.addPlanStrategy(planStrategy);

		String StrategyName = planStrategy.getStrategyName();

		JobData jobData = setJobData(summaryId, configTempPath, requestURL.get(0), username, password, configZipPath, TestType.New, "true",threadNum, runCount,thinkTime,user);

		Date date = null;
		try
		{
			date = getStartTime();
		}
		catch (ParseException e)
		{
			logger.error(e.getMessage(), e);
			updateStatusException(tempTestBrief);
			testError.setBriefId(tempTestBrief.getBriefId());
			testError.setErrorType(INSIDE);
			testError.setErrorMessage(e.getMessage());
			testError.setErrorName(e.getClass().getName());
			testErrorDao.addTestError(testError);
			throw new ParseException(e.getMessage(), e.getErrorOffset());
		}
		runtime.setStrategyId(planStrategyDao.getPlanStrategyByName(StrategyName).getStrategyId());
		runtime.setIntervalTime(0);
		runtime.setStartTime(new Timestamp(date.getTime()));
		String runtimeUUID = UUID.randomUUID().toString();
		runtime.setRuntimeUUID(runtimeUUID);
		runtimeDao.addRuntime(runtime);
		int runtimeId = runtimeDao.getRuntimeByUUID(runtimeUUID).getRuntimeId();
		TestBeanCollection collection = setTestBeanCollection(project, system, itemList, requestMapByItemId, tempTestBrief,
				tempPlan, user,ciConfig);

		runtimeTrigger.setRuntimeId(runtimeId);
		ScheduleData scheduleData = setScheduleData(date, tempTestBrief, collection, jobData,runtimeTrigger);
		logger.info("Set the schedule job data with summaryId[" + summaryId + "]");
		// scheduleData.setTestBeanCollection(collection);
		// add a new runtime to quartz
		logger.info("Trigger new quartz job...");

		QuartzManager quartzManager = QuartzManager.getQuartzManager();
		runtimeTrigger = quartzManager.addNewRuntime(scheduleData);
		runtimeTriggerDao.addRuntimeTrigger(runtimeTrigger);
		// errorPage = checkAndSchedule(requestURL.get(0),
		// username,password,testError,scheduleData,tempTestBrief);
		return errorPage;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public TestType CheckPorjectSystem(Project dbproject, System dbsystem, String MD5, String filepath)
	{

		MD5Util md5 = new MD5Util();
		Plan tempPlan = new Plan();
		tempPlan.setSystemId(dbsystem.getSystemId());
		Plan plan = null;
		List<Plan> planList = planDao.getPlanBySystemId(tempPlan.getSystemId());
		if (planList.size() != 0)
		{
			plan = planList.get(0);
		}
		logger.debug("MD5:" + MD5);
		logger.debug("md5.fileMD5CheckSum(filepath):" + md5.fileMD5CheckSum(filepath));
		if (dbproject == null || dbsystem ==null)
		{
			return TestType.Exception;

		}
		else if (md5.fileMD5CheckSum(filepath).equals(MD5))
		{
			return TestType.Remain;

		}
		else if (plan == null)
		{

			return TestType.New;

		}
		else
		{
			return TestType.Update;
		}

	}

	private Date getStartTime() throws ParseException
	{
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = dateformat.format(new Date(java.lang.System.currentTimeMillis() + Integer.parseInt(DELAY_TIME)));
		Date startTime = null;
		try
		{
			startTime = dateformat.parse(time);
		}
		catch (ParseException e)
		{
			logger.error(e.getMessage(), e);
			throw new ParseException(e.getMessage(), e.getErrorOffset());
		}
		return startTime;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public String Execute(String configTempPath, TestBrief testBrief, User user, System system, Plan plan, Project project,
			String configZipPath, String summaryId, TestError testError,CIConfig ciConfig,RuntimeTrigger runtimeTrigger) throws Exception
	{
		
		String errorPage = null;
		if(!checkConfigFileVaild(configTempPath))
			return "../Error/configZipError.jsp";
			// User user = userDao.getUserByName(tempUser.getUserName());
		logger.debug("login user id :" + user.getUserId());
		ReadXMLUtil xmlReader = new ReadXMLUtil();

		List<String> requestURL = xmlReader.getRequestURL(configTempPath);
		List<String> threadNumList = xmlReader.getThreadNum(configTempPath);
		List<String> runCountList = xmlReader.getRunCount(configTempPath);
		List<String> thinktimeList = xmlReader.getThinkTime(configTempPath);
		
		String threadNum = FilePathConstants.THREADNUM;
		String runCount = FilePathConstants.RUNCOUNT;
		String thinkTime = FilePathConstants.THINKTIME;
		if(threadNumList.size() != 0)
			threadNum = threadNumList.get(0);
		if(runCountList.size() != 0)
			runCount = runCountList.get(0);
		if(thinktimeList.size() != 0)
			thinkTime = thinktimeList.get(0);
		
		String url = requestURL.get(0);

		String userDat = configTempPath + "/user.csv";
		File userFile = new File(userDat);
		List<String[]> lines = null;
		try
		{
			lines = CSVReader.getInstance().getCSVLines(userFile);
		}
		catch (IOException e)
		{
			logger.error(e.getMessage(), e);
			throw new IOException(e.getMessage(), e);
		}
		String username = null;
		String password = null;
		if(lines.size() != 0)
		{
		username = lines.get(0)[0];
		password = lines.get(0)[1];
		}

		errorPage = CloudSignOn.getInstance().checkServer(url, username, password);
		if (errorPage != null)
			return errorPage;
		
		ciConfig = ciConfigDao.getCIConfigBySystemuuid(system.getSystemuuid());
		Plan p = plan;
		p.setSystemId(system.getSystemId());
		Plan tempPlan = planDao.getPlanBySystemId(p.getSystemId()).get(0);

		TestBrief tempTestBrief = addAndGetTestBrief(testBrief, user, tempPlan, summaryId);

		List<Item> itemList = new ArrayList<Item>();
		Map<Integer, List<Request>> requestMapByItemId = new HashMap<Integer, List<Request>>();
		List<PlanItem> AvailablePlanItem = planItemDao.getAllPlanItemByPlanId(tempPlan.getPlanId());
		for (int i = 0; i < AvailablePlanItem.size(); i++)
		{
			itemList.add(itemDao.getItemById(AvailablePlanItem.get(i).getItemId()));
			requestMapByItemId.put(AvailablePlanItem.get(i).getItemId(),
					requestDao.getRequestsByItemId(AvailablePlanItem.get(i).getItemId()));
		}
		TestBeanCollection collection = setTestBeanCollection(project, system, itemList, requestMapByItemId, tempTestBrief,
				tempPlan, user,ciConfig);

		JobData jobdata = setJobData(summaryId, configTempPath, requestURL.get(0), username, password, configZipPath, TestType.Remain, "true",threadNum, runCount,thinkTime,user);

		Date date = null;
		try
		{
			date = getStartTime();
		}
		catch (ParseException e)
		{
			logger.error(e.getMessage(), e);
			updateStatusException(tempTestBrief);
			testError.setBriefId(tempTestBrief.getBriefId());
			testError.setErrorType(INSIDE);
			testError.setErrorMessage(e.getMessage());
			testError.setErrorName(e.getClass().getName());
			testErrorDao.addTestError(testError);
			throw new ParseException(e.getMessage(), e.getErrorOffset());
		}
		
		int planId = tempPlan.getPlanId();
		List<PlanStrategy> strategyList = planStrategyDao.getPlanStrategyByPlanId(planId);
		List<Runtime> runtimeList = runtimeDao.getRuntimeByStrategyId(strategyList.get(0).getStrategyId());
		Runtime runtime = runtimeList.get(0);
		runtime.setStartTime(new Timestamp(date.getTime()));
		boolean isUpdated = runtimeDao.updateRuntime(runtime);
		runtimeTrigger.setRuntimeId(runtime.getRuntimeId());
		ScheduleData scheduleData = setScheduleData(date, tempTestBrief, collection, jobdata,runtimeTrigger);

		QuartzManager quartzManager = QuartzManager.getQuartzManager();
		runtimeTrigger = quartzManager.addNewRuntime(scheduleData);
		runtimeTriggerDao.updateRuntimeTrigger(runtimeTrigger);
		return errorPage;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public String update(Project project, System system, Item item, Request request, Plan plan, User user, PlanItem planItem,
			String configTempPath, PlanStrategy planStrategy, Runtime runtime, TestBrief testBrief, String configZipPath,
			String summaryId, TestError testError, CIConfig ciConfig,RuntimeTrigger runtimeTrigger) throws Exception
	{
		String errorPage = null;
		if(!checkConfigFileVaild(configTempPath))
			return "../Error/configZipError.jsp";
		
		ReadXMLUtil xmlReader = new ReadXMLUtil();

		long name = java.lang.System.currentTimeMillis();
		List<Item> itemList = new ArrayList<Item>();
		Map<Integer, List<Request>> requestMapByItemId = new HashMap<Integer, List<Request>>();
		List<String> requestURL = xmlReader.getRequestURL(configTempPath);
		String url = requestURL.get(0);
		List<String> appcode = xmlReader.getAppcode(configTempPath);
		List<String> requestName = xmlReader.getRequestName(configTempPath);
		List<String> threadNumList = xmlReader.getThreadNum(configTempPath);
		List<String> runCountList = xmlReader.getRunCount(configTempPath);
		List<String> thinktimeList = xmlReader.getThinkTime(configTempPath);
		
		String threadNum = FilePathConstants.THREADNUM;
		String runCount = FilePathConstants.RUNCOUNT;
		String thinkTime = FilePathConstants.THINKTIME;
		if(threadNumList.size() != 0)
			threadNum = threadNumList.get(0);
		if(runCountList.size() != 0)
			runCount = runCountList.get(0);
		if(thinktimeList.size() != 0)
			thinkTime = thinktimeList.get(0);
		
		String userDat = configTempPath + "/user.csv";
		File userFile = new File(userDat);
		List<String[]> lines = null;
		try
		{
			lines = CSVReader.getInstance().getCSVLines(userFile);
		}
		catch (IOException e)
		{
			logger.error(e.getMessage(), e);
			throw new IOException(e.getMessage(), e);
		}
		String username = null;
		String password = null;
		if(lines.size() != 0)
		{
		username = lines.get(0)[0];
		password = lines.get(0)[1];
		}

		errorPage = CloudSignOn.getInstance().checkServer(url, username, password);
		if (errorPage != null)
			return errorPage;

		//update CIConfig
		
		CIConfig cinfigBySysUUID = ciConfigDao.getCIConfigBySystemuuid(system.getSystemuuid());
		MD5Util md5Util = new MD5Util();
		String md5Num = md5Util.fileMD5CheckSum(configZipPath);
		File configZipFile = new File(configZipPath);
		byte[] zipByte = new byte[(int) configZipFile.length()];
		FileInputStream zipIn = new FileInputStream(configZipFile);
		zipIn.read(zipByte);
		if(zipIn != null)
			zipIn.close();
		if(cinfigBySysUUID != null)
		{
			ciConfig = cinfigBySysUUID;
    		ciConfig.setConfigFileMd5(md5Num);
    		ciConfig.setConfigFile(zipByte);
    		ciConfig.setConfigName(configZipFile.getName());
    		ciConfig.setCreatedBy(user.getUserId());
    		ciConfig.setSummaryId(summaryId);
    		ciConfigDao.updateCIConfig(ciConfig);
		}
		else{
			ciConfig.setConfigFileMd5(md5Num);
			ciConfig.setConfigFile(zipByte);
			ciConfig.setConfigName(configZipFile.getName());
			ciConfig.setCreatedBy(user.getUserId());
			ciConfig.setSummaryId(summaryId);
			ciConfigDao.addCIConfig(ciConfig);
			ciConfig = ciConfigDao.getCIConfig(ciConfig);
		}
		
		plan.setSystemId(system.getSystemId());
		Plan tempPlan1 = planDao.getPlanBySystemId(plan.getSystemId()).get(0);
		TestBrief tempTestBrief = addAndGetTestBrief(testBrief, user, tempPlan1, summaryId);

		List<PlanItem> relationListPlanItem = planItemDao.getAllPlanItemByPlanId(tempPlan1.getPlanId());
		List<Item> DBItemlist = new ArrayList<Item>();
		for (PlanItem relation : relationListPlanItem)
		{
			DBItemlist.add(itemDao.getItemById(relation.getItemId()));
		}
		List<String> DBItemNamelist = new ArrayList<String>();
		for (int i = 0; i < DBItemlist.size(); i++)
		{
			DBItemNamelist.add(DBItemlist.get(i).getItemName());
		}
		for (int j = 0; j < requestName.size(); j++)
		{
			if (!DBItemNamelist.contains(requestName.get(j)))
			{
				item.setItemName(requestName.get(j));
				item.setSystemId(system.getSystemId());
				item.setDeleted(false);
				itemDao.addItem(item);
				Item tempItem = itemDao.getItemBySystemIdItemName(item);
				logger.info("[" + summaryId + "] Add new item with itemId:[" + tempItem.getItemId() + "] itemName:["
						+ tempItem.getItemName() + "]");
				int itemid = tempItem.getItemId();

				request.setRequestUrl(requestURL.get(0));
				request.setRequestName(requestName.get(j));
				request.setItemName(requestName.get(j));
				request.setItemId(itemid);
				request.setPlanId(tempPlan1.getPlanId());
				requestDao.addRequest(request);
				logger.info("[" + summaryId + "] Add new request with requestName:[" + request.getRequestName() + "]");

				planItem.setItemId(itemid);
				planItem.setItemName(requestName.get(j));
				planItem.setPlanId(tempPlan1.getPlanId());
				planItem.setPlanName("planName" + name);
				planItem.setItemIsValid(true);
				planItemDao.addPlanItem(planItem);
			}
			else{
				Request requestByName = requestDao.getRequestByRequestName(requestName.get(j));
				if(!requestByName.getRequestUrl().equals(url))
				{
					requestByName.setRequestUrl(url);
					requestDao.updateRequest(requestByName);
				}
			}
		}

		for (int j = 0; j < DBItemlist.size(); j++)
		{
			if (!requestName.contains(DBItemlist.get(j).getItemName()))
			{
				PlanItem planitem = planItemDao.getPlanItemByItemId(DBItemlist.get(j).getItemId());
				planitem.setItemIsValid(false);
				planItemDao.updatePlanItem(planitem);
				logger.info("[" + summaryId + "] update item status with itemName:[" + DBItemlist.get(j).getItemName() + "]");
			}
			else if (!planItemDao.getPlanItemByItemId(DBItemlist.get(j).getItemId()).isItemIsValid())
			{
				PlanItem planitem = planItemDao.getPlanItemByItemId(DBItemlist.get(j).getItemId());
				planitem.setItemIsValid(true);
				planItemDao.updatePlanItem(planitem);
				logger.info("[" + summaryId + "] update item status with itemName:[" + DBItemlist.get(j).getItemName() + "]");
			}
		}

		List<PlanItem> AvailablePlanItem = planItemDao.getvalidPlanItemByPlanId(tempPlan1.getPlanId());
		for (int i = 0; i < AvailablePlanItem.size(); i++)
		{
			itemList.add(itemDao.getItemById(AvailablePlanItem.get(i).getItemId()));
			requestMapByItemId.put(AvailablePlanItem.get(i).getItemId(),
					requestDao.getRequestsByItemId(AvailablePlanItem.get(i).getItemId()));
		}
		TestBeanCollection collection = setTestBeanCollection(project, system, itemList, requestMapByItemId, tempTestBrief,
				tempPlan1, user,ciConfig);

		JobData jobdata = setJobData(summaryId, configTempPath, requestURL.get(0), username, password, configZipPath, TestType.Update, "true",threadNum,runCount,thinkTime,user);

		Date date = null;
		try
		{
			date = getStartTime();
		}
		catch (ParseException e)
		{
			logger.error(e.getMessage(), e);
			updateStatusException(tempTestBrief);
			testError.setBriefId(tempTestBrief.getBriefId());
			testError.setErrorType(INSIDE);
			testError.setErrorMessage(e.getMessage());
			testError.setErrorName(e.getClass().getName());
			testErrorDao.addTestError(testError);
			throw new ParseException(e.getMessage(), e.getErrorOffset());
		}
		
		int planId = tempPlan1.getPlanId();
		List<PlanStrategy> strategyList = planStrategyDao.getPlanStrategyByPlanId(planId);
		if(strategyList.size() != 0)
		{
			planStrategy = strategyList.get(0);
    		List<Runtime> runtimeList = runtimeDao.getRuntimeByStrategyId(planStrategy.getStrategyId());
    		if(runtimeList.size() !=0)
    		{
    			runtime = runtimeList.get(0);
    			runtime.setStartTime(new Timestamp(date.getTime()));
    			runtimeDao.updateRuntime(runtime);
    			runtimeTrigger.setRuntimeId(runtime.getRuntimeId());
    			ScheduleData scheduleData = setScheduleData(date, tempTestBrief, collection, jobdata, runtimeTrigger);
    			
    			QuartzManager quartzManager = QuartzManager.getQuartzManager();
    			runtimeTrigger = quartzManager.addNewRuntime(scheduleData);
    			
    			runtimeTriggerDao.updateRuntimeTrigger(runtimeTrigger);
    		}
    		else
    		{
    			String StrategyName = planStrategy.getStrategyName();
    			runtime.setStrategyId(planStrategyDao.getPlanStrategyByName(StrategyName).getStrategyId());
    			runtime.setIntervalTime(0);
    			runtime.setStartTime(new Timestamp(date.getTime()));
    			String runtimeUUID = UUID.randomUUID().toString();
    			runtime.setRuntimeUUID(runtimeUUID);
    			runtimeDao.addRuntime(runtime);
    			
    			int runtimeId = runtimeDao.getRuntimeByUUID(runtimeUUID).getRuntimeId();
    			runtimeTrigger.setRuntimeId(runtimeId);
    			ScheduleData scheduleData = setScheduleData(date, tempTestBrief, collection, jobdata, runtimeTrigger);
    			
    			QuartzManager quartzManager = QuartzManager.getQuartzManager();
    			runtimeTrigger = quartzManager.addNewRuntime(scheduleData);
    		}
		}
		else{
			planStrategy.setPlanId(planId);
			planStrategy.setStrategyLoad(Integer.parseInt(THREADNUM));
			planStrategy.setStrategyName("StrategyName" + name);
			planStrategy.setLoopCount(Integer.parseInt(RUNCOUNT));
			planStrategyDao.addPlanStrategy(planStrategy);
			
			String StrategyName = planStrategy.getStrategyName();
			runtime.setStrategyId(planStrategyDao.getPlanStrategyByName(StrategyName).getStrategyId());
			runtime.setIntervalTime(0);
			runtime.setStartTime(new Timestamp(date.getTime()));
			String runtimeUUID = UUID.randomUUID().toString();
			runtime.setRuntimeUUID(runtimeUUID);
			runtimeDao.addRuntime(runtime);
			
			int runtimeId = runtimeDao.getRuntimeByUUID(runtimeUUID).getRuntimeId();
			runtimeTrigger.setRuntimeId(runtimeId);
			ScheduleData scheduleData = setScheduleData(date, tempTestBrief, collection, jobdata, runtimeTrigger);
			
			QuartzManager quartzManager = QuartzManager.getQuartzManager();
			runtimeTrigger = quartzManager.addNewRuntime(scheduleData);
		}
		// errorPage = checkAndSchedule(requestURL.get(0),
		// username,password,testError,scheduleData,tempTestBrief);

		return errorPage;
	}

	private TestBeanCollection setTestBeanCollection(Project project, System system, List<Item> itemList,
			Map<Integer, List<Request>> requestMapByItemId, TestBrief testBrief, Plan plan, User user, CIConfig ciConfig)
	{
		TestBeanCollection collection = new TestBeanCollection();
		collection.setProject(project);
		collection.setSystem(system);
		collection.setItemList(itemList);
		collection.setRequestMapByItemId(requestMapByItemId);
		collection.setTestBrief(testBrief);
		collection.setPlan(plan);
		collection.setCiConfig(ciConfig);
		return collection;
	}

	private TestBrief addAndGetTestBrief(TestBrief testBrief, User user, Plan plan, String summaryId)
	{
		testBrief.setAutomated(false);
		logger.debug(user);
		testBrief.setExecutorId(user.getUserId());
		testBrief.setExecutorName(user.getUserName());
		logger.debug(plan);
		testBrief.setPlanId(plan.getPlanId());
		testBrief.setPlanName(plan.getPlanName());
		testBrief.setStatus(PREPARERUN);
		// testBrief.setSummaryId(Integer.parseInt(summaryId.get(0)));
		testBrief.setSummaryId(summaryId);
		logger.debug(testBrief);
		boolean briefInsertSucce = testBriefDao.addTestBrief(testBrief);
		logger.debug("test brief insert successfully: " + briefInsertSucce);
		TestBrief tempTestBrief = testBriefDao.getTestBrief(testBrief);
		logger.debug("testBreif :" + tempTestBrief);
		return tempTestBrief;
	}

	private JobData setJobData(String summaryId, String configTempPath, String url, String username, String password,
			String configZipPath, TestType status,String needLogin, String threadNum, String runCount, String thinkTime, User user)
	{
		JobData jobData = new JobData();
		jobData.setConfigPath(configTempPath);
		jobData.setSummaryId(summaryId);
		jobData.setConfigZipPath(configZipPath);
		jobData.setAsset(new File(configZipPath).getParent() + File.separator + ASSETTMEPPATH + "_" + summaryId);
		jobData.setOutput(CIOUTPUTTEMPPATH + "_" + summaryId);
		jobData.setNeedLogin(needLogin);
		jobData.setUrl(url);
		jobData.setUsername(username);
		jobData.setPassword(password);
		jobData.setDebug(CIDEBU);
		jobData.setIsServiceRequest("true");
		jobData.setConfigStatus(status);
		jobData.setUser(user);
		jobData.setThreadsNum(threadNum);
		jobData.setRunCount(runCount);
		jobData.setThinkTime(thinkTime);
		return jobData;
	}

	private ScheduleData setScheduleData(Date date, TestBrief testBrief, TestBeanCollection collection, JobData jobdata, RuntimeTrigger runtimeTrigger)
			throws ParseException
	{
		ScheduleData scheduleData = new ScheduleData();
		scheduleData.setStartTime(date);
		scheduleData.setData(jobdata);
		scheduleData.setRepeatTime(0);
		scheduleData.setServiceCall(true);
		scheduleData.setTestBeanCollection(collection);
		scheduleData.setStartNow(false);
		scheduleData.setRuntimeTrigger(runtimeTrigger);
		return scheduleData;
	}

	
	private TestBrief updateStatusException(TestBrief testBrief) throws Exception
	{
		 testBrief.setStatus(TESTEXCEPTION);
		 try
		{
			testBriefDao.updateTestBriefStatus(testBrief);
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(),e);
			TestError testError = new TestError();
			testError.setBriefId(testBrief.getBriefId());
			testError.setErrorType(INSIDE);
			testError.setErrorMessage(e.getMessage());
			testError.setErrorName(e.getClass().getName());
			testErrorDao.addTestError(testError);
			throw new Exception(e.getMessage(), e);
		}
		 return testBrief;
	}
	
	private boolean checkConfigFileVaild(String configPath)
	{
		boolean isVaild = false;
		File configParamFile = new File(configPath, "performanceTestParam.xml");
		File userFile = new File(configPath, "user.csv");
		if(configParamFile.exists() && userFile.exists())
		{
			isVaild = true;
		}
		
		return isVaild;
	}
}
