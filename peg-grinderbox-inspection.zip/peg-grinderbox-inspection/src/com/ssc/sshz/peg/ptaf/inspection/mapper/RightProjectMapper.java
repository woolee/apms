package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.RightProject;

public interface RightProjectMapper extends SqlMapper
{
	public void addRightProject(RightProject rightProject);
	public RightProject getRightProjectByRightId(int rightId);
	public RightProject getRightProjectByRightName(String rightName);
	public List<RightProject> getALLRightProject();
	public List<RightProject> getRightProjectByUserId(int userId);
}
