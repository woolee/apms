package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestStatisticsDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RequestStatisticsMapper;

@Repository
//@Named
public class RequestStatisticsDaoImpl<T extends RequestStatistics> implements RequestStatisticsDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RequestStatisticsMapper mapper;

	@Override
	public boolean addRequestStatistics(T entity)
	{
		boolean flag = false;
		try{
			mapper.addRequestStatistics(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while add RequestStatistics to database",e);
			throw new DaoException("Exception while add RequestStatistics to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllRequestStatistics()
	{
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllRequestStatistics();
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all RequestStatistics from database",e);
			throw new DaoException("Exception while get all RequestStatistics from database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getRequestStatistics(T entity)
	{
		T obj = null;
		try{ 
			obj = (T) mapper.getRequestStitistics(entity);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get RequestStatistics from database",e);
			throw new DaoException("Exception while get RequestStatistics from database",e);
		}
		return obj;
	}

	@Override
	public boolean updateRequesttatistics(T entity)
	{
		boolean flag = false;
		try{
			mapper.updateRequestStitistics(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while update Requesttatistics to database",e);
			throw new DaoException("Exception while update Requesttatistics to database",e);
		}
		return flag;
	}

	@Override
	public List<T> getAllRequestStatisticsByItemId(int itemId)
			throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllRequestStatisticsByItemId(itemId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all RequestStatistics from database",e);
			throw new DaoException("Exception while get all RequestStatistics from database",e);
		}
		return entity;
	}

	@Override
	public List<T> getAllRequestStatisticsByBriefId(int briefId)
			throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllRequestStatisticsByBriefId(briefId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all RequestStatistics from database",e);
			throw new DaoException("Exception while get all RequestStatistics from database",e);
		}
		return entity;
	}

	@Override
	public List<T> getAllRequestStatisticsByItemIdAndBriefId(T entity)
			throws DataAccessException {
		List<T> obj = null;
		try{ 
			obj = (List<T>) mapper.getAllRequestStatisticsByItemIdAndBriefId(entity);
			}
		catch(Exception e)
		{
			logger.error("Exception while get getAllRequestStatisticsByItemIdAndBriefId from database",e);
			throw new DaoException("Exception while get getAllRequestStatisticsByItemIdAndBriefId from database",e);
		}
		return obj;
	}


}
