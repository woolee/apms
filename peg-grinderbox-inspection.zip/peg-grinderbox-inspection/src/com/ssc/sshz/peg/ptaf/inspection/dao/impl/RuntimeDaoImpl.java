package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RuntimeMapper;

@Repository
public class RuntimeDaoImpl<T extends Runtime> implements RuntimeDao<T>{

	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RuntimeMapper mapper;

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllRuntime() throws DataAccessException {
		List<T> allRuntimeList=null;
		try{ 
			allRuntimeList =(List<T>) mapper.getAllRuntime();
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all runtime from database",e);
			throw new DaoException("Exception while get all runtime from database",e);
		}
		return allRuntimeList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getRuntimeById(Integer id) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getRuntimeById(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get runtime by id from database",e);
			throw new DaoException("Exception while get runtime by id from database",e);
		}
		return entity;
	}

	@Override
	public boolean addRuntime(T entity) throws DataAccessException {
		boolean flag = false;
		try {
			mapper.addRuntime(entity); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while add runtime to database",e);
			throw new DaoException("Exception while add runtime to database",e);
		}
		return flag;
	}

	@Override
	public boolean delRuntimeById(Integer id) throws DataAccessException {

		boolean flag = false;
		try {
			mapper.delRuntimeById(id);
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while delete runtime by id  to database",e);
			throw new DaoException("Exception while delete runtime by id  to database",e);
		}
		return flag;
	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getRuntimeByStrategyId(Integer id) throws DataAccessException
	{
		List<T> allRuntimeList=null;
		try{ 
			allRuntimeList =(List<T>) mapper.getRuntimeByStrategyId(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all runtime by strategy id from database",e);
			throw new DaoException("Exception while get all runtime by strategy id from database",e);
		}
		return allRuntimeList;
	}

	@Override
	public boolean updateRuntime(T entity) throws DataAccessException
	{
		boolean flag = false;
		try{
			mapper.updateRuntime(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while update runtime to database",e);
			throw new DaoException("Exception while update runtime to database",e);
		}
		return flag;
	}

	@Override
	public T getRuntimeByPlanId(Integer planid) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getRuntimeByPlanId(planid);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get runtime by planid from database",e);
			throw new DaoException("Exception while get runtime by planid from database",e);
		}
		return entity;
	}

	@Override
	public T getRuntime(T entity) throws DataAccessException
	{
		T obj = null;
		try{ 
			obj = (T) mapper.getRuntime(entity);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get runtime from database",e);
			throw new DaoException("Exception while get runtime from database",e);
		}
		return obj;
	}

	@Override
	public T getRuntimeByUUID(String uuid) throws DataAccessException
	{
		T entity = null;
		try{ 
			entity = (T) mapper.getRuntimeByUUID(uuid);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get runtime by uuid from database",e);
			throw new DaoException("Exception while get runtime by uuid from database",e);
		}
		return entity;
	}



	

}
