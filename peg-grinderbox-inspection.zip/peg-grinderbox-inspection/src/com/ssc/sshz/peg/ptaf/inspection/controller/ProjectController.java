package com.ssc.sshz.peg.ptaf.inspection.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.BriefOverview;
import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.ResultSearchBean;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.ItemDetail;
import com.ssc.sshz.peg.ptaf.inspection.bean.ItemStatistics;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestDetail;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;
import com.ssc.sshz.peg.ptaf.inspection.bean.Requirement;
import com.ssc.sshz.peg.ptaf.inspection.bean.Right;
import com.ssc.sshz.peg.ptaf.inspection.bean.RightProject;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.bean.UserRight;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.SubmitResultService;
import com.ssc.sshz.peg.ptaf.inspection.service.ItemDetailService;
import com.ssc.sshz.peg.ptaf.inspection.service.ItemStatisticsService;
import com.ssc.sshz.peg.ptaf.inspection.service.ProjectService;
import com.ssc.sshz.peg.ptaf.inspection.service.RequestDetaillService;
import com.ssc.sshz.peg.ptaf.inspection.service.RequestStatisticsService;
import com.ssc.sshz.peg.ptaf.inspection.service.RequirementService;
import com.ssc.sshz.peg.ptaf.inspection.service.ResultSearchService;
import com.ssc.sshz.peg.ptaf.inspection.service.RightProjectService;
import com.ssc.sshz.peg.ptaf.inspection.service.SystemService;
import com.ssc.sshz.peg.ptaf.inspection.service.TestBriefOverviewService;
import com.ssc.sshz.peg.ptaf.inspection.service.TestBriefService;
import com.ssc.sshz.peg.ptaf.inspection.service.TestErrorService;
import com.ssc.sshz.peg.ptaf.inspection.service.UserRightService;
import com.ssc.sshz.peg.ptaf.inspection.service.UserService;

@Controller
@RequestMapping("/project")
public class ProjectController {
	private static final Logger logger = Logger.getLogger(PlanController.class);

	@Inject
	private ProjectService<Project> projectService;

	@Inject
	private TestBriefService<TestBrief> testBriefService;

	@Inject
	private ItemDetailService<ItemDetail> itemDetailService;

	@Inject
	private ItemStatisticsService<ItemStatistics> itemStatistService;

	@Inject
	private SystemService<System> systemService;

	@Inject
	private RequestStatisticsService<RequestStatistics> requestStatisticsService;

	@Inject
	private RequestDetaillService<RequestDetail> requestDetailService;

	@Inject
	private TestErrorService<TestError> testErrorService;

	@Inject
	private ResultSearchService testBriefSearchService;

	@Inject
	private TestBriefOverviewService testBriefOverviewService;

	// @Inject
	// private UserGroupService<UserGroup> userGroupService;

	@Inject
	private UserRightService<UserRight> userRightService;
	
	@Inject
	private RequirementService<Requirement> requirementService;

	@Inject
	private RightProjectService<RightProject> rightProjectService;

	@Inject
	private UserService<User> userService;

	@RequestMapping("/CreateProject")
	public String createProject(Project project, HttpSession httpSession,
			Model model, Right right, UserRight userRight,
			RightProject rightProject) {
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		String username = auth.getName();
		projectService.addProjectByUserName(username, project);
		/*
		 * String projectName = project.getProjectName(); String groupName =
		 * projectName + GROUP_NAME_POSTFIX; group.setGroupName(groupName);
		 * groupService.addGroup(group); right.setRightName(groupName);
		 * rightService.addRight(right);
		 * groupRight.setGroupId(group.getGroupId());
		 * groupRight.setGroupName(groupName);
		 * groupRight.setRightId(right.getRightId());
		 * groupRight.setRightName(right.getRightName());
		 * groupRightService.addGroupRight(groupRight);
		 */

		// project.setProjectCreatorId(userService.getUserByName(name).getUserId());
		// project.setProjectCreatorName(name);
		// projectService.addProject(project);

		// userGroupService.addGroupAndUserGroup(userGroup, group, right,
		// groupRight, username, project.getProjectName());
		userRightService.addRightAndUserRight(userRight, right, userRight,
				rightProject, username, project.getProjectName());
		List<Project> projectList = new ArrayList<Project>();
		projectList.add(project);
		model.addAttribute("projects", projectList);
		httpSession
				.setAttribute("CurrentUserID", project.getProjectCreatorId());
		return "../plan/projectPageInit.do";
	}

	@RequestMapping("/manageCreateProject")
	public String manageCreateProject(Project project, HttpSession httpSession,
			Model model, Right right, RightProject rightProject,
			UserRight userRight) {
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		String username = auth.getName();
		/*
		 * project.setProjectCreatorId(userService.getUserByName(name).getUserId(
		 * )); project.setProjectCreatorName(name);
		 * projectService.addProject(project);
		 */
		projectService.addProjectByUserName(username, project);
		userRightService.addRightAndUserRight(userRight, right, userRight,
				rightProject, username, project.getProjectName());
		// userGroupService.addGroupAndUserGroup(userGroup, group, right,
		// groupRight, username, project.getProjectName());
		List<Project> projectList = new ArrayList<Project>();
		projectList.add(project);
		model.addAttribute("projects", projectList);
		httpSession
				.setAttribute("CurrentUserID", project.getProjectCreatorId());
		return "../project/manageProjectPageInit.do";
	}

	@RequestMapping("/ManagerdeleteProject")
	public String managerdeleteProject(Project project,
			HttpSession httpSession, Model model) {
		projectService.delProject(project);
		return "../project/manageProjectPageInit.do";
	}

	@RequestMapping("/showHistory")
	public String showHistory(ItemStatistics itemStatistics,
			HttpSession httpSession, Model model) {
		List<ItemStatistics> itemStatisticsList = itemStatistService
				.getItemStitisticsByPlanIdAndItemId(itemStatistics);
		model.addAttribute("HisitemStatisticsList", itemStatisticsList);
		return "../view/showHistory.jsp";
	}

	@RequestMapping("/showSystemError")
	public String showSystemError(TestBrief testBrief, HttpSession httpSession,
			Model model) {
		List<TestError> testErrorList = testErrorService
				.getTestErrorByBriefId(testBrief.getBriefId());
		model.addAttribute("testErrorList", testErrorList);
		return "../view/showSystemError.jsp";
	}

	@RequestMapping("/projectPageInit")
	public String inint(Model model) {
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		// List<? extends GrantedAuthority> groupList =
		// (List)auth.getAuthorities();
		// List<Project> projectList =
		// projectService.getProjectByGroup(groupList);
		List<Project> projectList = projectService.getProjectByRight(auth
				.getName());
		// String name = auth.getName();
		// List<Project> projectList =
		// projectService.getAllProjectByUserName(name);
		model.addAttribute("projects", projectList);
		return "/page/createProject.jsp";
	}

	@RequestMapping("/manageProjectPageInit")
	public String inintManagePage(Model model) {
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		List<Project> projectList = projectService.getProjectByRight(auth
				.getName());
		model.addAttribute("projects", projectList);
		return "/view/manageProject.jsp";
	}

	@RequestMapping("/homepageInit")
	public String homepageInit(Model model, RequestDetail requestDetail,
			ItemDetail itemDetail) {
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		List<TestBrief> temptb = testBriefService.getTestBriefByRight(auth
				.getName());
		// List<TestBrief> temptb =
		// testBriefService.getTestBriefByGroup(groupList);
		// List<TestBrief> temptb =
		// testBriefService.getLatestTestBriefByExecutorId(u.getUserId());
		if (temptb.size() == 0) {
			model.addAttribute("TestBriefSize",temptb.size());
			return "/view/homepage.jsp";
		}
		TestBrief testBrief = temptb.get(0);
		SubmitResultService submitResultService = new SubmitResultService();
		Map<String, String> returnStatistics = submitResultService
				.getReturnStatistics(testBrief.getBriefId());

		Date testStartTime = testBrief.getStartTime();
		Date testEndTime = testBrief.getEndTime();
		System sys = systemService.getSystemByPlanId(testBrief.getPlanId());
		List<ItemStatistics> itemStatisticsList = itemStatistService
				.getItemStitisticsByBriefId(testBrief.getBriefId());
		List<RequestStatistics> requestStatistList = requestStatisticsService
				.getAllRequestStatisticsByBriefId(testBrief.getBriefId());
		/*java.lang.System.out.println(GetresponsetimeString(itemDetail,
				itemStatisticsList));*/
		if (requestStatistList.size() == 0) {
			logger.debug("requestStatistList is null");
			model.addAttribute("testBrief", testBrief);
			model.addAttribute("Duration", null);
			model.addAttribute("system", sys);
			/*model.addAttribute("ItemNameList",
					"Total,Foreground,Background, '', '', '', '', '','', ''");*/
			// model.addAttribute("date","[[ [ '2014-09-03 16:54:41', 64356.0 ],[ '2014-09-03 16:56:41', 34324.0 ],[ '2014-09-03 16:51:41', 0.0 ],[ '2014-09-03 16:57:02', 31048.0 ],[ '2014-09-03 16:55:41', 37303.0 ],[ '2014-09-03 16:53:41', 62300.0 ],[ '2014-09-03 16:52:41', 31228.0 ], ],[ [ '2014-09-03 16:54:41', 1614.0 ],[ '2014-09-03 16:56:23', 1691.0 ],[ '2014-09-03 16:51:41', 0.0 ],[ '2014-09-03 16:55:41', 2347.0 ],[ '2014-09-03 16:53:41', 714.0 ],[ '2014-09-03 16:52:41', 729.0 ], ],[ [ '2014-09-03 16:55:47', 16526.0 ],[ '2014-09-03 16:52:47', 25387.0 ],[ '2014-09-03 16:57:02', 20857.0 ],[ '2014-09-03 16:54:47', 49774.0 ],[ '2014-09-03 16:53:47', 44511.0 ],[ '2014-09-03 16:56:47', 12667.0 ],[ '2014-09-03 16:51:47', 0.0 ], ]]");
			model.addAttribute("ItemNameList",GetItemNameListString(itemStatisticsList));
			java.lang.System.out.println(GetItemNameListString(itemStatisticsList));
			model.addAttribute("date",
					GetresponsetimeString(itemDetail, itemStatisticsList));
			model.addAttribute("TestBriefSize",temptb.size());
			return "/view/homepage.jsp";
		}
		String durationTime;
		if (testEndTime == null && testStartTime == null) {
			durationTime = null;
		} else {
			durationTime = ((double) (testEndTime.getTime() - testStartTime
					.getTime())) / 1000 + " s";
		}

		Map<Integer, Integer> reCode = requestDetailService
				.getRequestCountByReturnCode(requestStatistList, requestDetail);

		model.addAttribute("reCode", reCode);
		model.addAttribute("returnStatistics", returnStatistics);
		model.addAttribute("testBrief", testBrief);
		model.addAttribute("Duration", durationTime);
		model.addAttribute("system", sys);
		model.addAttribute("ItemStatisticsList", itemStatisticsList);
		/*model.addAttribute("ItemNameList",
				"Total,Foreground,Background, '', '', '', '', '','', ''");
		*/// model.addAttribute("date","[[ [ '2014-09-03 16:54:41', 64356.0 ],[ '2014-09-03 16:56:41', 34324.0 ],[ '2014-09-03 16:51:41', 0.0 ],[ '2014-09-03 16:57:02', 31048.0 ],[ '2014-09-03 16:55:41', 37303.0 ],[ '2014-09-03 16:53:41', 62300.0 ],[ '2014-09-03 16:52:41', 31228.0 ], ],[ [ '2014-09-03 16:54:41', 1614.0 ],[ '2014-09-03 16:56:23', 1691.0 ],[ '2014-09-03 16:51:41', 0.0 ],[ '2014-09-03 16:55:41', 2347.0 ],[ '2014-09-03 16:53:41', 714.0 ],[ '2014-09-03 16:52:41', 729.0 ], ],[ [ '2014-09-03 16:55:47', 16526.0 ],[ '2014-09-03 16:52:47', 25387.0 ],[ '2014-09-03 16:57:02', 20857.0 ],[ '2014-09-03 16:54:47', 49774.0 ],[ '2014-09-03 16:53:47', 44511.0 ],[ '2014-09-03 16:56:47', 12667.0 ],[ '2014-09-03 16:51:47', 0.0 ], ]]");
		model.addAttribute("ItemNameList",GetItemNameListString(itemStatisticsList));
		java.lang.System.out.println(GetItemNameListString(itemStatisticsList));
		model.addAttribute("date",
				GetresponsetimeString(itemDetail, itemStatisticsList));
		model.addAttribute("TestBriefSize",temptb.size());
		model.addAttribute("GetRequirmentMap",GetRequirmentMap(itemStatisticsList));
		return "/view/homepage.jsp";

	}

	@RequestMapping("/resultSearchPageInit")
	public String resultSearchPageInit(Model model, HttpSession httpSession,
			Plan plan) {
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		// String username = auth.getName();
		// List<? extends GrantedAuthority> groupList =
		// (List)auth.getAuthorities();
		// List<Project> projectList =
		// projectService.getProjectByGroup(groupList);
		List<Project> projectList = projectService.getProjectByRight(auth
				.getName());
		List<ResultSearchBean> tbSearchList = testBriefSearchService
				.getResultSearchByProject(projectList, plan);
		Calendar now = Calendar.getInstance();
		String time = now.get(Calendar.MONTH) + 1 + "/"
				+ now.get(Calendar.DAY_OF_MONTH) + "/" + now.get(Calendar.YEAR);
		model.addAttribute("time", time);
		model.addAttribute("vbList", tbSearchList);
		return "/view/resultSearch.jsp";
	}

	@RequestMapping("/SearchBySystem")
	public String searchBySystem(HttpServletRequest httpServletRequest,
			Model model, Plan plan, HttpSession httpSession, TestBrief testBrief)
			throws Exception {
		int planId = Integer.parseInt(httpServletRequest
				.getParameter("selectPlan"));
		String dateFrom = httpServletRequest.getParameter("date_from");
		String dateTo = httpServletRequest.getParameter("date_to");

		List<BriefOverview> briefOverviewList = testBriefOverviewService
				.getBriefOverviewBySearch(testBrief, planId, dateFrom, dateTo);
		model.addAttribute("briefOverviewList", briefOverviewList);
		return "/view/showAjaxTestbrief.jsp";
	}

	@RequestMapping("/ItemPageInit")
	public String itemPageInit(Model model,
			HttpServletRequest httpServletRequest, RequestDetail requestDetail) {
		String briefId = httpServletRequest.getParameter("briefId");
		TestBrief tb = testBriefService.getTestBreifBybreifId(Integer
				.parseInt(briefId));
		if (tb != null) {
			SubmitResultService submitResultService = new SubmitResultService();
			Map<String, String> returnStatistics = submitResultService
					.getReturnStatistics(tb.getBriefId());
			Date testStartTime = tb.getStartTime();
			Date testEndTime = tb.getEndTime();
			System sys = systemService.getSystemByPlanId(tb.getPlanId());
			List<ItemStatistics> itemStatisticsList = itemStatistService
					.getItemStitisticsByBriefId(tb.getBriefId());
			List<RequestStatistics> requestStatistList = requestStatisticsService
					.getAllRequestStatisticsByBriefId(tb.getBriefId());
			String durationTime;
			if (testEndTime == null && testStartTime == null) {
				durationTime = null;
			} else {
				durationTime = ((double) (testEndTime.getTime() - testStartTime
						.getTime())) / 1000 + " s";
			}
			if (requestStatistList.size() == 0) {
				logger.info("requestStatistList is null");
				model.addAttribute("testBrief", tb);
				model.addAttribute("Duration", durationTime);
				model.addAttribute("system", sys);
				return "/view/showTestBrief.jsp";
			}

			Map<Integer, Integer> reCode = requestDetailService
					.getRequestCountByReturnCode(requestStatistList,
							requestDetail);

			model.addAttribute("testBrief", tb);
			model.addAttribute("system", sys);
			model.addAttribute("reCode", reCode);
			model.addAttribute("Duration", durationTime);
			model.addAttribute("returnStatistics", returnStatistics);
			model.addAttribute("ItemStatisticsList", itemStatisticsList);
			return "/view/showTestBrief.jsp";
		} else {
			return "/view/showTestBrief.jsp";
		}

	}

	@RequestMapping("/RequestPageInit")
	public String requestPageInit(HttpServletRequest httpServletRequest,
			Model model, RequestStatistics requestStatistics,
			ItemDetail itemDetail) {
		int itemId = Integer
				.parseInt(httpServletRequest.getParameter("itemId"));
		int briefId = Integer.parseInt(httpServletRequest
				.getParameter("briefId"));

		itemDetail.setBriefId(briefId);
		itemDetail.setItemId(itemId);
		requestStatistics.setBriefId(briefId);
		requestStatistics.setItemId(itemId);
		List<RequestStatistics> requestStatisticsList = requestStatisticsService
				.getAllRequestStatisticsByItemIdAndBriefId(requestStatistics);

		List<ItemDetail> itemDetailList = itemDetailService
				.getAllItemDetailByItemIdAndBriefId(itemDetail);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<String> datelist = new ArrayList<String>();
		for (int i = 0; i < itemDetailList.size(); i++) {
			Date date = itemDetailList.get(i).getStartTime();
			int responseCode = (int) itemDetailList.get(i).getResponseTime();
			datelist.add(sdf.format(date) + "!" + responseCode);
		}
		model.addAttribute("requirement",requirementService.getRequirementByItemId(itemDetail.getItemId()).getAvgResponseTime());
		model.addAttribute("datelist", datelist);
		model.addAttribute("requestStatisticsList", requestStatisticsList);
		return "/view/transRequests.jsp";
	}

	@RequestMapping("/RequestDetilePageInit")
	public String requestDetilePageInit(HttpServletRequest httpServletRequest,
			Model model, RequestDetail requestDetail) {
		int requestId = Integer.parseInt(httpServletRequest
				.getParameter("requestId"));
		int briefId = Integer.parseInt(httpServletRequest
				.getParameter("briefId"));

		requestDetail.setRequestId(requestId);
		requestDetail.setBriefId(briefId);
		List<RequestDetail> requestDetailList = requestDetailService
				.getAllRequestDetailByReuqestIdBriefId(requestDetail);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		List<String> datelist = new ArrayList<String>();
		for (int i = 0; i < requestDetailList.size(); i++) {
			Date date = requestDetailList.get(i).getStartTime();
			int responseCode = requestDetailList.get(i).getResponseTime();
			datelist.add(sdf.format(date) + "!" + responseCode);
		}

		model.addAttribute("datelist", datelist);
		model.addAttribute("requestDetailList", requestDetailList);
		return "/view/requestDetail.jsp";
	}

	@RequestMapping("/GetProject")
	public String getProject(Project project, Model model) throws Exception {
		try {
			model.addAttribute(projectService.getProject(project));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw e;
		}
		return "/view/show.jsp";
	}

	@RequestMapping("/GetErrors")
	public String getErrors(HttpServletRequest httpServletRequest, Model model,
			RequestDetail requestDetail) {

		int briefId = Integer.parseInt(httpServletRequest
				.getParameter("briefId"));
		List<RequestStatistics> requestStatistList = requestStatisticsService
				.getAllRequestStatisticsByBriefId(briefId);

		Map<Integer, Integer> reCode = requestDetailService
				.getRequestCountByReturnCode(requestStatistList, requestDetail);
		logger.error(reCode.toString());
		model.addAttribute("reCode", reCode);
		return "/view/showError.jsp";
	}

	@RequestMapping("/showHomepage")
	public String showHomepage(Model model, RequestDetail requestDetail,
			HttpServletRequest httpServletRequest,ItemDetail itemDetail) {
		int selectnum = Integer.parseInt(httpServletRequest
				.getParameter("selectnum"));
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		// List<? extends GrantedAuthority> groupList =
		// (List)auth.getAuthorities();
		// List<TestBrief> temptb =
		// testBriefService.getTestBriefByGroup(groupList);
		List<TestBrief> temptb = testBriefService.getTestBriefByRight(auth
				.getName());
		// User u = userService.getUserByName(auth.getName());
		// List<TestBrief> temptb =
		// testBriefService.getLatestTestBriefByExecutorId(u.getUserId());
		if (temptb.size() == 0 || temptb.size() < selectnum) {
			model.addAttribute("TestBriefSize",temptb.size());
			return "/view/showHomePage.jsp";
		}
		TestBrief testBrief = temptb.get(selectnum - 1);
		SubmitResultService submitResultService = new SubmitResultService();
		Map<String, String> returnStatistics = submitResultService
				.getReturnStatistics(testBrief.getBriefId());
		Date testStartTime = testBrief.getStartTime();
		Date testEndTime = testBrief.getEndTime();
		System sys = systemService.getSystemByPlanId(testBrief.getPlanId());
		List<ItemStatistics> itemStatisticsList = itemStatistService
				.getItemStitisticsByBriefId(testBrief.getBriefId());
		List<RequestStatistics> requestStatistList = requestStatisticsService
				.getAllRequestStatisticsByBriefId(testBrief.getBriefId());
		if (requestStatistList.size() == 0) {
			model.addAttribute("testBrief", testBrief);
			model.addAttribute("Duration", null);
			model.addAttribute("system", sys);
			model.addAttribute("ItemNameList",GetItemNameListString(itemStatisticsList));
			model.addAttribute("date",
					GetresponsetimeString(itemDetail, itemStatisticsList));
			model.addAttribute("TestBriefSize",temptb.size());
			return "/view/showHomePage.jsp";
		}
		String durationTime;
		if (testEndTime == null && testStartTime == null) {
			durationTime = null;
		} else {
			durationTime = ((double) testEndTime.getTime() - testStartTime
					.getTime()) / 1000 + " s";
		}

		Map<Integer, Integer> reCode = requestDetailService
				.getRequestCountByReturnCode(requestStatistList, requestDetail);

		model.addAttribute("reCode", reCode);
		model.addAttribute("returnStatistics", returnStatistics);
		model.addAttribute("testBrief", testBrief);
		model.addAttribute("Duration", durationTime);
		model.addAttribute("system", sys);
		model.addAttribute("ItemStatisticsList", itemStatisticsList);
		model.addAttribute("ItemNameList",GetItemNameListString(itemStatisticsList));
		model.addAttribute("date",
				GetresponsetimeString(itemDetail, itemStatisticsList));
		model.addAttribute("TestBriefSize",temptb.size());
		return "/view/showHomePage.jsp";

	}

	@RequestMapping("/GetAllProject")
	public String getAllProject(Model model) throws Exception {
		try {
			model.addAttribute("projects", projectService.getAllProject());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw e;
		}
		return "/page/createSystem.jsp";
	}

	@RequestMapping("/RemoveProject")
	public String removeProject(Project project) throws Exception {
		try {
			projectService.delProject(project);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw e;
		}
		return "/view/success.jsp";
	}

	@ExceptionHandler(Exception.class)
	public String exception(Exception e, HttpServletRequest request) {
		request.setAttribute("exception", e);
		return "/view/error.jsp";
	}

	public String GetresponsetimeString(ItemDetail itemDetail,
			List<ItemStatistics> itemStatisticsList) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String responseDate = "";
		if(itemStatisticsList.size()==0){
			return "[]";
		}
		for (int i = 0; i < itemStatisticsList.size(); i++) {
			String tempString = "";
			itemDetail.setBriefId(itemStatisticsList.get(i).getBriefId());
			itemDetail.setItemId(itemStatisticsList.get(i).getItemId());
			List<ItemDetail> ItemDetailList = itemDetailService
					.getAllItemDetailByItemIdAndBriefId(itemDetail);
			for (int j = 0; j < ItemDetailList.size(); j++) {

				tempString = tempString + "['"
						+ sdf.format(ItemDetailList.get(j).getStartTime())
						+ "'," + ItemDetailList.get(j).getResponseTime() + "],";
			}
			responseDate = responseDate + "[" + tempString + "],";
		}

		return "[" + responseDate.substring(0, responseDate.length() - 1) + "]";

	}

	public String GetItemNameListString(List<ItemStatistics> itemStatisticsList) {
		String itemNameStringList = "";
		for (int i = 0; i < itemStatisticsList.size(); i++) {

			itemNameStringList = itemNameStringList
					+ itemStatisticsList.get(i).getItemName()+",";
		}
		for(int j=0;j<10-itemStatisticsList.size();j++){
			itemNameStringList=itemNameStringList+"' ',";
		}
		return itemNameStringList.substring(0, itemNameStringList.length()-1);

	}
	
	public Map<Integer, Integer>  GetRequirmentMap(List<ItemStatistics> itemStatisticsList) {
		Map<Integer, Integer> returnMap=new HashMap<Integer, Integer>();
		for (int i = 0; i < itemStatisticsList.size(); i++) {
			Integer key=itemStatisticsList.get(i).getItemId();
			returnMap.put(key,requirementService.getRequirementByItemId(itemStatisticsList.get(i).getItemId()).getAvgResponseTime());

		}
		return returnMap;

	}

}
