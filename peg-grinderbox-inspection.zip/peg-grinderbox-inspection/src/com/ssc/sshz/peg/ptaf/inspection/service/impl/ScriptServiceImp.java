package com.ssc.sshz.peg.ptaf.inspection.service.impl;



import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.dao.ScriptDao;
import com.ssc.sshz.peg.ptaf.inspection.service.ScriptService;

@Service

public class ScriptServiceImp<T extends Script> implements ScriptService<T>
{
	@Inject
	private ScriptDao<T> dao;
	

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllScripts() throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getAllScript();
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getScript(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getScript(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addScript(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addScript(entity);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean delScriptById(int id) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.delScriptById(id);
	}
}
