package com.ssc.sshz.peg.ptaf.inspection.mapper;
import com.ssc.sshz.peg.ptaf.inspection.bean.SystemItem;
public interface SystemItemMapper extends SqlMapper{
	public void addSystemItem(SystemItem systemitem);
}
