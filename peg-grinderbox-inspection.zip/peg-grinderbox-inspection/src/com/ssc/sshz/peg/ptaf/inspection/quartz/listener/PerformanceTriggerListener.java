package com.ssc.sshz.peg.ptaf.inspection.quartz.listener;

import org.apache.log4j.Logger;
import org.quartz.JobExecutionContext;
import org.quartz.Trigger;
import org.quartz.Trigger.CompletedExecutionInstruction;
import org.quartz.TriggerListener;

public class PerformanceTriggerListener implements TriggerListener
{
	private static final String name = "PerformanceTrifferListener";
	private static Logger logger = Logger.getLogger(PerformanceTriggerListener.class);
	@Override
	public String getName()
	{
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public void triggerComplete(Trigger trigger, JobExecutionContext jobexecutioncontext,
			CompletedExecutionInstruction completedexecutioninstruction)
	{
		
		logger.info("Tigger:" + trigger.getKey() + " complete with Job: " + trigger.getJobKey() );
		
	}

	@Override
	public void triggerFired(Trigger trigger, JobExecutionContext jobexecutioncontext)
	{
		logger.info("Tigger:" + trigger.getKey() + " is fired with Job: " +  trigger.getJobKey());
		
	}

	@Override
	public void triggerMisfired(Trigger trigger)
	{
		logger.info("Tigger:" + trigger.getKey() + " is misfired");
		
	}

	@Override
	public boolean vetoJobExecution(Trigger trigger, JobExecutionContext jobexecutioncontext)
	{
		// TODO Auto-generated method stub
		return false;
	}

}
