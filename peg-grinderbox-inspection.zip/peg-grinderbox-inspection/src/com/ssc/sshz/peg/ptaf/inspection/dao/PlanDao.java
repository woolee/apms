package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;

public interface PlanDao<T> {
	public List<T> getAllPlan() throws DataAccessException;
	public T getPlanById(Integer id) throws DataAccessException;
	public T getPlanByName(String name) throws DataAccessException;
	public List<T> getPlanBySystemId(int systemId) throws DataAccessException;
	public T getPlanBySystemIdPlanName(Plan plan) throws DataAccessException;
	public boolean addPlan(T entity) throws DataAccessException;
	public boolean delPlanById(Integer id) throws DataAccessException;
	public boolean delPlanByName(String name) throws DataAccessException;
}
