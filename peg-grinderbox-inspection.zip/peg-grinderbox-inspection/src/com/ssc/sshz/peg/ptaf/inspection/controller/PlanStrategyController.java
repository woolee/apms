package com.ssc.sshz.peg.ptaf.inspection.controller;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Requirement;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanService;
import com.ssc.sshz.peg.ptaf.inspection.service.ProjectService;
import com.ssc.sshz.peg.ptaf.inspection.service.SystemService;
import com.ssc.sshz.peg.ptaf.inspection.service.UserService;

@Controller
@RequestMapping("/planStrategy")
public class PlanStrategyController {
	private static final Logger logger = Logger.getLogger(PlanStrategyController.class);

	@Inject
	private SystemService<System> systemService;

	@Inject
	private PlanService<Plan> planService;

	@Inject
	private ProjectService<Project> projectService;

	@Inject
	private UserService<User> userService;
	
	/*@Inject
	private RequestService<Request> requestService;

	@Inject
	private PlanStrategyService<PlanStrategy> planStrategyService;

	@Inject
	private ItemService<Item> itemService;

	@Inject
	private PlanItemService<PlanItem> planItemService;


	@Inject
	private RuntimeService<Runtime> runtimeService;

	@Inject
	private RuntimeTriggerService<RuntimeTrigger> runtimeTriggerService;

	@Inject
	private ScriptService<Script> ScriptService;

	@Inject
	private PlanScriptService<PlanScript> planScriptService;

	@Inject
	private RequirementService<Requirement> requirementService;*/

	@ModelAttribute("getAllsystem")
	public List<System> getAllsystem() {
		List<System> s = systemService.getAllSystem();
		return s;
	}

	@RequestMapping("/CreatePlanStrategy")
	public String CreatePlanStrategy(PlanStrategy planStrategy,
			Runtime runtime, HttpServletRequest httpRequest,
			HttpSession httpSession, RuntimeTrigger rt, Plan plan,
			PlanScript planScript, PlanItem planItem, Request request,
			Script script, System system, Requirement requirement, Model model)
			throws Exception {
		int systemId = Integer.parseInt((String) httpSession.getAttribute("systemId"));
		String planName = (String) httpSession.getAttribute("planName");
		String zipFilePutPath = (String) httpSession.getAttribute("zipfileputpath");
		String zipfilepath = (String) httpSession.getAttribute("zipfilepath");
		String planDes = (String) httpSession.getAttribute("planDescription");
		String runtype = httpRequest.getParameter("runtype");
		String strategyLoad = httpRequest.getParameter("strategyLoad");
		String loopCount = httpRequest.getParameter("loopCount");
		String date_from = httpRequest.getParameter("date_from");
		String date_to = httpRequest.getParameter("date_to");
		String tempintervaltime = httpRequest.getParameter("intervaltime");
		String intervaltimeUnit = httpRequest.getParameter("intervaltimeUnit");
		String repeat = httpRequest.getParameter("repeat");
		
		system.setSystemId(systemId);

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String username = auth.getName();
		User user = userService.getUserByName(username);
		plan.setPlancreatorId(user.getUserId());
		plan.setSystemId(systemId);
		plan.setPlanName(planName);
		plan.setPlanDescription(planDes);
		Plan tempplan = planService.addPlan(plan);
		String itemRequirementString = (String) httpSession.getAttribute("itemRequirementString");
		
		List<Item> itemlist = ReadScripToDB(zipFilePutPath, system,httpSession, requirement, tempplan);
		
		planService.createPlan(runtime, planStrategy, rt, planScript, planItem, request, script, user, itemlist, tempplan, username, zipfilepath, zipFilePutPath, runtype, strategyLoad, loopCount, date_from, date_to, tempintervaltime, intervaltimeUnit, repeat,itemRequirementString);
		return "/job/monitor.do";
	}

	@RequestMapping("/PlanStrategyPageInint")
	public String Inint(Model model) {
		model.addAttribute("projects", projectService.getAllProject());
		model.addAttribute("systems", systemService.getAllSystem());
		model.addAttribute("plans", planService.getAllPlan());
		return "/page/createPlanStrategy.jsp";
	}

	@ExceptionHandler(Exception.class)
	public String exception(Exception e, HttpServletRequest request) {
		request.setAttribute("exception", e);
		logger.error(e.getMessage(), e);
		return "/view/error.jsp";
	}

	public List<Item> ReadScripToDB(String zipfileputpath, System system,
			HttpSession httpSession, Requirement requirement, Plan plan)
			throws Exception {
		String itemDescList = (String) httpSession.getAttribute("itemDescList");
		String itemRequirementString = (String) httpSession.getAttribute("itemRequirementString");
		List<Item> itemList = planService.addItemRequest(zipfileputpath, system, itemDescList, itemRequirementString, requirement, plan);
		return itemList;
	}
}
