package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeTriggerDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RuntimeTriggerMapper;

@Repository
public class RuntimeTriggerDaoImpl<T extends RuntimeTrigger> implements RuntimeTriggerDao<T>{

	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RuntimeTriggerMapper mapper;


	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllRuntimeTrigger() throws DataAccessException
	{
		List<T> list=null;
		try{ 
			list =(List<T>) mapper.getAllRuntimeTrigger();
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all runtime_trigger from database",e);
			throw new DaoException("Exception while get all runtime_trigger from database",e);
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getRuntimeTriggerByRuntimeId(int runtimeId) throws DataAccessException
	{
		T entity = null;
		try{ 
			entity = (T) mapper.getRuntimeTriggerByRuntimeId(runtimeId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get runtime_trigger by runtime id from database",e);
			throw new DaoException("Exception while get runtime_trigger by runtime id from database",e);
		}
		return entity;
	}

	@Override
	public boolean addRuntimeTrigger(T entity) throws DataAccessException
	{
		boolean flag = false;
		try {
			mapper.addRuntimeTrigger(entity); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while add runtime_trigger to database",e);
			throw new DaoException("Exception while add runtime_trigger to database",e);
		}
		return flag;
	}

	@Override
	public boolean delRuntimeTriggerByRuntimeId(int runtimeId) throws DataAccessException
	{
		boolean flag = false;
		try {
			mapper.delRuntimeTriggerByRuntimeId(runtimeId);
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while delete runtime_trigger by runtime id to database",e);
			throw new DaoException("Exception while delete runtime_trigger by runtime id  to database",e);
		}
		return flag;
	}

	@Override
	public boolean updateRuntimeTrigger(T entity) throws DataAccessException
	{
		boolean flag = false;
		try {
			mapper.updateRuntimeTrigger(entity);
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while update runtime_trigger to database",e);
			throw new DaoException("Exception while update runtime_trigger to database",e);
		}
		return flag;
	}

	@Override
	public List<T> getJobStateByUser(String username) throws DataAccessException
	{
		List<T> list=null;
		try{ 
			list = (List<T>) mapper.getJobStateByUser(username);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get jobs state by username from database",e);
			throw new DaoException("Exception while get jobs state by username from database",e);
		}
		return list;
	}

	@Override
	public List<T> getJobStateByProjectName(String projectName) throws DataAccessException
	{
		List<T> list=null;
		try{ 
			list = (List<T>) mapper.getJobStateByProjectName(projectName);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get jobs state by project name from database",e);
			throw new DaoException("Exception while get jobs state by project name from database",e);
		}
		return list;
	}



	

}
