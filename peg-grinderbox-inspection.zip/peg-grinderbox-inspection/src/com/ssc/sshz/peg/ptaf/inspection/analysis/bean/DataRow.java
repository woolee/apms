package com.ssc.sshz.peg.ptaf.inspection.analysis.bean;

import java.util.Comparator;
import java.util.HashMap;

import com.ssc.sshz.peg.ptaf.inspection.test.constants.DataHeaders;

/**
 * The class object denote lines in data file from output folder
 * @author a549324
 *
 */
public class DataRow
{
    private int thread;
    private int run;
    private int test;
    private long startTime;
    private int testTime;
    private int errors;
    private int httpResponseCode;
    private int httpResponseLength;
    private int httpResponseErrors;
    private int timeToResolveHost;
    private int timeToEstablishConnection;
    private int timeToFirstByte;
    private int newConnection;

    public static final Comparator<DataRow> threadComp = new ThreadComparator();

    public static final Comparator<DataRow> stratTimeComp = new StartTimeComparator();

    public DataRow(int thread, int run, int test, long startTime, int testTime, int errors, int httpResponseCode,
	    int httpResponseLength, int httpResponseErrors, int timeToResolveHost, int timeToEstablishConnection,
	    int timeToFirstByte, int newConnection)
    {
	super();
	this.thread = thread;
	this.run = run;
	this.test = test;
	this.startTime = startTime;
	this.testTime = testTime;
	this.errors = errors;
	this.httpResponseCode = httpResponseCode;
	this.httpResponseLength = httpResponseLength;
	this.httpResponseErrors = httpResponseErrors;
	this.timeToResolveHost = timeToResolveHost;
	this.timeToEstablishConnection = timeToEstablishConnection;
	this.timeToFirstByte = timeToFirstByte;
	this.newConnection = newConnection;
    }

    public DataRow()
    {

    }

    public DataRow(HashMap<String, String> rowsMap)
    {
    	setThread(Integer.parseInt(rowsMap.get(DataHeaders.THREAD)));
		setRun(Integer.parseInt(rowsMap.get(DataHeaders.RUN)));
		setTest(Integer.parseInt(rowsMap.get(DataHeaders.TEST)));
		setStartTime(Long.parseLong(rowsMap.get(DataHeaders.STARTTIME)));
		setTestTime(Integer.parseInt(rowsMap.get(DataHeaders.TESTTIME)));
		setErrors(Integer.parseInt(rowsMap.get(DataHeaders.ERRORS)));
		setHttpResponseCode(Integer.parseInt(rowsMap.get(DataHeaders.HTTPRESPONSECODE)));
		setHttpResponseLength(Integer.parseInt(rowsMap.get(DataHeaders.HTTPRESPONSELENGTH)));
		setHttpResponseErrors(Integer.parseInt(rowsMap.get(DataHeaders.HTTPRESPONSEERROR)));
		setTimeToResolveHost(Integer.parseInt(rowsMap.get(DataHeaders.TIMETORSVHOST)));
		setTimeToEstablishConnection(Integer.parseInt(rowsMap.get(DataHeaders.TIMETOESTCONN)));
		setTimeToFirstByte(Integer.parseInt(rowsMap.get(DataHeaders.TIMETOFIRSTBYTE)));
		setNewConnection(Integer.parseInt(rowsMap.get(DataHeaders.NEWCONN)));
    }
    
    public void setThread(int thread)
    {
	this.thread = thread;
    }

    public int getThread()
    {
	return thread;
    }

    public int getRun()
    {
	return run;
    }

    public void setRun(int run)
    {
	this.run = run;
    }

    public int getTest()
    {
	return test;
    }

    public void setTest(int test)
    {
	this.test = test;
    }

    public long getStartTime()
    {
	return startTime;
    }

    public void setStartTime(long startTime)
    {
	this.startTime = startTime;
    }

    public int getTestTime()
    {
	return testTime;
    }

    public void setTestTime(int testTime)
    {
	this.testTime = testTime;
    }

    public int getErrors()
    {
	return errors;
    }

    public void setErrors(int errors)
    {
	this.errors = errors;
    }

    public int getHttpResponseCode()
    {
	return httpResponseCode;
    }

    public void setHttpResponseCode(int httpResponseCode)
    {
	this.httpResponseCode = httpResponseCode;
    }

    public int getHttpResponseLength()
    {
	return httpResponseLength;
    }

    public void setHttpResponseLength(int httpResponseLength)
    {
	this.httpResponseLength = httpResponseLength;
    }

    public int getHttpResponseErrors()
    {
	return httpResponseErrors;
    }

    public void setHttpResponseErrors(int httpResponseErrors)
    {
	this.httpResponseErrors = httpResponseErrors;
    }

    public int getTimeToResolveHost()
    {
	return timeToResolveHost;
    }

    public void setTimeToResolveHost(int timeToResolveHost)
    {
	this.timeToResolveHost = timeToResolveHost;
    }

    public int getTimeToEstablishConnection()
    {
	return timeToEstablishConnection;
    }

    public void setTimeToEstablishConnection(int timeToEstablishConnection)
    {
	this.timeToEstablishConnection = timeToEstablishConnection;
    }

    public int getTimeToFirstByte()
    {
	return timeToFirstByte;
    }

    public void setTimeToFirstByte(int timeToFirstByte)
    {
	this.timeToFirstByte = timeToFirstByte;
    }

    public int getNewConnection()
    {
	return newConnection;
    }

    public void setNewConnection(int newConnection)
    {
	this.newConnection = newConnection;
    }

    @Override
    public String toString()
    {
	return "ContentInfo [thread=" + thread + ", run=" + run + ", test=" + test + ", startTime=" + startTime + ", testTime="
		+ testTime + ", errors=" + errors + ", httpResponseCode=" + httpResponseCode + ", httpResponseLength="
		+ httpResponseLength + ", httpResponseErrors=" + httpResponseErrors + ", timeToResolveHost=" + timeToResolveHost
		+ ", timeToEstablishConnection=" + timeToEstablishConnection + ", timeToFirstByte=" + timeToFirstByte
		+ ", newConnection=" + newConnection + "]";
    }

    @Override
	public boolean equals(Object obj)
	{
		return  this.thread == ((DataRow)obj).getThread() 
				&& this.run == ((DataRow)obj).getRun() 
				&& this.test == ((DataRow)obj).getTest()
				&& this.startTime == ((DataRow)obj).getStartTime()
				&& this.testTime == ((DataRow)obj).getTestTime()
				&& this.errors == ((DataRow)obj).getErrors()
				&& this.httpResponseCode == ((DataRow)obj).getHttpResponseCode()
				&& this.httpResponseLength == ((DataRow)obj).getHttpResponseLength()
				&& this.httpResponseErrors == ((DataRow)obj).getHttpResponseErrors()
				&& this.timeToResolveHost == ((DataRow)obj).getTimeToResolveHost()
				&& this.timeToEstablishConnection == ((DataRow)obj).getTimeToEstablishConnection()
				&& this.timeToFirstByte == ((DataRow)obj).getTimeToFirstByte()
				&& this.newConnection == ((DataRow)obj).getNewConnection()
				;
	}
    
	@Override
	public int hashCode()
	{
		return super.hashCode();
	}
}

class ThreadComparator implements Comparator<DataRow>
{
    public int compare(DataRow one, DataRow two)
    {
	return one.getThread() - (two.getThread());
    }
}

class StartTimeComparator implements Comparator<DataRow>
{
    public int compare(DataRow one, DataRow two)
    {
	return (int) (one.getStartTime() - (two.getStartTime()));
    }
}
