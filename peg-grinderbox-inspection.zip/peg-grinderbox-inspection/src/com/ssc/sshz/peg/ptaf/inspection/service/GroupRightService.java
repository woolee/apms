package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface GroupRightService<T>
{
	public boolean addGroupRight(T entity) throws DataAccessException;

	public List<T> getAllGroupRight() throws DataAccessException;
}
