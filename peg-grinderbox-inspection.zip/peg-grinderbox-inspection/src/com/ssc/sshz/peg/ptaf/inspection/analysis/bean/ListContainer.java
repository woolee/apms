package com.ssc.sshz.peg.ptaf.inspection.analysis.bean;

import java.util.ArrayList;
import java.util.List;

public class ListContainer
{
	private List<Integer> itemList = new ArrayList<Integer>();
	private List<Integer> requestList = new ArrayList<Integer>();
	public ListContainer(){}
	public List<Integer> getRequestList()
	{
		return requestList;
	}
	public void setRequestList(List<Integer> requestList)
	{
		this.requestList = requestList;
	}
	public List<Integer> getItemList()
	{
		return itemList;
	}
	public void setItemList(List<Integer> itemList)
	{
		this.itemList = itemList;
	}
	
	
}
