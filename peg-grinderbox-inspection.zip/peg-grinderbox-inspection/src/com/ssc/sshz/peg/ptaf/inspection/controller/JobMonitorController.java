package com.ssc.sshz.peg.ptaf.inspection.controller;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.quartz.SchedulerException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.quartz.QuartzManager;
import com.ssc.sshz.peg.ptaf.inspection.service.ProjectService;
import com.ssc.sshz.peg.ptaf.inspection.service.RuntimeTriggerService;

@Controller
@RequestMapping("/job")
public class JobMonitorController
{
	
	@Inject
	private RuntimeTriggerService<RuntimeTrigger> rtService;
	
	@Inject
	private ProjectService<Project> projectService;
	/**
	 * monitor the job status under the user 
	 * @param httpSession
	 * @param model
	 * @return
	 */
	@RequestMapping("/monitor")
	public String monitor(HttpSession httpSession,Model model){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
//		List<? extends GrantedAuthority> groupList = (List)auth.getAuthorities();
		List<Project> projectList = projectService.getProjectByRight(auth.getName());
		List<RuntimeTrigger> list = rtService.getJobStateByProjects(projectList);
//		List<RuntimeTrigger> list = rtService.getJobStateByUser(auth.getName());
		model.addAttribute("runtimeTriggerList", list);
		return "../view/jobMonitor.jsp";
	}
	
	@RequestMapping("/monitorRefresh")
	public String monitorRefresh(HttpSession httpSession,Model model){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
//		List<? extends GrantedAuthority> groupList = (List)auth.getAuthorities();
//		List<Project> projectList = projectService.getProjectByGroup(groupList);
		List<Project> projectList = projectService.getProjectByRight(auth.getName());
		List<RuntimeTrigger> list = rtService.getJobStateByProjects(projectList);
//		List<RuntimeTrigger> list = rtService.getJobStateByUser(auth.getName());
		model.addAttribute("runtimeTriggerList", list);
		return "../view/jobMonitorTable.jsp";
	}
	
	@RequestMapping("/pause")
	public String pauseJob(HttpSession httpSession,Model model,HttpServletRequest request) throws SchedulerException{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			
		String triggerName = request.getParameter("triggerName");
		QuartzManager.getQuartzManager().pauseTrigger(triggerName);
		
//		List<? extends GrantedAuthority> groupList = (List)auth.getAuthorities();
//		List<Project> projectList = projectService.getProjectByGroup(groupList);
		List<Project> projectList = projectService.getProjectByRight(auth.getName());
		List<RuntimeTrigger> list = rtService.getJobStateByProjects(projectList);
		
//		List<RuntimeTrigger> list = rtService.getJobStateByUser(auth.getName());
		model.addAttribute("runtimeTriggerList", list);
		return "../view/jobMonitor.jsp";
	}
	
	@RequestMapping("/resume")
	public String resumeJob(HttpSession httpSession,Model model,HttpServletRequest request) throws SchedulerException{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		
		String triggerName = request.getParameter("triggerName");
		QuartzManager.getQuartzManager().resumeTigger(triggerName);
		
//		List<? extends GrantedAuthority> groupList = (List)auth.getAuthorities();
//		List<Project> projectList = projectService.getProjectByGroup(groupList);
		List<Project> projectList = projectService.getProjectByRight(auth.getName());
		List<RuntimeTrigger> list = rtService.getJobStateByProjects(projectList);
		
//		List<RuntimeTrigger> list = rtService.getJobStateByUser(auth.getName());
		model.addAttribute("runtimeTriggerList", list);
		return "../view/jobMonitor.jsp";
	}
	
	/**
	 * if the trigger has no relation of runtime, only delete the trigger from quartz table,
	 * else delete the runtime_trigger table at the same time.
	 * @param httpSession
	 * @param model
	 * @param request
	 * @param rt
	 * @return
	 * @throws SchedulerException
	 */
	@RequestMapping("/delete")
	public String deleteJob(HttpSession httpSession,Model model,HttpServletRequest request,RuntimeTrigger rt) throws SchedulerException{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String runtimeIdStr = request.getParameter("runtimeId");
		String triggerName = request.getParameter("triggerName");
		if(!(runtimeIdStr == null || "".equals(runtimeIdStr)))
		{
			int runtimeId = Integer.parseInt(runtimeIdStr);
			rt = rtService.getRuntimeTriggerByRuntimeId(runtimeId);
			List<RuntimeTrigger> list = new ArrayList<RuntimeTrigger>();
			list.add(rt);
			QuartzManager.getQuartzManager().deleteJobs(list);
		}
		else
		{
			QuartzManager.getQuartzManager().removeTigger(triggerName);
		}
		
//		List<? extends GrantedAuthority> groupList = (List)auth.getAuthorities();
//		List<Project> projectList = projectService.getProjectByGroup(groupList);
		List<Project> projectList = projectService.getProjectByRight(auth.getName());
		List<RuntimeTrigger> list = rtService.getJobStateByProjects(projectList);
		
//		List<RuntimeTrigger> list = rtService.getJobStateByUser(auth.getName());
		model.addAttribute("runtimeTriggerList", list);
		return "../view/jobMonitor.jsp";
	}
}
