package com.ssc.sshz.peg.ptaf.inspection.analysis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.DataRow;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestDetail;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.RequestQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;

public class RequestAnalyzer
{
//		private List<DataRow> rows;
		private RequestQuartzService<Request> requestService = new RequestQuartzService<Request>();
		private static final Logger logger = Logger.getLogger(RequestAnalyzer.class);
	    private Map<Integer, List<DataRow>> requestDataMap ;
	    private Map<String, Request> requestMap;
	    private Plan plan;
	    private TestBrief testBrief;
	    private Map<Integer, List<DataRow>> rowDataMapByThreadId ;
	    private Map<Integer, List<String>>  threadRequestURL;
		private Map<Integer,Request> requestByTestId = new HashMap<Integer, Request>();
		
	    public RequestAnalyzer(Map<Integer, List<DataRow>> rowDataMap, TestBeanCollection collection, Map<Integer, List<DataRow>> rowDataMapByThreadId,Map<Integer, List<String>>  threadRequestURL) throws CloneNotSupportedException
	    {
//	    	this.rows = rowDataMap.get(TestConceptConstant.REQUEST);
	    	this.requestDataMap = rowDataMap;
	    	this.requestMap = getRequestMap(collection.getRequestMapByItemId());
	    	this.plan = collection.getPlan();
	    	this.testBrief = collection.getTestBrief();
	    	this.rowDataMapByThreadId = new HashMap<Integer, List<DataRow>>(rowDataMapByThreadId);
	    	this.threadRequestURL = threadRequestURL;
	    }
	    
	    
	    private Map<String,Request> getRequestMap(Map<Integer,List<Request>> requestListByItemIdMap)
	    {
	    	Set<Integer> itemIds = requestListByItemIdMap.keySet();
	    	Map<String, Request> requestMap = new HashMap<String, Request>();
	    	for (Integer itemId : itemIds)
			{
	    		List<Request> requestList = requestListByItemIdMap.get(itemId);
	    		for (Request request : requestList)
	    		{
	    			requestMap.put(request.getRequestName(), request);
	    		}
			}
	    	return requestMap;
	    }
	    /**
	     * get the detail URL value of every request
	     * @return key DateRow,value URL
	     */
	    public Map<DataRow,String> getRequestURL()
	    {
	    	Set<Integer> threads = threadRequestURL.keySet();
	    	Map<DataRow,String> requestURLMap = new HashMap<DataRow, String>();
	    	Map<Integer, List<DataRow>>  rowDataByThreadIdWithRequest = new HashMap<Integer, List<DataRow>>();
	    	for (Integer thread : threads)
			{
	    		List<String> urls = threadRequestURL.get(thread);
	    		List<DataRow> rows = rowDataMapByThreadId.get(thread);
	    		List<DataRow> newRows = new ArrayList<DataRow>();
	    		for (int i = rows.size()-1; i >= 0; i--)
				{
	    			if(requestMap.containsKey(rows.get(i).getTest()+""))
	    				newRows.add(rows.get(i));
				}
	    		for (int i = 0; i < urls.size(); i++)
				{
	    			DataRow row = newRows.get(i);
	    			requestURLMap.put(row, urls.get(i));
				}
	    			
				
			}
	    	return requestURLMap;
	    }
	    /**
	     * get service max response time
	     * @return map, key is service number, value is service max response time
	     */
	    public Map<Integer, Integer> getRequestMaxResponseTime()
	    {
		Map<Integer, Integer> maxRpsMap = new HashMap<Integer, Integer>();
		
		Set<Integer> testIds = requestDataMap.keySet();
		for (Integer testId : testIds)
		{
		    List<DataRow> dataRowList = requestDataMap.get(testId);
		    DataRow row = Collections.max(dataRowList, new Comparator<DataRow>()
			{

				@Override
				public int compare(DataRow data1,DataRow data2)
				{
					// TODO Auto-generated method stub
					return data1.getTestTime() - data2.getTestTime();
				}
			});
		    
		    maxRpsMap.put(testId, row.getTestTime());
		}
		return maxRpsMap;
	    }

	    /**
	     * get service min response time
	     * @return map, key is service number, value is service min response time
	     */
	    public Map<Integer, Integer> getRequestMinResponseTime()
	    {
		Map<Integer, Integer> minRpsMap = new HashMap<Integer, Integer>();
		
		Set<Integer> testIds = requestDataMap.keySet();
		for (Integer testId : testIds)
		{
		    List<DataRow> dataRowList = requestDataMap.get(testId);
		    DataRow row = Collections.min(dataRowList, new Comparator<DataRow>()
			{

				@Override
				public int compare(DataRow data1,DataRow data2)
				{
					// TODO Auto-generated method stub
					return data1.getTestTime() - data2.getTestTime();
				}
			});
		    
		    minRpsMap.put(testId, row.getTestTime());
		}
		return minRpsMap;
	    }

	    /**
	     * get the 90th response time of the requests
	     * @return
	     */
	    public Map<Integer, Integer> getRequest90thRespTime()
	    {
		Map<Integer, Integer> ninetyRespMap = new HashMap<Integer, Integer>();
		Set<Integer> testIds = requestDataMap.keySet();
		for (Integer testId : testIds)
		{
		    List<DataRow> dataRows = requestDataMap.get(testId);
		    Collections.sort(dataRows, new Comparator<DataRow>()
			{

				@Override
				public int compare(DataRow o1, DataRow o2)
				{
					
					return o1.getTestTime() - o2.getTestTime();
				}
			});
		    int index = (int) Math.round(0.9 * dataRows.size());
		    
		    int ninetiethTime = dataRows.get(index - 1).getTestTime();
		    ninetyRespMap.put(testId, ninetiethTime);

		}
		return ninetyRespMap;
	    }
	    
	    public Map<Integer, Double> getRequestVarianceRps()
	    {
		Map<Integer, Double> variance = new HashMap<Integer, Double>();
		Set<Integer> keys = requestDataMap.keySet();
		for (Integer key : keys)
		{
			double sum = 0;
		    double average = getRequestAverageResponseTime().get(key);
		    List<DataRow> list = requestDataMap.get(key);
		    for (int i = 0; i < list.size(); i++)
		    {
			int value = list.get(i).getTestTime();
			sum = sum + Math.pow((average - value), 2);
		    }
		    variance.put(key, sum / list.size());
		}
		return variance;
	    }
	    
	    public Map<Integer, Double> getRequestStdRps()
	    {
		Map<Integer, Double> variance = new HashMap<Integer, Double>();
		Set<Integer> keys = requestDataMap.keySet();
		for (Integer key : keys)
		{
			double sum = 0;
		    double average = getRequestAverageResponseTime().get(key);
		    List<DataRow> list = requestDataMap.get(key);
		    for (int i = 0; i < list.size(); i++)
		    {
			int value = list.get(i).getTestTime();
			sum = sum + Math.pow((average - value), 2);
		    }
		    variance.put(key, Math.sqrt(Math.abs(sum / list.size())));
		}
		return variance;
	    }
	    
	    /**
	     *get service average response time 
	     * @return map, key is service number, value is service average response time 
	     */
	    public Map<Integer, Double> getRequestAverageResponseTime()
	    {
		double average = 0;
		Map<Integer, Double> averageRps = new HashMap<Integer, Double>();
		Set<Integer> testIds = requestDataMap.keySet();
		for (Integer testId : testIds)
		{
		    int sum = 0;
		    List<DataRow> dataRows = requestDataMap.get(testId);
		    for (DataRow dataRow : dataRows)
			{
		    	sum = sum + dataRow.getTestTime();
			}
		    average = ((double) sum) / dataRows.size();
		    averageRps.put(testId, average);

		}
		return averageRps;
	    }
	    
	    /**
	     * get the total test count of services
	     * @return map, key is service number, value is service total test count
	     */
	    public Map<Integer, Integer> getRequestExexcuCount()
	    {
		Map<Integer, Integer> totalCount = new HashMap<Integer, Integer>();

		Set<Integer> testIds = requestDataMap.keySet();

		for (Integer testId : testIds)
		{
		    List<DataRow> list = requestDataMap.get(testId);
		    totalCount.put(testId, list.size());
		}

		return totalCount;
	    }
	    
	    /**
	     * get failed test count of services
	     * @return map, key is service time, value is service failed test count 
	     */
	    public Map<Integer, Integer> getRequestErrorCount()
	    {
		Map<Integer, Integer> failrequestDataMap = new HashMap<Integer, Integer>();

		Set<Integer> testIds = requestDataMap.keySet();
		for (Integer testId : testIds)
		{
			int sumFailed = 0;
		    List<DataRow> list = requestDataMap.get(testId);
		    for (DataRow dataRow : list)
			{
		    	if(  dataRow.getHttpResponseErrors() == 1)
		    	{
		    		sumFailed ++;
		    	}
//		    	if( 200 <= dataRow.getHttpResponseCode()&& dataRow.getHttpResponseCode() < 400)
//		    	{
//		    		sumFailed ++;
//		    	}
//		    	else if(dataRow.getTestTime() >= 2000)
//		    	{
//		    		sumFailed ++;
//		    	}
			}
		    failrequestDataMap.put(testId, sumFailed);
		}

		return failrequestDataMap;
	    }
	    
	    public Map<Integer, Double> getRequestErrorRate()
	    {
		Map<Integer, Integer> failrequestDataMap = getRequestErrorCount();
		Map<Integer, Integer> totalCountMap = getRequestExexcuCount();
		
		Map<Integer, Double> errorRateMap = new HashMap<Integer, Double>();
		Set<Integer> testIds = failrequestDataMap.keySet();
		for (Integer testId : testIds)
		{
		    int failCount = failrequestDataMap.get(testId);
		    int totalCount = totalCountMap.get(testId);
		    errorRateMap.put(testId, (double)failCount/totalCount);
		}

		return errorRateMap;
	    }
	    
	    
//	    /**
//	     * get all services from data rows list
//	     * @return map, key is service number, value is list of row data in data file
//	     */
//	    public Map<Integer, List<DataRow>> getrequestDataMap(List<DataRow> rows)
//	    {
//		Map<Integer, List<DataRow>> requestDataMap = new HashMap<Integer, List<DataRow>>();
//		for (DataRow row : rows)
//		{
//
//		    int testId = row.getTest();
//		    if (requestDataMap.containsKey(testId))
//		    {
//		    	List<DataRow> cntList = requestDataMap.get(testId);
//				cntList.add(row);
//		    }
//		    else
//		    {
//		    	List<DataRow> dataList = new ArrayList<DataRow>();
//		    	dataList.add(row);
//				requestDataMap.put(testId, dataList);
//			
//		    }
//		}
//		return requestDataMap;
//	    }
	    
	    /**
	     * get a service summary list 
	     * @return serviceSummary list
	     * @throws Exception 
	     */
	    public List<RequestStatistics> getRequestSummaryList() throws Exception
		{
	    	Map<Integer, Integer> maxRpsMap = getRequestMaxResponseTime();
	    	Map<Integer, Integer> minRpsMap = getRequestMinResponseTime();
	    	Map<Integer, Double> avgRpsMap = getRequestAverageResponseTime();
	    	Map<Integer, Integer> totalCountMap = getRequestExexcuCount();
	    	Map<Integer, Integer> errorCountmap = getRequestErrorCount();
	    	Map<Integer, Double> errorRateMap = getRequestErrorRate();
	    	Map<Integer, Integer> nintiethRespMap = getRequest90thRespTime();
	    	Map<Integer, Double> stdRps = getRequestStdRps();
	    	
	    	Set<Integer> testIds = maxRpsMap.keySet();
	    	List<RequestStatistics> requestSummaryList = new ArrayList<RequestStatistics>();
	    	for (Integer testId : testIds)
	    	{
	    	    int maxResp = maxRpsMap.get(testId);
	    	    int minResp = minRpsMap.get(testId);
	    	    double avgResp = avgRpsMap.get(testId);
	    	    int executeCount = totalCountMap.get(testId);
	    	    int errorCount = errorCountmap.get(testId);
	    	    double errorRate = errorRateMap.get(testId);
	    	    int nintiethResp = nintiethRespMap.get(testId);
	    	    double stdResp = stdRps.get(testId);
	    	    
	    	    /*DB read: get requestId, requestName, itemId, itemName from table request*/
	    	    String requestName = "" + testId;
	    	    if(!requestMap.containsKey(requestName))
	    	    	continue;
	    	    Request request = requestMap.get(requestName);
	    	    int requestId = request.getRequestId() ;
	    	    setRequestByTestId(testId, requestId);
	    	    requestName = request.getRequestName();
		    	int itemId = request.getItemId();
		    	String itemName = request.getItemName(); 
		    	int briefId = testBrief.getBriefId();
		    	
		    	RequestStatistics requestSummary = new RequestStatistics();
		    	
		    	requestSummary.setRequestId(requestId);
		    	requestSummary.setRequestName(requestName);
		    	requestSummary.setItemId(itemId);
		    	requestSummary.setItemName(itemName);
		    	requestSummary.setPlanId(plan.getPlanId());
		    	requestSummary.setBriefId(briefId);
		    	requestSummary.setMaxResponseTime(maxResp);
		    	requestSummary.setMinResponseTime(minResp);
		    	requestSummary.setAvgResponseTime(avgResp);
		    	requestSummary.setExecutionCount(executeCount);
		    	requestSummary.setErrorCount(errorCount);
		    	requestSummary.setErrorRate(errorRate);
		    	requestSummary.setNinetyResponseTime(nintiethResp);
		    	requestSummary.setStdResponseTime(stdResp);
		    	
		    	requestSummaryList.add(requestSummary);
	    	}
	    	
	    	return requestSummaryList;
		}
	    
	    public List<RequestDetail> getRequestDetailList() throws Exception
	    {
	    	List<RequestDetail> requestDatailList = new ArrayList<RequestDetail>();
	    	Set<Integer> testIds = requestDataMap.keySet();
	    	logger.debug("testIds size:" + testIds.size());
	    	Map<DataRow,String> requestURLMap = getRequestURL();
	    	for (Integer test : testIds)
			{
	    		List<DataRow> rows = requestDataMap.get(test);
	    		logger.debug("requestMap.keySet().size()=" + requestMap.keySet().size());
	    		for (String requestName : requestMap.keySet())
				{
	    			logger.debug("key = " + requestName);
				}
	    		if(!requestMap.containsKey(test+""))
					continue;
	    		Request request = requestMap.get(test + "");
	    		logger.debug("request == null?" + request );
	    		int requestId = request.getRequestId();
	    		setRequestByTestId(test, requestId);
//	    		String requestName = requestFromDB.getRequestName();
	    		logger.debug("testBrief.getBriefId()=" + testBrief.getBriefId());
	    		int brifId = testBrief.getBriefId();
	    		Collections.sort(rows, DataRow.stratTimeComp);
	    		for(DataRow dataRow : rows)
	    		{
	    			/*DB read: get requestId, requestName, itemId, itemName from table request*/
	    			
	    			int responseCode = dataRow.getHttpResponseCode();
	    			int responseTime = dataRow.getTestTime();
	    			int bodySize = dataRow.getHttpResponseLength();
	    			boolean isError = (dataRow.getErrors() == 1);
	    			Date startTime = new Date(dataRow.getStartTime());
	    			int thread = dataRow.getThread();
	    			String url = requestURLMap.get(dataRow);
	    			RequestDetail requestDetail = new RequestDetail();
	    			
	    			requestDetail.setItemId(request.getItemId());
	    			requestDetail.setItemName(request.getItemName());
	    			requestDetail.setRequestId(requestId);
	    			requestDetail.setRequestName(request.getRequestName());
	    			requestDetail.setRequestURL(url);
	    			requestDetail.setBriefId(brifId);
	    			requestDetail.setPlanId(plan.getPlanId());
	    			requestDetail.setReturnCode(responseCode);
	    			requestDetail.setResponseTime(responseTime);
	    			requestDetail.setBodySize(bodySize);
	    			requestDetail.setError(isError);
	    			requestDetail.setStartTime(startTime);
	    			requestDetail.setThread(thread);
	    			
	    			requestDatailList.add(requestDetail);
	    		}
			}
	    	
	    	return requestDatailList;
	    }
	    
	    private void setRequestByTestId(int testId, int requestId) throws Exception
		{
			Request request = null;
			if(requestByTestId.containsKey(testId))
			{
				request = requestByTestId.get(testId);
			}
			else{
				request = requestService.getRequestsByRequestId(requestId);
				requestByTestId.put(testId, request);
			}
		}
	    
	    public Map<Integer, Request> getRequestByTestId()
	    {
	    	return requestByTestId;
	    }
}
