package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;


//@Component
@Entity
public class User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 436417172881400339L;
	private Integer userId;
	private String userName;
	private String passWord;
	private String realName;
	private String telephonePrimary;
	private String telephoneSecond;
	private String email;
	private String createTime;
	private String lastLoginTime;
	private String lastLoginIp;
	private String loginCount;
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String password) {
		this.passWord = password;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	public String getTelephonePrimary() {
		return telephonePrimary;
	}
	public void setTelephonePrimary(String telephonePrimary) {
		this.telephonePrimary = telephonePrimary;
	}
	public String getTelephoneSecond() {
		return telephoneSecond;
	}
	public void setTelephoneSecond(String telephoneSecond) {
		this.telephoneSecond = telephoneSecond;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getLastLoginTime() {
		return lastLoginTime;
	}
	public void setLastLoginTime(String lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
	public String getLastLoginIp() {
		return lastLoginIp;
	}
	public void setLastLoginIp(String lastLoginIp) {
		this.lastLoginIp = lastLoginIp;
	}
	public String getLoginCount() {
		return loginCount;
	}
	public void setLoginCount(String loginCount) {
		this.loginCount = loginCount;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName
				+ ", passWord=" + passWord + ", realName=" + realName
				+ ", telephonePrimary=" + telephonePrimary
				+ ", telephoneSecond=" + telephoneSecond + ", email=" + email
				+ ", createTime=" + createTime + ", lastLoginTime="
				+ lastLoginTime + ", lastLoginIp=" + lastLoginIp
				+ ", loginCount=" + loginCount + "]";
	}

}
