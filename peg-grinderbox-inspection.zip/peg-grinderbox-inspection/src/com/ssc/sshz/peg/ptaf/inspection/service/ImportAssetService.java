package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;
import java.util.Map;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;

public interface ImportAssetService
{
	public List<Item> getItemList(String folderPath,Item item , System system) throws Exception;
	public Map<Integer,List<Request>> getRequestMap(String folderPath, List<Item> itemList,Request reqeust) throws Exception;
}
