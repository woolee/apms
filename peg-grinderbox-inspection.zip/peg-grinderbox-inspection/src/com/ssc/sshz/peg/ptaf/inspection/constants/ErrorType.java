package com.ssc.sshz.peg.ptaf.inspection.constants;

public class ErrorType
{
	public static final String INSIDE = "inside";
	public static final String OUTSIDE = "outside";
}	
