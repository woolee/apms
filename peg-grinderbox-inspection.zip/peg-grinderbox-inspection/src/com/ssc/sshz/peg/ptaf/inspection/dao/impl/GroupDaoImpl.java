package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.Group;
import com.ssc.sshz.peg.ptaf.inspection.dao.GroupDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.GroupMapper;

@Repository
public class GroupDaoImpl<T extends Group> implements GroupDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private GroupMapper mapper;


	@Override
	public boolean addGroup(T entity) throws DataAccessException
	{
		boolean flag = false;
		try
		{
			mapper.addGroup(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add group to database",e);
			throw new DaoException("Exception while add group to database",e);
		}
		return flag;
	}

	@Override
	public T getGroupByGroupName(String groupName) throws DataAccessException
	{
		T entity = null;
		try
		{
			entity = (T) mapper.getGroupByGroupName(groupName);
		}
		catch (Exception e)
		{
			logger.error("Exception while get group by name to database",e);
			throw new DaoException("Exception while get group by name to database",e);
		}
		return entity;
	}
}
