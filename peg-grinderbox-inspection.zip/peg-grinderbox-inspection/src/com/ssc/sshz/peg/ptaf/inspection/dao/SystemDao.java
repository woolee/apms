package com.ssc.sshz.peg.ptaf.inspection.dao;


import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.System;

public interface SystemDao<T> {
	public boolean addSystem(T entity) throws DataAccessException;
	public T getSystemById(Integer id) throws DataAccessException;
	public T getSystemByuuid(String id) throws DataAccessException;
	public T getSystemByName(String name) throws DataAccessException;
	public T getSystemByNameVersionEnv(System system) throws DataAccessException;
	public List<T>  getSystemByProjectName(String name) throws DataAccessException;
	public List<T>  getSystemByProjectId(int id) throws DataAccessException;
	public boolean delSystemById(Integer id) throws DataAccessException;
	public List<T> getAllSystem() throws DataAccessException;
}
