package com.ssc.sshz.peg.ptaf.inspection.controller;


import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.SystemItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.constants.TestType;
import com.ssc.sshz.peg.ptaf.inspection.service.CIConfigService;
import com.ssc.sshz.peg.ptaf.inspection.service.CIService;
import com.ssc.sshz.peg.ptaf.inspection.service.ProjectService;
import com.ssc.sshz.peg.ptaf.inspection.service.SystemService;

@Controller
@RequestMapping("/CI")
public class CIServiceController
{
	private Logger logger = Logger.getLogger(getClass());
	@Inject
	private CIService ciService;
	
	@Inject
	private ProjectService<Project> projectService;
	
	@Inject
	private SystemService<System> systemService;
	
	
	@Inject
	private CIConfigService<CIConfig> ciConfigSev;

	
	@RequestMapping("/readXML")
	public String ReadConfig(Project project, System system, Item item, Request request, Plan plan,PlanItem planItem ,PlanStrategy planStrategy,Runtime runtime,TestBrief testBrief,TestError testError,CIConfig ciConfig,RuntimeTrigger runtimeTrigger,HttpSession httpSession,Model model){
		User user = (User) httpSession.getAttribute("user");
		String systemuuid=(String)httpSession.getAttribute("systemuuid");
		String projectuuid=(String)httpSession.getAttribute("projectuuid");
		String configTempPath=(String)httpSession.getAttribute("configTempPath");
		String configZipPath = (String)httpSession.getAttribute("configOriginalPath");
		String summaryId = (String) httpSession.getAttribute("summaryId");
		
		logger.debug("configZipPath=" + configZipPath);
		project=projectService.getProjectByuuid(projectuuid);
		system.setSystemuuid(systemuuid);
		system.setSystemId(systemService.getSystemByuuid(systemuuid).getSystemId());
		try
		{
			String errorPage = ciService.ReadXMLWriteToDB(project, system, item, request,plan,user,planItem,configTempPath,planStrategy,runtime, testBrief,configZipPath,summaryId,testError,ciConfig,runtimeTrigger);
			if(errorPage != null)
				return errorPage;
		}
		catch (Exception e)
		{
			return "../Error/exceptionError.jsp";
		}
		httpSession.setAttribute("configTempPath", configTempPath);
		logger.info("file upload success by user[" + user.getUserName()+ "] " );
		return "/view/success.jsp";
	}
	
	@RequestMapping("/execute")
	public String Execute(Project project, System system, Item item, Request request, Plan plan,PlanItem planItem ,SystemItem systemItem,PlanStrategy planStrategy,Runtime runtime,TestBrief testBrief,TestError testError,CIConfig ciConfig,RuntimeTrigger runtimeTrigger,HttpSession httpSession,Model model){
		String systemuuid=(String)httpSession.getAttribute("systemuuid");
		String projectuuid=(String)httpSession.getAttribute("projectuuid");
		String configTempPath=(String)httpSession.getAttribute("configTempPath");
		String configZipPath = (String)httpSession.getAttribute("configOriginalPath");
		String summaryId = (String) httpSession.getAttribute("summaryId");
		User user = (User) httpSession.getAttribute("user");
		logger.debug("configZipPath=" + configZipPath);
		project=projectService.getProjectByuuid(projectuuid);
		system.setSystemuuid(systemuuid);
		system.setSystemId(systemService.getSystemByuuid(systemuuid).getSystemId());
		try
		{
			String errorPage = ciService.Execute(configTempPath,testBrief,user,system,plan,project,configZipPath,summaryId,testError,ciConfig,runtimeTrigger);
			if(errorPage != null)
				return errorPage;
		}
		catch (Exception e)
		{
			return "../Error/exceptionError.jsp";
		}
		logger.info("file upload success by user[" + user.getUserName()+ "] ");
		return "/view/success.jsp";
	}
	
	@RequestMapping("/update")
	public String Update(Project project, System system, Item item, Request request, Plan plan,PlanItem planItem ,PlanStrategy planStrategy,Runtime runtime,TestBrief testBrief,TestError testError,CIConfig ciConfig,RuntimeTrigger runtimeTrigger,HttpSession httpSession,Model model){
		String systemuuid=(String)httpSession.getAttribute("systemuuid");
		String projectuuid=(String)httpSession.getAttribute("projectuuid");
		String configTempPath=(String)httpSession.getAttribute("configTempPath");
		String configZipPath = (String)httpSession.getAttribute("configOriginalPath");
		String summaryId = (String) httpSession.getAttribute("summaryId");
		User user = (User) httpSession.getAttribute("user");
		
		logger.debug("configZipPath=" + configZipPath);
		project=projectService.getProjectByuuid(projectuuid);
		system.setSystemuuid(systemuuid);
		system.setSystemId(systemService.getSystemByuuid(systemuuid).getSystemId());
		try
		{
			String errorPage = ciService.update(project, system, item, request, plan, user, planItem,  configTempPath, planStrategy, runtime, testBrief, configZipPath,summaryId,testError,ciConfig,runtimeTrigger);
			if(errorPage != null)
				return errorPage;
		}
		catch (Exception e)
		{
			return "../Error/exceptionError.jsp";
		}
		
		logger.info("file upload success by user[" + user.getUserName()+ "] " );
		return "/view/success.jsp";
	}
	
	
	
	@RequestMapping("/checkProjectSystem")
	public String CheckProjectSystem(CIConfig ciconfig,HttpSession httpSession,Model model){
		String returnStr = null;
		User user = (User) httpSession.getAttribute("user");
       String projectuuid=(String) httpSession.getAttribute("projectuuid");
       String systemuuid=(String) httpSession.getAttribute("systemuuid");
	   String configOriginalPath=(String)httpSession.getAttribute("configOriginalPath");
	   Project isExistProject= projectService.getProjectByuuid(projectuuid);
	   System isExistSystem= systemService.getSystemByuuid(systemuuid);
/*	   ciconfig.setCreatedBy(1);
	   ciconfig.setConfigName("ciconfig.zip");*/
	   String md5 = null;
	
		CIConfig ci=ciConfigSev.getCIConfigBySystemuuid(systemuuid);
		logger.debug("ci"+ci);
		if(ci==null){
			md5="";
		}else{
		    md5 = ci.getConfigFileMd5();
		}
		logger.debug("md5"+md5);
		logger.info("check CI configuration MD5[" + md5 + "] if exsit from user[" + user.getUserName() + "]");
		TestType type = ciService.CheckPorjectSystem(isExistProject, isExistSystem,md5,configOriginalPath);
		switch(type)
		{
    		case New:
    			logger.info("Empty plan with the system uuid [" + isExistSystem.getSystemuuid() + "], will generate new plan" );
    			returnStr = "/CI/readXML.do";
    			break;
    		case Remain:
    			logger.info("Plan exists with the system uuid [" + isExistSystem.getSystemuuid() + "], the ci configuration file needn't update");
    			returnStr = "/CI/execute.do";
    			break;
    		case Update:
    			logger.info("Plan exists with the system uuid [" + isExistSystem.getSystemuuid() + "], will update the ci configuration file ");
    			returnStr = "/CI/update.do";
    			break;
    		case Exception:
    			logger.error("Error while check the system status with the system uuid[" + isExistSystem.getSystemuuid() + "]");
    			returnStr = "../Error/ProjectUUIDOrSystemUUIDError.jsp";
    			break;
    		default: break;
		}
		return returnStr;
//	   if(staute.equals("New")){
//		   logger.info("Empty plan with the system uuid [" + isExistSystem.getSystemuuid() + "], will generate new plan" );
//		   return "/CI/readXML.do";
//		   
//	   }else if(staute.equals(TestType.Remain)){
//		   logger.info("Plan exists with the system uuid [" + isExistSystem.getSystemuuid() + "], the ci configuration file needn't update");
//		   return "/CI/execute.do";
//		   
//	   }else if(staute.equals("Update")){
//		   logger.info("Plan exists with the system uuid [" + isExistSystem.getSystemuuid() + "], will update the ci configuration file ");
//		   return "/CI/update.do";
//		   
//	   }else {
//		   logger.error("Error while check the system status with the system uuid[" + isExistSystem.getSystemuuid() + "]");
//		   return "../Error/ProjectUUIDOrSystemUUIDError.jsp";
//	   }
	}
	
	@ExceptionHandler(Exception.class)
	public String exception(Exception e, HttpServletRequest request){
		request.setAttribute("exception", e);
		logger.error(e.getMessage(),e);
		return "/view/error.jsp";
	}
}
