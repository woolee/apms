/**
 * Errors.java
 * 
 * Copyright (c) 2006 State Street Bank and Trust Corp.
 * 225 Franklin Street, Boston, MA 02110, U.S.A.
 * All rights reserved.
 *
 * "com.ssc.sstz.peg.ptaf.analysis.grinder is the copyrighted,
 * proprietary property of State Street Bank and Trust Company and its
 * subsidiaries and affiliates which retain all right, title and interest
 * therein."
 * 
 * Revision History
 *
 * Date            Programmer              Notes
 * ---------    ---------------------  --------------------------------------------
 * Feb 2, 2015		a549324				  initial
 */
package com.ssc.sshz.peg.ptaf.inspection.data;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.Annotations;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.io.xml.DomDriver;

/**
 * 
 * pojo mapping with the Error_hostname.xml
 * xml structure like:
 * <Errors>
 * 	<Error>
 * 	<Error>
 * 	<Error>
 * 	<Error>
 * 	...
 * </Errors>
 * @author a549324
 *
 */
@XStreamAlias("Errors")
public class Errors{
	private List<Error> list = new ArrayList<Error>();
	
	public List<Error> getErrors() {
		return list;
	}

	/**
	 * transform a xml to Errors pojo
	 * @param istream
	 * @return Errors
	 * @throws IOException
	 */
	public static Errors loadErrors(InputStream istream) throws IOException {
		XStream xstream = new XStream(new DomDriver());
		xstream.addImplicitCollection(Errors.class, "list");
		Annotations.configureAliases(xstream, Error.class);
		Annotations.configureAliases(xstream, Errors.class);
		return (Errors)xstream.fromXML(istream);
	}
	
	/**
	 * for a test
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		String file = "C:\\test\\Errors_hz47p4993334.xml";
		InputStream in = new FileInputStream(new File(file));
		Errors es = Errors.loadErrors(in);
		System.out.println(es.getErrors());
	}
}
