package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.CIScript;

public interface CIScriptMapper extends SqlMapper
{
	public List<CIScript> getAllCIScript();
	public void addCIScript(CIScript ciScript);
	public CIScript getCIScript(CIScript ciScript);
	public CIScript getCIScriptByConfigId(int cconfigId);
}
