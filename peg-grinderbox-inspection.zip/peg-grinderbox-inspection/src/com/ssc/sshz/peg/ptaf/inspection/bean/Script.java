package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;

@Entity
public class Script implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1770967010418602956L;
	/**
	 * 
	 */
	private Integer scriptId;
	private String scriptName;
	private byte[]  scriptFile;
	private boolean isValid;
	private Timestamp uploadTime;
	private Integer uploaderId;
	private String uploaderName;
	private String scriptDescription;

	public Integer getScriptId()
	{
		return scriptId;
	}

	public void setScriptId(Integer scriptId)
	{
		this.scriptId = scriptId;
	}

	public String getScriptName()
	{
		return scriptName;
	}

	public void setScriptName(String scriptName)
	{
		this.scriptName = scriptName;
	}

	public boolean isValid()
	{
		return isValid;
	}

	public void setValid(boolean isValid)
	{
		this.isValid = isValid;
	}

	public Timestamp getUploadTime()
	{
		return uploadTime;
	}

	public void setUploadTime(Timestamp uploadTime)
	{
		this.uploadTime = uploadTime;
	}

	public Integer getUploaderId()
	{
		return uploaderId;
	}

	public void setUploaderId(Integer uploaderId)
	{
		this.uploaderId = uploaderId;
	}

	public String getUploaderName()
	{
		return uploaderName;
	}

	public void setUploaderName(String uploaderName)
	{
		this.uploaderName = uploaderName;
	}

	public String getScriptDescription()
	{
		return scriptDescription;
	}

	public void setScriptDescription(String scriptDescription)
	{
		this.scriptDescription = scriptDescription;
	}

	public byte[] getScriptFile()
	{
		return scriptFile;
	}

	public void setScriptFile(byte[] scriptFile)
	{
		this.scriptFile = scriptFile;
	}

	public Script(Integer scriptId, String scriptName, byte[] scriptFile, boolean isValid, Timestamp uploadTime,
			Integer uploaderId, String uploaderName, String scriptDescription)
	{
		super();
		this.scriptId = scriptId;
		this.scriptName = scriptName;
		this.scriptFile = scriptFile;
		this.isValid = isValid;
		this.uploadTime = uploadTime;
		this.uploaderId = uploaderId;
		this.uploaderName = uploaderName;
		this.scriptDescription = scriptDescription;
	}

	public Script()
	{
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString(){
		return "Script [scriptId=" + scriptId + ", scriptName=" + scriptName
				+ ", scriptFile=" + scriptFile + ", isValid=" + isValid
				+ ", uploadTime=" + uploadTime + ", uploaderId=" + uploaderId
				+", uploaderName=" + uploaderName +", scriptDescription=" + scriptDescription +"]";
		
	}

}
