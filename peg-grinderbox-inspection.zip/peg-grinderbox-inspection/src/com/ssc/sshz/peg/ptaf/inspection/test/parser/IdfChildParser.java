package com.ssc.sshz.peg.ptaf.inspection.test.parser;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Outputs;

/**
 * This class is used for parsing child Idf, when mfa.IDF_Joiner is found in
 * parent Idf.
 * 
 * @author randhir
 * 
 */
public class IdfChildParser
{

    private ArrayList<Outputs> childOutputList = null;

    /**
     * 
     * @param childIdf
     * @return
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    public ArrayList<Outputs> getChildIdfOutputs(String childIdf, String joinerPath) throws ParserConfigurationException,
	    SAXException, IOException
    {
	String sourcePath = joinerPath + "/WEB-INF/dat/" + "IDF_" + childIdf + ".xml";
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	// Using factory get an instance of document builder
	DocumentBuilder docBuilder = dbf.newDocumentBuilder();

	// parse using builder to get DOM representation of the XML file
	Document document = docBuilder.parse(sourcePath);
	parseDocument(document);
	return childOutputList;
    }

    /**
     * 
     * @param document
     */
    private void parseDocument(Document document)
    {
	// get the root element
	Element rootElement = document.getDocumentElement();
	populateReqAttribute(rootElement);
    }

    /**
     * @param rootElement
     */
    private void populateReqAttribute(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("request");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the request element
		Element element = (Element) nodeList.item(0);
		String reqName = element.getAttribute("name");
		populateOutputAttribute(reqName, rootElement);
	    }
	}
    }

    /**
     * 
     * @param reqName
     * @param rootElement
     */
    private void populateOutputAttribute(String reqName, Element rootElement)
    {
	childOutputList = new ArrayList<Outputs>();
	NodeList nList = rootElement.getElementsByTagName("field");
	if (nList != null && nList.getLength() > 0)
	{
	    for (int i = 0; i < nList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nList.item(i);
		if ("map".equals(element.getParentNode().getNodeName()))
		{
		    String fieldName = reqName + "." + element.getAttribute("name");
		    String fieldType = "string";
		    // populate Outputs class and put it in the list
		    Outputs output = new Outputs();
		    output.setOutputName(fieldName);
		    output.setOutputType(fieldType);
		    output.setOutputDesc("");
		    childOutputList.add(output);
		}
	    }
	}
    }

}
