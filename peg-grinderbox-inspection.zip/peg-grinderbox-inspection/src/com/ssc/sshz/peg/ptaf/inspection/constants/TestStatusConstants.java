package com.ssc.sshz.peg.ptaf.inspection.constants;

public class TestStatusConstants
{
	public static final String UPDATE = "update";
	public static final String NEW = "new";
	public static final String REMAIN = "remain";
}
