/**
 * ErrorStatus.java
 * 
 * Copyright (c) 2006 State Street Bank and Trust Corp.
 * 225 Franklin Street, Boston, MA 02110, U.S.A.
 * All rights reserved.
 *
 * "com.ssc.sstz.peg.ptaf.analysis.grinder is the copyrighted,
 * proprietary property of State Street Bank and Trust Company and its
 * subsidiaries and affiliates which retain all right, title and interest
 * therein."
 * 
 * Revision History
 *
 * Date            Programmer              Notes
 * ---------    ---------------------  --------------------------------------------
 * Mar 4, 2013		a525883				  initial
 */
package com.ssc.sshz.peg.ptaf.inspection.data;

/**
 * @author a525883
 *
 */
public enum ErrorStatus {
	ERROR,
	FAILURE,
	EMPTY,
	OTHER
}
