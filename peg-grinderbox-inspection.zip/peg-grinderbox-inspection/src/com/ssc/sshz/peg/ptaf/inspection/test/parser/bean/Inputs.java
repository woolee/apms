package com.ssc.sshz.peg.ptaf.inspection.test.parser.bean;

/**
 * The getters and setter for the inputs for the IDF file
 * 
 * @author p472061
 * 
 */
public class Inputs
{

    private String inputName = "";
    private String inputType = "";
    private String inputOptional = "";
    private String inputDesc = "";

    /**
     * @return the inputName
     */
    public String getInputName()
    {
	return inputName;
    }

    /**
     * @param inputName
     *                the inputName to set
     */
    public void setInputName(String inputName)
    {
	this.inputName = inputName;
    }

    /**
     * @return the inputType
     */
    public String getInputType()
    {
	return inputType;
    }

    /**
     * @param inputType
     *                the inputType to set
     */
    public void setInputType(String inputType)
    {
	this.inputType = inputType;
    }

    /**
     * @return the inputOptional
     */
    public String getInputOptional()
    {
	return inputOptional;
    }

    /**
     * @param inputOptional
     *                the inputOptional to set
     */
    public void setInputOptional(String inputOptional)
    {
	this.inputOptional = inputOptional;
    }

    /**
     * @return the inputDesc
     */
    public String getInputDesc()
    {
	return inputDesc;
    }

    /**
     * @param inputDesc
     *                the inputDesc to set
     */
    public void setInputDesc(String inputDesc)
    {
	this.inputDesc = inputDesc;
    }
}
