package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.quartz.SchedulerException;
import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;

public interface RuntimeService<T>{
	
	public List<T> getAllRuntime() throws DataAccessException;
	public List<T> getRuntimeStrategyID(int strategyId) throws DataAccessException;
	public T getRuntime(T entity) throws DataAccessException;
	public T getRuntimeByUUID(String uuid) throws DataAccessException;
	public T getRuntimeById(int id) throws DataAccessException;
	public T getRuntimeByPlanId(int planId) throws DataAccessException;
	public boolean addRuntime(T entity) throws DataAccessException;
	public boolean delRuntimeById(int id) throws DataAccessException;
	public boolean createRuntime(User user, RuntimeTrigger rt, Project project, System system, Plan plan, T runtime,
			RuntimeTrigger runtimeTrigger, int runType, JobData jobData, TestBeanCollection collection, String intervalTime,
			String timeUnit, String strategyName, String date_from, String date_to, String repeatStr
			) throws Exception;
	boolean delRtAndRtTriggerByRuntimeId(int runtimeId) throws DataAccessException, SchedulerException;
	
}
