package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;


//@Component
@Entity
public class System implements Serializable{

	@Override
	public String toString() {
		return "System [systemId=" + systemId + ", systemName=" + systemName
				+ ", systemVersion=" + systemVersion + ", systemEnv="
				+ systemEnv + ", projectId=" + projectId + ", projectName="
				+ projectName + ", systemDescription=" + systemDescription
				+ "]";
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 6268807614810287519L;
	private Integer systemId;
	private String systemName;
	private String systemVersion;
	private String systemEnv;
	private Integer projectId;
	private String projectName;
	private String systemDescription;
	private String systemuuid;
	
	public String getSystemuuid() {
		return systemuuid;
	}
	public void setSystemuuid(String systemuuid) {
		this.systemuuid = systemuuid;
	}
	public Integer getSystemId() {
		return systemId;
	}
	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getSystemEnv() {
		return systemEnv;
	}
	public void setSystemEnv(String systemEnv) {
		this.systemEnv = systemEnv;
	}
	public String getSystemVersion() {
		return systemVersion;
	}
	public void setSystemVersion(String systemVersion) {
		this.systemVersion = systemVersion;
	}
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getSystemDescription() {
		return systemDescription;
	}
	public void setSystemDescription(String systemDescription) {
		this.systemDescription = systemDescription;
	}


	
	

}
