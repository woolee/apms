package com.ssc.sshz.peg.ptaf.inspection.dao;

import org.springframework.dao.DataAccessException;

public interface RequirementDao<T> {

	public boolean addRequirement(T entity) throws DataAccessException;
	public T getRequirementByItemId(int itemId) throws DataAccessException;
}
