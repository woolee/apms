package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;



import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.mapper.PlanScriptMapper;

public class PlanScriptQuartzService<T extends PlanScript> {
	private Logger logger = Logger.getLogger(getClass());
//	private SqlSession session = ConnectionFactory.openSession();
//	private PlanScriptMapper mapper = session.getMapper(PlanScriptMapper.class);
	

	@SuppressWarnings("unchecked")
	public List<T> getAllPlanScripts() throws Exception
	{
		List<T> object = null;
		SqlSession session = null;
		try{
			session = ConnectionFactory.openSession();
			PlanScriptMapper mapper = session.getMapper(PlanScriptMapper.class);
		object = (List<T>) mapper.getAllPlanScript();
		}
		catch(Exception e)
		{
			logger.error("exception while get all PlanScript from database",e);
			throw new Exception("exception while get all PlanScript from database",e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
		
	}


	@SuppressWarnings("unchecked")
	public T getPlanScript(T entity) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try{
			session = ConnectionFactory.openSession();
			PlanScriptMapper mapper = session.getMapper(PlanScriptMapper.class);
		object = (T) mapper.getPlanScript(entity);
		}
		catch(Exception e)
		{
			logger.error("exception while get PlanScript object from databse",e);
			throw new Exception("exception while get PlanScript object from databse",e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	public T getPlanScriptByPlanId(int planId) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try{
			session = ConnectionFactory.openSession();
			PlanScriptMapper mapper = session.getMapper(PlanScriptMapper.class);
		object = (T) mapper.getPlanScriptByPlanId(planId);
		}
		catch(Exception e)
		{
			logger.error("exception while get PlanScript object by plan id from databse",e);
			throw new Exception("exception while get PlanScript object by plan id from databse",e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}
	
	public boolean addPlanScript(T entity) throws Exception 
	{
		boolean flag = false;
		SqlSession session = null;
		try{
			session = ConnectionFactory.openSession();
			PlanScriptMapper mapper = session.getMapper(PlanScriptMapper.class);
			mapper.addPlanScript(entity);
			session.commit();
			flag = true; 
			} 
		catch(Exception e)
		{
			flag = false;
			logger.error("exception while add PlanScript object to databse",e);
			throw new Exception("exception while add PlanScript object to databse",e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}


}
