/**
 * Error.java
 * 
 * Copyright (c) 2006 State Street Bank and Trust Corp.
 * 225 Franklin Street, Boston, MA 02110, U.S.A.
 * All rights reserved.
 *
 * "com.ssc.sstz.peg.ptaf.analysis.grinder is the copyrighted,
 * proprietary property of State Street Bank and Trust Company and its
 * subsidiaries and affiliates which retain all right, title and interest
 * therein."
 * 
 * Revision History
 *
 * Date            Programmer              Notes
 * ---------    ---------------------  --------------------------------------------
 * Feb 2, 2015		a549324			  initial
 */

package com.ssc.sshz.peg.ptaf.inspection.data;
import com.ssc.sshz.peg.ptaf.inspection.data.ErrorStatus;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * 
 * 
 * @author a549324
 *
 */

@XStreamAlias("Error")
public class Error{
	@XStreamAlias("Thread")
	private String thread;
	
	@XStreamAlias("RequestName")
	private String requestName;
	
	@XStreamAlias("Status")
	private ErrorStatus status;
	
	@XStreamAlias("Request")
	private String request;
	
	@XStreamAlias("Response")
	private String response;
	
	public String getThread() {
		return thread;
	}

	public void setThread(String thread) {
		this.thread = thread;
	}

	public String getRequestName() {
		return requestName;
	}

	public void setRequestName(String requestName) {
		this.requestName = requestName;
	}

	public ErrorStatus getStatus() {
		return status;
	}

	public void setStatus(ErrorStatus status) {
		this.status = status;
	}

	public String getRequest() {
		return request;
	}

	public void setRequest(String request) {
		this.request = request;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("");
		sb.append("RequestName="+thread+" ");
		sb.append("Thread="+requestName+" ");
		sb.append("Status="+status+" ");
		sb.append("Request="+request+" ");
		sb.append("Response="+response+" ");
		return sb.toString();
	}
}

