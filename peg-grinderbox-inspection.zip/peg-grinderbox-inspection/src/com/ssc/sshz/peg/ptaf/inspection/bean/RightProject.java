package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class RightProject implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8985572156699480817L;
	private int relationId;
	private int rightId;
	private String rightName;
	private int projectId;
	private String projectName;
	public int getRelationId()
	{
		return relationId;
	}
	public void setRelationId(int relationId)
	{
		this.relationId = relationId;
	}
	public int getRightId()
	{
		return rightId;
	}
	public void setRightId(int rightId)
	{
		this.rightId = rightId;
	}
	public String getRightName()
	{
		return rightName;
	}
	public void setRightName(String rightName)
	{
		this.rightName = rightName;
	}
	public int getProjectId()
	{
		return projectId;
	}
	public void setProjectId(int projectId)
	{
		this.projectId = projectId;
	}
	public String getProjectName()
	{
		return projectName;
	}
	public void setProjectName(String projectName)
	{
		this.projectName = projectName;
	}
	
}
