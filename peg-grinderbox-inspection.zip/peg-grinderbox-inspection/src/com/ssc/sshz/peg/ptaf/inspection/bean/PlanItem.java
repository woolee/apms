package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;

//@Component
@Entity
public class PlanItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5280292135562213508L;

	private Integer relationId;
	private Integer planId;
	private String planName;
	private Integer itemId;
	private String itemName;
	private boolean itemIsValid;
	public boolean isItemIsValid() {
		return itemIsValid;
	}
	public void setItemIsValid(boolean itemIsValid) {
		this.itemIsValid = itemIsValid;
	}
	public Integer getRelationId() {
		return relationId;
	}
	public void setRelationId(Integer relationId) {
		this.relationId = relationId;
	}
	
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	@Override
	public String toString() {
		return "PlanItem [relationId=" + relationId + ", planId=" + planId
				+ ", planName=" + planName + ", itemId=" + itemId
				+ ", itemName=" + itemName + ", itemIsValid=" + itemIsValid
				+ "]";
	}

	

}
