package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;

public interface RequestStatisticsMapper extends SqlMapper
{
	public void addRequestStatistics(RequestStatistics statistics);
	
	public RequestStatistics getRequestStitistics(RequestStatistics statistics);
	
	public void updateRequestStitistics(RequestStatistics statistics);
	
	public List<RequestStatistics> getAllRequestStatistics();
	
	public List<RequestStatistics> getAllRequestStatisticsByItemId(int itemId);
	
	public List<RequestStatistics> getAllRequestStatisticsByBriefId(int briefId);
	
	public List<RequestStatistics> getAllRequestStatisticsByItemIdAndBriefId(RequestStatistics statistics);
}
