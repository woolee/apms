package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.dao.TestErrorDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.TestErrorMapper;

@Repository
public class TestErrorDaoImpl<T extends TestError> implements TestErrorDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private TestErrorMapper mapper;

	@Override
	public boolean addTestError(T entity)
	{
		boolean flag = false;
		try{
			String errorMesg = entity.getErrorMessage();
			String errorDet = entity.getErrorDetail();
			if(errorMesg.length() > 1000)
			{
				entity.setErrorMessage(errorMesg.substring(0, 1000));
			}
			if(errorDet.length() > 1000)
			{
				entity.setErrorDetail(errorDet.substring(0, 1000));
			}
			mapper.addTestError(entity);
			flag = true;
		}
		catch(Exception e)
		{
			
			flag = false;
			logger.error("Exception while add testError to database",e);
			throw new DaoException("Exception while add testError to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllTestError()
	{
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllTestError();
			}
		catch(Exception e)
		{
			logger.error("Exception while get all testError from database",e);
			throw new DaoException("Exception while get all testError from database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getTestError(T entity)
	{
		T obj=null;
		try{ 
			obj =(T) mapper.getTestError(entity);
			}
		catch(Exception e)
		{
			logger.error("Exception while get testError from database",e);
			throw new DaoException("Exception while get testError from database",e);
		}
		return obj;
	}

	@Override
	public List<T> getTestErrorByBriefId(int planId) throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getTestErrorByBriefId(planId);
			}
		catch(Exception e)
		{
			logger.error("Exception while get all testError from database",e);
			throw new DaoException("Exception while get all testError from database",e);
		}
		return entity;
	}

	@Override
	public List<T> getTestErrorByBriefAndType(T entity) throws DataAccessException {
		List<T> obj=null;
		try{ 
			obj = (List<T>) mapper.getTestErrorByBriefAndType(entity);
			}
		catch(Exception e)
		{
			logger.error("Exception while get testError from database",e);
			throw new DaoException("Exception while get testError from database",e);
		}
		return obj;
	}




}
