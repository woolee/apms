package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.ItemStatistics;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ItemStatisticsMapper;

public class ItemStatisticsQuartzService<T extends ItemStatistics>
{
	private Logger logger = Logger.getLogger(getClass());

	// private SqlSession session = ConnectionFactory.openSession();
	// private ItemStatisticsMapper mapper =
	// session.getMapper(ItemStatisticsMapper.class);

	@SuppressWarnings("unchecked")
	public List<T> getAllItemStatistics() throws Exception
	{
		List<T> object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ItemStatisticsMapper mapper = session.getMapper(ItemStatisticsMapper.class);
			object = (List<T>) mapper.getAllItemStatistics();
		}
		catch (Exception e)
		{
			logger.error("exception while get all ItemDetail from databse",e);
			throw new Exception("exception while get all ItemStatistics from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	public T getItemStatistics(T entity) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ItemStatisticsMapper mapper = session.getMapper(ItemStatisticsMapper.class);
			object = (T) mapper.getItemStitistics(entity);
		}
		catch (Exception e)
		{
			logger.error("exception while get ItemStatistics object from databse",e);
			throw new Exception("exception while get ItemStatistics object from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	public boolean addItemStatistics(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ItemStatisticsMapper mapper = session.getMapper(ItemStatisticsMapper.class);
			mapper.addItemStatistics(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while add ItemStatistics object to databse",e);
			throw new Exception("exception while add ItemStatistics object to databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	public boolean updateItemStatistics(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ItemStatisticsMapper mapper = session.getMapper(ItemStatisticsMapper.class);
			mapper.updateItemStitistics(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while update ItemStatistics object to databse",e);
			throw new Exception("exception while update ItemStatistics object to databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

}
