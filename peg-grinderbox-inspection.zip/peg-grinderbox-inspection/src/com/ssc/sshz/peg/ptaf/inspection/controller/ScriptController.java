package com.ssc.sshz.peg.ptaf.inspection.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssc.peg.ptt.engine.grinder.GrinderEngine;
import com.ssc.sshz.peg.ptaf.inspection.analysis.AnalyzeManager;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.data.Error;
import com.ssc.sshz.peg.ptaf.inspection.data.ErrorCount;
import com.ssc.sshz.peg.ptaf.inspection.data.ErrorStatus;
import com.ssc.sshz.peg.ptaf.inspection.data.Errors;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.util.AssetModifyUtil;

/**
 * 
 * @author a549324
 *
 */
@Controller
@RequestMapping("script")
public class ScriptController {
	private Logger logger = Logger.getLogger(ScriptController.class);
	
	/**
	 * Uploaded script run once, results are not stored in database.
	 * At the moment, only check the following file:
	 * 1.hostname-0-data.log null or not
	 * 2.hostname-0.log has error information
	 * 3.console.out error information
	 * 4.Errors_hostname.xml error count(only for IDF service)
	 * 
	 * @param httpSession
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("check")
	@ResponseBody
	public String checkAbleToRun(HttpSession httpSession,HttpServletRequest request,HttpServletResponse response,Model model) throws Exception{
		String returnMesg = null;
		
		List<Object> returnList = new ArrayList<Object>();
		boolean checkResponse = false;
		if("checked".equalsIgnoreCase(request.getParameter("checkresponse").toLowerCase()))
			checkResponse = true;
		String uncompressedScriptFolderPath = (String) httpSession.getAttribute("zipfileputpath");
		File assetFolder = new File(uncompressedScriptFolderPath);
		long current = System.currentTimeMillis();
		String outputFolderPath = FilePathConstants.OUTPUTTEMPPATH + "_" + current;
		JobData jobData = new JobData();
		jobData.setAsset(uncompressedScriptFolderPath);
		jobData.setOutput(outputFolderPath);
		jobData.setThreadsNum("1");
		jobData.setRunCount("1");
		
		// get the configuration file from asset folder for grinder
		// engine
		File configFolder = new File(assetFolder, "config");
		File[] files = configFolder.listFiles(new FilenameFilter()
		{
			@Override
			public boolean accept(File dir, String name)
			{
				return name.endsWith(".ptafproperties");
			}
		});
		
		
		// change the attributes in asset
		File propFile = null;
		try {
			propFile = AssetModifyUtil.getInstance().changeAssetAttr(files[0], jobData);
		} catch (Exception e) {
			logger.error("Exception while modify the asset ", e);
			
		}
		
		File scriptFolder = new File(assetFolder,"scripts");
		if(checkResponse)
			checkResponseAvailable(scriptFolder);
		
		//send the grinder.properties file to grinder engine
		GrinderEngine engine = new GrinderEngine();
		engine.run(propFile);
		
		// check the test output errors
		File outputFolder = new File(uncompressedScriptFolderPath);
		/*File outputFolder = new File("C:/test/output");*/
		List<Error> errorList = null;
		Map<String,List<Error>> errorMapByRequestName = null;
		if(checkResponse)
		{
			errorList = checkError(outputFolder);
			errorMapByRequestName = transListToMapByRequestName(errorList);
		}
		
		
		String errorMsg = new AnalyzeManager().getErrorMsg(outputFolder);
		
		if ((errorMsg == null || errorMsg.isEmpty()) && errorList.size() == 0 )
		{
			returnMesg = "Run successfully";
		}
		else if (errorList.size() != 0 )
		{
			returnMesg = "Errors occurs in run once check ";
		}
		else
		{
			returnMesg = "Exception occurs in run once check: "+ errorMsg;
		}
		returnList.add(returnMesg);
		
		httpSession.setAttribute("checkResponse", checkResponse);
		httpSession.setAttribute("outputPath", uncompressedScriptFolderPath);
		/*httpSession.setAttribute("outputPath", "C:/test/output");*/
		
		return JSONArray.fromObject(returnList).toString();
	}
	
	/**
	 * Reread the Error_hostname.xml file and get data to show tables in showErrors.jsp
	 * @param session
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/errors")
	public String getErrors(HttpSession session,HttpServletRequest request,HttpServletResponse response,Model model) throws IOException
	{
		boolean checkResponse = (Boolean) session.getAttribute("checkResponse");
		String outputPath = (String) session.getAttribute("outputPath");
		File outputFolder = new File(outputPath);
		List<Error> errorList = null;
		Map<String, ErrorCount> errorCountMap = null;
		Map<String,List<Error>> errorMapByRequestName = null;
		if(checkResponse){
			errorList = checkError(outputFolder);
			errorMapByRequestName = transListToMapByRequestName(errorList);
			errorCountMap = statisticErrorCount(errorList);
		}
		model.addAttribute("errorCountMap", errorCountMap);
		session.setAttribute("errorMapByRequestName", JSONArray.fromObject(errorMapByRequestName).toString());
		return "/view/showErrors.jsp";
	}
	/**
	 * Count error count classified by request name
	 * @param errorList
	 * @return
	 */
	private Map<String, ErrorCount> statisticErrorCount(List<Error> errorList)
	{
		Map<String, ErrorCount> errorCountMap = new HashMap<String, ErrorCount>();
		
		int errorCount = 0;
		int failureCount = 0;
		int emptyCount = 0;
		int otherCount = 0;
		
		for (Error error : errorList) {
			String requestName = error.getRequestName();
			ErrorCount ec = errorCountMap.get(requestName);
			if(ec == null)
				ec = new ErrorCount();
			
			ec.setRequestName(requestName);
			ErrorStatus status = error.getStatus();
			switch (status) {
			case ERROR:
				ec.setErrorCount(ec.getErrorCount()+1);//errorCount++
				errorCount++;
				break;
			case FAILURE:
				ec.setFailureCount(ec.getFailureCount()+1);//failureCount++
				failureCount++;
				break;
			case EMPTY:
				ec.setEmptyCount(ec.getEmptyCount()+1);//emptyCount++
				emptyCount++;
				break;
			case OTHER:
				ec.setOtherCount(ec.getOtherCount()+1);//otherCount++
				otherCount++;
				break;
			}
			errorCountMap.put(requestName, ec);
		}
		ErrorCount ec = new ErrorCount();
		ec.setErrorCount(errorCount);
		ec.setFailureCount(failureCount);
		ec.setEmptyCount(emptyCount);
		ec.setOtherCount(otherCount);
		errorCountMap.put("Total", ec);
		return errorCountMap;
	}
	
	/**
	 * get error list form  Errors_hostname.xml file
	 * 
	 * @param outputFolder
	 * @return
	 * @throws IOException
	 */
	private List<Error> checkError(File outputFolder) throws IOException{
		String localhostName = InetAddress.getLocalHost().getHostName().toLowerCase();
		String errorFileName = "Errors_" + localhostName + ".xml";
		File errorFile = new File(outputFolder,errorFileName);
		
		
		InputStream inStream;
		List<Error> errorList = null;
		try {
			inStream = new FileInputStream(errorFile);
			Errors errors = Errors.loadErrors(inStream); 
			errorList = errors.getErrors();
		} catch (FileNotFoundException e) {
			logger.error(errorFile.getAbsoluteFile() + "not found", e);
			throw e;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage(),e);
			throw e;
		}
		
		return errorList;
	}
	
	/**
	 * classify errors by request name, save to the map
	 * @param errorList
	 * @return
	 */
	private Map<String,List<Error>> transListToMapByRequestName(List<Error> errorList)
	{
		Map<String,List<Error>> map = new HashMap<String, List<Error>>();
		for (Error error : errorList) {
			if(map.get(error.getRequestName()) == null){
				List<Error> list = new ArrayList<Error>();
				list.add(error);
				map.put(error.getRequestName(), list);
			}
			else{
				map.get(error.getRequestName()).add(error);
			}
		}
		return map;
	}
	
	/**
	 * Enable the Check response function for cloud IDF request.
	 * 
	 * "self.checker.checkResponse()" function is disabled as default,
	 * Change "#self.checker.checkResponse()" to "self.checker.checkResponse()"
	 *
	 * @param scriptFolder
	 * @throws IOException
	 */
	private void checkResponseAvailable(File scriptFolder) throws IOException{
		String checkScriptMatchPattern = "(#[\\s]*self.checker.checkResponse)";
		String replaceString = "self.checker.checkResponse";
		StringBuilder strBuilder = new StringBuilder();
		//list the script files in script folder except Main.py
		File[] scriptFiles = scriptFolder.listFiles(new FilenameFilter() {
			
			@Override
			public boolean accept(File dir, String name) {
				return name.endsWith(".py") && !("Main.py".equalsIgnoreCase(name) || name.toLowerCase().contains("login".toLowerCase()));
			}
		});
		
		BufferedReader reader = null;
		BufferedWriter writer = null;
		Pattern pattern = Pattern.compile(checkScriptMatchPattern);
		Matcher matcher = null;
			try {
				for (File scriptFile : scriptFiles) {
					reader = new BufferedReader(new FileReader(scriptFile));
					String line;
					line = reader.readLine();
					while(line != null){
						strBuilder.append(line + "\n");
						line = reader.readLine();
					}
					
					writer = new BufferedWriter(new FileWriter(scriptFile));
					String[] lines = strBuilder.toString().split("\n");
					String writeLine = null;
					for (String lineSplit : lines) {
						writeLine = lineSplit;
						matcher = pattern.matcher(writeLine);
						if(matcher.find()){
							writeLine = writeLine.replace(matcher.group(1), replaceString);
						}
							
//						if(writeLine.contains(checkScriptMatchPattern))
//							writeLine = writeLine.replace(checkScriptMatchPattern, replaceString);
						writer.write(writeLine+"\n");
					}
					
					//clear StringBuilder
					strBuilder.setLength(0);
				}
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
				throw e;
			}
			finally{
				if(writer != null)
					writer.close();
				if(reader != null)
					reader.close();
			}
	}
}
