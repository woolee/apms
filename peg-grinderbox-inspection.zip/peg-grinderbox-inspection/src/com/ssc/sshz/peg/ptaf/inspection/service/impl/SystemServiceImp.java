package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.SystemDao;
import com.ssc.sshz.peg.ptaf.inspection.service.SystemService;

@Service

public class SystemServiceImp<T extends System> implements SystemService<T> {
	
	@Inject
	private SystemDao<T> dao;

	@Inject
	private PlanDao<Plan> planDao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addSystem(T entity) throws DataAccessException {
		return dao.addSystem(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getSystem(Integer id) throws DataAccessException {
		return dao.getSystemById(id);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean delSystem(T entity) throws DataAccessException {
		return dao.delSystemById(entity.getSystemId());
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllSystem() throws DataAccessException {
		return dao.getAllSystem();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getSystemByName(String name) throws DataAccessException {
		return dao.getSystemByName(name);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getSystemByPlanId(int planId) throws DataAccessException {
		Plan plan = planDao.getPlanById(planId);
		int systemId = plan.getSystemId();
		return dao.getSystemById(systemId);
	}

	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getSystemByProjectName(String name) throws DataAccessException {
		
		return dao.getSystemByProjectName(name);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getSystemByNameVersionEnv(System system)
			throws DataAccessException {
		
		return dao.getSystemByNameVersionEnv(system);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getSystemById(int Id) throws DataAccessException {
		return dao.getSystemById(Id);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getSystemByuuid(String Id) throws DataAccessException {
		return dao.getSystemByuuid(Id);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getSystemByProjectId(int id) throws DataAccessException {
		return dao.getSystemByProjectId(id);
	}
	
}
