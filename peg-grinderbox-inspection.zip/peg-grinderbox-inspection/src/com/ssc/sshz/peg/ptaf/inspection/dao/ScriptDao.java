package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface ScriptDao<T> {
	public boolean addScript(T entity) throws DataAccessException;
	public T getScriptById(Integer id) throws DataAccessException;
	public boolean delScriptById(Integer id)throws DataAccessException;
	public boolean delScriptByName(String name) throws DataAccessException;
	public List<T> getAllScript()throws DataAccessException;
	public T getScript(T entity)throws DataAccessException;
}
