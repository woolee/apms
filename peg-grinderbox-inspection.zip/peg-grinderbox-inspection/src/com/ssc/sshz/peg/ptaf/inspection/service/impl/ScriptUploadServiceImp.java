package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestDao;
import com.ssc.sshz.peg.ptaf.inspection.service.ScriptUploadService;
import com.ssc.sshz.peg.ptaf.inspection.util.AssetAnalyzeUtil;

@Service
public class ScriptUploadServiceImp implements ScriptUploadService
{
	@Inject
	private PlanItemDao<PlanItem> planItemDao;
	
	@Inject
	private ItemDao<Item> itemDao;
	
	@Inject
	private RequestDao<Request> requestDao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<Item> upload( int systemId, Plan plan,String zipfileputpath, Item item, PlanItem planItem) throws Exception
	{
		planItemDao.deletePlanItemByPlanId(plan.getPlanId());
		
		List<Item> itemlist =(List<Item>) readScripToDB(zipfileputpath,systemId,item);
		try {
			
			AssetAnalyzeUtil util =AssetAnalyzeUtil.getInstance();	
			//update planitem to DB
			for(int i=0;i<itemlist.size();i++){
				Item tempItem = itemDao.getItemBySystemIdItemName(itemlist.get(i));
				int itemid = tempItem.getItemId();
				planItem.setItemId(itemid);
				planItem.setItemIsValid(itemlist.get(i).isDeleted());
				planItem.setPlanName(plan.getPlanName());
				planItem.setPlanId(plan.getPlanId());
				planItem.setItemName(itemlist.get(i).getItemName());
				planItemDao.addPlanItem(planItem);
				
			    
			    List<String>   DBRequestURLlist=new ArrayList<String>();
			    List<String>   DocRequestURLlist=new ArrayList<String>();
			    Request tmpreq=new Request();
			    tmpreq.setItemId(itemid);
			    tmpreq.setPlanId(plan.getPlanId());
			    List<Request>  DBItemRequestlist = requestDao.getRequestByItemIdAndPlanId(tmpreq);
			    List<Request>  requestList = util.getAllRequests(itemlist.get(i).getItemName());
			    Map<String,String> rq=new HashMap<String,String>();
			    for(Request DocRequest : requestList){
			    	DocRequestURLlist.add(DocRequest.getRequestUrl());
			    	rq.put(DocRequest.getRequestUrl(), DocRequest.getRequestName());
				}
			    
				for(Request DBRequest : DBItemRequestlist){
					DBRequestURLlist.add(DBRequest.getRequestUrl());
				}
				for(int k=0;k<DocRequestURLlist.size();k++){
					
					if (!DBRequestURLlist.contains(DocRequestURLlist.get(k))){
						
						Request request1=new Request();
						request1.setRequestUrl(DocRequestURLlist.get(k));
						request1.setRequestName(rq.get(DocRequestURLlist.get(k)));
						request1.setItemName(itemlist.get(i).getItemName());
						request1.setItemId(itemid);
						request1.setPlanId(plan.getPlanId());
						requestDao.addRequest(request1);			
					   }
				}
				
			}

		} catch (Exception e) {
			throw e;
		}
		return itemlist;
	}
	
	private List<Item> readScripToDB(String zipfileputpath,int systemId,Item item) throws Exception{
		List<Item> itemList = new ArrayList<Item>();
		List<String> dbItemNamelist = new ArrayList<String>();
		
		AssetAnalyzeUtil util =AssetAnalyzeUtil.getInstance();
		util.setRootPath(zipfileputpath);
		List<String> itemNameList = util.getItems(util.getRunTime().getName());
		
		List<Item> dbItemlist = itemDao.getItemBySystemId(systemId);
		for(Item dbItem : dbItemlist){
			dbItemNamelist.add(dbItem.getItemName());
		}
		
		for(int i=0;i<itemNameList.size();i++){
		
			if (!dbItemNamelist.contains(itemNameList.get(i))){
//				Item tempItem=new Item();
				item.setItemName(itemNameList.get(i));
				item.setSystemId(systemId);
				item.setDeleted(false);
				itemDao.addItem(item);
				Item itemFromDB = itemDao.getItemBySystemIdItemName(item);
				itemList.add(itemFromDB);				
			   }else{
				item.setItemName(itemNameList.get(i));
				item.setSystemId(systemId);
				item.setDeleted(false);
				itemList.add(item);
			   }
		}
		return itemList;
	}
}
