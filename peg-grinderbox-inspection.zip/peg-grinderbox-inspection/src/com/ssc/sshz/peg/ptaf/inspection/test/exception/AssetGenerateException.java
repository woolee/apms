package com.ssc.sshz.peg.ptaf.inspection.test.exception;
 
public class AssetGenerateException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public AssetGenerateException(){
		super();
	}
	public AssetGenerateException(String s)
	{
		super(s);
	}
}
