package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;

public interface PlanScriptMapper extends SqlMapper{
	public List<PlanScript> getAllPlanScript(); 
	public PlanScript getPlanScript(PlanScript panScript);
	public void addPlanScript(PlanScript planScript);
	public PlanScript getPlanScriptByPlanId(int planId);
}
