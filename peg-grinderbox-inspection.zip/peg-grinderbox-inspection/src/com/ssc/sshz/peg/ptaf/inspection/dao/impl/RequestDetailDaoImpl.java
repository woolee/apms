package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.RequestDetail;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestDetailDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RequestDetailMapper;

@Repository
public class RequestDetailDaoImpl<T extends RequestDetail> implements RequestDetailDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RequestDetailMapper mapper;

	@Override
	public boolean addRequestDetail(T entity)
	{
		boolean flag = false;
		try{
			mapper.addRequestDetail(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while add RequestDetail to database",e);
			throw new DaoException("Exception while add RequestDetail to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllRequestDetail()
	{
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllRequestDetail();
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all RequestDetail from database",e);
			throw new DaoException("Exception while get all RequestDetail from database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getRequestDetail(T entity)
	{
		T obj = null;
		try{ 
			obj = (T) mapper.getRequestDetail(entity);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get RequestDetail from database",e);
			throw new DaoException("Exception while get RequestDetail from database",e);
		}
		return obj;
	}

	@Override
	public boolean updateRequestDetail(T entity)
	{
		boolean flag = false;
		try{
			mapper.updateRequestDetail(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while update RequestDetail to database",e);
			throw new DaoException("Exception while update RequestDetail to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllRequestDetailByPlanId(int planId) {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllRequestDetailByPlanId(planId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all RequestDetailby plan id from database",e);
			throw new DaoException("Exception while get all RequestDetail by plan id from database",e);
		}
		return entity;
	}

	@Override
	public List<T> getAllRequestDetailByRequestId(int requestId)
			throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllRequestDetailByRequestId(requestId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all RequestStatistics from database",e);
			throw new DaoException("Exception while get all RequestStatistics from database",e);
		}
		return entity;
	}

	@Override
	public List<T> getAllRequestDetailByRequestIdBriefId(T entity)
			throws DataAccessException {
		List<T> obj = null;
		try{ 
			obj = (List<T>) mapper.getAllRequestDetailByRequestIdBriefId(entity);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all RequestStatistics from database",e);
			throw new DaoException("Exception while get all RequestStatistics from database",e);
		}
		return obj;
	}


	

}
