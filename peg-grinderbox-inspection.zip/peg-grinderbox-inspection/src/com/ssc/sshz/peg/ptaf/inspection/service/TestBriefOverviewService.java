package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.BriefOverview;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;

public interface TestBriefOverviewService
{
	public List<BriefOverview> getBriefOverviewBySearch(TestBrief testBrief,int planId,String dateFrom, String dateTo) throws Exception;
	
}
