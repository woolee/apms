package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.Right;
import com.ssc.sshz.peg.ptaf.inspection.bean.RightProject;
import com.ssc.sshz.peg.ptaf.inspection.bean.UserRight;

public interface UserRightService<T> {

	public boolean addUserRight(T entity) throws DataAccessException;
	
	public List<T> getUserRightByUserId(int userId) throws DataAccessException;

	public void addRightAndUserRight(T entity, Right right, UserRight userRight, RightProject rightProject, String username,
			String projectName) throws DataAccessException;
}
