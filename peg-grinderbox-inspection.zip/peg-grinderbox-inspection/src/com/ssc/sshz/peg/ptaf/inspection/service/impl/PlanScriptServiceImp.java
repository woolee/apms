package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanScriptDao;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanScriptService;

@Service

public class PlanScriptServiceImp<T extends PlanScript> implements PlanScriptService<T> {
	
	@Inject
	private PlanScriptDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addPlanScript(T entity) throws DataAccessException {
		return dao.addPlanScript(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllPlanScript() throws DataAccessException {
		return dao.getAllPlanScript();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getPlanScript(T entity) throws DataAccessException {
		return dao.getPlanScript(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getPlanScriptByPlanId(int PlanId) throws DataAccessException {
		return dao.getPlanScriptByPlanId(PlanId);
	}

	
}
