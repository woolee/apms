package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestDao;
import com.ssc.sshz.peg.ptaf.inspection.service.RequestService;
@Service

public class RequestServiceImp<T extends Request> implements RequestService<T>
{
	@Inject
	private RequestDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addRequest(T entity) throws DataAccessException {
		return dao.addRequest(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Request getRequestByRequestName(String requetName)
			throws DataAccessException {
		return dao.getRequestByRequestName(requetName);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getRequestByItemIdAndPlanId(T entity)
			throws DataAccessException {
		return dao.getRequestByItemIdAndPlanId(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Request getRequestByRequestId(int requestId)
			throws DataAccessException {
		return dao.getRequestByRequestId(requestId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getRequestByPlanId(int PlanId) throws DataAccessException {
		return dao.getRequestByPlanId(PlanId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getRequestsByItemId(int id) throws DataAccessException {
		return dao.getRequestsByItemId(id);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateRequest(T entity) throws DataAccessException {
		// TODO Auto-generated method stub
		return false;
	}

	

	
}
