package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ssc.sshz.peg.ptaf.inspection.bean.QTMLogScan;

public interface QTMLogScanMapper extends SqlMapper
{
	public List<QTMLogScan> getAllQTMLogScan();
	
	public QTMLogScan getQTMLogScanById(int  id);
	
	public void addQTMLogScan(QTMLogScan scan);
	
	public void delQTMLogScanById(int id);
	
	public void updateQTMLogScanFile(@Param("errorFile")byte[] errorFile,@Param("scanId")int scanId);
	
	public void updateQTMLogScanProgress(@Param("executePercentage")int executePercentage, @Param("scanId")int scanId);
}
