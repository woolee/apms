package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;


//@Component
@Entity
public class Request implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = -9032390490944678025L;
	private Integer requestId;
	private String requestName;
	private Integer planId;
	private Integer itemId;
	private String itemName;
	private String  requestUrl;
	private String requestData;
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}
	public String getRequestName() {
		return requestName;
	}
	public void setRequestName(String requestName) {
		this.requestName = requestName;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getRequestUrl() {
		return requestUrl;
	}
	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}
	public String getRequestData() {
		return requestData;
	}
	public void setRequestData(String requestData) {
		this.requestData = requestData;
	}
	@Override
	public String toString() {
		return "Request [requestId=" + requestId + ", requestName="
				+ requestName + ", itemId=" + itemId + ", itemName=" + itemName
				+ ", requestUrl=" + requestUrl + ", requestData=" + requestData
				+ "]";
	}
	
}
