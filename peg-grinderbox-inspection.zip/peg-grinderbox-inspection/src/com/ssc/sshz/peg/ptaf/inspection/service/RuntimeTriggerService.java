package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.Project;

public interface RuntimeTriggerService<T>{
	public List<T> getAllRuntimeTrigger() throws DataAccessException;
	public T getRuntimeTriggerByRuntimeId(int runtimeId) throws DataAccessException;
	public boolean addRuntimeTrigger(T entity) throws DataAccessException;
	public boolean delRuntimeTriggerByRuntimeId(int runtimeId) throws DataAccessException;
	public boolean updateRuntimeTrigger(T entity) throws DataAccessException;
	public List<T> getJobStateByUser(String username) throws DataAccessException;
	public List<T> getJobStateByProjects(List<Project> projectList) throws DataAccessException;
	
}
