package com.ssc.sshz.peg.ptaf.inspection.dao.impl;
import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanItemDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.PlanItemMapper;

@Repository
public class PlanItemDaoImpl<T extends PlanItem> implements PlanItemDao<T>{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private PlanItemMapper mapper;

	@Override
	public boolean addPlanItem(T entity) throws DataAccessException {
		boolean flag = false;
		try {
			mapper.addPlanItem(entity); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while add planItem to database",e);
			throw new DaoException("Exception while add planItem to database",e);
		}
		return flag;
	}

	@Override
	public boolean updatePlanItem(T entity) {
		boolean flag = false;
		try{
			mapper.updatePlanItem(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while update PlanItem to database",e);
			throw new DaoException("Exception while update PlanItem to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getPlanItemByItemId(Integer id) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getPlanItemByItemId(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get PlanItem by item id from database",e);
			throw new DaoException("Exception while get PlanItem by item id from database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllPlanItem() throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllPlanItem();
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while add PlanItem to database",e);
			throw new DaoException("Exception while add PlanItem to database",e);
		}
		return entity;
		
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllPlanItemByPlanId(int planId) throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllPlanItemByPlanId(planId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get planItems by plan id from database",e);
			throw new DaoException("Exception while get planItems by plan id from database",e);
		}
		return entity;
		
	}

	@Override
	public List<T> getvalidPlanItemByPlanId(int planId)
			throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getvalidPlanItemByPlanId(planId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get planItems by plan id from database",e);
			throw new DaoException("Exception while get planItems by plan id from database",e);
		}
		return entity;
		
	}

	@Override
	public boolean deletePlanItemByPlanId(int planId)
			throws DataAccessException {
		boolean flag = false;
		try{
			mapper.DeletePlanItemByPlanId(planId);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while DeletePlanItemByPlanId to database",e);
			throw new DaoException("Exception while DeletePlanItemByPlanId to database",e);
		}
		return flag;
	}
}
