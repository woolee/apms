package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;

public interface ProjectService<T>
{
	public boolean addProject(T entity) throws DataAccessException;
	public boolean delProject(T entity) throws DataAccessException;
	public T getProject(T entity) throws DataAccessException;
	public T getProjectByName(String name) throws DataAccessException;
	public T getProjectById(int Id) throws DataAccessException;
	public T getProjectByuuid(String Id) throws DataAccessException;
	public List<T> getAllProject()  throws DataAccessException;
	public List<T> getAllProjectByUserName(String userName)  throws DataAccessException;
	public boolean addProjectByUserName(String name, T project) throws DataAccessException;
	public List<T> getProjectByGroup(List<? extends GrantedAuthority> groupList);
	public List<T> getProjectByRight(String username);
}
