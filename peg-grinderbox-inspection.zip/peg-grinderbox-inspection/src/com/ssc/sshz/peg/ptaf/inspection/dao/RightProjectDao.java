package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface RightProjectDao<T> {
	public boolean addRightProject(T entity) throws DataAccessException;

	public T getRightProjectByRightId(int rightId) throws DataAccessException;
	
	public T getRightProjectByRightName(String rightName) throws DataAccessException;
	
	public List<T> getALLRightProject() throws DataAccessException;
	
	public List<T> getRightProjectByUserId(int userId) throws DataAccessException;
	
	
}
