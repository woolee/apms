package com.ssc.sshz.peg.ptaf.inspection.analysis.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;

public class ResultSearchBean  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2121569344363124170L;
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public List<System> getSystem() {
		return system;
	}
	public void setSystem(List<System> system) {
		this.system = system;
	}
//	public List<Plan> getPlan() {
//		return plan;
//	}
//	public void setPlan(List<Plan> plan) {
//		this.plan = plan;
//	}
	@Override
	public String toString() {
		return "ViewUtilBean [projectName=" + projectName + ", system="
				+ system + ", plan=" + plan + "]";
	}
	public Map<String, List<Plan>> getPlan() {
		return plan;
	}
	public void setPlan(Map<String, List<Plan>> plan) {
		this.plan = plan;
	}
	public String projectName;
	public List<System> system;
//	public List<Plan> plan;
	public Map<String, List<Plan>> plan;
}
