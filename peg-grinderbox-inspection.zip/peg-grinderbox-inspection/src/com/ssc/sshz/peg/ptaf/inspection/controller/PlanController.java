package com.ssc.sshz.peg.ptaf.inspection.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.PlanDisplayBean;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.service.ItemService;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanDisplayBeanService;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanService;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanStrategyService;
import com.ssc.sshz.peg.ptaf.inspection.service.ProjectService;
import com.ssc.sshz.peg.ptaf.inspection.service.RuntimeService;
import com.ssc.sshz.peg.ptaf.inspection.service.SystemService;

@Controller
@RequestMapping("/plan")
public class PlanController
{
	private static final Logger logger = Logger.getLogger(PlanController.class);	
	@Inject
	private PlanService<Plan> planService;
	
	@Inject
	private SystemService<System> systemService;
	
	@Inject
	private ProjectService<Project> projectService;
	
	@Inject
	private RuntimeService<Runtime> runtimeService;
	
	@Inject
	private PlanStrategyService<PlanStrategy> planStrategyService;
	
	
	@Inject
	private ItemService<Item> itemService;
	

	@Inject
	private PlanDisplayBeanService<PlanDisplayBean> planDisplayBeanService;
	
	@RequestMapping("/CreatePlan")
	public String CreatePlan(Plan plan,HttpSession httpSession,HttpServletRequest  request,Script script ,PlanScript planScript,Model model,PlanItem planItem,Item item,Request request1) throws Exception{
			httpSession.setAttribute("planName",request.getParameter("planName"));
			httpSession.setAttribute("planDescription",request.getParameter("planDescription"));
			httpSession.setAttribute("isEnabled",request.getParameter("isEnabled"));
			httpSession.setAttribute("itemDescList",request.getParameter("itemDescString"));
			httpSession.setAttribute("itemRequirementString",request.getParameter("itemRequirementString"));
			return "/view/step4.jsp";
	}
		
	@RequestMapping("/GetPlan")
	public String GetPlan(Plan plan,Model model){
		model.addAttribute(planService.getPlan(plan));
		return "/view/showPlan.jsp";
	}
	
	@RequestMapping("/projectPageInit")
	public String ProjectInint(Model model){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//	    String name = auth.getName(); 
//	    List<? extends GrantedAuthority> groupList = (List)auth.getAuthorities();
		List<Project> projectList = projectService.getProjectByRight(auth.getName());
//		List<Project> projectList=projectService.getAllProjectByUserName(name);
		model.addAttribute("projects",projectList);
		return "../view/step1.jsp";
	}
	
	@RequestMapping("/managePlanPageInit")
	public String managePlanPageInit(Model model){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//		List<? extends GrantedAuthority> groupList = (List)auth.getAuthorities();
		List<Project> projectList = projectService.getProjectByRight(auth.getName());
//	    String name = auth.getName(); 
//		List<Project> projectList=projectService.getAllProjectByUserName(name);
		model.addAttribute("projects",projectList);
		return "../view/managePlan.jsp";
	}
	
	@RequestMapping("/ManagerPlanPageGetSystemList")
	public String ManagerPlanPageGetSystemList(Project project,Model model,HttpSession httpSession){
		model.addAttribute("systems",systemService.getSystemByProjectId(project.getProjectId()));
		return "/view/showSystem.jsp";
	}
	
	@RequestMapping("/showPlanByProjectAndSystem")
	public String ManagerPlanPageGetPlanList(PlanStrategy planStrategy,Runtime runtime,PlanScript planScript,Model model,HttpSession httpSession,HttpServletRequest  request) throws Exception{
//		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//	    String username = auth.getName();
	    
		int systemId = Integer.parseInt(request.getParameter("systemId"));
		
		List<PlanDisplayBean> pbList = planDisplayBeanService.getPlanBySystem(systemId, planStrategy, planScript, runtime);		
		model.addAttribute("pbList",pbList);	
		return "/view/showAjaxPlan.jsp";
	}
	
	@RequestMapping("/ManagerPlanPageExcuter")
	public String ManagerPlanPageExcuter(Project project,HttpSession httpSession,System system,PlanStrategy planStrategy, Runtime runtime, Plan plan,Model model,HttpServletRequest  request){
		int strategyId=Integer.parseInt(request.getParameter("strategyId"));
		int planId=Integer.parseInt(request.getParameter("planId"));
		planStrategy=planStrategyService.getPlanStrategyById(strategyId);
		List<Runtime> RuntimeList=runtimeService.getRuntimeStrategyID(strategyId);
		plan=planService.getPlanById(planId);
		system=systemService.getSystemById(plan.getSystemId());
		List<Item> itemList = itemService.getItemsByPlanId(planId);
		/*List <PlanItem> PlanItemList=planItemService.getAllPlanItemByPlanId(planId);
		List<Item> itemList=new ArrayList<Item>();
		for(int k=0;k<PlanItemList.size();k++){
			itemList.add(itemService.getItemById(PlanItemList.get(k).getItemId()));
		}*/
/*		String startTime=runtime.getStartTime().toString();
		String endTime=runtime.getEndTime().toString();
		String FromYearDate =startTime.substring(5, 7)+"/"+startTime.substring(8, 10)+"/"+startTime.substring(0, 4);
		String Fromhour=startTime.substring(11, 13);
		String FromMin=startTime.substring(14, 16);
		String ToYearDate =endTime.substring(5, 7)+"/"+endTime.substring(8, 10)+"/"+endTime.substring(0, 4);
		String Tohour=endTime.substring(11, 13);
		String ToMin=endTime.substring(14, 16);
		String runtimeTpye=null;
		int Type=runtime.getRunType();
		if(Type==1){
			runtimeTpye="1:  Infinit";
		}else if(Type==2){
			runtimeTpye="2:  Once";
		}else{
			runtimeTpye="3:  Sometimes";
		}*/
		model.addAttribute("system",system);
		model.addAttribute("plan",plan);
		model.addAttribute("itemList",itemList);
		model.addAttribute("planStrategy",planStrategy);
		model.addAttribute("RuntimeList",RuntimeList);
/*		model.addAttribute("runtimeTpye",runtimeTpye);
		model.addAttribute("runtimeIntervaltime",runtime.getIntervalTime());
		model.addAttribute("FromYearDate",FromYearDate);
		model.addAttribute("Fromhour",Fromhour);
		model.addAttribute("FromMin",FromMin);
		model.addAttribute("ToYearDate",ToYearDate);
		model.addAttribute("Tohour",Tohour);
		model.addAttribute("ToMin",ToMin);*/
		httpSession.setAttribute("scirptChangeplan",plan);
		Calendar now= Calendar.getInstance();
		String time=now.get(Calendar.MONTH)+1+"/"+ now.get(Calendar.DAY_OF_MONTH)+"/"+now.get(Calendar.YEAR);	
		model.addAttribute("time",time);
		return "/view/showPlan.jsp";
	}
	
	@RequestMapping("/SystemPageInint")
	public String SystemInint(Project project,Model model,HttpSession httpSession){
		model.addAttribute("systems",systemService.getSystemByProjectId(project.getProjectId()));
		httpSession.setAttribute("systemPageProjectid", project.getProjectId());
		httpSession.setAttribute("systemPageProjectName", project.getProjectName());
		return "/view/step2.jsp";
	}
	
	@RequestMapping("/PlanPageInint")
	public String planInint(System system,Model model,HttpSession httpSession){
		model.addAttribute("projectName",(String)httpSession.getAttribute("systemPageProjectName"));
		model.addAttribute("systemName",system.getSystemName());
		List<Plan> planList = planService.getPlanBySystemId(system.getSystemId());
		List<String> planNameList = new ArrayList<String>();
		for (Plan plan : planList)
		{
			planNameList.add(plan.getPlanName());
		}
		httpSession.setAttribute("systemId",system.getSystemId()+"");
		model.addAttribute("planNameList", planNameList);
		model.addAttribute("planNameArray", planNameList.toArray());
		return "/view/step3.jsp";
	}
	
	@RequestMapping("/GetAllPlan")
	public String GetAllPlan(Model model){
		List<Plan> plans=planService.getAllPlan();
		model.addAttribute("plans",plans);
		return "/page/managePlan.jsp";
	}
	
	@RequestMapping("/RemovePlan")
	public String DelPlan(Plan plan){
		planService.delPlan(plan);
		return "/view/success.jsp";
	}
	@ExceptionHandler(Exception.class)
	public String exception(Exception e, HttpServletRequest request){
		request.setAttribute("exception", e);
		return "/view/error.jsp";
	}
}
