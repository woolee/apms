package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.BriefOverview;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.ProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.SystemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.TestBriefDao;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.SubmitResultService;
import com.ssc.sshz.peg.ptaf.inspection.service.TestBriefOverviewService;

@Service
public class TestBriefOverviewServiceImp implements TestBriefOverviewService
{
	private static final Logger logger = Logger.getLogger(TestBriefOverviewServiceImp.class);
	
	@Inject
	private SystemDao<System> systemDao;
	
	@Inject
	private TestBriefDao<TestBrief> testBriefDao;
	
	@Inject
	private ProjectDao<Project> projectDao;
	
	@Inject
	private PlanDao<Plan> planDao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<BriefOverview> getBriefOverviewBySearch(TestBrief testBrief,int planId,String dateFrom, String dateTo) throws Exception
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			testBrief.setStartTime(sdf.parse(dateFrom));
			testBrief.setEndTime(sdf.parse(dateTo));
			testBrief.setPlanId(planId);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw e;
		}
		List<TestBrief> testbriefList = testBriefDao.getTestBriefByPlanIdStartTimeEndTime(testBrief);
		SubmitResultService submitResultService = new SubmitResultService();
		List<BriefOverview> briefOverviewList = new ArrayList<BriefOverview>();
		for (int i = 0; i < testbriefList.size(); i++) {
			Map<String, String> returnStatistics = submitResultService
					.getReturnStatistics(testbriefList.get(i).getBriefId());
			String totalServiceNum = returnStatistics
					.get("TOTAL_SERVICE_NUM");
			String passServiceNum = returnStatistics
					.get("PASSED_SERVICE_NUM");
			String failedServiceNum = returnStatistics
					.get("FAILED_SERVICE_NUM");
			String passRatio = returnStatistics.get("PASSED_RATE");
			BriefOverview bo = new BriefOverview();
			System sys = systemDao.getSystemById(planDao.getPlanById(testbriefList.get(i).getPlanId()).getSystemId());
			Project pro = projectDao.getProjectById(sys.getProjectId());
			bo.setProjectName(pro.getProjectName());
			bo.setSystemName(sys.getSystemName());
			bo.setStatus(testbriefList.get(i).getStatus());
			bo.setStartTime(sdf.format(testbriefList.get(i).getStartTime()));
			bo.setEndTime(sdf.format(testbriefList.get(i).getEndTime()));
			bo.setSuccessCount(passServiceNum);
			bo.setErrorCount(failedServiceNum);
			bo.setTotalRequests(totalServiceNum);
			bo.setBeiefId(testbriefList.get(i).getBriefId());
			bo.setSummaryId(testbriefList.get(i).getPlanName());
			briefOverviewList.add(bo);
		}
		return briefOverviewList;
	}
	
}
