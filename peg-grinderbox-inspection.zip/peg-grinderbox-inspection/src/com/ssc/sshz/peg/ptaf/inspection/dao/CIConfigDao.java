package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface CIConfigDao<T> {
	public boolean addCIConfig(T entity) throws DataAccessException;
	public T getCIConfigById(Integer id) throws DataAccessException;
	public T getCIConfigBySystemuuid(String uuid) throws DataAccessException;
	public boolean delCIConfigById(Integer id) throws DataAccessException;
	public List<T> getAllCIConfig() throws DataAccessException;
	public T getCIConfig(T entity) throws DataAccessException;
	public int getCIConfigCount(T entity) throws DataAccessException;
	public boolean updateCIConfig(T entity) throws DataAccessException;
	public T getCIConfigByMD5(T entity) throws DataAccessException;
}
