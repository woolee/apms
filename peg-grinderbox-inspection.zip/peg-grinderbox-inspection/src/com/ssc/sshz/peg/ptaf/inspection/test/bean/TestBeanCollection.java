package com.ssc.sshz.peg.ptaf.inspection.test.bean;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Requirement;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;

public class TestBeanCollection implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3200435714580246511L;
	private Project project;
	private System system;
	private Plan plan;
	private CIConfig ciConfig;
	private List<Item> itemList;
	private Map<Integer,List<Request>> requestMapByItemId;
	private TestBrief testBrief;
	private Map<Integer,Requirement> requirementMapByItemid;
//	private String username;
//	private String password;
//	private User user;

	public System getSystem()
	{
		return system;
	}
	public void setSystem(System system)
	{
		this.system = system;
	}
	public Plan getPlan()
	{
		return plan;
	}
	public Project getProject()
	{
		return project;
	}
	public void setProject(Project project)
	{
		this.project = project;
	}
	public void setPlan(Plan plan)
	{
		this.plan = plan;
	}
	public List<Item> getItemList()
	{
		return itemList;
	}
	public void setItemList(List<Item> itemList)
	{
		this.itemList = itemList;
	}
	public Map<Integer, List<Request>> getRequestMapByItemId()
	{
		return requestMapByItemId;
	}
	public void setRequestMapByItemId(Map<Integer, List<Request>> requestMapByItemId)
	{
		this.requestMapByItemId = requestMapByItemId;
	}
	public TestBrief getTestBrief()
	{
		return testBrief;
	}
	public void setTestBrief(TestBrief testBrief)
	{
		this.testBrief = testBrief;
	}
	
	public Map<Integer, Requirement> getRequirementMapByItemid()
	{
		return requirementMapByItemid;
	}
	public void setRequirementMapByItemid(Map<Integer, Requirement> requirementMapByItemid)
	{
		this.requirementMapByItemid = requirementMapByItemid;
	}
	//	public User getUser()
//	{
//		return user;
//	}
//	public void setUser(User user)
//	{
//		this.user = user;
//	}
//	public String getUsername()
//	{
//		return username;
//	}
//	public void setUsername(String username)
//	{
//		this.username = username;
//	}
//	public String getPassword()
//	{
//		return password;
//	}
//	public void setPassword(String password)
//	{
//		this.password = password;
//	}
	public CIConfig getCiConfig()
	{
		return ciConfig;
	}
	public void setCiConfig(CIConfig ciConfig)
	{
		this.ciConfig = ciConfig;
	}
}
