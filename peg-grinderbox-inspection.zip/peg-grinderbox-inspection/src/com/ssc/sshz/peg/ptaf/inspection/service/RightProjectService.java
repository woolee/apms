package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface RightProjectService<T>
{
	public boolean addRightProject(T entity) throws DataAccessException;

	public List<T> getAllRightProject() throws DataAccessException;
	
	public List<T> getRightProjectByUsername(String username) throws DataAccessException;
	public T getRightProjectByRightName(String rightName) throws DataAccessException;
}
