package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.service.impl.CIServiceImp;



public class CSVReader
{
	private static CSVReader instance = new CSVReader() ;
	private static final Logger logger = Logger.getLogger(CSVReader.class);
	private CSVReader(){}
	public static CSVReader getInstance(){
		return instance;
	}
	
	public List<String[]> getCSVLines(File file) throws IOException{
		
		List<String[]> arrList = new ArrayList<String[]>();
		BufferedReader reader = null;
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String headers = reader.readLine();
			if(headers != null && !headers.isEmpty())
			{
				String line = reader.readLine();
				while(line != null && !line.isEmpty())
				{
					String[] valus = line.split(",");
					arrList.add(valus);
					line = reader.readLine();
				}
				
			}
		}
		catch (FileNotFoundException e)
		{
			logger.error(e.getMessage(),e);
			throw new FileNotFoundException(e.getMessage());
		}
		catch (IOException e)
		{
			logger.error(e.getMessage(),e);
			throw new IOException(e.getMessage(),e);
		}
		finally{
			if(reader != null)
				reader.close();
		}
		return arrList;
	}
	
}
