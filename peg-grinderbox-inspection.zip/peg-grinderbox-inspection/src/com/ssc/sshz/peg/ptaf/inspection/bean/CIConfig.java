package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Arrays;

import javax.persistence.Entity;


//@Component
@Entity
public class CIConfig implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3213683715778676926L;
	private int configId;
	private String configName;
	private String configFileMd5;
	private byte[] configFile;
	private int createdBy;
	private String createTime;
	private String summaryId;
	public int getConfigId() {
		return configId;
	}
	public void setConfigId(int configId) {
		this.configId = configId;
	}
	public String getConfigName() {
		return configName;
	}
	public void setConfigName(String configName) {
		this.configName = configName;
	}
	public byte[] getConfigFile() {
		return configFile;
	}
	public void setConfigFile(byte[] configFile) {
		this.configFile = configFile;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	@Override
	public String toString() {
		return "CIConfig [configId=" + configId + ", configName=" + configName
				+ ", configFile=" + Arrays.toString(configFile)
				+ ", createdBy=" + createdBy + ", createTime=" + createTime
				+ "]";
	}
	public String getSummaryId()
	{
		return summaryId;
	}
	public void setSummaryId(String summaryId)
	{
		this.summaryId = summaryId;
	}
	public String getConfigFileMd5() {
		return configFileMd5;
	}
	public void setConfigFileMd5(String configFileMd5) {
		this.configFileMd5 = configFileMd5;
	}
}
