package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestStatisticsDao;
import com.ssc.sshz.peg.ptaf.inspection.service.RequestStatisticsService;
@Service

public class RequestStatisticsServiceImp<T extends RequestStatistics> implements RequestStatisticsService<T>
{
	@Inject
	private RequestStatisticsDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRequestStatistics() throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getAllRequestStatistics();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getRequestStatistics(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getRequestStatistics(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addRequestStatistics(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addRequestStatistics(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateRequestStatistics(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.updateRequesttatistics(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRequestStatisticsByItemId(int itemId)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllRequestStatisticsByItemId(itemId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRequestStatisticsByBriefId(int briefId)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllRequestStatisticsByBriefId(briefId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRequestStatisticsByItemIdAndBriefId(T entity)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllRequestStatisticsByItemIdAndBriefId(entity);
	}



	
}
