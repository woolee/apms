package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;



import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;
import com.ssc.sshz.peg.ptaf.inspection.bean.ItemStatistics;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.mapper.CIConfigMapper;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ItemStatisticsMapper;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ProjectMapper;
import com.ssc.sshz.peg.ptaf.inspection.mapper.TestBriefMapper;
public class SubmitResultService 
{
	Logger logger = Logger.getLogger(getClass());
//	private ProjectMapper projectMapper = session.getMapper(ProjectMapper.class);
//	private CIConfigMapper ciConfigMapper = session.getMapper(CIConfigMapper.class);
	public String getProjectName(String projectuuid) throws Exception{
		SqlSession session = ConnectionFactory.openSession();
		ProjectMapper projectMapper = session.getMapper(ProjectMapper.class);
		Project project = projectMapper.getProjectByuuid(projectuuid);
		if(project == null)
		{
			logger.error("cannot find the project with the project uuid" +  projectuuid + " from databse");
			throw new Exception("cannot find the project with the project uuid" +  projectuuid + " from databse");
		}
		if (session != null)
			session.close();
		//System.out.println(project.getProjectName());
		return project.getProjectName();
	}
	
	public String getSummaryId(String systemuuid) throws Exception{
		SqlSession session = ConnectionFactory.openSession();
		CIConfigMapper ciConfigMapper = session.getMapper(CIConfigMapper.class);
		CIConfig ciconfig = ciConfigMapper.getCIConfigBySystemuuid(systemuuid);
    	if(ciconfig == null)
    	{
    		logger.error("cannot find the ciconfig with the system uuid" +  systemuuid + " from databse");
    		throw new Exception("cannot find the ciconfig with the system uuid" +  systemuuid + " from databse");
        }
    	if (session != null)
    		session.close();
    	//System.out.println(ciconfig.getSummaryId());
	return ciconfig.getSummaryId();
}
	
//	private TestBriefMapper testBriefMapper = session.getMapper(TestBriefMapper.class);
	public Date getEndTime(String systemuuid) throws Exception{
		SqlSession session = ConnectionFactory.openSession();
		TestBriefMapper testBriefMapper = session.getMapper(TestBriefMapper.class);
		TestBrief testBrief = testBriefMapper.getTestBriefBySystemuuid(systemuuid);
		if(testBrief == null)
    	{
    		logger.error("cannot find the testBrief with the system uuid" +  systemuuid + " from databse");
    		throw new Exception("cannot find the testBrief with the system uuid" +  systemuuid + " from databse");
        }
		if (session != null)
    		session.close();
		//System.out.println(testBrief.getEndTime());
		return testBrief.getEndTime();
	}
	
//	private ItemStatisticsMapper itemStatisticsMapper = session.getMapper(ItemStatisticsMapper.class);
	public Map<String,String> getReturnStatistics(int briefId){
		SqlSession session = ConnectionFactory.openSession();
		ItemStatisticsMapper itemStatisticsMapper = session.getMapper(ItemStatisticsMapper.class);
		Map<String,String> statisticMap = new HashMap<String,String>();
		List<ItemStatistics> itemStatisticsList = itemStatisticsMapper.getItemStitisticsByBriefId(briefId);
		int totalServiceSum = 0;
		int totalErrorSum = 0;
		for(ItemStatistics itemStatistics : itemStatisticsList){
			totalServiceSum += itemStatistics.getExecutionCount();
			totalErrorSum += itemStatistics.getErrorCount();
			//System.out.println(itemStatistics.getExecutionCount());
			//System.out.println(itemStatistics.getErrorCount());
			//System.out.println(itemStatistics.getErrorRate());
		}
		//totalServiceSum = 123;
		//totalErrorSum = 23;
		statisticMap.put("TOTAL_SERVICE_NUM", String.valueOf(totalServiceSum));
		statisticMap.put("PASSED_SERVICE_NUM", String.valueOf(totalServiceSum - totalErrorSum));
		statisticMap.put("FAILED_SERVICE_NUM", String.valueOf(totalErrorSum));
		if(totalServiceSum == 0){
			statisticMap.put("PASSED_RATE","0.00" );
		}else{
			String PASSED_RATE = String.valueOf(Math.round(100*(float)(totalServiceSum - totalErrorSum)/totalServiceSum)/100);
			statisticMap.put("PASSED_RATE",PASSED_RATE );
		}
		if (session != null)
    		session.close();
		return statisticMap;
	}

//	//issue retains
//	private RequestDetailMapper mapper = session.getMapper(RequestDetailMapper.class);
//	public void getRequestDetailBySystemuuid(){
//		RequestDetail requestDetail = mapper.getRequestDetailBySystemuuid("1ea513a2-4e5f-1032-95a9-8e580b32d69e");
//		System.out.println(requestDetail.getReturnCode());
//	}
	

	



//	public static void main(String args[]){
//		ResultSubmitService resultSubmitService = new ResultSubmitService();
//		//System.out.println(resultSubmitService.getProjectName("d900c033-4e5e-1032-95a9-8e580b32d69f"));
//		//System.out.println(resultSubmitService.getSummaryId("1ea513a2-4e5f-1032-95a9-8e580b32d69e"));
//		//System.out.println(resultSubmitService.getEndTime("1ea513a2-4e5f-1032-95a9-8e580b32d69e"));
//		System.out.println(resultSubmitService.getItemStatistics("1ea513a2-4e5f-1032-95a9-8e580b32d69e"));
//		
//		
//	}
	



	
}
