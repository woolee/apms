package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.RightProject;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.dao.ProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.TestBriefDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.service.TestBriefService;
@Service
public class TestBriefServiceImp<T extends TestBrief> implements TestBriefService<T>
{
	@Inject
	private TestBriefDao<T> dao;

	@Inject
	private RightProjectDao<RightProject> rightProjectDao;
	
	@Inject
	private ProjectDao<Project> projectDao;
	
	@Inject
	private UserDao<User> userDao;
	
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllTestBreif() throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getAllTestBrief();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getTestBreif(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getTestBrief(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addTestBreif(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addTestBrief(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateTestBreif(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.updateTestBrief(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateTestBreifStatus(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.updateTestBriefStatus(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getLatestTestBriefByExecutorId(int executorId)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getLatestTestBriefByExecutorId(executorId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getTestBriefBySystemuuid(String systemuuid) {
		// TODO Auto-generated method stub
		return dao.getTestBriefBySystemuuid(systemuuid);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean checkTestBriefExsitBySummaryId(String summaryId)
	{
		
		int count = dao.getAllTestBriefCountBySummaryId(summaryId);
		return count != 0;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getTestBreifByPlanId(int planId) throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getTestBriefByPlanId(planId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getTestBreifBybreifId(int breifId) throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getTestBriefByBriefId(breifId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getTestBriefByPlanIdStartTimeEndTime(T entity)
			throws DataAccessException {
		return dao.getTestBriefByPlanIdStartTimeEndTime(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getTestBriefByGroup(List<? extends GrantedAuthority> authorityList)
	{
		List<T> briefList = new ArrayList<T>();
		List<? extends GrantedAuthority> rightList = new ArrayList<GrantedAuthority>(authorityList);
		for (int i = rightList.size() -1 ; i >= 0; i--)
		{
			if("ROLE_USER".equals(rightList.get(i).getAuthority()))
			{
				rightList.remove(i);
				break;
			}
		}
		for (GrantedAuthority grantedAuthority : rightList)
		{
			String rightName = grantedAuthority.getAuthority();
			RightProject rightProject = rightProjectDao.getRightProjectByRightName(rightName);
			String projectName = projectDao.getProjectById(rightProject.getProjectId()).getProjectName();
			briefList.addAll(dao.getTestBriefByProjectName(projectName));
			
		}
		return briefList;
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getTestBriefByRight(String username)
	{
		User user = userDao.getUserByName(username);
		List<RightProject> rightProjectList = rightProjectDao.getRightProjectByUserId(user.getUserId());
		List<TestBrief> briefList = new ArrayList<TestBrief>();
		for (RightProject rightProject : rightProjectList)
		{
			List<TestBrief> birefListByProjectName =  (List<TestBrief>) dao.getTestBriefByProjectName(rightProject.getProjectName());
			if(birefListByProjectName.size() != 0)
			briefList.addAll(birefListByProjectName);
		}
		return (List<T>) briefList;
	}
	
}
