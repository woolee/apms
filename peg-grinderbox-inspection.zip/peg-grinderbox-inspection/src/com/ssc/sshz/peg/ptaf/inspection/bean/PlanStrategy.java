package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;


//@Component
@Entity
public class PlanStrategy implements Serializable{

	private static final long serialVersionUID = -5070771590074688213L;
	
	private Integer strategyId;
	private String strategyName;
	private Integer planId;
	private String planName;
	private Integer strategyLoad;
	private Integer loopCount;
	private String strategyDescription;
	@Override
	public String toString() {
		return "PlanStrategy [strategyId=" + strategyId + ", strategyName="
				+ strategyName + ", planId=" + planId + ", planName="
				+ planName + ", strategyLoad=" + strategyLoad + ", loopCount=" + loopCount
				+ ", strategyDescription=" + strategyDescription + "]";
	}
	public Integer getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}
	public String getStrategyName() {
		return strategyName;
	}
	public void setStrategyName(String strategyName) {
		this.strategyName = strategyName;
	}
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Integer getStrategyLoad() {
		return strategyLoad;
	}
	public void setStrategyLoad(Integer strategyLoad) {
		this.strategyLoad = strategyLoad;
	}
	public Integer getLoopCount() {
		return loopCount;
	}
	public void setLoopCount(Integer loopCount) {
		this.loopCount = loopCount;
	}
	public String getStrategyDescription() {
		return strategyDescription;
	}
	public void setStrategyDescription(String strategyDescription) {
		this.strategyDescription = strategyDescription;
	}
	
}
	
