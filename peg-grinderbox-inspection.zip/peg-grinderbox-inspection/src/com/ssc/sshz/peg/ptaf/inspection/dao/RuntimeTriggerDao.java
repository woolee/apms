package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;

public interface RuntimeTriggerDao<T> {
	public List<T> getAllRuntimeTrigger() throws DataAccessException;
	public T getRuntimeTriggerByRuntimeId(int runtimeId) throws DataAccessException;
	public boolean addRuntimeTrigger(T entity) throws DataAccessException;
	public boolean delRuntimeTriggerByRuntimeId(int runtimeId) throws DataAccessException;
	public boolean updateRuntimeTrigger(T entity) throws DataAccessException;
	public List<T> getJobStateByUser(String username) throws DataAccessException;
	public List<T> getJobStateByProjectName(String projectName)throws DataAccessException;
}
