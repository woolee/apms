package com.ssc.sshz.peg.ptaf.inspection.service;

import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.constants.TestType;

public interface CIService {
	public String ReadXMLWriteToDB(Project project, System system, Item item, Request request,Plan plan,User user,PlanItem planItem,String configTempPath,PlanStrategy planStrategy,Runtime runtime,  TestBrief testBrief, String configZipPath, String summaryId, TestError testError, CIConfig ciConfig,RuntimeTrigger runtimeTrigger)throws Exception;
   public TestType CheckPorjectSystem(Project dbproject, System dbsystem,String MD5,String filepath);
   public String Execute(String configTempPath,TestBrief testBrief,User user,System system,Plan plan,Project project, String configZipPath, String summaryId,TestError testError,CIConfig ciConfig,RuntimeTrigger runtimeTrigger)throws Exception;
   public String update(Project project, System system, Item item, Request request,Plan plan,User user,PlanItem planItem,String configTempPath,PlanStrategy planStrategy,Runtime runtime,  TestBrief testBrief, String configZipPath, String summaryId,TestError testError,CIConfig ciConfig,RuntimeTrigger runtimeTrigger)throws Exception;
}
