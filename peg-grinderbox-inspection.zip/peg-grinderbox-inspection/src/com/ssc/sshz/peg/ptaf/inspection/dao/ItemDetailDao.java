package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface ItemDetailDao<T> {
	public boolean addItemDetail(T entity) throws DataAccessException;
	public List<T> getAllItemDetail()throws DataAccessException;
	public List<T> getAllItemDetailByPlanId(int planId)throws DataAccessException;
	public List<T> getAllItemDetailByItemId(int itemId)throws DataAccessException;
	public List<T> getAllItemDetailByItemIdAndBriefId(T entity)throws DataAccessException;
	public T getItemDetails(T entity)throws DataAccessException;
	public boolean updateItemDetail(T entity) throws DataAccessException;
}
