package com.ssc.sshz.peg.ptaf.inspection.quartz.job;

import static com.ssc.sshz.peg.ptaf.inspection.constants.ErrorType.INSIDE;
import static com.ssc.sshz.peg.ptaf.inspection.constants.ErrorType.OUTSIDE;
import static com.ssc.sshz.peg.ptaf.inspection.constants.TestBriefStatusConstants.TESTEXCEPTION;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.ssc.cloud.Client;
import com.ssc.cloud.ProcessException;
import com.ssc.cloud.ResultSet;
import com.ssc.cloud.ResultSetException;
import com.ssc.cloud.SignOnException;
import com.ssc.faw.util.GenException;
import com.ssc.faw.util.PwMatrixUtil;
import com.ssc.peg.ptt.engine.grinder.GrinderEngine;
import com.ssc.sshz.peg.ptaf.inspection.analysis.AnalyzeManager;
import com.ssc.sshz.peg.ptaf.inspection.analysis.data.DataImport;
import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;
import com.ssc.sshz.peg.ptaf.inspection.bean.CIScript;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.cloud.CloudSignOn;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.constants.TestBriefStatusConstants;
import com.ssc.sshz.peg.ptaf.inspection.exception.ServerCheckException;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.CIScriptQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.PlanScriptQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.ScriptQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.SubmitResultService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.TestBriefQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.TestErrorQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;
import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;
import com.ssc.sshz.peg.ptaf.inspection.test.exception.AssetGenerateException;
import com.ssc.sshz.peg.ptaf.inspection.test.exception.IdfFileNameException;
import com.ssc.sshz.peg.ptaf.inspection.test.exception.InputParamException;
import com.ssc.sshz.peg.ptaf.inspection.test.exception.ParameterException;
import com.ssc.sshz.peg.ptaf.inspection.test.exception.PerformanRunException;
import com.ssc.sshz.peg.ptaf.inspection.test.generator.AssetGenerator;
import com.ssc.sshz.peg.ptaf.inspection.test.generator.bean.LoginScriptParamBean;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.IdfXmlParser;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Idf;
import com.ssc.sshz.peg.ptaf.inspection.util.AssetAnalyzeUtil;
import com.ssc.sshz.peg.ptaf.inspection.util.CSVReader;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;
import com.ssc.sshz.peg.ptaf.inspection.util.FileZip;
import com.ssc.sshz.peg.ptaf.inspection.util.ReadXMLUtil;
import com.ssc.sshz.peg.ptaf.inspection.util.AssetModifyUtil;

// @PersistJobDataAfterExecution
// @DisallowConcurrentExecution
public class PerformanceRunJob implements Job
{

	private static Logger log = Logger.getLogger(PerformanceRunJob.class);

	private TestErrorQuartzService<TestError> testErrorService = new TestErrorQuartzService<TestError>();
	private ScriptQuartzService<Script> scriptService = new ScriptQuartzService<Script>();
	private PlanScriptQuartzService<PlanScript> planScriptService = new PlanScriptQuartzService<PlanScript>();
	private TestBriefQuartzService<TestBrief> testBriefSerivce = new TestBriefQuartzService<TestBrief>();
	private CIScriptQuartzService<CIScript> ciScriptService = new CIScriptQuartzService<CIScript>();

	private JobData jobData;
	// private String assetZip;
	private TestBeanCollection collection;

	public void doExecute() throws Exception
	{
		log.info("staring performance build with summary id [" + jobData.getSummaryId() + "]...");

		validate();

		cleanUp();

		checkServerBeforeExecute();

		// generate asset
		File grinderProp = generateAssetAndInsert();

		// run engine
		runEngineAndUpdate(grinderProp);

		// analyze result
		analyze();

		boolean submitFlag = submitData();
		if (!submitFlag)
		{
			log.error("sumbit test result failed!");
		}

		// tear down
		tearDown();

		log.info("performance build completed with summary id [" + jobData.getSummaryId() + "]");
	}

	private void checkServerBeforeExecute() throws Exception
	{
		ReadXMLUtil xmlReader = new ReadXMLUtil();
		String url = xmlReader.getRequestURL(jobData.getConfigPath()).get(0);
		String userDat = jobData.getConfigPath() + "/user.csv";
		File userFile = new File(userDat);
		List<String[]> lines = null;
		try
		{
			lines = CSVReader.getInstance().getCSVLines(userFile);
			String username = null;
			String password = null;
			if (lines.size() != 0)
			{
				username = lines.get(0)[0];
				password = lines.get(0)[1];
			}
			String errorPage = CloudSignOn.getInstance().checkServer(url, username, password);
			if (errorPage != null && !errorPage.isEmpty())
			{
				updateStatusException();
				ServerCheckException e = new ServerCheckException("Server:" + url + " is unavaliable");
				updateTestError(e, OUTSIDE);
				throw e;
			}
			else
			{
				log.info("check " + url + " finished. Result: available");
			}
		}
		catch (IOException e)
		{
			log.error(e.getMessage());
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw new IOException(e.getMessage(), e);
		}
		catch (InterruptedException e)
		{
			log.error(e.getMessage());
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw new InterruptedException(e.getMessage());
		}

	}

	private void validate() throws Exception
	{
		// path attributes check
		if (jobData.getConfigPath() != null && !new File(jobData.getConfigPath()).exists())
		{
			CIConfig ciConfig = collection.getCiConfig();
			byte[] bFile = ciConfig.getConfigFile();
			File configZipFile = new File(jobData.getConfigZipPath());
			if (!configZipFile.exists())
			{
				configZipFile.getParentFile().mkdirs();
				configZipFile.createNewFile();
			}
			FileOutputStream out = new FileOutputStream(configZipFile);
			out.write(bFile);
			jobData.setConfigPath(new FileZip().unzip(jobData.getConfigZipPath(), new File(jobData.getConfigPath()).getParent()));
			if (!new File(jobData.getConfigPath()).exists())
			{
				log.error("Configuartion temp path \"" + jobData.getConfigPath() + "\" does not exist");
				updateStatusException();
				throw new FileNotFoundException("Path \"" + jobData.getConfigPath() + "\" does not exist");
			}
		}
		if (jobData.getNeedLogin() != null && Boolean.parseBoolean(jobData.getNeedLogin()))
		{
			if (jobData.getUsername() == null || jobData.getPassword() == null || "".equals(jobData.getPassword())
					|| "".equals(jobData.getUsername()))
			{
				log.error("Provided username or password is empty");
				updateStatusException();
				throw new ParameterException("Provided username or password is empty");
			}
		}

		// test scenario attributes check
		try
		{
			Integer.parseInt(jobData.getThreadsNum());
			Integer.parseInt(jobData.getRunCount());
			Integer.parseInt(jobData.getThinkTime());
		}
		catch (NumberFormatException e)
		{
			log.error("Integer parse error " + e.getMessage());
			updateStatusException();
			throw e;
		}

		if (Integer.parseInt(jobData.getThreadsNum()) <= 0 || Integer.parseInt(jobData.getRunCount()) <= 0
				|| Integer.parseInt(jobData.getThinkTime()) < 0)
		{
			log.error("Ant parameters \"threadNum\" and \"runCount\" must be positive integers, and \"thinkTime\" must be non-negative !");
			updateStatusException();
			throw new ParameterException(
					"Ant parameters \"threadNum\" and \"runCount\" must be positive integers, and \"thinkTime\" must be non-negative!");
		}
	}

	private File generateAssetAndInsert() throws Exception
	{
		// update test brief status
		TestBrief testBrief = collection.getTestBrief();
		testBrief.setStatus(TestBriefStatusConstants.STARTGENERATEASSET);
		collection.setTestBrief(testBrief);
		try
		{
			testBriefSerivce.updateTestBreifStatus(testBrief);

		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw new Exception(e.getMessage(), e);
		}

		log.info("Start generate asset with summary id [" + jobData.getSummaryId() + "].....");

		Script tempScript = null;

		// new script and set the uploader and uploaderName
		Script script = new Script();
		script.setUploaderId(jobData.getUser().getUserId());
		script.setUploaderName(jobData.getUser().getUserName());
		script.setValid(true);

		File grinderProp = null;

		try
		{
			switch (jobData.getConfigStatus())
			{
			case New:
			{
				log.debug("configStatus = new");

				// insert CI_config
				log.debug("configZipPath=" + jobData.getConfigZipPath());
				CIConfig ciConfig = collection.getCiConfig();

				CIScript ciScript = ciScriptService.getCIScriptByConfigId(ciConfig.getConfigId());
				if (ciScript != null)
				{
					int scriptId = ciScript.getScriptId();
					tempScript = scriptService.getScriptById(scriptId);
					byte[] scriptByteArr = tempScript.getScriptFile();
					String assetZipPath = new File(jobData.getConfigZipPath()).getParent() + File.separator
							+ tempScript.getScriptName();

					// unzip script file
					FileOutputStream out = new FileOutputStream(new File(assetZipPath));
					out.write(scriptByteArr);
					out.close();

					FileUtil.getInstance().delFolder(new File(jobData.getAsset()));
					FileZip.unzip(assetZipPath, new File(jobData.getConfigZipPath()).getParent());
					jobData.setAsset(assetZipPath.substring(0, assetZipPath.lastIndexOf(FileZip.ZIP)));
					FileUtil.getInstance().changePropValue(new File(jobData.getAsset(), TestAssetContants.GRINDER_PROPERTIES),
							TestAssetContants.GRINDER_LOGDIRECTORY, jobData.getOutput());
					jobData.setAssetZip(assetZipPath);

					grinderProp = new File(jobData.getAsset(), TestAssetContants.GRINDER_PROPERTIES);
				}
				else
				{
					// generate test scripts
					grinderProp = generateAsset();
					String assetFolderPath = jobData.getAsset();

					// add scipt to script DB table
					FileZip.doZip(assetFolderPath, assetFolderPath + FileZip.ZIP);
					jobData.setAssetZip(assetFolderPath + FileZip.ZIP);
					File zipAssetFolder = new File(assetFolderPath + FileZip.ZIP);
					byte[] bFile = new byte[(int) zipAssetFolder.length()];
					FileInputStream in = new FileInputStream(zipAssetFolder);
					in.read(bFile);
					if (in != null)
						in.close();
					script.setScriptName(zipAssetFolder.getName());
					script.setScriptFile(bFile);
					log.debug(script);
					scriptService.addScript(script);

					// get script from DB
					tempScript = scriptService.getScript(script);

					// insert ci script
					CIScript tempCIScript = new CIScript();
					tempCIScript.setScriptId(tempScript.getScriptId());
					tempCIScript.setConfigId(ciConfig.getConfigId());
					ciScriptService.addCIScript(tempCIScript);

					// add plan script to database
					PlanScript planScript = new PlanScript();
					planScript.setPlanId(collection.getPlan().getPlanId());
					planScript.setPlanName(collection.getPlan().getPlanName());
					planScript.setScriptId(tempScript.getScriptId());
					planScript.setScriptName(tempScript.getScriptName());
					planScriptService.addPlanScript(planScript);

				}
				break;
			}
			case Update:
			{
				log.debug("configStatus = update");
				// get ci config
				CIConfig ciConfig = collection.getCiConfig();

				// generate test scripts
				grinderProp = generateAsset();
				String assetFolderPath = jobData.getAsset();

				// update scipt to script DB table
				FileZip.doZip(assetFolderPath, assetFolderPath + FileZip.ZIP);
				jobData.setAssetZip(assetFolderPath + FileZip.ZIP);
				File zipAssetFolder = new File(assetFolderPath + FileZip.ZIP);
				byte[] bFile = new byte[(int) zipAssetFolder.length()];
				FileInputStream in = new FileInputStream(zipAssetFolder);
				in.read(bFile);
				if(in != null)
					in.close();
				script.setScriptName(zipAssetFolder.getName());
				script.setScriptFile(bFile);

				// get script Id
				int ciConfigId = ciConfig.getConfigId();
				CIScript ciScript = ciScriptService.getCIScriptByConfigId(ciConfigId);
				if (ciScript != null)
				{
					int scriptId = ciScriptService.getCIScriptByConfigId(ciConfigId).getScriptId();

					script.setScriptId(scriptId);
					scriptService.updateScript(script);
				}
				else
				{
					scriptService.addScript(script);
					script = scriptService.getScript(script);
					ciScript = new CIScript();
					ciScript.setConfigId(ciConfigId);
					ciScript.setScriptId(script.getScriptId());
					ciScriptService.addCIScript(ciScript);
					ciScript = ciScriptService.getCIScript(ciScript);
				}
				break;
			}
			case Remain:
			{
				log.debug("configStatus = none");
				// ci config from DB
				// CIConfig ciConfigFromDB =
				// ciConfigService.getCIConfigBySystemuuid(collection.getSystem().getSystemuuid());
				CIConfig ciConfig = collection.getCiConfig();
				int ciConfigId = ciConfig.getConfigId();
				log.debug("ciConfigId=" + ciConfigId);
				int scriptId = ciScriptService.getCIScriptByConfigId(ciConfigId).getScriptId();

				// get script
				tempScript = scriptService.getScriptById(scriptId);
				byte[] scriptByteArr = tempScript.getScriptFile();
				String assetZipPath = new File(jobData.getConfigZipPath()).getParent() + File.separator
						+ tempScript.getScriptName();

				FileOutputStream out = new FileOutputStream(new File(assetZipPath));
				out.write(scriptByteArr);
				if (out != null)
					out.close();

				// unzip script file
				FileUtil.getInstance().delFolder(new File(jobData.getAsset()));
				FileZip.unzip(assetZipPath, new File(jobData.getConfigZipPath()).getParent());
				jobData.setAsset(assetZipPath.substring(0, assetZipPath.lastIndexOf(FileZip.ZIP)));
				FileUtil.getInstance().changePropValue(new File(jobData.getAsset(), TestAssetContants.GRINDER_PROPERTIES),
						TestAssetContants.GRINDER_LOGDIRECTORY, jobData.getOutput());
				jobData.setAssetZip(assetZipPath);

				grinderProp = new File(jobData.getAsset(), TestAssetContants.GRINDER_PROPERTIES);
				break;
			}
			}
		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw new Exception(e.getMessage(), e);
		}

		return grinderProp;
	}

	private File generateAsset() throws Exception
	{
		int index = jobData.getUrl().lastIndexOf("/");

		String suburl = jobData.getUrl().substring(0, index);
		String context = jobData.getUrl().substring(index + 1);

		IdfXmlParser parser = new IdfXmlParser();

		// get IDF map from project source path
		Map<String, Idf> idfMap = null;
		try
		{
			idfMap = parser.getIDFService(jobData.getConfigPath());
		}
		catch (FileNotFoundException e)
		{
			log.error(e.getMessage());
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw e;
		}
		catch (IdfFileNameException e)
		{
			log.error(e.getMessage());
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw e;
		}

		AssetGenerator generator = new AssetGenerator(new File(jobData.getOutput()), new File(jobData.getAsset()));

		// check if headers in IDF parameter CSV files are the same as input
		// name in IDF map, if true get these CSV files
		Set<File> paramFileList;
		try
		{
			paramFileList = generator.checkIDFmatchParams(new File(jobData.getConfigPath()), idfMap);
		}
		catch (IOException e)
		{
			log.error(e.getMessage());
			updateStatusException();
			throw e;
		}
		catch (InputParamException e)
		{
			log.error(e.getMessage());
			updateStatusException();
			throw e;
		}

		// get service numbers which are contained in IDF map but user do not
		// provide corresponding CSV parameter files.
		// record log warn
		Set<String> params = new HashSet<String>();
		for (File file : paramFileList)
		{
			String fileName = FileUtil.getInstance().cutSuffix(file);
			params.add(fileName);
		}

		for (String idf : idfMap.keySet())
		{
			if (!params.contains(idf))
				log.error("service " + idf + " can not found corresponding parameter files with path " + jobData.getConfigPath());
		}

		File grinderProp = null;
		try
		{
			LoginScriptParamBean loginBean = new LoginScriptParamBean();
			loginBean.setNeedLogin(Boolean.parseBoolean(jobData.getNeedLogin()));
			loginBean.setContext(context);
			loginBean.setUrl(suburl);
			loginBean.setUsername(jobData.getUsername());
			loginBean.setPassword(jobData.getPassword());
			loginBean.setUserFile(new File(jobData.getConfigPath(), TestAssetContants.VUCSV));

			grinderProp = generator.generateAsset(paramFileList, idfMap, suburl, context, Long.parseLong(jobData.getThinkTime()),
					Integer.parseInt(jobData.getRunCount()), Integer.parseInt(jobData.getThreadsNum()), loginBean);
		}
		catch (AssetGenerateException e)
		{
			log.error(e.getMessage());
			updateStatusException();
			throw e;
		}
		return grinderProp;

	}

	private void analyze() throws Exception
	{
		// update test brief status
		TestBrief testBrief = collection.getTestBrief();
		testBrief.setStatus(TestBriefStatusConstants.STARTANALYZE);
		collection.setTestBrief(testBrief);
		testBriefSerivce.updateTestBreifStatus(testBrief);
		String returnMsg = null;
		// log("analyzing and store in database", Project.MSG_INFO);
		AnalyzeManager analyzeManger = new AnalyzeManager();
		try
		{
			log.info("starting analyze result with summary id [" + jobData.getSummaryId() + "]...");

			returnMsg = new AnalyzeManager().doAnalyze(new File(jobData.getOutput()),
					Boolean.parseBoolean(jobData.getIsServiceRequest()), collection);
			log.info("analyzing over with summary id [" + jobData.getSummaryId() + "]!");

		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			log.error("analyzing error!");
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw new Exception(e.getMessage(), e);
		}

		log.debug("----returnMsg=" + returnMsg);
		// get the latest testBrief from database
		testBrief = collection.getTestBrief();
		testBrief = testBriefSerivce.getTestBriefByBriefId(testBrief.getBriefId());
		collection.setTestBrief(testBrief);

		// update test brief status
		testBrief.setStatus(TestBriefStatusConstants.ANALYZEOVER);
		collection.setTestBrief(testBrief);
		testBriefSerivce.updateTestBreifStatus(testBrief);

		if (returnMsg != null && !returnMsg.isEmpty())
		{
			String msg = "test failed summary id [" + jobData.getSummaryId() + "] with error info: \n" + returnMsg;
			log.error(msg);
			throw new PerformanRunException(msg);
		}

		String warnMsg = analyzeManger.getWarnMesg();
		if (warnMsg != null)
		{
			log.warn(warnMsg);
		}

	}

	private void tearDown() throws Exception
	{
		// log.info("analyze completed");
		if (!Boolean.valueOf(FilePathConstants.CIDEBU))
		{
			File parentFile = new File(jobData.getAsset()).getParentFile();
			if (parentFile.exists())
			{
				boolean deleted = FileUtil.getInstance().delFolder(parentFile);
				if (deleted)
					log.info("delete temporary asset and configuration file with summary id [" + jobData.getSummaryId() + "]");
				else
					log.error("Fail to delete temporary asset and configuration file with summary id [" + jobData.getSummaryId()
							+ "] !");
			}
		}
		else
			log.info("asset and result folder are saved with summary id [" + jobData.getSummaryId() + "]");

		// update test brief status
		TestBrief testBrief = collection.getTestBrief();
		testBrief.setStatus(TestBriefStatusConstants.TESTCOMPLETED);
		collection.setTestBrief(testBrief);
		try
		{
			testBriefSerivce.updateTestBreifStatus(testBrief);
		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw new Exception(e.getMessage(), e);
		}
	}

	private void runEngineAndUpdate(File grinderProp) throws Exception
	{
		// update test brief status
		TestBrief testBrief = collection.getTestBrief();
		testBrief.setStatus(TestBriefStatusConstants.STARTRUN);
		collection.setTestBrief(testBrief);
		try
		{
			testBriefSerivce.updateTestBreifStatus(testBrief);
			runEngine(grinderProp);
		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw new Exception(e.getMessage(), e);
		}

	}

	private void runEngine(File grinderProp) throws Exception
	{

		try
		{
			log.info("starting engine run with summary id [" + jobData.getSummaryId() + "]...");
			// update test brief status
			TestBrief testBrief = collection.getTestBrief();
			testBrief.setStatus(TestBriefStatusConstants.RUN);
			collection.setTestBrief(testBrief);
			testBriefSerivce.updateTestBreifStatus(testBrief);

			engineRun(grinderProp);
			log.info("test run completed with summary id [" + jobData.getSummaryId() + "]");

			// update test brief status
			testBrief = collection.getTestBrief();
			testBrief.setStatus(TestBriefStatusConstants.RUNOVER);
			collection.setTestBrief(testBrief);
			testBriefSerivce.updateTestBreifStatus(testBrief);
		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			log.error("engine run error", e);
			updateStatusException();
			throw new Exception("engine run error");
		}
	}

	private void cleanUp() throws FileNotFoundException
	{

		// clean up
		if (!mkTmpFolder(jobData.getAsset()))
		{
			log.info("can not create asset folder with path " + jobData.getAsset());
			throw new FileNotFoundException("can not create asset folder with path " + jobData.getAsset());
		}

		if (!mkTmpFolder(jobData.getOutput()))
		{
			log.info("can not create result folder with path " + jobData.getOutput());
			throw new FileNotFoundException("can not create result folder with path " + jobData.getOutput());
		}

		// changeFiledAbsolute();
		printArgs();
	}

	private void engineRun(File grinderProp) throws Exception
	{

		GrinderEngine engine = new GrinderEngine();
		log.info("engine running with summary id [" + jobData.getSummaryId() + "]...");
		engine.run(grinderProp);
	}

	// /**
	// * change the relative path to absolutely path
	// */
	// private void changeFiledAbsolute()
	// {
	//
	// asset = changeToAbPath(asset);
	// output = changeToAbPath(output);
	// projectPath = changeToAbPath(projectPath);
	// paramFolderPath = changeToAbPath(paramFolderPath);
	// // xmlRoot = changeToAbPath(xmlRoot);
	// }

	private void printArgs()
	{
		log.debug("arg url: " + jobData.getUrl());
		log.debug("arg projectPath: " + jobData.getConfigPath());
		log.debug("arg paramFolderPath: " + jobData.getConfigPath());
		// log.info("arg xmlRoot: " + xmlRoot);
		if ("true".equals(jobData.getDebug()))
		{
			log.debug("arg result: " + jobData.getOutput());
			log.debug("arg asset: " + jobData.getAsset());
		}
	}

	private boolean mkTmpFolder(String name)
	{
		File file = new File(name);
		if (!file.exists())
		{
			if ("true".equals(jobData.getDebug()))
				log.info(name + " does not exist, will create...");
			return file.mkdirs();
		}
		else
		{
			if (file.isDirectory())
			{
				log.warn(name + " exists, will overlay...");
				FileUtil.getInstance().delAllFile(file.getAbsolutePath());
			}
		}
		return true;
	}

	public String changeToAbPath(String path)
	{
		if (path == null || path.isEmpty())
			return "";

		File file = new File(path);
		if (file.exists())
			return file.getAbsolutePath();
		else
			return path;

	}

	public boolean submitData() throws Exception
	{
		// String systemuuid = collection.getSystem().getSystemuuid();
		String projectName = collection.getProject().getProjectName();
		// Date startTime = collection.getTestBrief().getStartTime();
		Date endTime = collection.getTestBrief().getEndTime();
		int briefId = collection.getTestBrief().getBriefId();
		List<TestError> errorList = null;
		try
		{
			errorList = testErrorService.getTestErrorByBriefId(briefId);
		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw new Exception(e.getMessage(), e);
		}
		StringBuilder sb = new StringBuilder();
		for (TestError testError : errorList)
		{
			sb.append(testError.getErrorMessage());
		}
		// String errorMsg = collection.getTestBrief().getErrorInformation();
		String errorMsg = sb.toString();
		boolean submitFlag = false;
		try
		{
			submitFlag = submitResult(jobData.getSummaryId(), endTime, briefId, projectName, errorMsg);
		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			updateStatusException();
			// updateTestError(e,INSIDE);
			throw new Exception(e.getMessage(), e);
		}
		return submitFlag;
	}

	public boolean submitResult(String summaryid, Date endTime, int briefId, String projectName, String errorMsg) throws Exception 
	{
		SubmitResultService submitResultService = new SubmitResultService();
		Map<String, String> statisticMap = submitResultService.getReturnStatistics(briefId);
		String requestId = FilePathConstants.REQUEST_ID;
		String SUMMARY_ID = summaryid;
		String PROJECT_NAME = projectName;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd%20HH:mm:ss");
//		HttpGet httpget = null;
		
		String processId = FilePathConstants.UPLOADPROCESSID;
		String server = FilePathConstants.UPLOADSERVER;
		PwMatrixUtil pwmUtil = new PwMatrixUtil(server, processId);
		String password;
		Client client = null;
		ResultSet rs = null;
		String params = null;
		try
		{
			password = pwmUtil.getPassword();
			client = new Client(FilePathConstants.RESULT_UPLOAD_URL);
			client.signOn(processId, password);
		}
		catch (GenException e)
		{
			log.error(e);
			updateStatusException();
			updateTestError(e, OUTSIDE);
			throw e;
		}
		catch (SignOnException e)
		{
			log.error(e);
			updateStatusException();
			updateTestError(e, OUTSIDE);
			throw e;
		}
		catch (MalformedURLException e)
		{
			log.error(e);
			updateStatusException();
			updateTestError(e, OUTSIDE);
			throw e;
		}
		
		if (endTime == null)
		{
			String ERROR_MESSAGE = FileUtil.getInstance().getStringNoSpace(errorMsg);
			// String url= "http://10.248.66.141:8888/xml?__request="+requestId
			params = "__request=" + requestId + "&SUMMARY_ID=" + SUMMARY_ID
					+ "&PROJECT_NAME=" + PROJECT_NAME + "&ERROR_MESSAGE=" + ERROR_MESSAGE;
			
			log.info(FilePathConstants.RESULT_UPLOAD_URL + " Cloud post data:" + params);
			try
			{
				rs = client.process(params);
			}
			catch (ProcessException e)
			{
				log.error(e);
				updateStatusException();
				updateTestError(e, OUTSIDE);
				throw e;
			}
//			String url = FilePathConstants.RESULT_UPLOAD_URL + "xml?__request=" + requestId + "&SUMMARY_ID=" + SUMMARY_ID
//					+ "&PROJECT_NAME=" + PROJECT_NAME + "&ERROR_MESSAGE=" + ERROR_MESSAGE;
//			httpget = new HttpGet(url);
		}
		else
		{
			String FINISH_TIME = dateFormat.format(endTime);
			String TOTAL_SERVICE_NUM = statisticMap.get("TOTAL_SERVICE_NUM");
			String PASSED_SERVICE_NUM = statisticMap.get("PASSED_SERVICE_NUM");
			String FAILED_SERVICE_NUM = statisticMap.get("FAILED_SERVICE_NUM");
			String PASSED_RATE = statisticMap.get("PASSED_RATE");
			String COMPLETION_TIME = FINISH_TIME;
			String ERROR_MESSAGE = FileUtil.getInstance().getStringNoSpace(errorMsg);
			
			params = "__request=" + requestId + "&SUMMARY_ID=" + SUMMARY_ID
					+ "&PROJECT_NAME=" + PROJECT_NAME + "&FINISH_TIME=" + FINISH_TIME + "&TOTAL_SERVICE_NUM=" + TOTAL_SERVICE_NUM
					+ "&PASSED_SERVICE_NUM=" + PASSED_SERVICE_NUM + "&FAILED_SERVICE_NUM=" + FAILED_SERVICE_NUM + "&PASSED_RATE="
					+ PASSED_RATE + "&COMPLETION_TIME=" + COMPLETION_TIME;
//			String url = FilePathConstants.RESULT_UPLOAD_URL + "xml?__request=" + requestId + "&SUMMARY_ID=" + SUMMARY_ID
//					+ "&PROJECT_NAME=" + PROJECT_NAME + "&FINISH_TIME=" + FINISH_TIME + "&TOTAL_SERVICE_NUM=" + TOTAL_SERVICE_NUM
//					+ "&PASSED_SERVICE_NUM=" + PASSED_SERVICE_NUM + "&FAILED_SERVICE_NUM=" + FAILED_SERVICE_NUM + "&PASSED_RATE="
//					+ PASSED_RATE + "&COMPLETION_TIME=" + COMPLETION_TIME;
			if (ERROR_MESSAGE != null && !ERROR_MESSAGE.isEmpty())
			{
				params = params + "&ERROR_MESSAGE=" + ERROR_MESSAGE;
//				url = url + "&ERROR_MESSAGE=" + ERROR_MESSAGE;
			}
			log.info(FilePathConstants.RESULT_UPLOAD_URL + " Cloud post data:" + params);
			statisticMap = null;
			// String url= "http://10.248.66.141:8888/xml?__request="+requestId
//			httpget = new HttpGet(url);
			try
			{
				rs = client.process(params);
			}
			catch (ProcessException e)
			{
				log.error(e);
				updateStatusException();
				updateTestError(e, OUTSIDE);
				throw e;
			}
		}
//		log.info(httpget.getURI());

		try
		{
			while(rs.next())
			{
				int flag = Integer.parseInt(rs.getString("FLAG"));
				if(flag == 1)
				{
					log.info("Submit success:" + FilePathConstants.RESULT_UPLOAD_URL + "xml?"+ params);
					return true;
				}
				else
				{
					log.error("Submit fail:" + FilePathConstants.RESULT_UPLOAD_URL + "xml?"+ params );
					return false;
				}
					
			}
		}
		catch (NumberFormatException e)
		{
			log.error(e);
			updateStatusException();
			updateTestError(e, OUTSIDE);
		}
		catch (ResultSetException e)
		{
			log.error(e);
			updateStatusException();
			updateTestError(e, OUTSIDE);
		}
		return false;
//		CloseableHttpClient httpClient = HttpClients.createDefault();
//		HttpResponse response = null;
//		try
//		{
//			response = httpClient.execute(httpget);
//			log.info("response.getStatusLine(): " + response.getStatusLine().toString());
//			log.info("response.getAllHeaders(): " + response.getAllHeaders().toString());
//		}
//		catch (HttpHostConnectException e)
//		{
//			log.error(e);
//			updateStatusException();
//			updateTestError(e, OUTSIDE);
//		}
//		catch (ClientProtocolException e)
//		{
//			log.error(e);
//			updateStatusException();
//			throw e;
//			// updateTestError(e,INSIDE);
//		}
//		catch (IOException e)
//		{
//			log.error(e);
//			updateStatusException();
//			throw e;
//			// updateTestError(e,INSIDE);
//		}
//
//		String returnString = null;
//		if (response != null)
//		{
//			HttpEntity httpEntity = response.getEntity();
//			try
//			{
//				returnString = EntityUtils.toString(httpEntity);
//				log.info("returnString: " + returnString);
//			}
//			catch (ParseException e)
//			{
//				log.error(e.getMessage(), e);
//				updateStatusException();
//				updateTestError(e, OUTSIDE);
//			}
//			catch (IOException e)
//			{
//				log.error(e.getMessage(), e);
//				updateStatusException();
//				updateTestError(e, OUTSIDE);
//			}
//		}
//		else
//		{
//			return false;
//		}
//		String positiveFlag = "FLAG=\"1\"";
//		if (returnString.contains(positiveFlag))
//		{
//			log.info("positive flag");
//			return true;
//		}
//		else
//		{
//			log.info("negative flag");
//			// TestBrief brief = collection.getTestBrief();
//			// brief.setErrorInformation(returnString);
//			// testBriefSerivce.updateTestBreif(brief);
//			return false;
//		}

	}

	private void updateStatusException() throws Exception
	{
		TestBrief testBrief = collection.getTestBrief();
		testBrief.setStatus(TESTEXCEPTION);
		try
		{
			testBriefSerivce.updateTestBreifStatus(testBrief);
		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			// updateTestError(e,INSIDE);
			throw new Exception(e.getMessage(), e);
		}
		collection.setTestBrief(testBrief);
	}

	private void updateTestError(Exception e, String errorType) throws Exception
	{
		TestError testError = new TestError();
		testError.setBriefId(collection.getTestBrief().getBriefId());
		testError.setErrorType(errorType);
		if (e.getCause() != null)
		{
			testError.setErrorMessage(e.getCause().getMessage());
			testError.setErrorName(e.getCause().getClass().getName());
		}
		else
		{
			testError.setErrorMessage(e.getMessage());
			testError.setErrorName(e.getClass().getName());
		}
		testErrorService.addTestError(testError);
	}

	/**
	 * change to value which related with run engine host name and Main.py path
	 * and output path
	 * 
	 * @param jobdata
	 * @param file
	 * @throws Exception
	 */
	private File changeAssetAttr(File file) throws Exception
	{
		File propFile = null;
		try
		{
			propFile = FileUtil.getInstance().changeToLocalHost(file);
			FileUtil.getInstance().changePropValue(propFile, TestAssetContants.GRINDER_LOGDIRECTORY, jobData.getOutput());
			FileUtil.getInstance().changePropValue(propFile, TestAssetContants.GRINDER_SCRIPT, "../scripts/Main.py");
			String localhostName = InetAddress.getLocalHost().getHostName();
			FileUtil.getInstance().changePropValue(propFile, TestAssetContants.GRINDER_CONSOLEHOST, localhostName);
			FileUtil.getInstance().changePropValue(propFile, TestAssetContants.GRINDER_THREADS, jobData.getThreadsNum());
			AssetAnalyzeUtil.getInstance().setRootPath(jobData.getAsset());
			File runtimeFile = AssetAnalyzeUtil.getInstance().getRunTime();
			FileUtil.getInstance().changeAttributeValue(runtimeFile, "runtime/agents/agent", "name", localhostName);
			FileUtil.getInstance().changeAttributeValue(runtimeFile, "runtime", "liveCycles", jobData.getRunCount());
			FileUtil.getInstance().changeAttributeValue(runtimeFile, "runtime/agents/agent", "threads", jobData.getThreadsNum());
		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			updateStatusException();
			throw e;
			// updateTestError(e, INSIDE);
		}
		return propFile;
	}

	private File acqiureAsset() throws Exception
	{
		File assetFile = null;
		try
		{
			PlanScript planScript = planScriptService.getPlanScriptByPlanId(collection.getPlan().getPlanId());
			int scriptId = planScript.getScriptId();
			Script script = scriptService.getScriptById(scriptId);
			byte[] scriptByte = script.getScriptFile();

			String assetZipPath = FilePathConstants.TEMPFOLDERPATH + File.separator + System.currentTimeMillis() + File.separator
					+ script.getScriptName();
			File assetZipFile = new File(assetZipPath);
			if (!assetZipFile.exists())
			{
				assetZipFile.getParentFile().mkdirs();
				assetZipFile.createNewFile();
			}
			FileOutputStream out = new FileOutputStream(assetZipFile);
			out.write(scriptByte);
			if (out != null)
				out.close();
			assetFile = new File(assetZipPath.substring(0, assetZipPath.lastIndexOf(FileZip.ZIP)));
			// unzip the asset zip file to folder
			FileZip.unzip(assetZipPath, assetFile.getParent());
		}
		catch (Exception e)
		{
			log.error(e.getMessage(), e);
			updateStatusException();
			throw e;
			// updateTestError(e, INSIDE);
		}
		return assetFile;
	}

	/**
	 * the job executed method
	 */
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException
	{
		try
		{
			if (Boolean.parseBoolean(jobData.getIsServiceRequest()))
			{
				doExecute();
			}
			else
			{
				if (!mkTmpFolder(jobData.getOutput()))
				{
					log.info("can not create result folder with path " + jobData.getOutput());
					throw new FileNotFoundException("can not create result folder with path " + jobData.getOutput());
				}

				// add a new test brief for this test
				TestBrief tempTestBrief = new TestBrief();
				tempTestBrief.setAutomated(true);
				tempTestBrief.setExecutorId(jobData.getUser().getUserId());
				tempTestBrief.setExecutorName(jobData.getUser().getUserName());
				tempTestBrief.setPlanId(collection.getPlan().getPlanId());
				tempTestBrief.setPlanName(collection.getPlan().getPlanName());
				tempTestBrief.setStatus(TestBriefStatusConstants.PREPARERUN);
				tempTestBrief.setSummaryId("" + UUID.randomUUID());
				testBriefSerivce.addTestBreif(tempTestBrief);

				TestBrief testBrief = testBriefSerivce.getTestBreif(tempTestBrief);
				collection.setTestBrief(testBrief);

				// set the output with current time to avoid the same folder name
				long current = System.currentTimeMillis();
				jobData.setOutput(jobData.getOutput() + "_" + current);

				// check if the asset exist in the local disk,
				// if true, get the file
				// else get file from database and unzip the file
				File assetFile = null;
				if(jobData.getAsset() != null){
					assetFile = new File(jobData.getAsset());
					if(!assetFile.exists())
					{
						assetFile = acqiureAsset();
						jobData.setAsset(assetFile.getAbsolutePath());
						
					}
				}
				else
				{
					assetFile = acqiureAsset();
					jobData.setAsset(assetFile.getAbsolutePath());

				}
				

				// get the configuration file from asset folder for grinder
				// engine
				File file = new File(assetFile, "config");
				File[] files = file.listFiles(new FilenameFilter()
				{
					@Override
					public boolean accept(File dir, String name)
					{
						return name.endsWith(".ptafproperties");
					}
				});

				// change the attributes in asset
				File propFile = null;
				try{
					propFile = AssetModifyUtil.getInstance().changeAssetAttr(files[0], jobData); //changeAssetAttr(files[0]);
				}catch(Exception e)
				{
					updateTestError(e, INSIDE);
				}

				//send the grinder.properties file to grinder engine
				runEngine(propFile);

				// check the test output errors
				String errorMsg = new AnalyzeManager().getErrorMsg(new File(jobData.getOutput()), testBrief);
				if (errorMsg == null || errorMsg.isEmpty())
				{
					DataImport dataImport = new DataImport(new File(jobData.getOutput()));
					collection = dataImport.execute(collection);
					analyze();
				}
				else
				{
					String msg = "test failed testBrief id [" + testBrief.getBriefId() + "] with error info: \n" + errorMsg;
					log.error(msg);
				}

				tearDown();
			}
		}
		catch (PerformanRunException e)
		{
			throw new JobExecutionException(e.getMessage(), e);
		}
		catch (Exception e)
		{
			try
			{
				updateStatusException();
				updateTestError(e, INSIDE);
				throw new JobExecutionException(e.getMessage(), e);
			}
			catch (Exception e1)
			{
				throw new JobExecutionException("exception while performance test running", e);
			}
		}
	}

	public TestBeanCollection getCollection()
	{
		return collection;
	}

	public void setCollection(TestBeanCollection collection)
	{
		this.collection = collection;
	}

	public JobData getJobData()
	{
		return jobData;
	}

	public void setJobData(JobData jobData)
	{
		this.jobData = jobData;
	}
}
