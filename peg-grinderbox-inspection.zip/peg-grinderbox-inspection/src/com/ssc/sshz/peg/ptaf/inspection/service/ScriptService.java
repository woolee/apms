package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface ScriptService<T>
{
	public List<T> getAllScripts() throws DataAccessException;
	public T getScript(T entity) throws DataAccessException;
	public boolean addScript(T entity) throws DataAccessException;
	public boolean delScriptById(int id) throws DataAccessException;
}
