package com.ssc.sshz.peg.ptaf.inspection.controller;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.service.ProjectService;
import com.ssc.sshz.peg.ptaf.inspection.service.SystemService;

@Controller
@RequestMapping("/system")
public class SystemController
{
	private static final Logger logger = Logger.getLogger(SystemController.class);	
	@Inject
	private SystemService<System> systemService;
	
	@Inject
	private ProjectService<Project> projectService;
	
	
	@RequestMapping("/CreateSystem")
	public String CreateSystem(System system,HttpSession httpSession,Model model){
		
		int ProjectID=(Integer) httpSession.getAttribute("systemPageProjectid");
		String ProjectName = (String) httpSession.getAttribute("systemPageProjectName");
        system.setProjectId(ProjectID);	
        system.setProjectName(ProjectName);
        systemService.addSystem(system);			
		return "/plan/SystemPageInint.do?projectId="+ProjectID+"&projectName="+ProjectName;
	}
	
	@RequestMapping("/ManagePageCreateSystem")
	public String ManagePageCreateSystem(System system,Model model,HttpServletRequest request){
		String ProjectName=request.getParameter("projectName");
		int ProjectID=projectService.getProjectByName(ProjectName).getProjectId();
        system.setProjectId(ProjectID);	
        system.setProjectName(ProjectName);
        systemService.addSystem(system);			
		return "/system/manageSystemPageInit.do";
	}
	
	@RequestMapping("/GetSystem")
	public String GetSystem(Integer SystemId,Model model){
		model.addAttribute(systemService.getSystem(SystemId));
		return "/view/showSystem.jsp";
	}
	
	@RequestMapping("/diaplyPageInint")
	public String displayPageInint(Model model){
		model.addAttribute("projects",projectService.getAllProject());
		model.addAttribute("systems",systemService.getAllSystem());
		return "/page/displaySystem.jsp";
	}
	
	@RequestMapping("/systemAjax")
	public String ajaxtest(String projectName,Model model){
		model.addAttribute("systems",systemService.getSystemByProjectName(projectName));
		return "/page/system.jsp";
	}
	
	@RequestMapping("/DelSystem")
	public String DelSystem(Model model,System system){
		systemService.delSystem(system);
		model.addAttribute("systems",systemService.getSystemByProjectName(system.getProjectName()));
		return "/view/showManagePageSystem.jsp";
	}
	
	@RequestMapping("/manageSystemPageInit")
	public String manageSystemPageInit(Model model){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//		List<? extends GrantedAuthority> groupList = (List)auth.getAuthorities();
//		List<Project> projectList = projectService.getProjectByGroup(groupList);
		List<Project> projectList = projectService.getProjectByRight(auth.getName());
		model.addAttribute("projects",projectList);
//	    String name = auth.getName();
//		model.addAttribute("projects",projectService.getAllProjectByUserName(name));
		return "/view/manageSystem.jsp";
	}
	
	@RequestMapping("/ManageGetSystems")
	public String ManageGetSystems(Model model,HttpServletRequest request){
		String name=request.getParameter("ProjectId");
		model.addAttribute("systems",systemService.getSystemByProjectName(name));
		return "/view/showManagePageSystem.jsp";
	}

	@ExceptionHandler(Exception.class)
	public String exception(Exception e, HttpServletRequest request){
		request.setAttribute("exception", e);
		return "/view/error.jsp";
	}
}
