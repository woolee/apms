package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.ItemDetail;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemDetailDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ItemDetailMapper;

@Repository
public class ItemDetailDaoImpl<T extends ItemDetail> implements ItemDetailDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private ItemDetailMapper mapper;

	@Override
	public boolean addItemDetail(T entity)throws DataAccessException
	{
		boolean flag = false;
		try{
			mapper.addItemDetail(entity);
			flag = true;
		
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while add CIScript to database",e);
			throw new DaoException("Exception while add CIScript to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllItemDetail()throws DataAccessException
	{
		List<T> object = null;
		try{
		object =  (List<T>) mapper.getAllItemDetail();
		}
		catch(Exception e)
		{
			logger.error("Exception while get all ItemDetail from database",e);
			throw new DaoException("Exception while get all ItemDetail from database",e);
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getItemDetails(T entity)throws DataAccessException
	{
		T object = null;
		try{
		object = (T)mapper.getItemDetail(entity);
		}
		catch(Exception e)
		{
			logger.error("Exception while get itemDetail from database",e);
			throw new DaoException("Exception while get itemDetail from database",e);
		}
		return object;
	}

	@Override
	public boolean updateItemDetail(T entity)throws DataAccessException
	{
		boolean flag = false;
		try{
			mapper.updateItemDetail(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while update itemDetail to database",e);
			throw new DaoException("Exception while update itemDetail to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllItemDetailByPlanId (int planId)throws DataAccessException {
		List<T> object = null;
		try{
		object = (List<T>)mapper.getAllItemDetailByPlanId(planId);
		}
		catch(Exception e)
		{
			logger.error("Exception while get itemDetail list by plan id from database",e);
			throw new DaoException("Exception while get itemDetail list by plan id from database",e);
		}
		return object;
		
	}

	@Override
	public List<T> getAllItemDetailByItemId(int itemId)
			throws DataAccessException {
		List<T> object = null;
		try{
		object = (List<T>)mapper.getAllItemDetailByItemId(itemId);
		}
		catch(Exception e)
		{
			logger.error("Exception while get itemDetail list by plan id from database",e);
			throw new DaoException("Exception while get itemDetail list by plan id from database",e);
		}
		return object;
		
	}

	@Override
	public List<T> getAllItemDetailByItemIdAndBriefId(T entity)
			throws DataAccessException {
		List<T> object = null;
		try{
		object = (List<T>)mapper.getAllItemDetailByItemIdAndBriefId(entity);
		}
		catch(Exception e)
		{
			logger.error("Exception while get getAllItemDetailByItemIdAndBriefId from database",e);
			throw new DaoException("Exception while get getAllItemDetailByItemIdAndBriefId from database",e);
		}
		return object;
		
	}

	

}
