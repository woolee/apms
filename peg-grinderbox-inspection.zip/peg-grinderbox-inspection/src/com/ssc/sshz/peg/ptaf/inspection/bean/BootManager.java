package com.ssc.sshz.peg.ptaf.inspection.bean;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.quartz.SchedulerException;


import com.ssc.sshz.peg.ptaf.inspection.quartz.QuartzManager;

public class BootManager extends HttpServlet{

    public void init() throws ServletException{
    	QuartzManager quartzManager = QuartzManager.getQuartzManager();
    	try
		{
			quartzManager.initQuartzScheduler();
		}
		catch (SchedulerException e)
		{
			throw new ServletException(e.getMessage(), e);
		}
//    	quartzManager.rescheduleQuartzJob();
    	//quartzManager.setName("quartz");
    }
    
}
