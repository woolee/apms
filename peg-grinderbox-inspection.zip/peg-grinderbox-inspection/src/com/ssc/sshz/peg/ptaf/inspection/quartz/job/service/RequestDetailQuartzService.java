package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestDetail;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RequestDetailMapper;

public class RequestDetailQuartzService<T extends RequestDetail>
{
	private Logger logger = Logger.getLogger(getClass());

	// private SqlSession session = ConnectionFactory.openSession();
	// private RequestDetailMapper mapper =
	// session.getMapper(RequestDetailMapper.class);

	@SuppressWarnings("unchecked")
	public List<T> getAllRequestDetail() throws Exception
	{
		List<T> object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestDetailMapper mapper = session.getMapper(RequestDetailMapper.class);
			object = (List<T>) mapper.getAllRequestDetail();
		}
		catch (Exception e)
		{
			logger.error("exception while get all RequestDetail from databse",e);
			throw new Exception("exception while get all RequestDetail from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	public T getRequestDetail(T entity) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestDetailMapper mapper = session.getMapper(RequestDetailMapper.class);
			object = (T) mapper.getRequestDetail(entity);
		}
		catch (Exception e)
		{
			logger.error("exception while get RequestDetail object from databse",e);
			throw new Exception("exception while get RequestDetail object from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	public boolean addRequestDetail(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestDetailMapper mapper = session.getMapper(RequestDetailMapper.class);
			mapper.addRequestDetail(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while add RequestDetail object to databse",e);
			throw new Exception("exception while add RequestDetail object to databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	public boolean updateRequestDetail(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestDetailMapper mapper = session.getMapper(RequestDetailMapper.class);
			mapper.updateRequestDetail(entity);
			session.commit();
			flag = true;
		}
		catch (DataAccessException e)
		{
			flag = false;
			logger.error("exception while update RequestDetail object to databse",e);
			throw new Exception("exception while update RequestDetail object to databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

}
