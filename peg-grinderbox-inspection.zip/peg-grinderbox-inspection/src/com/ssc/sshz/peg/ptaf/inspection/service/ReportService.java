package com.ssc.sshz.peg.ptaf.inspection.service;


import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.Report;

public interface ReportService<T>{
	
	public List<T> getAllReportState()  throws DataAccessException;
	public boolean addReport(T entity) throws DataAccessException;
	public boolean updateByStatus(Report report) throws DataAccessException;
	public boolean deleteReportByUUID(String reportUUID) throws DataAccessException;
	public List<Report> getPagingReprot(Map<String, Integer> pageparm);
	public boolean updateExecutePercent(Report report) throws DataAccessException;
	public List<Report> getDownloadPercentList();
	public Report getReportByUUID(String reportUUID) throws DataAccessException;
}
