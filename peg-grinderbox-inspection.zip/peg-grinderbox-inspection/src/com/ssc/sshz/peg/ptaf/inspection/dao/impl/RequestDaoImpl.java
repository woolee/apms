package com.ssc.sshz.peg.ptaf.inspection.dao.impl;


import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RequestMapper;
@Repository
public class RequestDaoImpl<T extends Request> implements RequestDao<T>{

	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RequestMapper mapper;

	@Override
	public boolean addRequest(T entity) throws DataAccessException {
		boolean flag = false;
		try {
			mapper.addRequest(entity); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while add request to database",e);
			throw new DaoException("Exception while add request to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Request getRequestByRequestName(String requestName) throws DataAccessException
	{
		T entity = null;
		try{ 
			entity = (T) mapper.getRequestByRequestName(requestName);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get request by name from database",e);
			throw new DaoException("Exception while get request by name from database",e);
		}
		return entity;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getRequestsByItemId(int id) throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getRequestsByItemId(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get requests by item id from database",e);
			throw new DaoException("Exception while get request by item id from database",e);
		}
		return entity;
	}

	@Override
	public boolean updateRequest(T entity) throws DataAccessException
	{
		boolean flag = false;
		try {
			mapper.updateRequest(entity);
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while update request to database",e);
			throw new DaoException("Exception while update request to database",e);
		}
		return flag;
	}

	@Override
	public List<T> getRequestByItemIdAndPlanId(T entity)
			throws DataAccessException {
		List<T> obj = null;
		try{ 
			obj =  (List<T>) mapper.getRequestByItemIdAndPlanId(entity);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while getRequestByItemIdAndPlanIdfrom database",e);
			throw new DaoException("Exception while getRequestByItemIdAndPlanId from database",e);
		}
		return obj;
		
	}

	@Override
	public List<T> getRequestByPlanId(int PlanId) throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getRequestsByPlanId(PlanId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get requests by item id from database",e);
			throw new DaoException("Exception while get request by item id from database",e);
		}
		return entity;
	}

	@Override
	public Request getRequestByRequestId(int requestId)
			throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getRequestByRequestId(requestId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get request by Id from database",e);
			throw new DaoException("Exception while get request by Id from database",e);
		}
		return entity;
		
	}
	
}
