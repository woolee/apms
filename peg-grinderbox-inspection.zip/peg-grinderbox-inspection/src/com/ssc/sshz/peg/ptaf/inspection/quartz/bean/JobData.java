package com.ssc.sshz.peg.ptaf.inspection.quartz.bean;

import java.io.Serializable;

import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.constants.TestStatusConstants;
import com.ssc.sshz.peg.ptaf.inspection.constants.TestType;

public class JobData implements Serializable
{
		/**
	 * 
	 */
	private static final long serialVersionUID = -2503718353943609778L;

		private String isServiceRequest = "false";
		
	 	private String url;// the url to access the web project
	 	private String configPath; // the path contains the project IDF file and test data parameter files
	 	private String assetZip;
	    private String summaryId;
	    private String configZipPath;
	    private String output = "output";// grinder test result home
	    private String asset = "asset";// grinder script home
	    private User user;
	    private String username;
	    private String password;
	    private String needLogin ="true";// is test target system need to login
	    private String debug ;// debug mode will store the asset and result
	    private String threadsNum = FilePathConstants.THREADNUM;
	    private String runCount = FilePathConstants.RUNCOUNT;
	    private String thinkTime = FilePathConstants.THINKTIME;
	    private TestType configStatus = TestType.New;
	    
		public String getUrl()
		{
			return url;
		}
		public String getIsServiceRequest()
		{
			return isServiceRequest;
		}
		public void setIsServiceRequest(String isServiceRequest)
		{
			this.isServiceRequest = isServiceRequest;
		}
		public void setUrl(String url)
		{
			this.url = url;
		}
		public String getSummaryId()
		{
			return summaryId;
		}
		public void setSummaryId(String summaryId)
		{
			this.summaryId = summaryId;
		}
		public String getOutput()
		{
			return output;
		}
		public void setOutput(String output)
		{
			this.output = output;
		}
		public String getAsset()
		{
			return asset;
		}
		public void setAsset(String asset)
		{
			this.asset = asset;
		}
		public String getUsername()
		{
			return username;
		}
		public void setUsername(String username)
		{
			this.username = username;
		}
		public String getPassword()
		{
			return password;
		}
		public void setPassword(String password)
		{
			this.password = password;
		}
		public String getNeedLogin()
		{
			return needLogin;
		}
		public void setNeedLogin(String needLogin)
		{
			this.needLogin = needLogin;
		}
		public String getDebug()
		{
			return debug;
		}
		public void setDebug(String debug)
		{
			this.debug = debug;
		}
		public String getThreadsNum()
		{
			return threadsNum;
		}
		public void setThreadsNum(String threadsNum)
		{
			this.threadsNum = threadsNum;
		}
		public String getRunCount()
		{
			return runCount;
		}
		public void setRunCount(String runCount)
		{
			this.runCount = runCount;
		}
		public String getThinkTime()
		{
			return thinkTime;
		}
		public void setThinkTime(String thinkTime)
		{
			this.thinkTime = thinkTime;
		}
	    
		public JobData()
		{
			super();
			// TODO Auto-generated constructor stub
		}
		public String getConfigZipPath()
		{
			return configZipPath;
		}
		public void setConfigZipPath(String configZipPath)
		{
			this.configZipPath = configZipPath;
		}
		public String getConfigPath()
		{
			return configPath;
		}
		public void setConfigPath(String configPath)
		{
			this.configPath = configPath;
		}
		public User getUser()
		{
			return user;
		}
		public void setUser(User user)
		{
			this.user = user;
		}
		public String getAssetZip()
		{
			return assetZip;
		}
		public void setAssetZip(String assetZip)
		{
			this.assetZip = assetZip;
		}
		public TestType getConfigStatus()
		{
			return configStatus;
		}
		public void setConfigStatus(TestType configStatus)
		{
			this.configStatus = configStatus;
		}
			
		
}
