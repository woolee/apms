package com.ssc.sshz.peg.ptaf.inspection.test.exception;

public class ParameterException extends Exception
{
	public ParameterException(String mesg)
	{
		super(mesg);
	}
	
	public ParameterException(String mesg, Throwable e)
	{
		super(mesg,e);
	}
}
