package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class Group implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5582511791232278395L;
	private int groupId;
	private String groupName;
	private String groupEmail;
	private String groupDescription;
	public int getGroupId()
	{
		return groupId;
	}
	public void setGroupId(int groupId)
	{
		this.groupId = groupId;
	}
	public String getGroupName()
	{
		return groupName;
	}
	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}
	public String getGroupEmail()
	{
		return groupEmail;
	}
	public void setGroupEmail(String groupEmail)
	{
		this.groupEmail = groupEmail;
	}
	public String getGroupDescription()
	{
		return groupDescription;
	}
	public void setGroupDescription(String groupDescription)
	{
		this.groupDescription = groupDescription;
	}
	
}
