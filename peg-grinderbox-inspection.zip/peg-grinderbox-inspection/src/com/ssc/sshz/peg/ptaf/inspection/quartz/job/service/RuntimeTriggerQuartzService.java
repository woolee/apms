package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RuntimeTriggerMapper;

public class RuntimeTriggerQuartzService<T extends RuntimeTrigger>
{
	private Logger logger = Logger.getLogger(getClass());


	@SuppressWarnings("unchecked")
	public List<T> getAllRuntimeTrigger() throws Exception
	{
		List<T> object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RuntimeTriggerMapper mapper = session.getMapper(RuntimeTriggerMapper.class);
			object = (List<T>) mapper.getAllRuntimeTrigger();
		}
		catch (Exception e)
		{
			logger.error("exception while get all runtime_trigger",e);
			throw new Exception("exception while get all runtime_trigger", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	public T getRuntimeTriggerByRuntimeId(int runtimeId) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RuntimeTriggerMapper mapper = session.getMapper(RuntimeTriggerMapper.class);
			object = (T) mapper.getRuntimeTriggerByRuntimeId(runtimeId);
		}
		catch (Exception e)
		{
			logger.error("exception while get RuntimeTrigger object by runtime id from databse",e);
			throw new Exception("exception while get RuntimeTrigger object by runtime id from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;

	}

	public boolean addRuntimeTrigger(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RuntimeTriggerMapper mapper = session.getMapper(RuntimeTriggerMapper.class);
			mapper.addRuntimeTrigger(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while add RuntimeTrigger to database",e);
			throw new Exception("exception while add RuntimeTrigger to database", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	public boolean delRuntimeTrigger(int id) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RuntimeTriggerMapper mapper = session.getMapper(RuntimeTriggerMapper.class);
			mapper.delRuntimeTriggerByRuntimeId(id);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while delete RuntimeTrigger by runtime id from database",e);
			throw new Exception("exception while delete RuntimeTrigger by runtime id from database", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	public boolean delRuntimeTriggerByJobName(String jobName) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RuntimeTriggerMapper mapper = session.getMapper(RuntimeTriggerMapper.class);
			mapper.delRuntimeTriggerByJobName(jobName);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while delete RuntimeTrigger by job name from database",e);
			throw new Exception("exception while delete RuntimeTrigger by job name from database", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	public boolean delRuntimeTriggerByTriggerName(String triggerName) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RuntimeTriggerMapper mapper = session.getMapper(RuntimeTriggerMapper.class);
			mapper.delRuntimeTriggerByTriggerName(triggerName);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while delete RuntimeTrigger by trigger name from database",e);
			throw new Exception("exception while delete RuntimeTrigger by trigger name from database", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}
	
	
	public boolean updateRuntimeTrigger(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RuntimeTriggerMapper mapper = session.getMapper(RuntimeTriggerMapper.class);
			mapper.updateRuntimeTrigger(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while update RuntimeTrigger ",e);
			throw new Exception("exception while update RuntimeTrigger ", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}
}
