package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;

//@Component
@Entity
public class Requirement implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7396821710690001407L;

	public Integer getRequirementId() {
		return requirementId;
	}

	public void setRequirementId(Integer requirementId) {
		this.requirementId = requirementId;
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}

	public Integer getAvgResponseTime() {
		return avgResponseTime;
	}

	public void setAvgResponseTime(Integer avgResponseTime) {
		this.avgResponseTime = avgResponseTime;
	}

	private Integer requirementId;
	private Integer planId;
	private Integer itemId;
	private Integer avgResponseTime;
}
