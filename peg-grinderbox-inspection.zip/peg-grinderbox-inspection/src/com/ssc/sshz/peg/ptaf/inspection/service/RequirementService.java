package com.ssc.sshz.peg.ptaf.inspection.service;


import org.springframework.dao.DataAccessException;


public interface RequirementService<T>
{

	public boolean addRequirement(T entity) throws DataAccessException;
	public T getRequirementByItemId(int itemId) throws DataAccessException;
}
