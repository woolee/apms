package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.RequestDetail;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;

public interface RequestDetaillService<T>
{
	public List<T> getAllRequestDetail() throws DataAccessException;
	public List<T> getAllRequestDetailByPlanId(int planId) throws DataAccessException;
	public List<T> getAllRequestDetailByReuqestId(int requestId) throws DataAccessException;
	public List<T> getAllRequestDetailByReuqestIdBriefId(T entity) throws DataAccessException;
	public T getRequestDetail(T entity) throws DataAccessException;
	public boolean addRequestDetail(T entity) throws DataAccessException;
	public boolean updateRequestDetail(T entity) throws DataAccessException;
	public Map<Integer, Integer> getRequestCountByReturnCode(List<RequestStatistics> requestStatistList,T entity) throws DataAccessException;
}
