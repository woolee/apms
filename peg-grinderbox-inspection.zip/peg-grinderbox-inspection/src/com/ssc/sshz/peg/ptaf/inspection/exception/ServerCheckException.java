package com.ssc.sshz.peg.ptaf.inspection.exception;

public class ServerCheckException extends Exception
{
	public ServerCheckException(String msg)
	{
		super(msg);
	}
	public ServerCheckException(String msg, Throwable e)
	{
		super(msg,e);
	}
}
