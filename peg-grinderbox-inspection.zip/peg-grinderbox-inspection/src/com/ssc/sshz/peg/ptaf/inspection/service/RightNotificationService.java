package com.ssc.sshz.peg.ptaf.inspection.service;

import org.springframework.dao.DataAccessException;

public interface RightNotificationService<T>
{

	public boolean addRightNotification(T entity) throws DataAccessException;

}
