package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.RightProject;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.dao.ProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.service.ProjectService;

@Service

public class ProjectServiceImp<T extends Project> implements ProjectService<T> {
	
	@Inject
	private ProjectDao<T> dao;

	@Inject
	private UserDao<User> userDao;
	
	@Inject
	private RightProjectDao<RightProject> rightProjectDao;
	
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addProject(T entity) throws DataAccessException {
		return dao.addProject(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addProjectByUserName(String name,T project) throws DataAccessException {
		project.setProjectCreatorId(userDao.getUserByName(name).getUserId());
		project.setProjectCreatorName(name);
		return dao.addProject(project);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean delProject(T entity) throws DataAccessException {
		
		return dao.delProjectById(entity.getProjectId());
		
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getProject(T entity) throws DataAccessException {
		return dao.getProjectById(entity.getProjectId());
	}
	

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllProject() throws DataAccessException {
		return dao.getAllProject();
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getProjectByName(String name) throws DataAccessException {
		return dao.getProjectByName(name);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getProjectById(int Id) throws DataAccessException {
		return dao.getProjectById(Id);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getProjectByuuid(String Id) throws DataAccessException {
		return dao.getProjectByuuid(Id);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllProjectByUserName(String userName) throws DataAccessException {
		return dao.getAllProjectByUsername(userName);
	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getProjectByGroup(List<? extends GrantedAuthority> authorityRightList)
	{
		List<T> projectList = new ArrayList<T>();
		List<? extends GrantedAuthority> rightList = new ArrayList<GrantedAuthority>(authorityRightList);
		for (int i = rightList.size() -1 ; i >= 0; i--)
		{
			if("ROLE_USER".equals(rightList.get(i).getAuthority()))
			{
				rightList.remove(i);
				break;
			}
		}
		for (GrantedAuthority grantedAuthority : rightList)
		{
			String rightName = grantedAuthority.getAuthority();
			RightProject rightProject = rightProjectDao.getRightProjectByRightName(rightName);
			Project project = dao.getProjectById(rightProject.getProjectId());
			projectList.add((T)project);
			/*for (GroupRight groupRight : groupRightList)
			{
				String projectName = rightProjectDao.getRightProjectByRightId(groupRight.getRightId()).getProjectName();
				Project project = dao.getProjectByName(projectName);
				if(project != null)
					projectList.add((T)project);
			}*/
			
		}
		return projectList;
	}
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getProjectByRight(String username){
		User user = userDao.getUserByName(username);
		List<RightProject> rightProjectList = rightProjectDao.getRightProjectByUserId(user.getUserId());
		List<Project> projectList = new ArrayList<Project>();
		for (RightProject rightProject : rightProjectList)
		{
			Project project = dao.getProjectById(rightProject.getProjectId());
			projectList.add(project);
		}
		return (List<T>) projectList;
	}
}
