package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Requirement;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.ScheduleData;
import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.constants.StrategyType;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanScriptDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanStrategyDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.ProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequirementDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeTriggerDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.ScriptDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.SystemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.quartz.QuartzManager;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;
import com.ssc.sshz.peg.ptaf.inspection.util.AssetAnalyzeUtil;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;

@Service
public class PlanServiceImp<T extends Plan> implements PlanService<T>
{

	@Inject
	private PlanDao<T> dao;

	@Inject
	private PlanStrategyDao<PlanStrategy> planStrategyDao;

	@Inject
	private SystemDao<System> systemDao;


	@Inject
	private RequestDao<Request> requestDao;


	@Inject
	private ItemDao<Item> itemDao;

	@Inject
	private PlanItemDao<PlanItem> planItemDao;

	@Inject
	private ProjectDao<Project> projectDao;

	@Inject
	private RuntimeDao<Runtime> runtimeDao;

	@Inject
	private RuntimeTriggerDao<RuntimeTrigger> runtimeTriggerDao;

	@Inject
	private ScriptDao<Script> scriptDao;

	@Inject
	private PlanScriptDao<PlanScript> planScriptDao;

	@Inject
	private RequirementDao<Requirement> requirementDao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllPlan() throws DataAccessException
	{
		return dao.getAllPlan();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getPlan(T entity) throws DataAccessException
	{
		return dao.getPlanById(entity.getPlanId());
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Plan addPlan(T entity) throws DataAccessException
	{
		boolean success = dao.addPlan(entity);
		if (success)
			return dao.getPlanBySystemIdPlanName(entity);
		return null;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean delPlan(T entity) throws DataAccessException
	{
		return dao.delPlanById(entity.getPlanId());
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getPlanByName(String name) throws DataAccessException
	{
		return dao.getPlanByName(name);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getPlanBySystemId(int systemId) throws DataAccessException
	{
		return (List<T>) dao.getPlanBySystemId(systemId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getPlanById(Integer id) throws DataAccessException
	{
		return dao.getPlanById(id);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getPlanBySystemIdPlanName(Plan plan) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getPlanBySystemIdPlanName(plan);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean createPlan(Runtime runtime, PlanStrategy planStrategy, RuntimeTrigger rt, PlanScript planScript,
			PlanItem planItem, Request request, Script script, User user, List<Item> itemlist, Plan tempplan, String username,
			String zipfilepath, String zipfileputpath, String runtype, String strategyLoad, String loopCount, String date_from,
			String date_to, String tempintervaltime, String intervaltimeUnit, String repeat,String itemRequirementString) throws Exception
	{
		int runType = Integer.parseInt(runtype);
		// create planItem
		AssetAnalyzeUtil util = AssetAnalyzeUtil.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for (int i = 0; i < itemlist.size(); i++)
		{

			Item tempItem = itemDao.getItemBySystemIdItemName(itemlist.get(i));
			int itemid = tempItem.getItemId();
			planItem.setItemId(itemid);
			planItem.setItemIsValid(itemlist.get(i).isDeleted());
			planItem.setPlanName(tempplan.getPlanName());
			planItem.setPlanId(tempplan.getPlanId());
			planItem.setItemName(itemlist.get(i).getItemName());
			planItemDao.addPlanItem(planItem);
			// creat request
			List<Request> requestList = util.getAllRequests(itemlist.get(i).getItemName());

			for (Request temprequest : requestList)
			{
				request.setRequestUrl(temprequest.getRequestUrl());
				request.setRequestName(temprequest.getRequestName());
				request.setItemName(itemlist.get(i).getItemName());
				request.setItemId(itemid);
				request.setPlanId(tempplan.getPlanId());
				requestDao.addRequest(request);
			}
		}
		// Add to DB
		File zipAssetFolder = new File(zipfilepath);
		byte[] bFile = new byte[(int) zipAssetFolder.length()];
		FileInputStream in = new FileInputStream(zipAssetFolder);
		in.read(bFile);
		if (in != null)
			in.close();
		String ScriptId = tempplan.getSystemId() + "" + tempplan.getPlanId();
		script.setScriptName(zipAssetFolder.getName());
		script.setScriptFile(bFile);
		script.setUploaderName(username);
		script.setUploaderId(user.getUserId());
		script.setUploadTime(new Timestamp(java.lang.System.currentTimeMillis()));
		script.setValid(true);
		script.setScriptId(Integer.parseInt(ScriptId));
		scriptDao.addScript(script);

		planScript.setPlanId(tempplan.getPlanId());
		planScript.setPlanName(tempplan.getPlanName());
		planScript.setScriptId(Integer.parseInt(ScriptId));
		planScript.setScriptName(zipAssetFolder.getName());
		planScriptDao.addPlanScript(planScript);

		// add planStrategy
		String StrategyName = "StrategyName" + java.lang.System.currentTimeMillis();
		planStrategy.setLoopCount(Integer.parseInt(loopCount));
		planStrategy.setStrategyLoad(Integer.parseInt(strategyLoad));
		planStrategy.setPlanId(tempplan.getPlanId());
		planStrategy.setPlanName(tempplan.getPlanName());
		planStrategy.setStrategyName(StrategyName);
		planStrategyDao.addPlanStrategy(planStrategy);

		// add collection
		QuartzManager quartzManager = QuartzManager.getQuartzManager();
		TestBeanCollection collection = new TestBeanCollection();

		JobData jobData = new JobData();
		jobData.setUser(user);
		jobData.setAsset(zipfileputpath);
		jobData.setDebug(FilePathConstants.CIDEBU);
		jobData.setOutput(FilePathConstants.OUTPUTTEMPPATH);
		jobData.setThreadsNum(strategyLoad);
		jobData.setRunCount(loopCount);
		jobData.setDebug("false");
		ScheduleData scheduleData = new ScheduleData();

		Map<Integer, List<Request>> requestMapByItemId = new HashMap<Integer, List<Request>>();
		List<PlanItem> planItemList = planItemDao.getAllPlanItemByPlanId(tempplan.getPlanId());
		List<Item> itemList = new ArrayList<Item>();
		for (int i = 0; i < planItemList.size(); i++)
		{
			itemList.add(itemDao.getItemById(planItemList.get(i).getItemId()));
			Request r = new Request();
			r.setPlanId(tempplan.getPlanId());
			r.setItemId(planItemList.get(i).getItemId());
			List<Request> requestList = requestDao.getRequestByItemIdAndPlanId(r);
			requestMapByItemId.put(planItemList.get(i).getItemId(), requestList);
		}
		Map<Integer,Requirement> requirementMap = new HashMap<Integer, Requirement>();
		for (Item item : itemList)
		{
			Requirement require = requirementDao.getRequirementByItemId(item.getItemId());
			requirementMap.put(item.getItemId(), require);
		}
		System cllsys = systemDao.getSystemById(tempplan.getSystemId());
		collection.setProject(projectDao.getProjectById(cllsys.getProjectId()));
		collection.setSystem(cllsys);
		collection.setPlan(tempplan);
		collection.setItemList(itemList);
		collection.setRequestMapByItemId(requestMapByItemId);
		collection.setRequirementMapByItemid(requirementMap);
		
		switch (StrategyType.values()[runType - 1])
		{
		case Infinite:
		{

			// add runtime
			runtime.setStartTime(Timestamp.valueOf(date_from));
			runtime.setRunType(Integer.parseInt(runtype));
			runtime.setIntervalTime(Integer.parseInt(tempintervaltime) * Integer.parseInt(intervaltimeUnit));
			int strategyId = planStrategyDao.getPlanStrategyByName(StrategyName).getStrategyId();
			runtime.setStrategyId(strategyId);
			String runtimeUUID = UUID.randomUUID().toString();
			runtime.setRuntimeUUID(runtimeUUID);
			runtimeDao.addRuntime(runtime);
			int runtimeId = runtimeDao.getRuntimeByUUID(runtimeUUID).getRuntimeId();
			rt.setRuntimeId(runtimeId);

			scheduleData.setStartTime(sdf.parse(date_from));
			scheduleData.setEndTime(null);
			scheduleData.setData(jobData);
			scheduleData.setIntervalSeconds(Integer.parseInt(tempintervaltime) * Integer.parseInt(intervaltimeUnit));
			scheduleData.setRepeatTime(-1);
			scheduleData.setStartNow(false);
			scheduleData.setServiceCall(false);
			scheduleData.setTestBeanCollection(collection);
			scheduleData.setRuntimeTrigger(rt);
			rt = quartzManager.addNewRuntime(scheduleData);
			break;
		}
		case Once:
		{

			// add runtime
			runtime.setStartTime(Timestamp.valueOf(date_from));
			runtime.setRunType(Integer.parseInt(runtype));
			int strategyId = planStrategyDao.getPlanStrategyByName(StrategyName).getStrategyId();
			runtime.setStrategyId(strategyId);
			String runtimeUUID = UUID.randomUUID().toString();
			runtime.setRuntimeUUID(runtimeUUID);
			runtimeDao.addRuntime(runtime);
			int runtimeId = runtimeDao.getRuntimeByUUID(runtimeUUID).getRuntimeId();
			rt.setRuntimeId(runtimeId);

			scheduleData.setStartTime(sdf.parse(date_from));
			scheduleData.setEndTime(null);
			scheduleData.setData(jobData);
			scheduleData.setIntervalSeconds(0);
			scheduleData.setRepeatTime(0);
			scheduleData.setStartNow(false);
			scheduleData.setServiceCall(false);
			scheduleData.setTestBeanCollection(collection);
			scheduleData.setRuntimeTrigger(rt);
			rt = quartzManager.addNewRuntime(scheduleData);
			break;
		}
		case Sometime:
		{
			String endTime = null;
			int realrepat = 0;
			if (date_to.equalsIgnoreCase(""))
			{
				endTime = null;
				runtime.setEndTime(null);
				scheduleData.setEndTime(null);
			}
			else
			{
				endTime = date_to;
				runtime.setEndTime(Timestamp.valueOf(endTime));
				scheduleData.setEndTime(sdf.parse(endTime));
			}

			if (repeat.equalsIgnoreCase(""))
			{
				realrepat = 0;
			}
			else
			{
				realrepat = Integer.parseInt(repeat);
				scheduleData.setRepeatTime(realrepat);
			}
			// add runtime
			runtime.setStartTime(Timestamp.valueOf(date_from));
			runtime.setRunType(Integer.parseInt(runtype));
			runtime.setIntervalTime(Integer.parseInt(tempintervaltime) * Integer.parseInt(intervaltimeUnit));
			int strategyId = planStrategyDao.getPlanStrategyByName(StrategyName).getStrategyId();
			runtime.setStrategyId(strategyId);
			String runtimeUUID = UUID.randomUUID().toString();
			runtime.setRuntimeUUID(runtimeUUID);
			runtimeDao.addRuntime(runtime);
			int runtimeId = runtimeDao.getRuntimeByUUID(runtimeUUID).getRuntimeId();
			rt.setRuntimeId(runtimeId);

			scheduleData.setStartTime(sdf.parse(date_from));
			scheduleData.setData(jobData);
			scheduleData.setIntervalSeconds(Integer.parseInt(tempintervaltime) * Integer.parseInt(intervaltimeUnit));
			scheduleData.setStartNow(false);
			scheduleData.setServiceCall(false);
			scheduleData.setTestBeanCollection(collection);
			scheduleData.setRuntimeTrigger(rt);
			rt = quartzManager.addNewRuntime(scheduleData);
			break;
		}
		}
		if (rt != null)
		{
			runtimeTriggerDao.addRuntimeTrigger(rt);
		}
		FileUtil.getInstance().delFolder(zipAssetFolder.getParentFile());
		return false;
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<Item> addItemRequest(String zipfileputpath, System system, String itemDescList, String itemRequirementString,
			Requirement requirement, Plan plan) throws Exception
	{
		AssetAnalyzeUtil util = AssetAnalyzeUtil.getInstance();
		List<Item> itemList = new ArrayList<Item>();
		util.setRootPath(zipfileputpath);
		List<String> itemNameList = util.getItems(util.getRunTime().getName());
		List<String> DBItemNamelist = new ArrayList<String>();
		List<Item> DBItemlist = itemDao.getItemBySystemId(system.getSystemId());
		// desc list
		String[] tpitemDescList = itemDescList.split("@");
		String[] itemRequirementStringList = itemRequirementString.split("@");
		for (Item DBItem : DBItemlist)
		{
			DBItemNamelist.add(DBItem.getItemName());
		}

		for (int i = 0; i < itemNameList.size(); i++)
		{

			if (!DBItemNamelist.contains(itemNameList.get(i)))
			{
				Item tempItem = new Item();
				tempItem.setItemDescription(tpitemDescList[i]);
				tempItem.setItemName(itemNameList.get(i));
				tempItem.setSystemId(system.getSystemId());
				tempItem.setDeleted(false);
				itemDao.addItem(tempItem);
				Item tempItem1 = itemDao.getItemBySystemIdItemName(tempItem);
				requirement.setItemId(tempItem1.getItemId());
				requirement.setPlanId(plan.getPlanId());
				if (itemRequirementStringList[i] == null || "".equals(itemRequirementStringList[i].trim()))
				{
					requirement.setAvgResponseTime(0);
				}
				else
				{
					requirement.setAvgResponseTime(Integer.parseInt(itemRequirementStringList[i].trim()));
				}
				requirementDao.addRequirement(requirement);
				itemList.add(tempItem1);
			}
			else
			{
				Item im = new Item();
				im.setItemName(itemNameList.get(i));
				im.setSystemId(system.getSystemId());
				im.setDeleted(false);
				itemList.add(im);
			}
		}
		return itemList;
	}
}
