package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface CIConfigService<T>
{
	public List<T> getAllConfigs() throws DataAccessException;
	public T getCIConfig(T entity) throws DataAccessException;
	public T getCIConfigBySystemuuid(String uuid) throws DataAccessException;
	public boolean addCIConfig(T entity) throws DataAccessException;
	public boolean delCIConfigtById(int id) throws DataAccessException;
	public int getCIConfigCount(T entity) throws DataAccessException;
	public boolean updateCIConfig(T entity) throws DataAccessException;
}
