package com.ssc.sshz.peg.ptaf.inspection.controller;


import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.service.ScriptUploadService;
import com.ssc.sshz.peg.ptaf.inspection.util.AssetAnalyzeUtil;
import com.ssc.sshz.peg.ptaf.inspection.util.FileZip;


@Controller
@RequestMapping("/file")
public class ScirptFileUploadController {
	
//	@Inject
//	private ItemService<Item> itemService;
//	
//	@Inject
//	private PlanItemService<PlanItem> planItemService;
//	
//	@Inject
//	private RequestService<Request> requestService;
	
	@Inject
	private ScriptUploadService scriptUploadService;
	
	 @RequestMapping(value = "/fileUpload", method = RequestMethod.POST)
	 public String createDocument(String name,
			@RequestParam("uploadFile") MultipartFile file, HttpServletResponse response,HttpSession httpSession,Item item,System system,PlanItem planItem,Request request,Model model) 
					throws Exception {
		    String realPath = FilePathConstants.TEMPFOLDERPATH;
			File pathFile=new File(realPath);
			if(!pathFile.exists()){
				pathFile.mkdirs();
			}
			file.transferTo(new File(realPath+"/"+file.getOriginalFilename()));
			
			String zipfilepath=FilePathConstants.TEMPFOLDERPATH + "/" + file.getOriginalFilename();
			String zipfileputpath =  FileZip.unzip(zipfilepath, FilePathConstants.TEMPFOLDERPATH + File.separator + java.lang.System.currentTimeMillis());
			String sid=(String) httpSession.getAttribute("systemId");
			system.setSystemId(Integer.parseInt(sid));
			
		     
			//List sumlist=ReadXMLWriteToDB(zipfileputpath, item, system, planItem, request);
			
			try {
				AssetAnalyzeUtil util =AssetAnalyzeUtil.getInstance();
				util.setRootPath(zipfileputpath);
				List<Item> DisplayItemlist = new ArrayList<Item>();
				File runtimeFile = util.getRunTime();
				if(runtimeFile == null)
					return null;
				List<String> itemNameList = util.getItems(util.getRunTime().getName());
				if(itemNameList == null || itemNameList.size() == 0)
					return null;
				for (int j = 0; j < itemNameList.size(); j++){
					Item tempitem=new Item();
					tempitem.setItemName(itemNameList.get(j));
					DisplayItemlist.add(tempitem);
				}
				//List<Item> itemList = ReadScripToDB(zipfileputpath,system);
				model.addAttribute("itemlist",DisplayItemlist);
				httpSession.setAttribute("zipfilepath",zipfilepath);
			//	httpSession.setAttribute("itemlist",itemList);
				httpSession.setAttribute("zipfileputpath",zipfileputpath);
			} catch (Exception e) {
				throw e;
			}
		    return "/view/fileUploadSuccess.jsp";                            
	 }
	 
		
		/*@SuppressWarnings({ "unchecked", "rawtypes" })
		public List ReadXMLWriteToDB(String configTempPath,Item item,System system,PlanItem planItem,Request request) throws IOException, ParseException, InterruptedException, DocumentException
		{
			ReadXMLUtil xmlReader = new ReadXMLUtil();
			List<String> requestURL = xmlReader.getRequestURL(configTempPath);
			List<String> requestName = xmlReader.getRequestName(configTempPath);
			List<Item> itemList = new ArrayList<Item>();
			List<Item> DBItemlist = new ArrayList<Item>();
			List sumList = new ArrayList();
			List<String> DBItemNamelist = new ArrayList<String>();
			for (int i = 0; i < requestName.size(); i++)
			{
				
				DBItemlist=itemService.getItemBySystemId(system.getSystemId());
				for (int j = 0; j < DBItemlist.size(); j++)
				{
					DBItemNamelist.add(DBItemlist.get(j).getItemName());
				}
				
				if (!DBItemNamelist.contains(requestName.get(i)))
				{
					item.setItemName(requestName.get(i));
					item.setSystemId(system.getSystemId());
					item.setDeleted(false);
					itemService.addItem(item);
					Item tempItem = itemService.getItemBySystemIdItemName(item);
					int itemid = tempItem.getItemId();
					itemList.add(tempItem);
					
				}else{
					Item im=new Item();
					im.setItemName(requestName.get(i));
					im.setSystemId(system.getSystemId());
					im.setDeleted(false);
					itemList.add(im);
				}
			}
			sumList.add(requestURL);
			sumList.add(itemList);
			sumList.add(requestName);
			return sumList;
		}*/
		
/*		@SuppressWarnings("rawtypes")
		public List readScripToDB(String zipfileputpath,System system,Item item) throws Exception{
			List<Item> itemList = new ArrayList<Item>();
			List<String> dbItemNamelist = new ArrayList<String>();
			
			AssetAnalyzeUtil util =AssetAnalyzeUtil.getInstance();
			util.setRootPath(zipfileputpath);
			List<String> itemNameList = util.getItems(util.getRunTime().getName());
			
			int systemId = system.getSystemId();
			List<Item> dbItemlist = itemService.getItemBySystemId(systemId);
			for(Item dbItem : dbItemlist){
				dbItemNamelist.add(dbItem.getItemName());
			}
			
			for(int i=0;i<itemNameList.size();i++){
			
				if (!dbItemNamelist.contains(itemNameList.get(i))){
//					Item tempItem=new Item();
					item.setItemName(itemNameList.get(i));
					item.setSystemId(systemId);
					item.setDeleted(false);
					itemService.addItem(item);
					Item itemFromDB = itemService.getItemBySystemIdItemName(item);
					itemList.add(itemFromDB);				
				   }else{
					item.setItemName(itemNameList.get(i));
					item.setSystemId(systemId);
					item.setDeleted(false);
					itemList.add(item);
				   }
			}
			return itemList;
		}
		*/
		
		 @RequestMapping(value = "/fileUploadforEdit", method = RequestMethod.POST)
		 public String createDocument1(String name,
				@RequestParam("uploadFile") MultipartFile file, HttpServletResponse response,HttpSession httpSession,Item item,System system,PlanItem planItem,Request request,Script script,Model model) 
						throws Exception {
			 
//    			 String sid=(String) httpSession.getAttribute("systemId");
    			 Plan plan=(Plan) httpSession.getAttribute("scirptChangeplan");
    			 
				File pathFile=new File(FilePathConstants.TEMPFOLDERPATH);
				if(!pathFile.exists()){
					pathFile.mkdirs();
				}
				file.transferTo(new File(FilePathConstants.TEMPFOLDERPATH+"/"+file.getOriginalFilename()));
				
				String zipfilepath=FilePathConstants.TEMPFOLDERPATH + "/" + file.getOriginalFilename();
				String zipfileputpath = FileZip.unzip(zipfilepath, FilePathConstants.TEMPFOLDERPATH + File.separator + java.lang.System.currentTimeMillis());
				
//				system.setSystemId(plan.getSystemId());
				
				List<Item> itemlist = scriptUploadService.upload(plan.getSystemId(), plan, zipfileputpath, item, planItem);
//				planItemService.DeletePlanItemByPlanId(plan.getPlanId());
//				
//				List<Item> itemlist =(List<Item>) readScripToDB(zipfileputpath,system,item);
//				try {
//					
//					AssetAnalyzeUtil util =AssetAnalyzeUtil.getInstance();	
//					//update planitem to DB
//					for(int i=0;i<itemlist.size();i++){
//						Item tempItem = itemService.getItemBySystemIdItemName(itemlist.get(i));
//						int itemid = tempItem.getItemId();
//						planItem.setItemId(itemid);
//						planItem.setItemIsValid(itemlist.get(i).isDeleted());
//						planItem.setPlanName(plan.getPlanName());
//						planItem.setPlanId(plan.getPlanId());
//						planItem.setItemName(itemlist.get(i).getItemName());
//						planItemService.addPlanItem(planItem);
//						
//					    
//					    List<String>   DBRequestURLlist=new ArrayList<String>();
//					    List<String>   DocRequestURLlist=new ArrayList<String>();
//					    Request tmpreq=new Request();
//					    tmpreq.setItemId(itemid);
//					    tmpreq.setPlanId(plan.getPlanId());
//					    List<Request>  DBItemRequestlist=requestService.getRequestByItemIdAndPlanId(tmpreq);
//					    List<Request>  requestList = util.getAllRequests(itemlist.get(i).getItemName());
//					    Map<String,String> rq=new HashMap<String,String>();
//					    for(Request DocRequest : requestList){
//					    	DocRequestURLlist.add(DocRequest.getRequestUrl());
//					    	rq.put(DocRequest.getRequestUrl(), DocRequest.getRequestName());
//						}
//					    
//						for(Request DBRequest : DBItemRequestlist){
//							DBRequestURLlist.add(DBRequest.getRequestUrl());
//						}
//						for(int k=0;k<DocRequestURLlist.size();k++){
//							
//							if (!DBRequestURLlist.contains(DocRequestURLlist.get(k))){
//								
//								Request request1=new Request();
//								request1.setRequestUrl(DocRequestURLlist.get(k));
//								request1.setRequestName(rq.get(DocRequestURLlist.get(k)));
//								request1.setItemName(itemlist.get(i).getItemName());
//								request1.setItemId(itemid);
//								request1.setPlanId(plan.getPlanId());
//								requestService.addRequest(request1);			
//							   }
//						}
//						
//					}
///*				    //Add to DB
//					File zipAssetFolder = new File(zipfilepath);
//					byte[] bFile = new byte[(int) zipAssetFolder.length()];
//					FileInputStream in = new FileInputStream(zipAssetFolder);
//					in.read(bFile);
//					String ScriptId=tempplan.getSystemId()+""+tempplan.getPlanId();
//					java.lang.System.out.println("...................................."+ScriptId);
//					script.setScriptName(zipAssetFolder.getName());
//					script.setScriptFile(bFile);
//					script.setUploaderName(username);
//					script.setUploaderId(CurrentUserID);
//					script.setUploadTime(new Timestamp(java.lang.System.currentTimeMillis()));
//					script.setValid(true);
//					script.setScriptId(Integer.parseInt(ScriptId));
//					ScriptService.addScript(script);
//					
//					planScript.setPlanId(tempplan.getPlanId());
//					planScript.setPlanName(tempplan.getPlanName());
//					planScript.setScriptId(Integer.parseInt(ScriptId));
//					planScript.setScriptName(zipAssetFolder.getName());
//					planScriptDao.addPlanScript(planScript);*/
//					
//				} catch (Exception e) {
//					throw e;
//				}
				model.addAttribute("itemlist",itemlist);	
			    return "/view/fileUploadSuccess.jsp";                            
		 }
}
