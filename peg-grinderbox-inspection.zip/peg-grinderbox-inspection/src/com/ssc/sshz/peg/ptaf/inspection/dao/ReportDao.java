package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.Report;

public interface ReportDao<T> {

	public List<T> getAllReport() throws DataAccessException;

	public boolean addReport(T entity) throws DataAccessException;

	public boolean updateStatus(Report report) throws DataAccessException;

	public boolean updateExecutePercent(Report report)
			throws DataAccessException;

	public boolean deleteReportByUUID(String reportUUID)
			throws DataAccessException;;

	public T getReportByUUID(String reportUUID)
			throws DataAccessException;;

	public List<T> getPagingReprot(Map<String, Integer> pageparm)
			throws DataAccessException;

	public List<Report> getDownloadPercentList() throws DataAccessException;
}
