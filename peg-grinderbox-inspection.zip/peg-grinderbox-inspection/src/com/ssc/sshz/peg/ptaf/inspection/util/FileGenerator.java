package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.Logger;

public class FileGenerator
{
	private static final Logger logger = Logger.getLogger(FileGenerator.class);
	public static boolean generateFile(byte[] bytes, String targertFolder, String filename)
	{
		boolean flag = false;
		FileOutputStream out = null;
		File folder = new File(targertFolder);
		if(!folder.exists())
			folder.mkdir();
		try
		{
			out = new FileOutputStream(new File(folder, filename));
			out.write(bytes);
		}
		catch (FileNotFoundException e)
		{
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		catch (IOException e)
		{
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		return flag;
	}
}
