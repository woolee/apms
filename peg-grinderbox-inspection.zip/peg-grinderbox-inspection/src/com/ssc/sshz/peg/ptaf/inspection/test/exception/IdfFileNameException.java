package com.ssc.sshz.peg.ptaf.inspection.test.exception;

public class IdfFileNameException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IdfFileNameException(){
		super();
	}
	
	public IdfFileNameException(String str){
		super(str);
	}
}
