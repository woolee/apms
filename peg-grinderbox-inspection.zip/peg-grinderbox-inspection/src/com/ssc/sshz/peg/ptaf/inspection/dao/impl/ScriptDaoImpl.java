package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.dao.ScriptDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ScriptMapper;

@Repository
public class ScriptDaoImpl<T extends Script> implements ScriptDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private ScriptMapper mapper;

	@Override
	public boolean addScript(T entity)
	{
		boolean flag = false;
		try
		{
			mapper.addScript(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add script to database",e);
			throw new DaoException("Exception while add script to database", e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getScriptById(Integer id)
	{
		T entity = null;
		try
		{
			entity = (T) mapper.getScriptById(id);
		}
		catch (Exception e)
		{
			logger.error("Exception while get script by id from database",e);
			throw new DaoException("Exception while get script by id from database",e);
		}
		return entity;
	}

	@Override
	public boolean delScriptById(Integer id)
	{
		boolean flag = false;
		try
		{
			mapper.delScriptById(id);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while delete script by id from database",e);
			throw new DaoException("Exception while delete script by id from database",e);
		}
		return flag;
	}

	@Override
	public boolean delScriptByName(String name)
	{
		boolean flag = false;
		try
		{
			mapper.delScriptByName(name);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while delete script by name from database",e);
			throw new DaoException("Exception while delete script by name from database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllScript()
	{
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllScript();
			}
		catch(Exception e)
		{
			logger.error("Exception while get all scripts from database",e);
			throw new DaoException("Exception while get all scripts from database",e);
		}
		return entity;

	}

	@SuppressWarnings("unchecked")
	@Override
	public T getScript(T entity)
	{
		T obj = null;
		try
		{
			obj = (T) mapper.getScript(entity);
		}
		catch (Exception e)
		{
			logger.error("Exception while get script from database",e);
			throw new DaoException("Exception while get script from database",e);
		}
		return obj;
	}

}
