package com.ssc.sshz.peg.ptaf.inspection.bean;

public class TestError
{
	private int errorId;
	private String errorType;
	private String errorName;
	private String errorMessage;
	private String errorDetail;
	private int briefId;
	public int getErrorId()
	{
		return errorId;
	}
	public void setErrorId(int errorId)
	{
		this.errorId = errorId;
	}
	public String getErrorType()
	{
		return errorType;
	}
	public void setErrorType(String errorType)
	{
		this.errorType = errorType;
	}
	public String getErrorName()
	{
		return errorName;
	}
	public void setErrorName(String errorName)
	{
		this.errorName = errorName;
	}
	public String getErrorMessage()
	{
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage)
	{
		this.errorMessage = errorMessage;
	}
	public String getErrorDetail()
	{
		return errorDetail;
	}
	public void setErrorDetail(String errorDetail)
	{
		this.errorDetail = errorDetail;
	}
	public int getBriefId()
	{
		return briefId;
	}
	public void setBriefId(int briefId)
	{
		this.briefId = briefId;
	}
	
}
