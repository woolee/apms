package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface CIScriptDao<T> {
	public boolean addCIScript(T entity) throws DataAccessException;
	public List<T> getAllCIScript() throws DataAccessException;
	public T getCIScript(T entity) throws DataAccessException;
}
