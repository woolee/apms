package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.dao.TestErrorDao;
import com.ssc.sshz.peg.ptaf.inspection.service.TestErrorService;

@Service

public class TestErrorServiceImp<T extends TestError> implements TestErrorService<T>
{
	@Inject
	private TestErrorDao<T> dao;
	
	@Override
	public boolean addTestError(T entity) throws DataAccessException {
		return false;
	}

	@Override
	public List<T> getAllTestError() throws DataAccessException {
		return null;
	}

	@Override
	public T getTestError(T entity) throws DataAccessException {
		return null;
	}

	@Override
	public List<T> getTestErrorByBriefId(int briefId)
			throws DataAccessException {
		return dao.getTestErrorByBriefId(briefId);
	}

	@Override
	public List<T> getTestErrorByBriefAndType(T entity)
			throws DataAccessException {
		return null;
	}
	
}
