package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface UserGroupDao<T> {
	public boolean addUserGroup(T entity) throws DataAccessException;
	public List<T> getUserGroupByUserId(int userId) throws DataAccessException;
}
