package com.ssc.sshz.peg.ptaf.inspection.service;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;

public interface TestBeanCollectionService<T>
{
	public TestBeanCollection setCollectionWithPlanId(int planId) throws DataAccessException;
}
