package com.ssc.sshz.peg.ptaf.inspection.mapper;
import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
public interface PlanStrategyMapper extends SqlMapper{
	public void addPlanStrategy(PlanStrategy planStrategy);
	public List<PlanStrategy> getAllPlanStrategy(); 
	public PlanStrategy getPlanStrategyByName(String name);
	public List<PlanStrategy> getPlanStrategyByPlanId(int id);
	public PlanStrategy getPlanStrategyById(int id);
}
