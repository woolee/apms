package com.ssc.sshz.peg.ptaf.inspection.test.constants;

public class DataHeaders
{
	public static final String THREAD = "Thread";
	public static final String RUN = "Run";
	public static final String TEST = "Test";
	public static final String STARTTIME = "Start time (ms since Epoch)";
	public static final String TESTTIME = "Test time";
	public static final String ERRORS = "Errors";
	public static final String HTTPRESPONSECODE = "HTTP response code";
	public static final String HTTPRESPONSELENGTH = "HTTP response length";
	public static final String HTTPRESPONSEERROR = "HTTP response errors";
	public static final String TIMETORSVHOST = "Time to resolve host";
	public static final String TIMETOESTCONN = "Time to establish connection";
	public static final String TIMETOFIRSTBYTE = "Time to first byte";
	public static final String NEWCONN = "New connections";
	
}
