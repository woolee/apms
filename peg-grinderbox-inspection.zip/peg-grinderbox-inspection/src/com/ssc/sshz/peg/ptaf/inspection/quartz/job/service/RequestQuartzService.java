package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RequestMapper;

public class RequestQuartzService<T extends Request>
{
	private Logger logger = Logger.getLogger(getClass());
	public List<T> getRequestsByItemId(int id) throws Exception
	{
		List<T> object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestMapper mapper = session.getMapper(RequestMapper.class);
			object = (List<T>) mapper.getRequestsByItemId(id);
		}
		catch (Exception e)
		{
			logger.error("exception while get all request from databse",e);
			throw new Exception("exception while get all request from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	};
	
	public T getRequestsByRequestId(int requestId) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestMapper mapper = session.getMapper(RequestMapper.class);
			object = (T) mapper.getRequestByRequestId(requestId);
		}
		catch (Exception e)
		{
			logger.error("exception while get request by request id from databse",e);
			throw new Exception("exception while get request by request id from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	};
	
	public T getRequestByRequestName(String requestName) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestMapper mapper = session.getMapper(RequestMapper.class);
			object = (T) mapper.getRequestByRequestName(requestName);
		}
		catch (Exception e)
		{
			logger.error("exception while get all request from databse",e);
			throw new Exception("exception while get  request from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	};
	
	
	public boolean addRequest(T request) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestMapper mapper = session.getMapper(RequestMapper.class);
			mapper.addRequest(request);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while get all request from databse",e);
			throw new Exception("exception while get all request from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	};
}
