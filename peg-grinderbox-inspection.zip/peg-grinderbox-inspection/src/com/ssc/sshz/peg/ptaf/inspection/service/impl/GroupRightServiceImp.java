package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.GroupRight;
import com.ssc.sshz.peg.ptaf.inspection.dao.GroupRightDao;
import com.ssc.sshz.peg.ptaf.inspection.service.GroupRightService;
@Service
public class GroupRightServiceImp<T extends GroupRight> implements GroupRightService<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private GroupRightDao<T> dao;
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addGroupRight(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addGroupRight(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllGroupRight() throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getAllGroupRight();
	}
	
	
}
