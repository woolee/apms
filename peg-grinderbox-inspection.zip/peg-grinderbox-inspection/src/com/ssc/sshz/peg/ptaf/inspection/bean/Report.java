package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;


//@Component
@Entity
public class Report implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8225379095340041819L;
	private int reportId;
	private String reportUUID;
	private String projectName;
	private String fgSystemName;
	private String bgSystemName;
	private String reportName;
	private String fgContext;
	private String bgContext;
	private String fgEnv;
	private String bgEnv;
	private Date startTime;
	private Date endTime;
	private String analysisStatus;
	private int executePercentage;
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getFgSystemName() {
		return fgSystemName;
	}
	public void setFgSystemName(String fgSystemName) {
		this.fgSystemName = fgSystemName;
	}
	public String getBgSystemName() {
		return bgSystemName;
	}
	public void setBgSystemName(String bgSystemName) {
		this.bgSystemName = bgSystemName;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public String getFgContext() {
		return fgContext;
	}
	public void setFgContext(String fgContext) {
		this.fgContext = fgContext;
	}
	public String getBgContext() {
		return bgContext;
	}
	public void setBgContext(String bgContext) {
		this.bgContext = bgContext;
	}
	public String getFgEnv() {
		return fgEnv;
	}
	public void setFgEnv(String fgEnv) {
		this.fgEnv = fgEnv;
	}
	public String getBgEnv() {
		return bgEnv;
	}
	public void setBgEnv(String bgEnv) {
		this.bgEnv = bgEnv;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime()
	{
		return endTime;
	}
	public void setEndTime(Date endTime)
	{
		this.endTime = endTime;
	}
	
	public int getReportId()
	{
		return reportId;
	}
	public void setReportId(int reportId)
	{
		this.reportId = reportId;
	}
	public String getReportUUID()
	{
		return reportUUID;
	}
	public void setReportUUID(String reportUUID)
	{
		this.reportUUID = reportUUID;
	}
	public String getAnalysisStatus()
	{
		return analysisStatus;
	}
	public void setAnalysisStatus(String analysisStatus)
	{
		this.analysisStatus = analysisStatus;
	}
	public int getExecutePercentage()
	{
		return executePercentage;
	}
	public void setExecutePercentage(int executePercentage)
	{
		this.executePercentage = executePercentage;
	}
	
	
}
