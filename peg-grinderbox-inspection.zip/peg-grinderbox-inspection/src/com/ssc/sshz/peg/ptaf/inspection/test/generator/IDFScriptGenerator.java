package com.ssc.sshz.peg.ptaf.inspection.test.generator;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Idf;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;
import com.ssc.sshz.peg.ptaf.inspection.util.IDFUtil;

public class IDFScriptGenerator
{

    /**
     * generate test script for each IDF service,
     * 
     * @param idfMap
     * @param url
     * @param context
     * @param paramFiles
     * @param scriptDest
     * @return return the generated files 
     * @throws IOException
     */
    public Set<File> generateIDFScript(Map<String, Idf> idfMap, String url, String context, Set<File> paramFiles, File scriptDest)
	    throws IOException
    {
	
	FileUtil.getInstance().checkAndCreateFolder(scriptDest);
	
	Set<File> scripts = new HashSet<File>();

	Set<String> idfKeys = idfMap.keySet();
	for (String reqNum : idfKeys)
	{
	    File paramFile = matchFile(reqNum, paramFiles);
	    if(paramFile == null)
		continue;

	    Map<String, String> varMap = new HashMap<String, String>();

	    varMap.put("${url}", FileUtil.getInstance().quot(url));
	    varMap.put("${context}", FileUtil.getInstance().quot(context));
	    varMap.put("${IDFnum}", FileUtil.getInstance().quot(reqNum));
	    varMap.put("${inputs}", FileUtil.getInstance().quot(IDFUtil.listToString(idfMap.get(reqNum).getInputList())));

//	    varMap.put("${paramsFile}", FileUtil.getInstance().quot(paramFile.getAbsolutePath()));
	    varMap.put("${paramsFile}", FileUtil.getInstance().quot(TestAssetContants.PARAMFOLDER + File.separator + paramFile.getName()));
	    varMap.put("${Reqnum}", reqNum);
	    varMap.put("${IDFname}", "IDF_" + reqNum);

	    String scriptFileName = "IDF_" + reqNum + ".py";
	    File scriptFile = new File(scriptDest, scriptFileName);
	    InputStream in = IDFScriptGenerator.class.getResourceAsStream(TestAssetContants.IDF_SCRIPT_TMP);
	    FileUtil.getInstance().createScriptContents(varMap, in, scriptFile);
	    scripts.add(scriptFile);
	}
	return scripts;
    }
    
    private File matchFile(String reqNum, Set<File> params)
    {
	if(params == null )
	    return null;
	
	for (File file : params)
	{
	    if(file.getName().equalsIgnoreCase(reqNum + ".csv"))
		return file;
	}
	return null;
    }
}
