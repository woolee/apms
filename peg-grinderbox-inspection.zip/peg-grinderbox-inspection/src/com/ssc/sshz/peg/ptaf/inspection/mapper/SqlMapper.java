package com.ssc.sshz.peg.ptaf.inspection.mapper;

public interface SqlMapper
{

}
