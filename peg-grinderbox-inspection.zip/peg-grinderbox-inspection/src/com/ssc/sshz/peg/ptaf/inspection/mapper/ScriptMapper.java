package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.Script;

public interface ScriptMapper extends SqlMapper{
	public List<Script> getAllScript(); 
	public Script getScript(Script script);
	public Script getScriptById(Integer id);
	public Script getScriptByName(String name);
	public void addScript(Script script);
//	public void editScript(Script script);
	public void delScriptById(Integer id);
	public void delScriptByName(String name);
	public void updateScript(Script script);
}
