package com.ssc.sshz.peg.ptaf.inspection.service.impl;
import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.service.UserService;

@Service

public class UserServiceImp<T extends User> implements UserService<T> {
	
	@Inject
	private UserDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public User getUserByName(String name) throws DataAccessException {
		return dao.getUserByName(name);
	}



}
