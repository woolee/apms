package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.util.Date;

public class QTMLogScan implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1805307419515143953L;
	private int scanId;
	private String scanUUID;
	private String projectName;
	private String fgSystemName;
	private String bgSystemName;
	private String fgContext;
	private String bgContext;
	private String fgEnv;
	private String bgEnv;
	private Date startTime;
	private Date endTime;
	private int executePercentage;
	private byte[] errorFile;
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getFgSystemName() {
		return fgSystemName;
	}
	public void setFgSystemName(String fgSystemName) {
		this.fgSystemName = fgSystemName;
	}
	public String getBgSystemName() {
		return bgSystemName;
	}
	public void setBgSystemName(String bgSystemName) {
		this.bgSystemName = bgSystemName;
	}
	public String getFgContext() {
		return fgContext;
	}
	public void setFgContext(String fgContext) {
		this.fgContext = fgContext;
	}
	public String getBgContext() {
		return bgContext;
	}
	public void setBgContext(String bgContext) {
		this.bgContext = bgContext;
	}
	public String getFgEnv() {
		return fgEnv;
	}
	public void setFgEnv(String fgEnv) {
		this.fgEnv = fgEnv;
	}
	public String getBgEnv() {
		return bgEnv;
	}
	public void setBgEnv(String bgEnv) {
		this.bgEnv = bgEnv;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public int getExecutePercentage() {
		return executePercentage;
	}
	public void setExecutePercentage(int executePercentage) {
		this.executePercentage = executePercentage;
	}
	public byte[] getErrorFile() {
		return errorFile;
	}
	public void setErrorFile(byte[] errorFile) {
		this.errorFile = errorFile;
	}
	public int getScanId() {
		return scanId;
	}
	public void setScanId(int scanId) {
		this.scanId = scanId;
	}
	public String getScanUUID() {
		return scanUUID;
	}
	public void setScanUUID(String scanUUID) {
		this.scanUUID = scanUUID;
	}

}
