package com.ssc.sshz.peg.ptaf.inspection.controller;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.ScheduleData;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.quartz.QuartzManager;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanService;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanStrategyService;
import com.ssc.sshz.peg.ptaf.inspection.service.ProjectService;
import com.ssc.sshz.peg.ptaf.inspection.service.RuntimeService;
import com.ssc.sshz.peg.ptaf.inspection.service.SystemService;
import com.ssc.sshz.peg.ptaf.inspection.service.TestBeanCollectionService;
import com.ssc.sshz.peg.ptaf.inspection.service.UserService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;

@Controller
@RequestMapping("/runtime")
public class RuntimeController
{
	private static final Logger logger = Logger.getLogger(RuntimeController.class);
	@Inject
	private RuntimeService<Runtime> runtimeService;
	
	@Inject
	private SystemService<System> systemService;
	
	@Inject
	private PlanService<Plan> planService;
	
	@Inject
	private UserService<User> userService;
	
	@Inject
	private PlanStrategyService<PlanStrategy> planStrategyService;
	
	@Inject
	private ProjectService<Project> projectService;
	
	
	@Inject
	private TestBeanCollectionService<TestBeanCollection> testBeanCollService;
	
	@RequestMapping("/CreateRuntime")
	public String CreateRuntime(Runtime runtime,HttpServletRequest  request){
		String strategyName=request.getParameter("strategyName");
		int StrategyID=planStrategyService.getPlanStrategyByName(strategyName).getStrategyId();
		runtime.setStrategyId(StrategyID);
		runtimeService.addRuntime(runtime);
		return "/view/success.jsp";
	}
	
	
	@RequestMapping("/CreateRuntimeForEditer")
	public String CreateRuntimeForEditer(RuntimeTrigger rt,Project project,System system,Plan plan,Model model,Runtime runtime,HttpServletRequest  request,RuntimeTrigger runtimeTrigger,HttpSession httpSession ) throws Exception{

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userName = auth.getName();
		
		int runtype = Integer.parseInt(request.getParameter("runtype"));
		String strategyLoad = request.getParameter("strategyLoad");
		String loopCount = request.getParameter("loopCount");
		int planId= Integer.parseInt(request.getParameter("planId"));
		String strategyName=request.getParameter("strategyName");
		String dateFrom = request.getParameter("date_from");
		String dateTo = request.getParameter("date_to");
		String intervalTime = request.getParameter("intervaltime");
		String timeUnit = request.getParameter("intervaltimeUnit");
		String repeatStr = request.getParameter("repeat");
		
		User user = userService.getUserByName(userName);
		
		JobData jobData = new JobData();
		jobData.setUser(user);
		jobData.setAsset(null);
		jobData.setOutput(FilePathConstants.OUTPUTTEMPPATH);
		jobData.setDebug(FilePathConstants.CIDEBU);
		jobData.setThreadsNum(strategyLoad);
		jobData.setRunCount(loopCount);
		
		TestBeanCollection collection = testBeanCollService.setCollectionWithPlanId(planId);
		
		runtimeService.createRuntime(user, rt, project, system, plan, runtime, runtimeTrigger, runtype, jobData, collection, intervalTime, timeUnit, strategyName, dateFrom, dateTo, repeatStr);
		return "/view/showRuntime.jsp";
	
	}
	
	@RequestMapping("/ManualExecuteRuntime")
	public String ManualRuntime(Project project,System system,Plan plan,Runtime runtime,HttpServletRequest  request) throws Exception{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userName = auth.getName(); 
		int planId=Integer.parseInt(request.getParameter("planId"));
		//add to job
//		TestBeanCollection collection = new TestBeanCollection();
		JobData jobData=new JobData();
		jobData.setAsset(null);
		jobData.setOutput(FilePathConstants.OUTPUTTEMPPATH);
	    User user =userService.getUserByName(userName);
	    jobData.setUser(user);
	    jobData.setDebug("false");
	    List<PlanStrategy> planStrategys = planStrategyService.getPlanStrategyByPlanId(planId);
	    if(planStrategys.size() != 0)
	    {
	    	PlanStrategy planStrtegy = planStrategys.get(0);
	    	jobData.setRunCount(String.valueOf(planStrtegy.getLoopCount()));
	    	jobData.setThreadsNum(String.valueOf(planStrtegy.getStrategyLoad()));
	    	
	    }
	    
	    TestBeanCollection collection = testBeanCollService.setCollectionWithPlanId(planId);
		QuartzManager quartzManager = QuartzManager.getQuartzManager();
		ScheduleData scheduleData=new ScheduleData();
		try {
			scheduleData.setData(jobData);
			scheduleData.setStartNow(true);
			scheduleData.setServiceCall(false);
			scheduleData.setTestBeanCollection(collection);
			quartzManager.addNewRuntime(scheduleData);
			
		}catch (Exception e) {
			throw e;
		}
	
		return "/job/monitor.do";
	}
	
	@RequestMapping("/RemoveRuntime")
	public String delRuntime(Model model,Runtime runtime,HttpServletRequest  request) throws Exception{
		String strategyName=request.getParameter("strategyName");
		PlanStrategy planStrategy=planStrategyService.getPlanStrategyByName(strategyName);
		int runtimeId = runtime.getRuntimeId();
		runtimeService.delRtAndRtTriggerByRuntimeId(runtimeId);
		
		List<Runtime> runtimeList=runtimeService.getRuntimeStrategyID(planStrategy.getStrategyId());
		model.addAttribute("RuntimeList",runtimeList);
		return "/view/showRuntime.jsp";
	}
	
	@RequestMapping("/RuntimePageInint")
	public String Inint(Model model){
		model.addAttribute("projects",projectService.getAllProject());
		model.addAttribute("systems",systemService.getAllSystem());
		model.addAttribute("plans",planService.getAllPlan());
		model.addAttribute("strategys",planStrategyService.getAllPlanStrategy());
		return "/page/createRuntime.jsp";
	}
	
	@RequestMapping("/GetRuntime")
	public String GetRuntime(Runtime runtime,Model model){
		model.addAttribute(runtimeService.getRuntime(runtime));
		return "/view/showRuntime.jsp";
	}
	
	@ExceptionHandler(Exception.class)
	public String exception(Exception e, HttpServletRequest request){
		request.setAttribute("exception", e);
		logger.error(e.getMessage(),e);
		return "/view/error.jsp";
	}
}
