package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.Request;

public interface RequestService<T>
{
	public boolean addRequest(T entity) throws DataAccessException;
	public Request getRequestByRequestName(String requetName) throws DataAccessException;
	public List<T> getRequestByItemIdAndPlanId(T entity) throws DataAccessException;
	public Request getRequestByRequestId(int requestId) throws DataAccessException;
	public List<T> getRequestByPlanId( int PlanId) throws DataAccessException;
	public List<T> getRequestsByItemId(int id) throws DataAccessException;
	public boolean updateRequest(T entity) throws DataAccessException;
}
