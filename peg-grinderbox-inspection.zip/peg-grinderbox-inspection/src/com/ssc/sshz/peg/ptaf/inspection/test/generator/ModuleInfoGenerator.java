package com.ssc.sshz.peg.ptaf.inspection.test.generator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Set;

import org.apache.log4j.Logger;

public class ModuleInfoGenerator
{
	private static final Logger logger = Logger.getLogger(ModuleInfoGenerator.class);
    /**
     * 
     * @param ScriptFile
     * @param modules
     * @throws IOException
     */
    public void gnerateModuleInfo(File ScriptFile, Set<String> modules) throws IOException
    {

	String line;

	BufferedWriter out = null;

	try
	{
	    out = new BufferedWriter(new FileWriter(ScriptFile));
	    for (String module : modules)
	    {
		line = "from " + module + " import *";
		out.write(line);
		out.newLine();
	    }

	}
	catch (IOException e)
	{
		logger.error(e.getMessage(),e);
	    e.printStackTrace();
	    throw new IOException("can not gengerate __init__.py:" + e.getMessage());
	}
	finally
	{
	    if (out != null)
		out.close();
	}
    }
}
