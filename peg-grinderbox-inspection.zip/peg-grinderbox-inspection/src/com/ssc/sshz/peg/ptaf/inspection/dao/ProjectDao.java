package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface ProjectDao<T> {
	public boolean addProject(T entity) throws DataAccessException;
	public T getProjectById(Integer id) throws DataAccessException;
	public T getProjectByuuid(String id) throws DataAccessException;
	public T getProjectByName(String name) throws DataAccessException;
	public boolean delProjectById(Integer id) throws DataAccessException;
	public boolean delProjectByName(String name) throws DataAccessException;
	public List<T> getAllProject() throws DataAccessException;
	public List<T> getAllProjectByUsername(String userName) throws DataAccessException;
}
