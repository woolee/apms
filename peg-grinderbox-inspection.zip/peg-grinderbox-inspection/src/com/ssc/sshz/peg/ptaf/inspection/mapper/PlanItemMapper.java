package com.ssc.sshz.peg.ptaf.inspection.mapper;
import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
public interface PlanItemMapper extends SqlMapper{
	public void addPlanItem(PlanItem planitem);
	public void DeletePlanItemByPlanId(int planId);
	public void updatePlanItem(PlanItem planitem);
	public PlanItem getPlanItemByItemId(Integer id);
	public PlanItem getPlanItemByPlanIdAndItemName(PlanItem planitem);
	public List<PlanItem> getAllPlanItem(); 
	public List<PlanItem> getAllPlanItemByPlanId(int planId);
	public List<PlanItem> getvalidPlanItemByPlanId(int planId);
}
