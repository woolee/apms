package com.ssc.sshz.peg.ptaf.inspection.controller;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssc.sshz.peg.ptaf.inspection.bean.RightNotification;
import com.ssc.sshz.peg.ptaf.inspection.bean.RightProject;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.service.RightNotificationService;
import com.ssc.sshz.peg.ptaf.inspection.service.RightProjectService;
import com.ssc.sshz.peg.ptaf.inspection.service.UserService;

@Controller
@RequestMapping("/permission")
public class PermissionController
{
	private static final Logger logger = Logger.getLogger(PermissionController.class);	
	
	@Inject
	private RightProjectService<RightProject> rightProjectService;
	
	@Inject
	private UserService<User> userService;
	
	@Inject
	private RightNotificationService<RightNotification> rightNoticeService;
	@RequestMapping("/init")
	public String CreateSystem(Model model){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String username = auth.getName();
		List<RightProject> rightProjectList = rightProjectService.getAllRightProject();
		for (int i = rightProjectList.size()-1; i >=0; i--)
		{
			if("ROLE_USER".equals(rightProjectList.get(i).getRightName()))
				rightProjectList.remove(i);
		}
//		int userId = userService.getUserByName(username).getUserId();
		List<RightProject> userRightProjectList = rightProjectService.getRightProjectByUsername(username);
		for (int i = userRightProjectList.size()-1; i >=0; i--)
		{
			if("ROLE_USER".equals(userRightProjectList.get(i).getRightName()))
				userRightProjectList.remove(i);
		}
		
        model.addAttribute("rightProjectList", rightProjectList);
        model.addAttribute("userRightProjectList", userRightProjectList);
		return "../view/permissionSelect.jsp";
	}
	
	
	@RequestMapping("/applyRights")
	@ResponseBody
	/**
	 * get the apply new rights and delete current right
	 * @param request
	 * @param model return the apply status
	 * @return
	 */
	public String applyRights(HttpServletRequest request,RightNotification rightNotice,Model model){
		String rights = request.getParameter("rights");
		System.out.println(rights);
		List<String> applyProjectList = Arrays.asList(rights.split(","));
		List<String> applyList = new ArrayList<String>();
		List<String> deleteList = new ArrayList<String>();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String username = auth.getName();
		int userId = userService.getUserByName(username).getUserId();
		List<RightProject> userRightProjectList = rightProjectService.getRightProjectByUsername(username);
		
//		List<UserGroup> userGroupList = userGroupService.getUserGroupByUser(username);
		
		//
		for (RightProject rightProject : userRightProjectList)
		{
			//if rightList don't contain the group name, means user select to delete this right
			if(!applyProjectList.contains(rightProject.getProjectName()))
			{
				deleteList.add(rightProject.getProjectName());
			}

		}
		for (String project : applyProjectList)
		{
			//false: not existed group name in current userGroupList
			boolean flag = false;
			for (RightProject rightProject : userRightProjectList)
			{
				if(project.equals(rightProject.getProjectName()))
				{
					flag = true;
					break;
				}
			}
			
			//if the right is not existed in the user's group,means user select to add this right
			if(!flag)
			{
				applyList.add(project);
			}
		}
		
       /*
        * notice the administrator to add the right
        * 
        */
		rightNotice.setRightAdd(Arrays.toString(applyList.toArray()));
		rightNotice.setRightDelete(Arrays.toString(deleteList.toArray()));
		rightNotice.setUsername(username);
		rightNotice.setUserId(userId);
		rightNoticeService.addRightNotification(rightNotice);
		
		logger.info("user:"+ username + " apply for add rights of " + Arrays.toString(applyList.toArray()) + " and delete rights:" + Arrays.toString(deleteList.toArray()));
		return "success";
	}
	
	@ExceptionHandler(Exception.class)
	public String exception(Exception e, HttpServletRequest request){
		request.setAttribute("exception", e);
		return "/view/error.jsp";
	}
}
