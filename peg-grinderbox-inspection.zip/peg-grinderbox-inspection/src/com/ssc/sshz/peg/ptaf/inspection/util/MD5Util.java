package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.log4j.Logger;

public class MD5Util {
	private static final Logger logger = Logger.getLogger(MD5Util.class);
	// return 32bit digest String
	public String fileMD5CheckSum(String filePath) {

		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(filePath);
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		byte[] dataBytes = new byte[1024];
		int nread = 0;
		try {
			while ((nread = fis.read(dataBytes)) != -1) {
				md.update(dataBytes, 0, nread);
			}
		} catch (IOException e) {
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		;
		try {
			fis.close();
		} catch (IOException e) {
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}

		byte[] mdbytes = md.digest();

		// convert the byte to hex format method 1
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < mdbytes.length; i++) {
			sb.append(Integer.toString((mdbytes[i] & 0xff) + 0x100, 16)
					.substring(1));
		}

		// System.out.println("Digest(in hex format):: " + sb.toString());
		return sb.toString();

		// //convert the byte to hex format method 2
		// StringBuffer hexString = new StringBuffer();
		// for (int i=0;i<mdbytes.length;i++) {
		// String hex=Integer.toHexString(0xff & mdbytes[i]);
		// if(hex.length()==1) hexString.append('0');
		// hexString.append(hex);
		// }
		// System.out.println("Digest(in hex format):: " +
		// hexString.toString());
	}

	public  String StringMD5(String passWord) {
		char hexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
				'a', 'b', 'c', 'd', 'e', 'f' };
		try {
			byte[] strTemp = passWord.getBytes();
			MessageDigest messageDigest = MessageDigest.getInstance("MD5");
			messageDigest.update(strTemp);
			byte[] md = messageDigest.digest();
			int j = md.length;
			char str[] = new char[j * 2];
			int k = 0;
			for (int i = 0; i < j; i++) {
				byte byte0 = md[i];
				str[k++] = hexDigits[byte0 >>> 4 & 0xf];
				str[k++] = hexDigits[byte0 & 0xf];
			}
			return new String(str);
		} catch (Exception e) {
			return null;
		}
	}
	
}