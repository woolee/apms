package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.dao.TestBriefDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.TestBriefMapper;

@Repository
//@Named
public class TestBriefDaoImpl<T extends TestBrief> implements TestBriefDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private TestBriefMapper mapper;

	@Override
	public boolean addTestBrief(T entity)
	{
		boolean flag = false;
		try{
			mapper.addTestBrief(entity);
			flag = true;
		}
		catch(Exception e)
		{
			
			flag = false;
			logger.error("Exception while add testBrief to database",e);
			throw new DaoException("Exception while add testBrief to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllTestBrief()
	{
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllTestBrief();
			}
		catch(Exception e)
		{
			logger.error("Exception while get all testBrief from database",e);
			throw new DaoException("Exception while get all testBrief from database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getTestBrief(T entity)
	{
		T obj=null;
		try{ 
			obj = (T) mapper.getTestBrief(entity);
			}
		catch(Exception e)
		{
			logger.error("Exception while get testBrief from database",e);
			throw new DaoException("Exception while get testBrief from database",e);
		}
		return obj;
	}

	@Override
	public boolean updateTestBrief(T entity)
	{
		boolean flag = false;
		try{
			mapper.updateTestBrief(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while update testBrief to database",e);
			throw new DaoException("Exception while update testBrief to database",e);
		}
		return flag;
	}

	@Override
	public boolean updateTestBriefStatus(T entity)
	{
		boolean flag = false;
		try{
			mapper.updateTestBriefStatus(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while update testBrief status to database",e);
			throw new DaoException("Exception while update testBrief status to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getLatestTestBriefByExecutorId(int executorId) {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getLatestTestBriefByExecutorId(executorId);
			}
		catch(Exception e)
		{
			logger.error("Exception while get all testBrief from database",e);
			throw new DaoException("Exception while get all testBrief from database",e);
		}
		return entity;
	}

	@Override
	public int getAllTestBriefCountBySummaryId(String summaryId) throws DataAccessException
	{
		int count = 0;
		try{ 
			count = mapper.getAllTestBriefCountBySummaryId(summaryId);
			}
		catch(Exception e)
		{
			logger.error("Exception while get all TestBrief count by SummaryId from database",e);
			throw new DaoException("Exception while get all TestBrief count by SummaryId from database",e);
		}
		return count;
		
	}
	
	@Override
	public T getTestBriefBySystemuuid(String systemuuid) {
		T entity=null;
		try{ 
			entity = (T)mapper.getTestBriefBySystemuuid(systemuuid);
			}
		catch(Exception e)
		{
			logger.error("Exception while get latest testBrief by executor id from database",e);
			throw new DaoException("Exception while get latest testBrief by executor id from database",e);
		}
		return entity;
	}

	@Override
	public List<T> getTestBriefByPlanId(int planId) throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getTestBriefByPlanId(planId);
			}
		catch(Exception e)
		{
			logger.error("Exception while get all testBrief from database",e);
			throw new DaoException("Exception while get all testBrief from database",e);
		}
		return entity;
	}

	@Override
	public T getTestBriefByBriefId(int briefId) throws DataAccessException {
		T obj=null;
		try{ 
			obj = (T) mapper.getTestBriefByBriefId(briefId);
			}
		catch(Exception e)
		{
			logger.error("Exception while get testBrief from database",e);
			throw new DaoException("Exception while get testBrief from database",e);
		}
		return obj;
	}

	@Override
	public List<T> getTestBriefByPlanIdStartTimeEndTime(T entity)
			throws DataAccessException {
		List<T> obj = null;
		try{ 
			obj = (List<T>) mapper.getTestBriefByPlanIdStartTimeEndTime(entity);
			}
		catch(Exception e)
		{
			logger.error("Exception while get all testBrief from database",e);
			throw new DaoException("Exception while get all testBrief from database",e);
		}
		return obj;
	}

	@Override
	public List<T> getTestBriefByProjectName(String projectName)
	{
		List<T> obj = null;
		try{ 
			obj = (List<T>) mapper.getTestBriefByProjectName(projectName);
			}
		catch(Exception e)
		{
			logger.error("Exception while get testBrief by project name from database",e);
			throw new DaoException("Exception while get testBrief by project name from database",e);
		}
		return obj;
	}




}
