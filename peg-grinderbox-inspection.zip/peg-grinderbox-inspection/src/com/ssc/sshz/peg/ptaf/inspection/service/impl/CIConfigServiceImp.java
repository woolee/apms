package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;
import com.ssc.sshz.peg.ptaf.inspection.dao.CIConfigDao;
import com.ssc.sshz.peg.ptaf.inspection.service.CIConfigService;
@Service
public class CIConfigServiceImp<T extends CIConfig> implements CIConfigService<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private CIConfigDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllConfigs() throws DataAccessException
	{
		return dao.getAllCIConfig();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getCIConfig(T entity) throws DataAccessException
	{
		return dao.getCIConfig(entity);
		
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addCIConfig(T entity) throws DataAccessException
	{
		return dao.addCIConfig(entity);
		
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean delCIConfigtById(int id) throws DataAccessException
	{
		return dao.delCIConfigById(id);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public int getCIConfigCount(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getCIConfigCount(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateCIConfig(T entity) throws DataAccessException
	{
		return dao.updateCIConfig(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getCIConfigBySystemuuid(String uuid) throws DataAccessException{
		return dao.getCIConfigBySystemuuid(uuid);
	}
	
}
