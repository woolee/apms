package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.RightProject;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RightProjectMapper;

@Repository
public class RightProjectDaoImpl<T extends RightProject> implements RightProjectDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RightProjectMapper mapper;


	@Override
	public boolean addRightProject(T entity) throws DataAccessException
	{
		boolean flag = false;
		try
		{
			mapper.addRightProject(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add RightProject to database",e);
			throw new DaoException("Exception while add RightProject to database",e);
		}
		return flag;
	}
	
	@Override
	public T getRightProjectByRightId(int rightId) throws DataAccessException
	{
		T entity = null;
		try
		{
			entity = (T) mapper.getRightProjectByRightId(rightId);
		}
		catch (Exception e)
		{
			logger.error("Exception while get RightProject by right id from database",e);
			throw new DaoException("Exception while get RightProject by right id from database",e);
		}
		return entity;
	}

	@Override
	public List<T> getALLRightProject() throws DataAccessException
	{
		List<T> list = null;
		try
		{
			list = (List<T>) mapper.getALLRightProject();
		}
		catch (Exception e)
		{
			logger.error("Exception while get all RightProject from database",e);
			throw new DaoException("Exception while get all RightProject from database",e);
		}
		return list;
	}

	@Override
	public List<T> getRightProjectByUserId(int userId) throws DataAccessException
	{
		List<T> list = null;
		try
		{
			list = (List<T>) mapper.getRightProjectByUserId(userId);
		}
		catch (Exception e)
		{
			logger.error("Exception while get RightProject by user id from database",e);
			throw new DaoException("Exception while get RightProject by user id from database",e);
		}
		return list;
	}

	@Override
	public T getRightProjectByRightName(String rightName) throws DataAccessException
	{
		T entity = null;
		try
		{
			entity = (T) mapper.getRightProjectByRightName(rightName);
		}
		catch (Exception e)
		{
			logger.error("Exception while get RightProject by right name from database",e);
			throw new DaoException("Exception while get RightProject by right name from database",e);
		}
		return entity;
	}


}
