package com.ssc.sshz.peg.ptaf.inspection.util;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Inputs;


public class IDFUtil {
	/**
	 * get input names from inputs list and return as string
	 * @param list
	 * @return input parameter names
	*/ 
	public static String listToString(List<Inputs> list){
		StringBuilder params = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			params.append(list.get(i).getInputName());
			if(i != list.size()-1)
				params.append(",");
		}
		return params.toString();
		
	}
}
