package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.UserRight;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserRightDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.UserRightMapper;

@Repository
public class UserRightDaoImpl<T extends UserRight> implements UserRightDao<T> {
	Logger logger = Logger.getLogger(getClass());
	
	@Inject
	private UserRightMapper mapper;

	@Override
	public boolean addUserRight(T entity) throws DataAccessException {
		boolean flag = false;
		try
		{
			mapper.addUserRight(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add UserRight to database",e);
			throw new DaoException("Exception while add UserRight to database",e);
		}
		return flag;
		
	}

	@Override
	public List<T> getUserRightByUserId(int userId) throws DataAccessException
	{
		List<T> list = null;
		try
		{
			list = (List<T>) mapper.getUserRightByUser(userId);
		}
		catch (Exception e)
		{
			logger.error("Exception while get UserRight by userId to database",e);
			throw new DaoException("Exception while get UserRight by userId to database",e);
		}
		return list;
	}

}
