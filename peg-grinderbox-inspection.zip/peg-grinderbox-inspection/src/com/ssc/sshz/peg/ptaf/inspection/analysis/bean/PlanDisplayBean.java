package com.ssc.sshz.peg.ptaf.inspection.analysis.bean;

import java.io.Serializable;


public class PlanDisplayBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2325626077046436452L;
	private int planId;
	private String planName;
	private String creatorName;
	private String scriptName;	
	private int strategyId;
	private String strategyName;
	private int runtimeId;
	private String planDes;
	public int getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(int strategyId) {
		this.strategyId = strategyId;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getCreatorName() {
		return creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public String getScriptName() {
		return scriptName;
	}
	public void setScriptName(String scriptName) {
		this.scriptName = scriptName;
	}
	public String getStrategyName() {
		return strategyName;
	}
	public void setStrategyName(String strategyName) {
		this.strategyName = strategyName;
	}
	public int getRuntimeId() {
		return runtimeId;
	}
	public void setRuntimeId(int runtimeId) {
		this.runtimeId = runtimeId;
	}
	public String getPlanDes() {
		return planDes;
	}
	public void setPlanDes(String planDes) {
		this.planDes = planDes;
	}
	@Override
	public String toString() {
		return "PlanDisPlayBean [planId=" + planId + ", planName=" + planName
				+ ", creatorName=" + creatorName + ", scriptName=" + scriptName
				+ ", strategyName=" + strategyName + ", runtimeId=" + runtimeId
				+ ", planDes=" + planDes + "]";
	}
	
}
