package com.ssc.sshz.peg.ptaf.inspection.test.parser.bean;

/**
 * The getters and setter for the output for the IDF file
 * 
 * @author p472061
 * 
 */
public class Outputs
{

    private String outputName = "";
    private String outputType = "";
    private String outputDesc = "";

    /**
     * @return the outputName
     */
    public String getOutputName()
    {
	return outputName;
    }

    /**
     * @param outputName
     *                the outputName to set
     */
    public void setOutputName(String outputName)
    {
	this.outputName = outputName;
    }

    /**
     * @return the outputType
     */
    public String getOutputType()
    {
	return outputType;
    }

    /**
     * @param outputType
     *                the outputType to set
     */
    public void setOutputType(String outputType)
    {
	this.outputType = outputType;
    }

    /**
     * @return the outputDesc
     */
    public String getOutputDesc()
    {
	return outputDesc;
    }

    /**
     * @param outputDesc
     *                the outputDesc to set
     */
    public void setOutputDesc(String outputDesc)
    {
	this.outputDesc = outputDesc;
    }
}
