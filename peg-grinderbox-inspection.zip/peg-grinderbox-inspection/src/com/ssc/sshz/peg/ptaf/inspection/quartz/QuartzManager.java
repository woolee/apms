package com.ssc.sshz.peg.ptaf.inspection.quartz;

import java.util.List;

import org.apache.log4j.Logger;
import org.quartz.SchedulerException;

import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.ScheduleData;


public class QuartzManager {
	private static final Logger logger = Logger.getLogger(QuartzManager.class);
	private static QuartzManager instance = null;
	//private String name = "";	
    private QuartzManager(){}
    public static QuartzManager getQuartzManager() {
        if (instance == null){
            synchronized(QuartzManager.class){
                if(instance == null) {
                     instance = new QuartzManager();
                }
            }
        }
        return instance;
    }
    
    
//    public String getName() {
//		return name;
//	}
//    
//	public synchronized void setName(String name) {
//		this.name = name;
//	}
	
	public synchronized RuntimeTrigger addNewRuntime(ScheduleData scheduledata) throws Exception{
		RuntimeTrigger rt = JDBCJobStoreRunner.schedule(scheduledata.getStartTime(), scheduledata.getEndTime(), scheduledata.getIntervalSeconds(), scheduledata.getRepeatTime(), scheduledata.getData(), scheduledata.isServiceCall(), scheduledata.getTestBeanCollection(),scheduledata.isStartNow(),scheduledata.getRuntimeTrigger());
		return rt;
	}
	
	public synchronized void initQuartzScheduler() throws SchedulerException{
		JDBCJobStoreRunner.init();
	}
	
	public synchronized void rescheduleQuartzJob() throws SchedulerException{
		JDBCJobStoreRunner.rescheduleStoredJob();
	}
 
	public synchronized boolean deleteJobs(List<RuntimeTrigger> list) throws SchedulerException
	{
		return JDBCJobStoreRunner.deleteJobs(list);
	}
	
	public synchronized boolean pauseTriggers(List<RuntimeTrigger> list) throws SchedulerException
	{
		return JDBCJobStoreRunner.pauseTiggers(list);
	}
	
	public synchronized boolean pauseTrigger(String triggerName) throws SchedulerException
	{
		return JDBCJobStoreRunner.pauseTigger(triggerName);
	}
	
	public synchronized boolean resumeTiggers(List<RuntimeTrigger> list) throws SchedulerException
	{
		return JDBCJobStoreRunner.resumeTriggers(list);
	}
	
	public synchronized boolean resumeTigger(String triggerName) throws SchedulerException
	{
		return JDBCJobStoreRunner.resumeTrigger(triggerName);
	}
	
	public synchronized boolean removeTigger(String triggerName) throws SchedulerException
	{
		return JDBCJobStoreRunner.removeTigger(triggerName);
	}
}
