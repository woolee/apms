package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class Right implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7284756499775518635L;
	private int rightId;
	private String rightName;
	private String rightDescription;
	public int getRightId()
	{
		return rightId;
	}
	public void setRightId(int rightId)
	{
		this.rightId = rightId;
	}
	public String getRightName()
	{
		return rightName;
	}
	public void setRightName(String rightName)
	{
		this.rightName = rightName;
	}
	public String getRightDescription()
	{
		return rightDescription;
	}
	public void setRightDescription(String rightDescription)
	{
		this.rightDescription = rightDescription;
	}
	
}
