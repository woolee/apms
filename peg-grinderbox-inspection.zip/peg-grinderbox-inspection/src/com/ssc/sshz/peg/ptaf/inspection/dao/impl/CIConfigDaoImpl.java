package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;
import com.ssc.sshz.peg.ptaf.inspection.dao.CIConfigDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.CIConfigMapper;

@Repository
public class CIConfigDaoImpl<T extends CIConfig> implements CIConfigDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private CIConfigMapper mapper;

	@Override
	public boolean addCIConfig(T entity) throws DataAccessException
	{
		long currentTime = System.currentTimeMillis();
		boolean flag = false;
		try
		{
			mapper.addCIConfig(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add CIConfig to database",e);
			throw new DaoException("Exception while add CIConfig to database",e);
		}
		logger.info("Database access: [" + (System.currentTimeMillis()- currentTime) + "]ms");
		return flag;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getCIConfigById(Integer id) throws DataAccessException
	{
		return (T) mapper.getCIConfigById(id);
	}

	@Override
	public boolean delCIConfigById(Integer id) throws DataAccessException
	{
		boolean flag = false;
		try
		{
			mapper.delCIConfigById(id);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while delete CIConfig from database",e);
			throw new DaoException("Exception while delete CIConfig from database",e);
		}
		return flag;
		
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllCIConfig() throws DataAccessException
	{
		List<T> object = null;
		try{
		object =  (List<T>) mapper.getAllCIConfig();
		}
		catch(Exception e)
		{
			logger.error("Exception while get all CIConfig from database",e);
			throw new DaoException("Exception while get all CIConfig from database",e);
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getCIConfig(T entity) throws DataAccessException
	{
		T object = null;
		try{
		object = (T) mapper.getCIConfig(entity);
		}
		catch(Exception e)
		{
			logger.error("Exception while get CIConfig from database",e);
			throw new DaoException("Exception while get CIConfig from database",e);
		}
		return object;
	}

	@Override
	public int getCIConfigCount(T entity) throws DataAccessException
	{
		
		return mapper.getCIConfigCount(entity);
	}

	@Override
	public boolean updateCIConfig(T entity) throws DataAccessException
	{
		boolean flag = false;
		try{
			mapper.updateCIConfig(entity);
			flag = true;
		}
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while update CIConfig to database",e);
			throw new DaoException("Exception while update CIConfig to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getCIConfigBySystemuuid(String uuid) throws DataAccessException {
		T returnEntity = null;
		try{
			returnEntity = (T) mapper.getCIConfigBySystemuuid(uuid);
			}catch(Exception e){
				logger.error("Exception while get CIConfig by system uuid from database",e);
				throw new DaoException("Exception while get CIConfig by system uuid from database",e);
			}
		return returnEntity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getCIConfigByMD5(T entity) throws DataAccessException
	{
		long currentTime = System.currentTimeMillis();
		T returnEntity = null;
		try{
			returnEntity = (T) mapper.getCIConfigByMD5(entity);
			}catch(Exception e){
				logger.error("Exception while get CIConfig by MD5 from database",e);
				throw new DaoException("Exception while get CIConfig by MD5 from database",e);
			}
		logger.info("Database access: [" + (System.currentTimeMillis()- currentTime) + "]ms");
		return returnEntity;
	}

	

}
