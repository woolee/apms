package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.UserMapper;

@Repository
public class UserDaoImpl<T extends User> implements UserDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private UserMapper mapper;

	@Override
	public boolean addUser(T entity) throws DataAccessException
	{

		boolean flag = false;
		try
		{
			mapper.addUser(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add user to database", e);
			throw new DaoException("Exception while add user to database", e);
		}
		return flag;

	}

	@SuppressWarnings("unchecked")
	@Override
	public T getUserByName(String name) throws DataAccessException
	{
		T entity = null;
		try
		{
			entity = (T) mapper.getUserByName(name);
		}
		catch (Exception e)
		{
			logger.error("Exception while get user by name from database", e);
			throw new DaoException("Exception while get user by name from database", e);
		}
		return entity;
	}

	@Override
	public T getUserById(int id) throws DataAccessException
	{
		T entity = null;
		try
		{
			entity = (T) mapper.getUserById(id);
		}
		catch (Exception e)
		{
			logger.error("Exception while get user by id from database", e);
			throw new DaoException("Exception while get user by id from database", e);
		}
		return entity;
	}
	
	@Override
	public List<T> getAllUsers() throws DataAccessException
	{
		List<T> list = null;
		try{ 
			list = (List<T>) mapper.getAllUsers();
			}
		catch(Exception e)
		{
			logger.error("Exception while all user from database",e);
			throw new DaoException("Exception while all user from database",e);
		}
		return list;
	}

}
