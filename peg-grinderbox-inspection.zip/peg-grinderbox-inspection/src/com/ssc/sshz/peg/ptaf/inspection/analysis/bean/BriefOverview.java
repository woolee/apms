package com.ssc.sshz.peg.ptaf.inspection.analysis.bean;

import java.io.Serializable;

public class BriefOverview implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7919305080993129774L;
	private String projectName;
	private String systemName;	
	private String startTime;		
	private String endTime;	
	private String totalRequests;
	private String successCount;
	private String errorCount;
	private String status;
	private int beiefId;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private String summaryId;
	public String getSummaryId() {
		return summaryId;
	}
	public void setSummaryId(String summaryId) {
		this.summaryId = summaryId;
	}
	public int getBeiefId() {
		return beiefId;
	}
	public void setBeiefId(int beiefId) {
		this.beiefId = beiefId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getTotalRequests() {
		return totalRequests;
	}
	public void setTotalRequests(String totalRequests) {
		this.totalRequests = totalRequests;
	}
	public String getSuccessCount() {
		return successCount;
	}
	public void setSuccessCount(String successCount) {
		this.successCount = successCount;
	}
	public String getErrorCount() {
		return errorCount;
	}
	public void setErrorCount(String errorCount) {
		this.errorCount = errorCount;
	}
	@Override
	public String toString() {
		return "BriefOverview [projectName=" + projectName + ", systemName="
				+ systemName + ", startTime=" + startTime + ", endTime="
				+ endTime + ", totalRequests=" + totalRequests
				+ ", successCount=" + successCount + ", errorCount="
				+ errorCount + "]";
	}
	


}
