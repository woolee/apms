package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ItemMapper;

public class ItemQuartzService<T extends Item>
{
	private Logger logger = Logger.getLogger(getClass());
	public T getItemBySystemIdItemName(Item item) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ItemMapper mapper = session.getMapper(ItemMapper.class);
			object = (T) mapper.getItemBySystemIdItemName(item);
		}
		catch (Exception e)
		{
			logger.error("exception while get all item from databse",e);
			throw new Exception("exception while get all item from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	};
	
	public T getItemByItemId(int itemId) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			ItemMapper mapper = session.getMapper(ItemMapper.class);
			object = (T) mapper.getItemById(itemId);
		}
		catch (Exception e)
		{
			logger.error("exception while get item by itemId from databse",e);
			throw new Exception("exception while get item by itemId from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	};
	
	public boolean addItem(Item item) throws Exception
	{
		SqlSession session = null;
		boolean flag = false;
		try
		{
			session = ConnectionFactory.openSession();
			ItemMapper mapper = session.getMapper(ItemMapper.class);
			mapper.addItem(item);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while get all item from databse",e);
			throw new Exception("exception while get all item from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	};
}
