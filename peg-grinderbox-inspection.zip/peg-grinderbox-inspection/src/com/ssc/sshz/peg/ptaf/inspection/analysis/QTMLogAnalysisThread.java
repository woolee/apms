package com.ssc.sshz.peg.ptaf.inspection.analysis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.bean.QTMLogScan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Report;
import com.ssc.sshz.peg.ptaf.inspection.constants.AutoAnalysisStatus;
import com.ssc.sshz.peg.ptaf.inspection.service.QTMLogScanService;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;
import com.ssc.sshz.peg.ptaf.inspection.util.FileZip;
import com.ssc.sshz.peg.ptaf.inspection.util.StringHelper;
import com.statestr.gcth.cloud.deploy.tool.AutoDeploymentTool;

/**
 * 
 * @author a549324
 * 
 */
public class QTMLogAnalysisThread implements Runnable{
//	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//	private String errorInfo;
	private static final Logger logger = Logger
			.getLogger(QTMLogAnalysisThread.class);

	private QTMLogScan scan;
	private String username;
	private String password;
	private boolean isIaas;
	private boolean deleteTempPath;
	private AtomicBoolean finishScan;
	private QTMLogScanService<QTMLogScan> qtmLogScanService;
	public QTMLogAnalysisThread(QTMLogScan scan,String username,String password,boolean isIaas,boolean deleteTempPath,AtomicBoolean finishScan,QTMLogScanService<QTMLogScan> qtmLogScanService)
	{
		this.scan = scan;
		this.username = username;
		this.password = password;
		this.isIaas = isIaas;
		this.deleteTempPath = deleteTempPath;
		this.finishScan = finishScan;
		this.qtmLogScanService = qtmLogScanService;
	}
	@Override
	public void run() {
		long current = System.currentTimeMillis();
		String logTempPath = "C:/apms_log/" + current;
		String analysisTempPath = "C:/apms_analysis/" + current;
		/*doDownload(logTempPath, report, username, password, isIaas);*/
		try {
			doAnalysis( logTempPath,  analysisTempPath);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		qtmLogScanService.updateQTMLogScanFile(scan.getErrorFile(), scan.getScanId());
		if (deleteTempPath)
			doClear(logTempPath, analysisTempPath);
		int percentage = 100;
		scan.setExecutePercentage(percentage);
		qtmLogScanService.updateQTMLogScanProgress(scan.getExecutePercentage(), scan.getScanId());
	}
	
/*	public void doAutoAnalysis(
			final QTMLogScan scan, final String username, final String password,
			final boolean isIaas, final boolean deleteTempPath,AtomicBoolean finishScan) {
//		String errorInfo ;
		Thread thread = new Thread(new Runnable() {

			@Override
			public void run() {
				long current = System.currentTimeMillis();
				try {
					String logTempPath = "C:/apms_log/" + current;
					String analysisTempPath = "C:/apms_analysis/" + current;
//					String analysisTempPath = "C:\\test\\mqerrors";
//					doDownload(logTempPath, report, username, password, isIaas);
					doAnalysis( logTempPath,  analysisTempPath,
							scan);
					if (deleteTempPath)
						doClear(logTempPath, analysisTempPath);
					int percentage = 100;
					scan.setExecutePercentage(percentage);
				} catch (Exception e) {
					// update
//					report.setAnalysisStatus(AutoAnalysisStatus.EXCEPTION);
					logger.error(e.getMessage(), e);
					return;
				}
//				scan.setAnalysisStatus(AutoAnalysisStatus.COMPLETE);
			}
		});

		thread.start();

	}*/
	
	/**
	 * 
	 * @param logTempPath
	 * @param tempPath
	 * @throws Exception 
	 */
	private void doAnalysis( String logTempPath,
			String tempPath) throws Exception {
		// update
//		report.setAnalysisStatus(AutoAnalysisStatus.ANALYZE);

		String propPath = tempPath + "/analysis.properties";
		String fgLogPath = logTempPath + "/fg/";
		String bgLogPath = logTempPath + "/bg/";
		// String cpuLogPath = logTempPath + "/cpu/";

		/*
		 * Map<String, String> map = FileUtil.arrayToMap(args); AnalysisProperty
		 * propValues = new AnalysisProperty();
		 * propValues.setFgLogFolderPath(fgLogPath);
		 * propValues.setBgLogFolderPath(bgLogPath);
		 * propValues.setCpuLog(cpuLogPath); propValues.setRowDatapath(tempPath
		 * + "/data.csv"); propValues.setRowDataBKPath(tempPath +
		 * "/data_bk.csv"); propValues.setSummaryPath(tempPath +
		 * "/summary.csv"); propValues.setTempFolderPath(tempPath);
		 * propValues.setRuntimeStart(sdf.format(report.getStartTime()));
		 * propValues.setRuntimeEnd(sdf.format(report.getEndTime()));
		 * propValues.setDurationMillSec("10000");
		 * 
		 * PropertyGenerator.createProperties(propPath, propValues);
		 * 
		 * AnalyzerManager la = new AnalyzerManager(); boolean analyzeOver =
		 * la.doAnalyze(propPath);
		 * 
		 * AnalysisResult ar = la.getResult(); generateReport(map, ar, htmlPath,
		 * tempPath, analyzeOver);
		 */
		logTempPath = "C:\\test\\mqerrors";
		String errorSaveTo = "C:\\test\\1\\errors.txt";
		boolean errorFind = findErrorsOfCloudLog(logTempPath,errorSaveTo);
		
		if(errorFind){
			File errorFile = new File(errorSaveTo);
			FileZip.doZip(errorFile.getParent(), "C:\\test" + File.separator + errorFile.getName()+".zip");
			File zipFile = new File("C:\\test",errorFile.getName()+".zip");
			byte [] errorBytes = new byte[(int) zipFile.length()];
			InputStream is = new FileInputStream(zipFile);
			is.read(errorBytes);
			scan.setErrorFile(errorBytes);
			qtmLogScanService.addQTMLogScan(scan);
			if(is != null)
				is.close();
		}
			
	}

	public boolean findErrorsOfCloudLog(
			String fileDirecotry,String errorSaveTo) throws IOException {
		BufferedReader brOld = null;
		StringBuilder strBuilder = new StringBuilder(20480);
		// String fileDirecotry =
		// "C:\\Users\\e531810\\Documents\\Work\\PEG\\Test\\QTM\\Report\\AFC_11112014-with-without-Statistics\\UAT\\NoLog\\infoVSWarnStatistics\\logs\\mq\\50";
		String saveTo = errorSaveTo;
//		"C:\\test\\errors.txt";

		// get star, end time from output of grinderbox
		ArrayList<Date> dates = new ArrayList<Date>();

		// getLogDateRangeForGrinderBoxOut(outputDirectory,dates);
		Date logStartTime = scan.getStartTime();
		Date logEndTime = scan.getEndTime();

		if (logStartTime != null) {
			logStartTime.setMinutes(logStartTime.getMinutes() - 13 * 60);
		}
		if (logEndTime != null) {
			logEndTime.setMinutes(logEndTime.getMinutes() - 12 * 60);
		}

		FileFilter filefilter = new FileFilter() {

			public boolean accept(File file) {
				// if the file extension is .txt return true, else false
				if (file.getName().endsWith(".log")) {
					return true;
				}
				return false;
			}
		};
		
		List<File> files = FileUtil.listFiles(fileDirecotry, filefilter);
		
		writeToFile(saveTo, strBuilder, files, logStartTime, logEndTime);
		return true;
	}
	
	public void writeToFile(String saveTo,StringBuilder strBuilder,List<File> readFiles,Date logStartTime,Date logEndTime) throws IOException{
		
		Pattern timePattern = Pattern
				.compile("[a-zA-Z]+ >([0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2},[0-9]{3})");
		BufferedReader brOld = null;
		for (int i = 0; i < readFiles.size(); i++) {
			try {
				// parse each log file under the log directory
				brOld = new BufferedReader(new InputStreamReader(
						new FileInputStream(URLDecoder.decode(readFiles.get(i)
								.getAbsolutePath(), "utf-8"))));
				for (String line = brOld.readLine(); line != null; line = brOld
						.readLine()) {
					Matcher m = timePattern.matcher(line);
					if (m.find()) {

						String found = m.group(1);
						Date currTime = StringHelper.getInstance()
								.convertStringToDateTime("yyyy-MM-dd HH:mm:ss",
										found);

						if (logStartTime != null
								&& currTime.before(logStartTime))
							continue;
						if (logEndTime != null && currTime.after(logEndTime))
							break;
					}
					// find error line
					boolean findExpectedLog = false;
					String tempLogString = line;
					boolean exceptionStartFlag = false;
					// System.out.println(line);

					if (line.startsWith("ERROR") || line.startsWith("FATAL")) {

						// parse error log
						String line2 = null;
						for (line2 = brOld.readLine(); line2 != null;) {

							tempLogString = tempLogString + "\r\n" + line2;

							if (line2.startsWith("\tat")) {
								exceptionStartFlag = true;// break;
							} else if (exceptionStartFlag)
								break;
							line2 = brOld.readLine();
						}
						if (findExpectedLog == false) {
							// wirte down the error log
							// System.out.println("Error");
							/*strBuilder.append(files.get(i) + "\t:"
									+ tempLogString + "\r\n");*/
							 wirteFileToOld(saveTo, readFiles.get(i) +
							 "\t:"
							 + tempLogString + "\r\n");
//							 System.out.println(tempLogString);

						}

					}

				}

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			} finally {
				if (brOld != null)
					brOld.close();
			}
		}
	}
	
	public boolean wirteFileToOld(String filePath, String contents){
	     FileWriter fileWriter;
	  try {
	   fileWriter = new FileWriter(URLDecoder.decode(filePath, "utf-8"),true);
	   fileWriter.write(contents);
	   fileWriter.flush();
	   fileWriter.close();
	   return true;
	  } catch (IOException e) {
	   logger.error(new Exception(Arrays.toString(e.getStackTrace())));
	   return false;
	  }     
	    }

	private void doDownload(String logTempPath, QTMLogScan scan, String uesrname,
			String password, boolean isIaas) throws Exception {
		// update
//		report.setAnalysisStatus(AutoAnalysisStatus.DOWNLOAD);

		// long current = System.currentTimeMillis();
		String fgLogPath = logTempPath + "/fg/";
		String bgLogPath = logTempPath + "/bg/";
		String cpuLogPath = logTempPath + "/cpu/";

		List<Date> logTimeList = getLogTimes(scan.getStartTime(),
				scan.getEndTime());

		String[] bgSysNames = scan.getBgSystemName().split(",");
		String[] bgContexts = scan.getBgContext().split(",");
		String[] bgEnvs = scan.getBgEnv().split(",");

		int percentage = 0;
		int totalDownloadCount = (1 + bgEnvs.length) * logTimeList.size()
				+ bgEnvs.length;
		int oneCountPercentage = (int) (((double) 1 / totalDownloadCount * 0.95) * 100);
		/*
		 * foreground
		 */
		try {
			for (int i = 0; i < logTimeList.size(); i++) {
				Date startTime = logTimeList.get(i);
				Date endTime = null;
				if ((i + 1) <= logTimeList.size() - 1)
					endTime = logTimeList.get(i + 1);
				else if (logTimeList.size() >= 2)
					break;
				String[] fgArgs = { "--Fetch", "Y", "--appCode",
						scan.getFgSystemName(), "--Context",
						scan.getFgContext(), "--env", scan.getFgEnv(),
						"--Path", fgLogPath, "--LogName", "FAW_l4j",
						"--Approvers", "-P", uesrname + "/" + password };
				AutoDeploymentTool.fetchLogs(fgArgs, true, isIaas, startTime,
						endTime);

				percentage = percentage + oneCountPercentage;
				scan.setExecutePercentage(percentage);
				qtmLogScanService.updateQTMLogScanProgress(percentage, scan.getScanId());
				// update the percentage to database
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw e;
		}

		try {
			for (int i = 0; i < bgSysNames.length; i++) {

				for (int j = 0; j < logTimeList.size(); j++) {
					Date startTime = logTimeList.get(j);
					Date endTime = null;
					if ((j + 1) <= logTimeList.size() - 1)
						endTime = logTimeList.get(j + 1);
					else if (logTimeList.size() >= 2)
						break;
					/*
					 * background
					 */
					String[] bgArgs = { "--Fetch", "Y", "--appCode",
							bgSysNames[i], "--Context", bgContexts[i], "--env",
							bgEnvs[i], "--Path", bgLogPath, "--LogName",
							"FAW_l4j", "--Approvers", "-P",
							uesrname + "/" + password };
					AutoDeploymentTool.fetchLogs(bgArgs, true, isIaas,
							startTime, endTime);

					percentage = percentage + oneCountPercentage;
					scan.setExecutePercentage(percentage);
					qtmLogScanService.updateQTMLogScanProgress(percentage, scan.getScanId());
					// update the percentage to database
				}
				/*
				 * cpu
				 */
				/*
				 * String[] cpuArgs = { "--Fetch", "Y", "--appCode",
				 * bgSysNames[i], "--Context", bgContexts[i], "--env",
				 * bgEnvs[i], "--Path", cpuLogPath, "--Approvers", "-P",
				 * uesrname + "/" + password };
				 * 
				 * Date endDate = report.getEndTime();
				 * endDate.setDate(endDate.getDate() + 1);
				 * AutoDeploymentTool.fetchCPULog(cpuArgs,
				 * report.getStartTime(), endDate);
				 * endDate.setDate(endDate.getDate() - 1);
				 * 
				 * percentage = percentage + oneCountPercentage;
				 * report.setExecutePercentage(percentage);
				 */
				// update the percentage to database
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw e;
		}

	}


	private List<Date> getLogTimes(Date start, Date end) {
		Calendar cld = Calendar.getInstance();
		ArrayList<Date> logTimeStrings = new ArrayList<Date>();
		Date current;
		if (start == null || end == null) {
			logTimeStrings.add(new Date());
		} else {
			current = new Date(start.getTime());
			while (current.before(end) || current.equals(end)) {

				logTimeStrings.add(current);
				current.setHours(current.getHours() + 1);
			}
		}

		return logTimeStrings;
	}

	private void doClear(String logTempPath, String analysisTempPath) {
		File logFolder = new File(logTempPath);
		File analyFolder = new File(analysisTempPath);
		if (logFolder.exists())
			com.ssc.sshz.peg.ptaf.inspection.util.FileUtil.getInstance()
					.delFolder(logFolder);
		if (analyFolder.exists())
			com.ssc.sshz.peg.ptaf.inspection.util.FileUtil.getInstance()
					.delFolder(analyFolder);

	}
	
	public static void main(String[] args) throws Exception {
		File errorFile = new File("C:\\test\\errors.txt");
		FileZip.doZip("C:\\test\\1", "C:\\test\\errors.zip");
	}
	
}
