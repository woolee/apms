package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;


import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.mapper.TestErrorMapper;
public class TestErrorQuartzService<T extends TestError> 
{
	private Logger logger = Logger.getLogger(getClass());
	
	@SuppressWarnings("unchecked")
	public List<T> getAllTestError() throws Exception 
	{
		List<T> object = null;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestErrorMapper mapper = session.getMapper(TestErrorMapper.class);
			object = (List<T>) mapper.getAllTestError();
		}
		catch(Exception e)
		{
			logger.error("exception while get all TestError from database",e);
			throw new Exception("exception while get all TestError from database",e);
		}finally{
			if(session != null)
				session.close();
		}
		return object;
		
	}
	@SuppressWarnings("unchecked")
	public T getTestError(T entity) throws Exception 
	{
		T object = null;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestErrorMapper mapper = session.getMapper(TestErrorMapper.class);
		object = (T) mapper.getTestError(entity);
		}
		catch(Exception e)
		{
			logger.error("exception while get TestError object from databse",e);
			throw new Exception("exception while get TestError object from databse",e);
		}finally{
			if(session != null)
				session.close();
		}
		return object;
	}

	public boolean addTestError(T entity) throws Exception 
	{
		boolean flag = false;
		SqlSession session = null;
		try {
			String errorMesg = entity.getErrorMessage();
			String errorDet = entity.getErrorDetail();
			if(errorMesg != null && errorMesg.length() > 1000)
			{
				entity.setErrorMessage(errorMesg.substring(0, 1000));
			}
			if(errorDet != null && errorDet.length() > 1000)
			{
				entity.setErrorDetail(errorDet.substring(0, 1000));
			}
			session = ConnectionFactory.openSession();
			TestErrorMapper mapper = session.getMapper(TestErrorMapper.class);
			mapper.addTestError(entity);
			session.commit();
			flag = true; 
			} 
		catch(Exception e)
		{
			flag = false;
			logger.error("exception while add TestError object to databse",e);
			throw new Exception("exception while add TestError object to databse",e);
		}finally{
			if(session != null)
				session.close();
		}
		return flag;
	}



	@SuppressWarnings("unchecked")
	public List<T> getTestErrorByBriefId(int id) throws Exception 
	{
		List<T> object = null;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestErrorMapper mapper = session.getMapper(TestErrorMapper.class);
			object = (List<T>) mapper.getTestErrorByBriefId(id);
		}
		catch(Exception e)
		{
			logger.error("exception while get TestError object by briefId from databse",e);
			throw new Exception("exception while get TestError object by briefId from databse",e);
		}
		finally{
			if(session != null)
				session.close();
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	public List<T> getTestErrorByBriefAndType(T entity) throws Exception 
	{
		List<T> object = null;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestErrorMapper mapper = session.getMapper(TestErrorMapper.class);
			object = (List<T>) mapper.getTestErrorByBriefAndType(entity);
		}
		catch(Exception e)
		{
			logger.error("exception while get TestError object by briefId from databse",e);
			throw new Exception("exception while get TestError object by briefId from databse",e);
		}
		finally{
			if(session != null)
				session.close();
		}
		return object;
	}
	
}
