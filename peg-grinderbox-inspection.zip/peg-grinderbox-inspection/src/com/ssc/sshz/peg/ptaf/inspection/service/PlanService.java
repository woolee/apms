package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Requirement;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;

public interface PlanService<T>{
	
	public List<T> getAllPlan() throws DataAccessException;
	public T getPlan(T entity) throws DataAccessException;
	public T getPlanById(Integer id) throws DataAccessException;
	public T getPlanByName(String name) throws DataAccessException;
	public List<T> getPlanBySystemId(int systemId) throws DataAccessException;
	public T getPlanBySystemIdPlanName(Plan plan) throws DataAccessException;
	public Plan addPlan(T entity) throws DataAccessException;
	public boolean delPlan(T entity) throws DataAccessException;
	public boolean createPlan(Runtime runtime, PlanStrategy planStrategy, RuntimeTrigger rt, 
			PlanScript planScript, PlanItem planItem, Request request,
			Script script,  User user,List<Item> itemlist,
			Plan tempplan,String username,String zipfilepath,String zipfileputpath,String runtype,
			String strategyLoad,String loopCount,String date_from,String date_to,String tempintervaltime,String intervaltimeUnit
			,String repeat,String itemRequirementString) throws Exception;
	public List<Item> addItemRequest(String zipfileputpath,System system,String itemDescList,String itemRequirementString,Requirement requirement, Plan plan) throws Exception;
}
