package com.ssc.sshz.peg.ptaf.inspection.service;

import org.springframework.dao.DataAccessException;

public interface RightService<T>
{
	public boolean addRight(T entity) throws DataAccessException;
}
