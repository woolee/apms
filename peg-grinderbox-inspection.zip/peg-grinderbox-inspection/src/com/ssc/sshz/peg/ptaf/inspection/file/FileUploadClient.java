package com.ssc.sshz.peg.ptaf.inspection.file;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
  
public class FileUploadClient
{
//    public static void main(String args[]) throws Exception
//    {
//    	 FileUploadClient fileUpload = new FileUploadClient();
//    	 String username = "user2";
//         String password = "123456";
//         String projectuuid = "d900c033-4e5e-1032-95a9-8e580b32d69e";
//         String systemuuid = "1ea513a2-4e5f-1032-95a9-8e580b32d69e";
//         String filePath = "C:\\test\\test.zip";
//         String summaryId = "1260";
//         String version = "1.0.1";
//         System.out.println(fileUpload.upload(username,password,projectuuid,systemuuid,summaryId,version,filePath));
//		
//    } 
//	private static final 
	
	/**
	 * Use system default:
	 * Thread number:10 
	 * Run count:1000
	 * Think time:1000ms
	 * @param username
	 * @param password
	 * @param projectuuid
	 * @param systemuuid
	 * @param summaryId
	 * @param version
	 * @param filePath
	 * @return
	 */
    public boolean upload(String username,String password,String projectuuid,String systemuuid,String summaryId, String version, String filePath){
		Logger logger = Logger.getLogger(FileUploadClient.class);
    	logger.setLevel(Level.INFO);
    	logger.addAppender(new ConsoleAppender(new PatternLayout("%-d{yyyy-MM-dd HH:mm:ss} [%c]-[%p] %m%n"),ConsoleAppender.SYSTEM_OUT));
    	CloseableHttpClient httpClient = HttpClients.createDefault();
	    String postUrl = null;
		try {
	    	postUrl= this.getPostUrl();
		} catch (IOException e) {
			logger.error("IOException occured!",e);
			e.printStackTrace();
			return false;
		}
	    HttpPost uploadFile = new HttpPost(postUrl);
	    MultipartEntityBuilder builder = MultipartEntityBuilder.create();
	    builder.addTextBody("username", username, ContentType.TEXT_PLAIN);
	    builder.addTextBody("password", password, ContentType.TEXT_PLAIN);
	    builder.addTextBody("projectuuid", projectuuid, ContentType.TEXT_PLAIN);
	    builder.addTextBody("systemuuid", systemuuid, ContentType.TEXT_PLAIN);
	    builder.addTextBody("summaryId", summaryId, ContentType.TEXT_PLAIN);
	    builder.addTextBody("version", version, ContentType.TEXT_PLAIN);
	    String fileName = null;
	    if(filePath.lastIndexOf("\\")!= -1){
	    	fileName = filePath.substring(filePath.lastIndexOf("\\")+1);
	    }else{
	    	fileName = filePath.substring(filePath.lastIndexOf("/")+1);
	    }
	    builder.addBinaryBody("file", new File(filePath), ContentType.APPLICATION_OCTET_STREAM, fileName);
	    HttpEntity multipart = builder.build();
	    uploadFile.setEntity(multipart);
	    HttpResponse response = null;
		try {
			response = httpClient.execute(uploadFile);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		
		
		HttpEntity httpEntity = response.getEntity();
		String returnString = null;
		try {
			
			returnString = EntityUtils.toString(httpEntity);
			logger.debug("returnString: "+returnString);
		} catch (ParseException e1) {
			e1.printStackTrace();
			return false;
		} catch (IOException e1) {
			e1.printStackTrace();
			return false;
		}
	    String statusCode = String.valueOf(response.getStatusLine().getStatusCode());
	    if(returnString.contains("SummaryID Error"))
	    {
	    	logger.error("upload file: " + fileName + " failed: Invalid summary ID");
	    	try {
	    		httpClient.close();
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    		return false;
	    	}
	    	return false;
	    }
	    else if(returnString.contains("Username Or Password Error"))
	    {
	    	logger.error("upload file: " + fileName + " failed: Invalid username or password");
	    	try {
	    		httpClient.close();
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    		return false;
	    	}
	    	return false;
	    }
	    else if(returnString.contains("projectUUID Or systemUUID Error"))
	    {
	    	logger.error("upload file: " + fileName + " failed: Invalid projectUUID or systemUUID");
	    	try {
	    		httpClient.close();
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    		return false;
	    	}
	    	return false;
	    }
	    else if(returnString.contains("Uploaded config file Error"))
	    {
	    	logger.error("upload file: " + fileName + " failed: Invalid uploaded configuration file");
	    	try {
	    		httpClient.close();
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    		return false;
	    	}
	    	return false;
	    } 
	    
	    else if(returnString.contains("Server unavailable Error"))
	    {
	    	logger.error("upload file: " + fileName + " failed: Unavailable server");
	    	try {
	    		httpClient.close();
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    		return false;
	    	}
	    	return false;
	    }
	    else if(returnString.contains("Exception Error"))
	    {
	    	logger.error("upload file: " + fileName + " failed: Inside exception error");
	    	try {
	    		httpClient.close();
	    	} catch (IOException e) {
	    		e.printStackTrace();
	    		return false;
	    	}
	    	return false;
	    }
	    else if((statusCode.substring(0,2).equals("20")) | (statusCode.substring(0,2).equals("30"))){
	    	try {
	    		logger.info("upload file " + fileName + " successful!");
				httpClient.close();
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
	    	return true;
	    }
	    else{
	    	logger.error("upload file: " + fileName + " failed: Return statusCode is " + statusCode);
	    	try {
				httpClient.close();
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
	    	return false;
	    }
	    
    }
    
    public String getPostUrl() throws IOException{
    	//String targetFilePath2 = "./conf/configuration.properties";
//    	String targetFilePath = "com/ssc/sshz/peg/ptaf/inspection/file/configuration.properties";
//    	URL url = ClassLoader.getSystemResource(targetFilePath);
//    	String targetFilePath2 = url.getFile();
//    	System.out.println(targetFilePath2);
//    	Properties prop = new Properties();     
//		FileInputStream fis = null;
//		fis = new FileInputStream(targetFilePath2);
//		prop.load(fis);
//		String postUrl = prop.getProperty("postUrl");
//		//System.out.println(postUrl);
//		fis.close();
//		prop.clear();
		
//   	 BufferedReader br=new BufferedReader(new InputStreamReader(is));
//   	 String s="";  
//        while((s=br.readLine())!=null)  
//            System.out.println(s);  
   	//URL url = ClassLoader.getSystemResource(targetFilePath);
   	//URL url =this.getClass().getResource(targetFilePath);
		//String filePath = url.getFile();
		//String filePath = url.getPath();
		//System.out.println(filePath);
//		System.out.println(this.getClass().getName());
//		FileInputStream fis = null;
//		fis = new FileInputStream(filePath);
//		
//       BufferedReader br=new BufferedReader(new InputStreamReader(is));  
//       String s="";  
//       while((s=br.readLine())!=null)  
//           System.out.println(s);  		
		
    	String targetFilePath = "com/ssc/sshz/peg/ptaf/inspection/file/configuration.properties";
    	//InputStream is= ClassLoader.getSystemResourceAsStream(targetFilePath);
    	InputStream is = this.getClass().getClassLoader().getResourceAsStream(targetFilePath);
    	Properties prop = new Properties();
    	prop.load(is);
		String postUrl = prop.getProperty("postUrl");
		//System.out.println(postUrl);
		is.close();
		prop.clear();
		
		return postUrl;

    }


    

    
    
}