package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;
import com.ssc.sshz.peg.ptaf.inspection.mapper.CIConfigMapper;

public class CIConfigQuartzService<T extends CIConfig>
{
	// private SqlSession session = ConnectionFactory.openSession();
	// private CIConfigMapper mapper = session.getMapper(CIConfigMapper.class);
	private Logger logger = Logger.getLogger(getClass());

	@SuppressWarnings("unchecked")
	public List<T> getAllCIConfig() throws Exception
	{
		List<T> object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIConfigMapper mapper = session.getMapper(CIConfigMapper.class);
			object = (List<T>) mapper.getAllCIConfig();
		}
		catch (Exception e)
		{
			logger.error("exception while get all CIConfig",e);
			throw new Exception("exception while get all CIConfig", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	/**
	 * get CIConfig by configName, createdBy, configFileMD5
	 * @param entity
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public T getCIConfig(T entity) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIConfigMapper mapper = session.getMapper(CIConfigMapper.class);
			object = (T) mapper.getCIConfig(entity);
		}
		catch (Exception e)
		{
			logger.error("exception while get CI config",e);
			throw new Exception("exception while get CI config", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	public boolean addCIConfig(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIConfigMapper mapper = session.getMapper(CIConfigMapper.class);
			mapper.addCIConfig(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while add CIConfig to database",e);
			throw new Exception("exception while add CIConfig to database", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	public boolean updateCIConfig(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIConfigMapper mapper = session.getMapper(CIConfigMapper.class);
			mapper.updateCIConfig(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while update CIConfig",e);
			throw new Exception("exception while update CIConfig", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	public T getCIConfigByMD5(T entity) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIConfigMapper mapper = session.getMapper(CIConfigMapper.class);
			object = (T) mapper.getCIConfigByMD5(entity);
		}
		catch (Exception e)
		{
			logger.error("exception while get CIConfig by the unique MD5 value",e);
			throw new Exception("exception while get CIConfig by the unique MD5 value", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	public int getCIConfigCountByMD5(T entity)
	{
		SqlSession session = null;
		session = ConnectionFactory.openSession();
		CIConfigMapper mapper = session.getMapper(CIConfigMapper.class);
		if (session != null)
			session.close();
		return mapper.getCIConfigCountByMD5(entity);
	}

	@SuppressWarnings("unchecked")
	public T getCIConfigBySystemuuid(String uuid) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIConfigMapper mapper = session.getMapper(CIConfigMapper.class);
			object = (T) mapper.getCIConfigBySystemuuid(uuid);
		}
		catch (Exception e)
		{
			logger.error("exception while get CIConfig by system uuid",e);
			throw new Exception("exception while get CIConfig by system uuid", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;

	}
}
