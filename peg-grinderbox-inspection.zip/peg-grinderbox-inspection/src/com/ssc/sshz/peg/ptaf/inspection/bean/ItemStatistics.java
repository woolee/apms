package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class ItemStatistics implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6643795705884757803L;
	private int summaryId;
	private int itemId;
	private String itemName;
	private int briefId;
	private int planId;
	private int executionCount;
	private double minResponseTime;
	private double avgResponseTime;
	private int ninetyResponseTime;
	private double maxResponseTime;
	private double stdResponseTime;
	private boolean isPassed;
	private int requestCount;
	private int errorCount;
	private double errorRate;
	private int requirementId;
	public int getNinetyResponseTime()
	{
		return ninetyResponseTime;
	}
	public void setNinetyResponseTime(int ninetyResponseTime)
	{
		this.ninetyResponseTime = ninetyResponseTime;
	}
	public double getStdResponseTime()
	{
		return stdResponseTime;
	}
	public void setStdResponseTime(double stdResponseTime)
	{
		this.stdResponseTime = stdResponseTime;
	}
	public int getRequirementId()
	{
		return requirementId;
	}
	public void setRequirementId(int requirementId)
	{
		this.requirementId = requirementId;
	}
	public int getSummaryId()
	{
		return summaryId;
	}
	public void setSummaryId(int summaryId)
	{
		this.summaryId = summaryId;
	}
	public int getItemId()
	{
		return itemId;
	}
	public void setItemId(int itemId)
	{
		this.itemId = itemId;
	}
	public String getItemName()
	{
		return itemName;
	}
	public void setItemName(String itemName)
	{
		this.itemName = itemName;
	}
	public int getBriefId()
	{
		return briefId;
	}
	public void setBriefId(int briefId)
	{
		this.briefId = briefId;
	}
	public int getPlanId()
	{
		return planId;
	}
	public void setPlanId(int planId)
	{
		this.planId = planId;
	}
	public int getExecutionCount()
	{
		return executionCount;
	}
	public void setExecutionCount(int executionCount)
	{
		this.executionCount = executionCount;
	}
	public double getMinResponseTime()
	{
		return minResponseTime;
	}
	public void setMinResponseTime(double minResponseTime)
	{
		this.minResponseTime = minResponseTime;
	}
	public double getMaxResponseTime()
	{
		return maxResponseTime;
	}
	public void setMaxResponseTime(double maxResponseTime)
	{
		this.maxResponseTime = maxResponseTime;
	}
	public double getAvgResponseTime()
	{
		return avgResponseTime;
	}
	public void setAvgResponseTime(double avgResponseTime)
	{
		this.avgResponseTime = avgResponseTime;
	}
	/*public boolean isPassed()
	{
		return isPassed;
	}
	public void setPassed(boolean isPassed)
	{
		this.isPassed = isPassed;
	}*/
	public int getRequestCount()
	{
		return requestCount;
	}
	public void setRequestCount(int requestCount)
	{
		this.requestCount = requestCount;
	}
	public int getErrorCount()
	{
		return errorCount;
	}
	public void setErrorCount(int errorCount)
	{
		this.errorCount = errorCount;
	}
	public double getErrorRate()
	{
		return errorRate;
	}
	public void setErrorRate(double errorRate)
	{
		this.errorRate = errorRate;
	}
	public boolean getIsPassed()
	{
		return isPassed;
	}
	public void setPassed(boolean isPassed)
	{
		this.isPassed = isPassed;
	}
	
}
