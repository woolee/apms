package com.ssc.sshz.peg.ptaf.inspection.quartz.bean;

import java.text.SimpleDateFormat;

public class ScheduleStrategy
{
	private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private boolean startNow;
	private boolean runOnce;
	private int startYear;
	private int startMonth;
	private int startDay;
	private int runHour;
	private int runMinute;
	private int runSecond;
	// private int startHour;
	// private int startMinute;
	// private int startSecond;
	private int endYear;
	private int endMonth;
	private int endDay;
	// private int endHour;
	// private int endMinute;
	// private int endSecond;
	private int intervalInSeconds;
	private int repeatCount;

	public SimpleDateFormat getFormat()
	{
		return format;
	}

	public void setFormat(SimpleDateFormat format)
	{
		this.format = format;
	}

	public boolean isStartNow()
	{
		return startNow;
	}

	public void setStartNow(boolean startNow)
	{
		this.startNow = startNow;
	}

	public int getStartYear()
	{
		return startYear;
	}

	public void setStartYear(int startYear)
	{
		this.startYear = startYear;
	}

	public int getStartMonth()
	{
		return startMonth;
	}

	public void setStartMonth(int startMonth)
	{
		this.startMonth = startMonth;
	}

	public int getStartDay()
	{
		return startDay;
	}

	public void setStartDay(int startDay)
	{
		this.startDay = startDay;
	}

	public int getEndYear()
	{
		return endYear;
	}

	public void setEndYear(int endYear)
	{
		this.endYear = endYear;
	}

	public int getEndMonth()
	{
		return endMonth;
	}

	public void setEndMonth(int endMonth)
	{
		this.endMonth = endMonth;
	}

	public int getEndDay()
	{
		return endDay;
	}

	public void setEndDay(int endDay)
	{
		this.endDay = endDay;
	}

	// public int getEndHour()
	// {
	// return endHour;
	// }
	// public void setEndHour(int endHour)
	// {
	// this.endHour = endHour;
	// }
	// public int getEndMinute()
	// {
	// return endMinute;
	// }
	// public void setEndMinute(int endMinute)
	// {
	// this.endMinute = endMinute;
	// }
	// public int getEndSecond()
	// {
	// return endSecond;
	// }
	// public void setEndSecond(int endSecond)
	// {
	// this.endSecond = endSecond;
	// }

	public int getIntervalInSeconds()
	{
		return intervalInSeconds;
	}

	public int getRunHour()
	{
		return runHour;
	}

	public void setRunHour(int runHour)
	{
		this.runHour = runHour;
	}

	public int getRunMinute()
	{
		return runMinute;
	}

	public void setRunMinute(int runMinute)
	{
		this.runMinute = runMinute;
	}

	public int getRunSecond()
	{
		return runSecond;
	}

	public void setRunSecond(int runSecond)
	{
		this.runSecond = runSecond;
	}

	public void setIntervalInSeconds(int intervalInSeconds)
	{
		this.intervalInSeconds = intervalInSeconds;
	}

	public int getRepeatCount()
	{
		return repeatCount;
	}

	public void setRepeatCount(int repeatCount)
	{
		this.repeatCount = repeatCount;
	}

	public boolean isRunOnce()
	{
		return runOnce;
	}

	public void setRunOnce(boolean runOnce)
	{
		this.runOnce = runOnce;
	}

	public ScheduleStrategy()
	{
		super();
	}

	/**
	 * 
	 * @param runOnce just run once in specify time
	 * @param startNow 
	 * @param startDate
	 * @param endDate
	 * @param runTime the specify time for running in specify date
	 * @param intervalInSeconds run every interval time
	 * @param repeatCount if intervalInSeconds > 0, set the total repeat count of running.
	 */
	public ScheduleStrategy(boolean runOnce, boolean startNow, String startDate, String endDate, String runTime,
			int intervalInSeconds, int repeatCount)
	{
		super();
		if (!startNow)
		{
			if (runTime != null && !"".equals(runTime))
			{
				String[] runTimeArr = runTime.split(":");
				this.runHour = Integer.parseInt(runTimeArr[0]);
				this.runMinute = Integer.parseInt(runTimeArr[1]);
				this.runSecond = Integer.parseInt(runTimeArr[2]);
			}
			if (startDate != null && !"".equals(startDate))
			{

				String[] startDateArr = startDate.split("-");
				this.startYear = Integer.parseInt(startDateArr[0]);
				this.startMonth = Integer.parseInt(startDateArr[1]);
				this.startDay = Integer.parseInt(startDateArr[2]);
			}
			if (!runOnce && endDate != null && !"".equals(endDate))
			{
				String[] endDateArr = startDate.split("-");
				this.endYear = Integer.parseInt(endDateArr[0]);
				this.endMonth = Integer.parseInt(endDateArr[1]);
				this.endDay = Integer.parseInt(endDateArr[2]);
			}

		}
		this.intervalInSeconds = intervalInSeconds;
		if(intervalInSeconds > 0)
			// while repeatCount = -1, repeat it forever
			this.repeatCount = repeatCount;
	}

}
