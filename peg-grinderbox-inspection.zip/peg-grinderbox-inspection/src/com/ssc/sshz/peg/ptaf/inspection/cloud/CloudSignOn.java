package com.ssc.sshz.peg.ptaf.inspection.cloud;

import static com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants.CHECKCOUNT;
import static com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants.CHECKINTERVAL;

import java.net.MalformedURLException;

import org.apache.log4j.Logger;

import com.ssc.cloud.Client;
import com.ssc.cloud.ProcessException;
import com.ssc.cloud.ResultSet;
import com.ssc.cloud.ResultSetException;
import com.ssc.cloud.SignOnException;

public class CloudSignOn
{
	private Logger logger = Logger.getLogger(getClass());
	private CloudSignOn(){}
	private static CloudSignOn instance = new CloudSignOn();
	public static CloudSignOn getInstance()
	{
		return instance;
	}
	public boolean checkServerAvaliable(String url, String username, String password)
	{
		boolean flag = false;
		Client client;
		try
		{
			client = new Client(url);
			client.signOn(username, password);
			
			ResultSet rs = client.process("__request=102");
			
			while (rs.next()) {
				String name = rs.getString("name");
				if(name != null)
					flag = true;
				else
					flag = false;
			}
		}
		catch (MalformedURLException e)
		{
			flag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		catch (SignOnException e)
		{
			flag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		catch (ResultSetException e)
		{
			flag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		catch (ProcessException e)
		{
			flag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		
		return flag;
	}
	
	/**
	 * return the error page 
	 * @param url
	 * @param username
	 * @param password
	 * @return
	 * @throws InterruptedException
	 */
	public String checkServer(String url, String username, String password) throws InterruptedException
	{
		String errorPage = null;
		int intevalSeconds = (Integer.parseInt(CHECKINTERVAL) / 1000);
		for (int i = 0; i < Integer.parseInt(CHECKCOUNT); i++)
		{
			logger.info("Checking " + url + " if is available...");
			boolean serverAvaliable = CloudSignOn.getInstance().checkServerAvaliable(url, username, password);
			if (serverAvaliable)
			{
				logger.info(url + " is available");
				break;
			}
			else
			{
				if(i < Integer.parseInt(CHECKCOUNT) - 1)
				{
				logger.info(url + " is unavailable, check again after " + intevalSeconds + "s");
				Thread.sleep(Integer.parseInt(CHECKINTERVAL));
				errorPage = "../Error/serverUnavailableError.jsp";
				}
			}
		}
		return errorPage;
	}
//	public static void main(String[] args)
//	{
//		CloudSignOn.getInstance().checkServerAvaliable("https://cloud-dev1.statestr.com/lccgui", "a533493", "Xxni@321");
////		CloudSignOn.getInstance().checkServerAvaliable("https://cloud.statestr.com/controller", "a549324", "ZXCvbn[9");
//	}
}
