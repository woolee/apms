package com.ssc.sshz.peg.ptaf.inspection.service;

import org.springframework.dao.DataAccessException;

public interface GroupService<T>
{
	public boolean addGroup(T entity) throws DataAccessException;
}
