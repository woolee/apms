package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.Report;
import com.ssc.sshz.peg.ptaf.inspection.dao.ReportDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ReportMapper;

@Repository
public class ReportDaoImpl<T extends Report> implements ReportDao<T> {

	Logger logger = Logger.getLogger(getClass());

	@Inject
	private ReportMapper mapper;

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllReport() throws DataAccessException {
		List<T> ReportList;
		try {
			ReportList = (List<T>) mapper.getAllReport();
		} catch (DataAccessException e) {
			logger.error("Exception while get all report from database", e);
			throw new DaoException(
					"Exception while get all report from database", e);
		}
		return ReportList;
	}

	@Override
	public boolean addReport(T entity) throws DataAccessException {

		boolean flag = false;
		try {
			mapper.addReport(entity);
			flag = true;
		} catch (DataAccessException e) {
			flag = false;
			logger.error("Exception while add Report to database", e);
			throw new DaoException("Exception while add Report to database", e);
		}
		return flag;

	}

	@Override
	public boolean updateStatus(Report report) throws DataAccessException {

		boolean flag = false;
		try {
			mapper.updateByStatus(report);
			flag = true;
		} catch (DataAccessException e) {
			flag = false;
			logger.error("Exception while update Report status to database", e);
			throw new DaoException(
					"Exception while update Report status to database", e);
		}
		return flag;
	}

	@Override
	public boolean deleteReportByUUID(String reportUUID)
			throws DataAccessException {
		boolean flag = false;
		try {
			mapper.deleteReportByUUID(reportUUID);
			flag = true;
		} catch (DataAccessException e) {
			flag = false;
			logger.error("Exception while delete report to database", e);
			throw new DaoException("Exception while delete report to database",
					e);
		}
		return flag;
	}

	@Override
	public List<T> getPagingReprot(Map<String, Integer> pageparm)
			throws DataAccessException {

		List<T> getPagingReprotList;
		try {
			getPagingReprotList = (List<T>) mapper.getPagingReprot(pageparm);
		} catch (DataAccessException e) {
			logger.error("Exception while get all PagingReprot from database",
					e);
			throw new DaoException(
					"Exception while get all PagingReprot from database", e);
		}
		return getPagingReprotList;

	}

	@Override
	public boolean updateExecutePercent(Report report)
			throws DataAccessException {
		boolean flag = false;
		try {
			mapper.updateExecutePercent(report);
			flag = true;
		} catch (DataAccessException e) {
			flag = false;
			logger.error(
					"Exception while update execute percentage of report to database",
					e);
			throw new DaoException(
					"Exception while update execute percentage of report to database",
					e);
		}
		return flag;

	}

	@Override
	public List<Report> getDownloadPercentList() throws DataAccessException {

		List<Report> getDownloadPercentList;
		try {
			getDownloadPercentList =  mapper.getDownloadPercentList();
		} catch (DataAccessException e) {
			logger.error(
					"Exception while get all getDownloadPercentList from database",
					e);
			throw new DaoException(
					"Exception while get all getDownloadPercentList from database",
					e);
		}
		return getDownloadPercentList;

	}

	@Override
	public T getReportByUUID(String reportUUID) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getReportByUUID(reportUUID);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get Report from database",e);
			throw new DaoException("Exception while get Report from database",e);
		}
		return entity;
	}

}
