package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.ItemDetail;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemDetailDao;
import com.ssc.sshz.peg.ptaf.inspection.service.ItemDetailService;
@Service

public class ItemDetailServiceImp<T extends ItemDetail> implements ItemDetailService<T>
{
	@Inject
	private ItemDetailDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllItemDetail() throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getAllItemDetail();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getItemDetail(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getItemDetails(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addItemDetail(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addItemDetail(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateItemDetail(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.updateItemDetail(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllItemDetailByPlanId(int planId)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllItemDetailByPlanId(planId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllItemDetailByItemId(int itemId)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllItemDetailByItemId(itemId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllItemDetailByItemIdAndBriefId(T entity)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllItemDetailByItemIdAndBriefId(entity);
	}



	
}
