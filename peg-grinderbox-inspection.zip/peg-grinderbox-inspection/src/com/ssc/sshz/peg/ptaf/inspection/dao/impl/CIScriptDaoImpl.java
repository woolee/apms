package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.CIScript;
import com.ssc.sshz.peg.ptaf.inspection.dao.CIScriptDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.CIScriptMapper;

@Repository
public class CIScriptDaoImpl<T extends CIScript> implements CIScriptDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private CIScriptMapper mapper;

	@Override
	public boolean addCIScript(T entity)
	{
		boolean flag = false;
		try
		{
			mapper.addCIScript(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add CIScript to database",e);
			throw new DaoException("Exception while add CIScript to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllCIScript()
	{
		List<T> object = null;
		try{
		object =  (List<T>) mapper.getAllCIScript();
		}
		catch(Exception e)
		{
			logger.error("Exception while get all CIScript from database",e);
			throw new DaoException("Exception while get all CIScript from database",e);
		}
		return object;
		// TODO Auto-generated method stub
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getCIScript(T entity)
	{
		T object = null;
		try{
		object = (T)mapper.getCIScript(entity);
		}
		catch(Exception e)
		{
			logger.error("Exception while get CIScript from database",e);
			throw new DaoException("Exception while get CIScript from database",e);
		}
		return object;
	}


}
