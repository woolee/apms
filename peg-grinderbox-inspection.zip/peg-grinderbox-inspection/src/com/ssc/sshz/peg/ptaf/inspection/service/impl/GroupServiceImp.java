package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Group;
import com.ssc.sshz.peg.ptaf.inspection.dao.GroupDao;
import com.ssc.sshz.peg.ptaf.inspection.service.GroupService;
@Service
public class GroupServiceImp<T extends Group> implements GroupService<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private GroupDao<T> dao;
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addGroup(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addGroup(entity);
	}


	
}
