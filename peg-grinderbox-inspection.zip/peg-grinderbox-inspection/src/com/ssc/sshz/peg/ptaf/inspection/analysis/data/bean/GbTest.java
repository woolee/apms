package com.ssc.sshz.peg.ptaf.inspection.analysis.data.bean;

public class GbTest
{
	private int testId ;
	private int scenarioId ;
	private int sessionId;
	private int actionId ;
	private int requestId ;
	public GbTest()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public int getTestId()
	{
		return testId;
	}
	public void setTestId(int testId)
	{
		this.testId = testId;
	}
	public int getScenarioId()
	{
		return scenarioId;
	}
	public void setScenarioId(int scenarioId)
	{
		this.scenarioId = scenarioId;
	}
	public int getSessionId()
	{
		return sessionId;
	}
	public void setSessionId(int sessionId)
	{
		this.sessionId = sessionId;
	}
	public int getActionId()
	{
		return actionId;
	}
	public void setActionId(int actionId)
	{
		this.actionId = actionId;
	}
	public int getRequestId()
	{
		return requestId;
	}
	public void setRequestId(int requestId)
	{
		this.requestId = requestId;
	}
	public GbTest(int testId, int scenarioId, int sessionId, int actionId, int requestId)
	{
		super();
		this.testId = testId;
		this.scenarioId = scenarioId;
		this.sessionId = sessionId;
		this.actionId = actionId;
		this.requestId = requestId;
	}
}
