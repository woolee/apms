package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.Project;

public interface ProjectMapper extends SqlMapper{
	public List<Project> getAllProject(); 
	public List<Project> getAllProjectByUsername(String userName); 
	public Project getProject();
	public Project getProjectById(Integer id);
	public Project getProjectByuuid(String id);
	public Project getProjectByName(String name);
	public void addProject(Project Project);
	public void editProject(Project Project);
	public void delProject(int id);
	
}
