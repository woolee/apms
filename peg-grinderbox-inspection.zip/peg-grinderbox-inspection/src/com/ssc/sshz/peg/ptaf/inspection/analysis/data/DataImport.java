package com.ssc.sshz.peg.ptaf.inspection.analysis.data;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.ListContainer;
import com.ssc.sshz.peg.ptaf.inspection.analysis.data.bean.GbAction;
import com.ssc.sshz.peg.ptaf.inspection.analysis.data.bean.GbRequest;
import com.ssc.sshz.peg.ptaf.inspection.analysis.data.bean.GbScenario;
import com.ssc.sshz.peg.ptaf.inspection.analysis.data.bean.GbService;
import com.ssc.sshz.peg.ptaf.inspection.analysis.data.bean.GbSession;
import com.ssc.sshz.peg.ptaf.inspection.analysis.data.bean.GbTest;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.constants.ErrorType;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;

public class DataImport 
{
	private File outputFolder;
	private final static String TESTS = "Tests.csv";
	private final static String SCENARIONS = "Scenarios.csv";
	private final static String SESSIONS = "Sessions.csv";
	private final static String ACTIONS = "Actions.csv";
	private final static String REQUESTS = "Requests.csv";
	private final static String SERVICES = "Services.csv";

	private ListContainer container = new ListContainer();

	private Map<Integer,GbTest> testMap = new HashMap<Integer, GbTest>();
	private Map<Integer, GbScenario> scenarioMap = new HashMap<Integer, GbScenario>();
	private Map<Integer, GbSession> sessionMap = new HashMap<Integer, GbSession>();
	private Map<Integer, GbAction> actionMap = new HashMap<Integer, GbAction>();
	private Map<Integer, GbRequest> requestMap = new HashMap<Integer, GbRequest>();
	private Map<Integer, GbService> serviceMap = new HashMap<Integer, GbService>();
	
	
	public DataImport( File outputFolder)
	{
		this.outputFolder = outputFolder;
		
	}

	
	public TestBeanCollection execute(TestBeanCollection collection) throws IOException
	{
		List<Item> itemList = collection.getItemList();
		List<Item> itemTempList = new ArrayList<Item>();
		Map<Integer,List<Request>> requestMapFromColl = collection.getRequestMapByItemId();
		Map<Integer,List<Request>> requestTempMap = new HashMap<Integer, List<Request>>();
		
		importTests();
		importScenarios();
		importSessions();
		importActions();
		importRequests();
		importServices();
		
		//transfer the itemList to map with the key - itemName
		Set<Integer> testIds = testMap.keySet();
		Map<String,Item> itemMap = new HashMap<String, Item>();
		for (Item item : itemList)
		{
			itemMap.put(item.getItemName(),item);
		}
		for (Integer testId : testIds)
		{
			GbTest test = testMap.get(testId);
			int scenarioId = test.getScenarioId();
			int sessionId = test.getSessionId();
			int actionId = test.getActionId();
			int requestId = test.getRequestId();
			if(requestId == 0)
			{
				
				GbAction action = actionMap.get(actionId);
				Item item = itemMap.get(action.getClassName());
				if(item != null)
				{
					item.setItemName(testId + "");
					itemTempList.add(item);
				}
			}
			else{
				//get the GBaction object by action id
				GbAction action = actionMap.get(actionId);
				Item item = null;
				Request requestTemp = null;
				
				//if the itemMap contains the action with the action name
				//contains: get the request and add to the map
				//if not: continue
				if((item = itemMap.get(action.getClassName())) != null)
				{
					// get request list by item id and transfer the request list to map with key - request name
					int itemId = item.getItemId();
					List<Request> requests = requestMapFromColl.get(itemId);
					Map<String, Request> requestMapByRequestName = new HashMap<String, Request>();
					for (Request request : requests)
					{
						requestMapByRequestName.put(request.getRequestName(), request);
					}
					
					//get the GBRequest object from request map and get Request object by request name
					//set the request name with testId, do not submit to DB, used in memory
					GbRequest gbRequest = requestMap.get(requestId);
					Request request = requestMapByRequestName.get(gbRequest.getName());
					request.setRequestName(testId+ "");
					for (Integer testIdInside : testIds)
					{
						GbTest gbTest = testMap.get(testIdInside);
						if(gbTest != null && gbTest.getScenarioId() == scenarioId && gbTest.getSessionId() == sessionId && gbTest.getActionId() == actionId && gbTest.getRequestId() ==0)
						{
							request.setItemName(testIdInside + "");
						}
					}
					//if the requestTempMap contains the itemId key, add to map
					//else new list and added to map
					if(requestTempMap.containsKey(item.getItemId()))
					{
						requestTempMap.get(item.getItemId()).add(request);
					}
					else{
						List<Request> requestListByItemId = new ArrayList<Request>();
						requestListByItemId.add(request);
						requestTempMap.put(item.getItemId(), requestListByItemId);
					}
				}
				else continue;
			}
				
		}
		//add the itemTmepList and requestTempMap to collection and return 
		collection.setItemList(itemTempList);
		collection.setRequestMapByItemId(requestTempMap);
		return collection;
		
	}
	private void importTests() throws IOException
	{
		File file = new File(outputFolder, TESTS);
		BufferedReader reader = null;
//		List<GbTest> testList = new ArrayList<GbTest>();
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String headers = reader.readLine();
			String line = reader.readLine();
			while(line != null && !"".equals(line))
			{
				String[] dataLine = line.split(",",-1);
				int testId = Integer.parseInt(dataLine[0]);
				int scenarioId = Integer.parseInt(dataLine[1]);
				int sessionId = Integer.parseInt(dataLine[2]);
				int actionId = Integer.parseInt(dataLine[3]);
				int requestId = Integer.parseInt(dataLine[4]);
				GbTest test = new GbTest(testId, scenarioId, sessionId, actionId, requestId);
//				System.out.println(test.getTestId() + test.getScenarioId() + test.getSessionId() + test.getActionId() + test.getRequestId());
				testMap.put(testId,test);
				line = reader.readLine();
			}
			
		}
		catch (FileNotFoundException e)
		{
			throw new FileNotFoundException("tests.csv can't found");
		}
		catch (IOException e)
		{
			throw new IOException("exception while reading scenarios.csv");
		}
		finally
		{
			if (reader != null)
				reader.close();
		}
	}

	private void importScenarios() throws IOException
	{
		File file = new File(outputFolder, SCENARIONS);
		BufferedReader reader = null;
//		List<GbScenario> scenarioList = new ArrayList<GbScenario>();
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String headers = reader.readLine();
			String line = reader.readLine();
			while(line != null && !"".equals(line))
			{
				String[] dataLine = line.split(",", -1);
				int id = Integer.parseInt(dataLine[0]);
				String className = dataLine[1];
				String name = dataLine[2];
				String description = dataLine[3];
				GbScenario scenario = new GbScenario(id, className, name, description);
				scenarioMap.put(id, scenario);
				line = reader.readLine();
			}
			
		}
		catch (FileNotFoundException e)
		{
			throw new FileNotFoundException("scenarios.csv can't found");
		}
		catch (IOException e)
		{
			throw new IOException("exception while reading scenarios.csv");
		}
		finally
		{
			if (reader != null)
				reader.close();
		}
	}

	
	private void importSessions() throws IOException
	{
		File file = new File(outputFolder, SESSIONS);
		BufferedReader reader = null;
//		List<GbSession> sessionList = new ArrayList<GbSession>();
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String headers = reader.readLine();
			String line = reader.readLine();
			while(line != null && !"".equals(line))
			{
				String[] dataLine = line.split(",",-1);
				int id = Integer.parseInt(dataLine[0]);
				String className = dataLine[1];
				String name = dataLine[2];
				String description = dataLine[3];
				GbSession session = new GbSession(id, className, name, description);
				sessionMap.put(id, session);
				line = reader.readLine();
			}
			
		}
		catch (FileNotFoundException e)
		{
			throw new FileNotFoundException("sessions.csv can't found");
		}
		catch (IOException e)
		{
			throw new IOException("exception while reading sessions.csv");
		}
		finally
		{
			if (reader != null)
				reader.close();
		}
	}

	private void importActions() throws IOException 
	{
		File file = new File(outputFolder, ACTIONS);
		BufferedReader reader = null;
//		List<GbAction> actionList = new ArrayList<GbAction>();
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String headers = reader.readLine();
			String line = reader.readLine();
			while(line != null && !"".equals(line))
			{
				String[] dataLine = line.split(",",-1);
				int id = Integer.parseInt(dataLine[0]);
				String className = dataLine[1];
				String name = FileUtil.getInstance().getStringWithSpace(FileUtil.getInstance().getStringWithSeparator(dataLine[2]));
				String description = dataLine[3];
				GbAction action = new GbAction(id, className, name, description);
				actionMap.put(id, action);
				line = reader.readLine();
			}
		}
		catch (FileNotFoundException e)
		{
			throw new FileNotFoundException("actions.csv can't found");
		}
		catch (IOException e)
		{
			throw new IOException("exception while reading actions.csv");
		}
		finally
		{
			if (reader != null)
				reader.close();
		}
	}

	private void importRequests() throws IOException 
	{
		File file = new File(outputFolder, REQUESTS);
		BufferedReader reader = null;
//		List<GbRequest> requsetList = new ArrayList<GbRequest>();
		try
		{
			reader = new BufferedReader(new FileReader(file));
			String headers = reader.readLine();
			String line = reader.readLine();
			while(line != null && !"".equals(line))
			{
				String[] dataLine = line.split(",",-1);
				int id = Integer.parseInt(dataLine[0]);
				String className = dataLine[1];
				
				String name = FileUtil.getInstance().getStringWithSpace(FileUtil.getInstance().getStringWithSeparator(dataLine[2]));
				String description = dataLine[3];
				GbRequest request = new GbRequest(id, className, name, description);
				requestMap.put(id, request);
				line = reader.readLine();
			}
		}
		catch (FileNotFoundException e)
		{
			throw new FileNotFoundException("requests.csv can't found");
		}
		catch (IOException e)
		{
			throw new IOException("exception while reading requests.csv");
		}
		finally
		{
			if (reader != null)
				reader.close();
		}
	}

	private void importServices() throws IOException 
	{
		File file = new File(outputFolder, SERVICES);
		BufferedReader reader = null;
//		List<GbService> serviceList = new ArrayList<GbService>();
		if (file.exists())
		{
			try
			{
				reader = new BufferedReader(new FileReader(file));
				String headers = reader.readLine();
				String line = reader.readLine();
				while(line != null && !"".equals(line))
				{
					String[] dataLine = line.split(",",-1);
					int serviceNumber = Integer.parseInt(dataLine[0]);
					int requestId = Integer.parseInt(dataLine[1]);
					GbService service = new GbService(serviceNumber, requestId);
					serviceMap.put(serviceNumber, service);
					line = reader.readLine();
				}
			}
			catch (FileNotFoundException e)
			{
				throw new FileNotFoundException("services.csv can't found");
			}
			catch (IOException e)
			{
				throw new IOException("exception while reading services.csv");
			}
			finally
			{
				if (reader != null)
					reader.close();
			}
		}
	}

	public ListContainer getContainer()
	{
		return container;
	}

	public void setContainer(ListContainer container)
	{
		this.container = container;
	}
	


	public static void main(String[] args) throws IOException
	{
		DataImport transfer = new DataImport(new File("C:\\result\\gb\\output"));
		
	}
}
