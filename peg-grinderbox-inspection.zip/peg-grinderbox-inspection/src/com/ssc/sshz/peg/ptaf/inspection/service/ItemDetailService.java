package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface ItemDetailService<T>
{
	public List<T> getAllItemDetail() throws DataAccessException;
	public List<T> getAllItemDetailByPlanId(int planId) throws DataAccessException;
	public List<T> getAllItemDetailByItemId(int itemId) throws DataAccessException;
	public List<T> getAllItemDetailByItemIdAndBriefId(T entity) throws DataAccessException;
	public T getItemDetail(T entity) throws DataAccessException;
	public boolean addItemDetail(T entity) throws DataAccessException;
	public boolean updateItemDetail(T entity) throws DataAccessException;
}
