package com.ssc.sshz.peg.ptaf.inspection.mapper;

import com.ssc.sshz.peg.ptaf.inspection.bean.RightNotification;

public interface RightNotificationMapper extends SqlMapper
{
	public void addRightNotification(RightNotification rightNotification);
	
}
