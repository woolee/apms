package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
public class AssetModifyUtil {
	private Logger logger = Logger.getLogger(AssetModifyUtil.class);
	private AssetModifyUtil(){}
	private static final AssetModifyUtil instance = new AssetModifyUtil();
	public static AssetModifyUtil getInstance(){
		return instance;
	}
	
	/**
	 * change the attributes in asset
	 * @param file
	 * @return
	 * @throws Exception
	 */
	public File changeAssetAttr(File file, JobData jobData) throws Exception
	{
		File propFile = null;
		try
		{
			propFile = FileUtil.getInstance().changeToLocalHost(file);
			FileUtil.getInstance().changePropValue(propFile, TestAssetContants.GRINDER_LOGDIRECTORY, jobData.getOutput());
			FileUtil.getInstance().changePropValue(propFile, TestAssetContants.GRINDER_SCRIPT, "../scripts/Main.py");
			String localhostName = InetAddress.getLocalHost().getHostName();
			FileUtil.getInstance().changePropValue(propFile, TestAssetContants.GRINDER_CONSOLEHOST, localhostName);
			FileUtil.getInstance().changePropValue(propFile, TestAssetContants.GRINDER_THREADS, jobData.getThreadsNum());
			AssetAnalyzeUtil.getInstance().setRootPath(jobData.getAsset());
			File runtimeFile = AssetAnalyzeUtil.getInstance().getRunTime();
			FileUtil.getInstance().changeAttributeValue(runtimeFile, "runtime/agents/agent", "name", localhostName);
			FileUtil.getInstance().changeAttributeValue(runtimeFile, "runtime", "liveCycles", jobData.getRunCount());
			FileUtil.getInstance().changeAttributeValue(runtimeFile, "runtime/agents/agent", "threads", jobData.getThreadsNum());
		}
		catch(UnknownHostException e)
		{
			logger.error(e.getMessage(), e);
			throw e;
		}
		catch(IOException e)
		{
			logger.error(e.getMessage(), e);
			throw e;
		}
		return propFile;
	}
}
