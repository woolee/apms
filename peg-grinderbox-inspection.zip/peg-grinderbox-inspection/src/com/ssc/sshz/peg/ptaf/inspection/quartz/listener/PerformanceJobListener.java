package com.ssc.sshz.peg.ptaf.inspection.quartz.listener;

import org.apache.log4j.Logger;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobListener;

public class PerformanceJobListener implements JobListener
{
	public static final String LISTENER_NAME = "PerformanceJobListener";
	private static Logger logger = Logger.getLogger(PerformanceJobListener.class);
	@Override
	public String getName()
	{
		return LISTENER_NAME;
	}

	@Override
	public void jobExecutionVetoed(JobExecutionContext context)
	{
		String jobName = context.getJobDetail().getKey().toString();
		logger.error("Job : " + jobName + " is vetoed to be executed...");
		
	}

	@Override
	public void jobToBeExecuted(JobExecutionContext context)
	{
		String jobName = context.getJobDetail().getKey().toString();
		logger.info("Job :" + jobName + " is to be executed...");
		
	}

	@Override
	public void jobWasExecuted(JobExecutionContext context, JobExecutionException exception)
	{
		String jobName = context.getJobDetail().getKey().toString();
		logger.info("Job : " + jobName + " is finished...");
 
		if (exception != null && !"".equals(exception.getMessage())) {
			logger.error("Exception thrown by: " + jobName + " Exception: " + exception.getMessage());
		}
		
	}

}
