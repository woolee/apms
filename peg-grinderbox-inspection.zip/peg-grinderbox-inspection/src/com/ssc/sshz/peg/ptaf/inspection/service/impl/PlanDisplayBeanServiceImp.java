package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.PlanDisplayBean;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanScriptDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanDisplayBeanService;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanStrategyService;

@Service
public class PlanDisplayBeanServiceImp<T> implements PlanDisplayBeanService<T>
{
	@Inject
	private PlanDao<Plan> planDao;
	
	@Inject
	private PlanStrategyService<PlanStrategy> planStrategyDao;
	
	@Inject
	private PlanScriptDao<PlanScript> planScriptDao;
	
	@Inject
	private RuntimeDao<Runtime> runtimeDao;
	
	@Inject
	private UserDao<User> userDao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<PlanDisplayBean> getPlanBySystem(int systemId,PlanStrategy planStrategy,PlanScript planScript,Runtime runtime) throws Exception
	{
		List<Plan> planList=planDao.getPlanBySystemId(systemId);
		List<PlanDisplayBean> pbList=new ArrayList<PlanDisplayBean>();
		for(int i=0;i<planList.size();i++){
			planStrategy=planStrategyDao.getPlanStrategyByPlanId(planList.get(i).getPlanId()).get(0);
			runtime=runtimeDao.getRuntimeByStrategyId(planStrategy.getStrategyId()).get(0);
			planScript=planScriptDao.getPlanScriptByPlanId(planList.get(i).getPlanId());
			PlanDisplayBean pb=new PlanDisplayBean();
			User user = userDao.getUserById(planList.get(i).getPlancreatorId());
			pb.setCreatorName(user.getUserName());
			pb.setPlanDes(planList.get(i).getPlanDescription());
			pb.setRuntimeId(runtime.getRuntimeId());
			pb.setStrategyName(planStrategy.getStrategyName());
			pb.setPlanName(planList.get(i).getPlanName());
			pb.setPlanId(planList.get(i).getPlanId());
			pb.setScriptName(planScript.getScriptName());
			pb.setStrategyId(planStrategy.getStrategyId());
			pbList.add(pb);
		}	
		return pbList;
	}
}
