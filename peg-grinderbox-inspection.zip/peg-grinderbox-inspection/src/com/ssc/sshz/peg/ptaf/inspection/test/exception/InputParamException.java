package com.ssc.sshz.peg.ptaf.inspection.test.exception;

public class InputParamException extends Exception
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public InputParamException(){
		super();
	}
	public InputParamException(String s){
		super(s);
	}
}
