package com.ssc.sshz.peg.ptaf.inspection.dao.impl;
import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanStrategyDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.PlanStrategyMapper;

@Repository
public class PlanStrategyDaoImpl<T extends PlanStrategy> implements PlanStrategyDao<T>{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private PlanStrategyMapper mapper;

	@Override
	public boolean addPlanStrategy(T entity) throws DataAccessException {
		boolean flag = false;
		try {
			mapper.addPlanStrategy(entity); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while add PlanStrategy to database",e);
			throw new DaoException("Exception while add PlanStrategy to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllPlanStrategy() throws DataAccessException {
		List<T> allPlanStrategyList=null;
		try{ 
			allPlanStrategyList =(List<T>) mapper.getAllPlanStrategy();
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all PlanStrategy from database",e);
			throw new DaoException("Exception while get all PlanStrategy from database",e);
		}
		return allPlanStrategyList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getPlanStrategyByName(String name) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getPlanStrategyByName(name);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all PlanStrategy by name from database",e);
			throw new DaoException("Exception while get all PlanStrategy by name from database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getPlanStrategyByPlanId(int id) throws DataAccessException
	{
		List<T> allPlanStrategyList=null;
		try{ 
			allPlanStrategyList =(List<T>) mapper.getPlanStrategyByPlanId(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all PlanStrategy by plan id from database",e);
			throw new DaoException("Exception while get all PlanStrategy by plan id from database",e);
		}
		return allPlanStrategyList;
	}

	@Override
	public T getPlanStrategyById(int id) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getPlanStrategyById(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all PlanStrategy by name from database",e);
			throw new DaoException("Exception while get all PlanStrategy by name from database",e);
		}
		return entity;
	}


}
