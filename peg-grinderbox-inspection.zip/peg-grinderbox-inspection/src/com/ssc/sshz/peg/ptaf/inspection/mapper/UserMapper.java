package com.ssc.sshz.peg.ptaf.inspection.mapper;


import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.User;

public interface UserMapper extends SqlMapper{
	public void addUser(User user);
	public User getUserByName(String name);
	public User getUserById(int id);
	public List<User> getAllUsers();
}
