package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.ItemStatistics;

public interface ItemStatisticsMapper extends SqlMapper
{
	public void addItemStatistics(ItemStatistics statistics);
	
	public ItemStatistics getItemStitistics(ItemStatistics statistics);
	
	public void updateItemStitistics(ItemStatistics statistics);
	
	public List<ItemStatistics> getAllItemStatistics();
	
	public List<ItemStatistics> getItemStitisticsByBriefId(int briefId);

	public List<ItemStatistics> getAllItemStatisticsByPlanIdAndItemId(ItemStatistics statistics);

}
