package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.util.Date;

import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;

public class ScheduleData {
	 Date startTime ;
	 Date endTime;
	 int intervalSeconds;
	 int repeatTime;
	 JobData data;
	 boolean  isServiceCall = false;
	 RuntimeTrigger runtimeTrigger;
	 TestBeanCollection testBeanCollection;
	 boolean startNow = false;

	public Date getEndTime() {
		return endTime;
	}
	public int getIntervalSeconds() {
		return intervalSeconds;
	}
	public void setIntervalSeconds(int intervalSeconds) {
		this.intervalSeconds = intervalSeconds;
	}
	public int getRepeatTime() {
		return repeatTime;
	}
	public void setRepeatTime(int repeatTime) {
		this.repeatTime = repeatTime;
	}
	public JobData getData() {
		return data;
	}
	public void setData(JobData data) {
		this.data = data;
	}
	public boolean isServiceCall() {
		return isServiceCall;
	}
	public void setServiceCall(boolean isServiceCall) {
		this.isServiceCall = isServiceCall;
	}
	public TestBeanCollection getTestBeanCollection() {
		return testBeanCollection;
	}
	public void setTestBeanCollection(TestBeanCollection testBeanCollection) {
		this.testBeanCollection = testBeanCollection;
	}
	@Override
	public String toString() {
		return "ScheduleData [startTime=" + startTime + ", endTime=" + endTime
				+ ", intervalSeconds=" + intervalSeconds + ", repeatTime="
				+ repeatTime + ", data=" + data + ", isServiceCall="
				+ isServiceCall + "]";
	}
	 public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public boolean isStartNow()
	{
		return startNow;
	}
	public void setStartNow(boolean startNow)
	{
		this.startNow = startNow;
	}
	public RuntimeTrigger getRuntimeTrigger()
	{
		return runtimeTrigger;
	}
	public void setRuntimeTrigger(RuntimeTrigger runtimeTrigger)
	{
		this.runtimeTrigger = runtimeTrigger;
	}
}
