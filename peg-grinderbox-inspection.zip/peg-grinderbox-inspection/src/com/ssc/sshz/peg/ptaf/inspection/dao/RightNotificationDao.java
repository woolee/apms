package com.ssc.sshz.peg.ptaf.inspection.dao;

import org.springframework.dao.DataAccessException;



public interface RightNotificationDao<T> {
	public boolean addRightNotification(T entity) throws DataAccessException;

}
