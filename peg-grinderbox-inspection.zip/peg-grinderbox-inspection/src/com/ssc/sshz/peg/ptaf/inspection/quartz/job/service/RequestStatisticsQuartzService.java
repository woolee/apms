package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RequestStatisticsMapper;

public class RequestStatisticsQuartzService<T extends RequestStatistics>
{
	private Logger logger = Logger.getLogger(getClass());

	// private SqlSession session = ConnectionFactory.openSession();
	// private RequestStatisticsMapper mapper =
	// session.getMapper(RequestStatisticsMapper.class);

	@SuppressWarnings("unchecked")
	public List<T> getAllRequestStatistics() throws Exception
	{
		List<T> object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestStatisticsMapper mapper = session.getMapper(RequestStatisticsMapper.class);
			object = (List<T>) mapper.getAllRequestStatistics();
		}
		catch (Exception e)
		{
			logger.error("exception while get all RequestStatistics from databse",e);
			throw new Exception("exception while get all RequestStatistics from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	public T getRequestStatistics(T entity) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestStatisticsMapper mapper = session.getMapper(RequestStatisticsMapper.class);
			object = (T) mapper.getRequestStitistics(entity);
		}
		catch (Exception e)
		{
			logger.error("exception while get RequestStatistics object from databse",e);
			throw new Exception("exception while get RequestStatistics object from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	public boolean addRequestStatistics(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestStatisticsMapper mapper = session.getMapper(RequestStatisticsMapper.class);
			mapper.addRequestStatistics(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while add RequestStatistics object to databse",e);
			throw new Exception("exception while add RequestStatistics object to databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	public boolean updateRequestStatistics(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			RequestStatisticsMapper mapper = session.getMapper(RequestStatisticsMapper.class);
			mapper.updateRequestStitistics(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while update RequestStatistics object to databse",e);
			throw new Exception("exception while update RequestStatistics object to databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

}
