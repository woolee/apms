package com.ssc.sshz.peg.ptaf.inspection.exception;

import org.springframework.dao.DataAccessException;

public class ServiceException extends DataAccessException
{

	public ServiceException(String msg)
	{
		super(msg);
		// TODO Auto-generated constructor stub
	}

	public ServiceException(String msg, Throwable cause )
	{
		super(msg, cause);
		// TODO Auto-generated constructor stub
	}
}
