package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.User;

public interface UserService<T>
{

	public User getUserByName(String name) throws DataAccessException;
}
