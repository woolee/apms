package com.ssc.sshz.peg.ptaf.inspection.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ResultUploadReceiver {
	
	
	@RequestMapping(value = "/xml", method = RequestMethod.GET) 
	public String createDocument(String name,
			HttpServletRequest  request,
			HttpServletResponse response,HttpSession httpSession) 
					throws IllegalStateException, IOException {
		 	System.out.println("request URI="+request.getRequestURI());
		 	System.out.println("__request="+request.getParameter("__request"));
		 	System.out.println("SUMMARY_ID="+request.getParameter("SUMMARY_ID"));
		 	System.out.println("PROJECT_NAME="+request.getParameter("PROJECT_NAME"));
		 	System.out.println("FINISH_TIME="+request.getParameter("FINISH_TIME"));
		 	System.out.println("TOTAL_SERVICE_NUM="+request.getParameter("TOTAL_SERVICE_NUM"));
		 	System.out.println("PASSED_SERVICE_NUM="+request.getParameter("PASSED_SERVICE_NUM"));
		 	System.out.println("FAILED_SERVICE_NUM="+request.getParameter("FAILED_SERVICE_NUM"));
		 	System.out.println("PASSED_RATE="+request.getParameter("PASSED_RATE"));
		 	System.out.println("COMPLETION_TIME="+request.getParameter("COMPLETION_TIME"));
		 	System.out.println("ERROR_MESSAGE="+request.getParameter("ERROR_MESSAGE"));
		 	
		 	return "/view/resultReceiveResponse.jsp";
   
	 }
		 
}
