package com.ssc.sshz.peg.ptaf.inspection.test.generator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;


public class GrinderPropGenerator
{
	private static final Logger logger = Logger.getLogger(GrinderPropGenerator.class);
    /**
     * generate grinder.properties.
     * 
     * @param propertyFile the file to be generated
     * @param threadNum number of thread
     * @param logDir test output path
     * @throws IOException
     */
    public void generateProperties(File propertyFile, int threadNum, String logDir) throws IOException
    {
	Properties grinderProp = new Properties();
	OutputStream out = null;

	grinderProp.setProperty(TestAssetContants.GRINDER_THREADS, String.valueOf(threadNum));
	grinderProp.setProperty(TestAssetContants.GRINDER_LOGDIRECTORY, logDir);
	grinderProp.setProperty(TestAssetContants.GRINDER_SCRIPT, "grinder.py");
	grinderProp.setProperty(TestAssetContants.GRINDER_PROCESS, String.valueOf(TestAssetContants.PROCESSNUM));
	grinderProp.setProperty(TestAssetContants.GRINDER_RUNS, String.valueOf(TestAssetContants.RUNSNUM));
	grinderProp.setProperty(TestAssetContants.GRINDER_USECONSOLE, String.valueOf(TestAssetContants.USECONSOLE));
	grinderProp.setProperty(TestAssetContants.GRINDER_NUMBEROFOLDLOGS, String.valueOf(TestAssetContants.NUMBEROFOLDLOGS));
	grinderProp.setProperty(TestAssetContants.GRINDER_SLPTIMEVARIATION, String.valueOf(TestAssetContants.SLPTIMEVARIATIONNUM));
	grinderProp.setProperty(TestAssetContants.GRINDER_SLPTIMEFACTOR, String.valueOf(TestAssetContants.SLPTIMEFACTORNUM));
	try
	{
	    out = new FileOutputStream(propertyFile);
	    grinderProp.store(out, "properties generator");

	}
	catch (IOException e)
	{
		logger.error(e.getMessage(),e);
	    e.printStackTrace();
	    throw new IOException("can not gengerate grinder.properties:" + e.getMessage());
	}
	finally
	{
	    if (out != null)
		out.close();
	}
    }

}
