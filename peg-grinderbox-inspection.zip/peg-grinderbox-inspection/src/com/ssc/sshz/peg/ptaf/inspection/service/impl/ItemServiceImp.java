package com.ssc.sshz.peg.ptaf.inspection.service.impl;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanItemDao;
import com.ssc.sshz.peg.ptaf.inspection.service.ItemService;

@Service

public class ItemServiceImp<T extends Item> implements ItemService<T> {
	
	@Inject
	private ItemDao<T> dao;

	@Inject
	private PlanItemDao<PlanItem> planItemDao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addItem(T entity) throws DataAccessException {
		return dao.addItem(entity);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllItem() throws DataAccessException {
		return dao.getAllItem();
		}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getItemByName(String name) throws DataAccessException {
		return dao.getItemByName(name);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getItemBySystemIdItemName(T entity) throws DataAccessException {
		return dao.getItemBySystemIdItemName(entity);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getItemById(int id) throws DataAccessException {
		return dao.getItemById(id);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getItemBySystemId(int sysId) throws DataAccessException {
		return dao.getItemBySystemId(sysId);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getItemsByPlanId(int planId) throws DataAccessException
	{
		List <PlanItem> PlanItemList=planItemDao.getAllPlanItemByPlanId(planId);
		List<Item> itemList=new ArrayList<Item>();
		for(int k=0;k<PlanItemList.size();k++){
			itemList.add(dao.getItemById(PlanItemList.get(k).getItemId()));
		}
		return (List<T>) itemList;
	}

}
