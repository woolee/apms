package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;


public interface GroupRightDao<T> {
	public boolean addGroupRight(T entity) throws DataAccessException;
	public List<T> getAllGroupRight() throws DataAccessException;
	public List<T> getGroupRightByGroupName(String groupName) throws DataAccessException;
}
