package com.ssc.sshz.peg.ptaf.inspection.test.generator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;

public class GrinderScriptGenerator
{
	private static final Logger logger = Logger.getLogger(GrinderScriptGenerator.class);
    public void generateGrinderScript(File scriptFile, String loginScriptName, long thinkTime, int runCount, Set<String> IDFScripts)
	    throws IOException
    {
	InputStream in = GrinderScriptGenerator.class.getResourceAsStream(TestAssetContants.GRINDER_SCRIPT_TMP);
	BufferedReader reader = null;
	BufferedWriter writer = null;

	try
	{

	    // reader = new RandomAccessFile(tmpFileUrl.getPath(), "r");
	    reader = new BufferedReader(new InputStreamReader(in));
	    writer = new BufferedWriter(new FileWriter(scriptFile));
	    String line;
	    while ((line = reader.readLine()) != null)
	    {

		if (line.contains("${put_to_script_map}"))
		{
		    line = line.replace("${put_to_script_map}", "");

		    // replace ${put_to_script_map}
		    // exp. scriptMap.put("IDF_10001",IDF_10001());
		    // exp. scriptMap.put("IDF_10002",IDF_10002());
		    for (String script : IDFScripts)
		    {
			line = "scriptMap.put(" + FileUtil.getInstance().quot(script) + "," + script + "())";

			writer.write(line);
			writer.newLine();
		    }
		}
		else if (line.contains("${callTimes}"))
		{
		    line = line.replace("${callTimes}", String.valueOf(runCount));
		    writer.write(line);
		    writer.newLine();
		}
		else if (line.contains("${sleepTime}"))
		{
		    line = line.replace("${sleepTime}", String.valueOf(thinkTime));
		    writer.write(line);
		    writer.newLine();
		}
		else
		{
		    if (line.contains("${importloginScript}"))
			line = line.replace("${importloginScript}", loginScriptName);
		    else if (line.contains("${loginMethod}"))
			line = line.replace("${loginMethod}", loginScriptName);
		    writer.write(line);
		    writer.newLine();
		}

	    }
	}
	catch (IOException e)
	{
		logger.error(e.getMessage(),e);
	    e.printStackTrace();
	    throw new IOException("can not gengerate grinder.py:" + e.getMessage());
	}
	finally
	{
	    if (reader != null)
		reader.close();
	    if (writer != null)
		writer.close();
	}

    }
}
