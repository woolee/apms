package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface TestBriefDao<T> {
	public boolean addTestBrief(T entity) throws DataAccessException;
	public List<T> getAllTestBrief() throws DataAccessException;
	public T getTestBrief(T entity)throws DataAccessException;
	public T getTestBriefByBriefId(int briefId)throws DataAccessException;
	public List<T> getTestBriefByPlanId(int planId)throws DataAccessException;
	public List<T> getTestBriefByPlanIdStartTimeEndTime(T entity)throws DataAccessException;
	public boolean updateTestBrief(T entity)throws DataAccessException;
	public boolean updateTestBriefStatus(T entity)throws DataAccessException;
	public List<T> getLatestTestBriefByExecutorId(int executorId)throws DataAccessException;
	public int getAllTestBriefCountBySummaryId(String summaryId)throws DataAccessException;
	public T getTestBriefBySystemuuid(String systemuuid);
	public List<T> getTestBriefByProjectName(String projectName);
}
