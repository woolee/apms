package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanScriptDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.PlanScriptMapper;

@Repository
public class PlanScriptDaoImpl<T extends PlanScript> implements PlanScriptDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private PlanScriptMapper mapper;

	@Override
	public boolean addPlanScript(T entity)
	{
		boolean flag = false;
		try
		{
			mapper.addPlanScript(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add PlanScript to database",e);
			throw new DaoException("Exception while add PlanScript to database",e);
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllPlanScript()
	{
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllPlanScript();
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all PlanScript to database",e);
			throw new DaoException("Exception while get all PlanScript to database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getPlanScript(T entity)
	{
		T object = null;
		try{ 
			object =  (T) mapper.getPlanScript(entity);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get PlanScript from database",e);
			throw new DaoException("Exception while get PlanScript from database",e);
		}
		return object;
	}

	@Override
	public T getPlanScriptByPlanId(int PlanId) throws DataAccessException {
		T object = null;
		try{ 
			object =  (T) mapper.getPlanScriptByPlanId(PlanId);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get PlanScript By planID from database",e);
			throw new DaoException("Exception while get PlanScript By planID  from database",e);
		}
		return object;
	}

}
