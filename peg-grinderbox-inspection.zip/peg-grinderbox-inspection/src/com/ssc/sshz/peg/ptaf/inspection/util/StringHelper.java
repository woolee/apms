package com.ssc.sshz.peg.ptaf.inspection.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringHelper {
	private final static StringHelper instance = new StringHelper();
	private StringHelper(){}
	public static StringHelper getInstance(){return instance;}
	
	public Date convertStringToDateTime(String pattern,String dateStr) throws ParseException{
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		return dateFormat.parse(dateStr);
	}
}
