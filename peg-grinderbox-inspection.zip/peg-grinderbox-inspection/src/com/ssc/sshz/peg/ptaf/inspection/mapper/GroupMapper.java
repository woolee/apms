package com.ssc.sshz.peg.ptaf.inspection.mapper;

import com.ssc.sshz.peg.ptaf.inspection.bean.Group;

public interface GroupMapper extends SqlMapper
{
	public void addGroup(Group group);
	
	public Group getGroupByGroupName(String groupName);
	
}
