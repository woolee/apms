package com.ssc.sshz.peg.ptaf.inspection.dao.impl;
import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ItemMapper;

@Repository
public class ItemDaoImpl<T extends Item> implements ItemDao<T>{

	Logger logger = Logger.getLogger(getClass());
	@Inject
	private ItemMapper mapper;

	
	@Override
	public boolean addItem(T entity) throws DataAccessException {
		boolean flag = false;
		try {
			mapper.addItem(entity); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while add item to database",e);
			throw new DaoException("Exception while add item to database",e);
		}
		return flag;
	}


	@SuppressWarnings("unchecked")
	@Override
	public T getItemByName(String name) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getItemByName(name);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get item by name from database",e);
			throw new DaoException("Exception while get item by name from database",e);
		}
		return entity;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllItem() throws DataAccessException {
		List<T> object = null;
		try{
		object =  (List<T>) mapper.getAllItem();
		}
		catch(Exception e)
		{
			logger.error("Exception while get all items from database",e);
			throw new DaoException("Exception while get all items from database",e);
		}
		return object;
		}


	@SuppressWarnings("unchecked")
	@Override
	public T getItemById(int id) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getItemById(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get item by id from database",e);
			throw new DaoException("Exception while get item by id from database",e);
		}
		return entity;
	}


	@SuppressWarnings("unchecked")
	@Override
	public T getItemBySystemIdItemName(T entity)
			throws DataAccessException {
		try{ 
			entity = (T) mapper.getItemBySystemIdItemName(entity);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get item by system id and item name from database",e);
			throw new DaoException("Exception while get item by system id and item name from database",e);
		}
		return entity;
	}


	@Override
	public List<T> getItemBySystemId(int sysId) throws DataAccessException {
		List<T> object = null;
		try{
		object =  (List<T>) mapper.getItemBySystemId(sysId);
		}
		catch(Exception e)
		{
			logger.error("Exception while get all items from database",e);
			throw new DaoException("Exception while get all items from database",e);
		}
		return object;
		}


}
