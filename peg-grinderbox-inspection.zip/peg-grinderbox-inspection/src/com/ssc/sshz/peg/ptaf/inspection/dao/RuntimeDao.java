package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface RuntimeDao<T> {
	public List<T> getAllRuntime() throws DataAccessException;
	public T getRuntime(T entity) throws DataAccessException;
	public T getRuntimeById(Integer id) throws DataAccessException;
	public T getRuntimeByPlanId(Integer planid) throws DataAccessException;
	public boolean addRuntime(T entity) throws DataAccessException;
	public boolean delRuntimeById(Integer id) throws DataAccessException;
	public List<T> getRuntimeByStrategyId(Integer id) throws DataAccessException;
	public boolean  updateRuntime(T entity)throws DataAccessException;
	public T getRuntimeByUUID(String uuid) throws DataAccessException;
}
