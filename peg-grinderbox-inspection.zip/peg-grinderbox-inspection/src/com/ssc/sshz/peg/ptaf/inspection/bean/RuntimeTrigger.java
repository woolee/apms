package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class RuntimeTrigger implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1111965119844468775L;
	private int relationId;
	private int runtimeId;
	private String schedulerInsName;
	private String jobGroupName;
	private String tiggerGroupName;
	private String jobName;
	private String triggerName;
	private Runtime runtime;
	private PlanStrategy planStrategy;
	private Plan plan;
	private System system;
	private Project project;
	private QrtzTriggers trigger;
	public Runtime getRuntime()
	{
		return runtime;
	}
	public void setRuntime(Runtime runtime)
	{
		this.runtime = runtime;
	}
	public PlanStrategy getPlanStrategy()
	{
		return planStrategy;
	}
	public void setPlanStrategy(PlanStrategy planStrategy)
	{
		this.planStrategy = planStrategy;
	}
	public Plan getPlan()
	{
		return plan;
	}
	public void setPlan(Plan plan)
	{
		this.plan = plan;
	}
	public System getSystem()
	{
		return system;
	}
	public void setSystem(System system)
	{
		this.system = system;
	}
	public Project getProject()
	{
		return project;
	}
	public void setProject(Project project)
	{
		this.project = project;
	}
	public QrtzTriggers getTrigger()
	{
		return trigger;
	}
	public void setTrigger(QrtzTriggers trigger)
	{
		this.trigger = trigger;
	}
	public int getRuntimeId()
	{
		return runtimeId;
	}
	public void setRuntimeId(int runtimeId)
	{
		this.runtimeId = runtimeId;
	}
	public String getJobName()
	{
		return jobName;
	}
	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}
	public String getSchedulerInsName()
	{
		return schedulerInsName;
	}
	public void setSchedulerInsName(String schedulerInsName)
	{
		this.schedulerInsName = schedulerInsName;
	}
	public String getTriggerName()
	{
		return triggerName;
	}
	public void setTriggerName(String triggerName)
	{
		this.triggerName = triggerName;
	}
	public int getRelationId()
	{
		return relationId;
	}
	public void setRelationId(int relationId)
	{
		this.relationId = relationId;
	}
	public String getJobGroupName()
	{
		return jobGroupName;
	}
	public void setJobGroupName(String jobGroupName)
	{
		this.jobGroupName = jobGroupName;
	}
	public String getTiggerGroupName()
	{
		return tiggerGroupName;
	}
	public void setTiggerGroupName(String tiggerGroupName)
	{
		this.tiggerGroupName = tiggerGroupName;
	}
	
}
