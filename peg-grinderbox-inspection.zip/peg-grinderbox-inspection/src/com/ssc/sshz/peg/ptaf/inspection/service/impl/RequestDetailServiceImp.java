package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.RequestDetail;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestDetailDao;
import com.ssc.sshz.peg.ptaf.inspection.service.RequestDetaillService;
@Service

public class RequestDetailServiceImp<T extends RequestDetail> implements RequestDetaillService<T>
{
	@Inject
	private RequestDetailDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRequestDetail() throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getAllRequestDetail();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getRequestDetail(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getRequestDetail(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addRequestDetail(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addRequestDetail(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateRequestDetail(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.updateRequestDetail(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRequestDetailByPlanId(int planId)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllRequestDetailByPlanId(planId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRequestDetailByReuqestId(int requestId)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllRequestDetailByRequestId(requestId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRequestDetailByReuqestIdBriefId(T entity)
			throws DataAccessException {
		// TODO Auto-generated method stub
		return dao.getAllRequestDetailByRequestIdBriefId(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Map<Integer, Integer> getRequestCountByReturnCode(List<RequestStatistics> requestStatistList,T entity) throws DataAccessException
	{
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		for (int i = 0; i < requestStatistList.size(); i++) {
			if (requestStatistList.get(i).getErrorCount() > 0) {
				entity.setRequestId(requestStatistList.get(i).getRequestId());
				entity.setBriefId(requestStatistList.get(i).getBriefId());
				
				List<RequestDetail> reqDetailList = (List<RequestDetail>) dao.getAllRequestDetailByRequestIdBriefId(entity);
				for (int j = 0; j < reqDetailList.size(); j++) {
					if (reqDetailList.get(j).getReturnCode() >= 400 && reqDetailList.get(j).getReturnCode() <= 600) {
						if (map.containsKey(reqDetailList.get(j).getReturnCode())) {
							int count = map.get(reqDetailList.get(j).getReturnCode()) + 1;
							map.put(reqDetailList.get(j).getReturnCode(),count);
						} else {
							map.put(reqDetailList.get(j).getReturnCode(), 1);
						}

					}
				}

			}
		}
		return map;
	}

	



	
}
