package com.ssc.sshz.peg.ptaf.inspection.analysis.data.bean;

public class GbAction
{
	public GbAction(int id, String className, String name, String description)
	{
		super();
		this.id = id;
		this.className = className;
		this.name = name;
		this.description = description;
	}
	private int id;
	private String className;
	private String name;
	private String description;
	public GbAction()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getClassName()
	{
		return className;
	}
	public void setClassName(String className)
	{
		this.className = className;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	

}
