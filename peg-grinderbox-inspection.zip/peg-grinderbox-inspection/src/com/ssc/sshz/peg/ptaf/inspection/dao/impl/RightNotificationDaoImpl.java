package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.RightNotification;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightNotificationDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RightNotificationMapper;

@Repository
public class RightNotificationDaoImpl<T extends RightNotification> implements RightNotificationDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RightNotificationMapper mapper;


	@Override
	public boolean addRightNotification(T entity) throws DataAccessException
	{
		boolean flag = false;
		try
		{
			mapper.addRightNotification(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add RightNotification to database",e);
			throw new DaoException("Exception while add RightNotification to database",e);
		}
		return flag;
	}

	
}
