package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.RightProject;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.service.RightProjectService;
@Service
public class RightProjectServiceImp<T extends RightProject> implements RightProjectService<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RightProjectDao<T> dao;
	
	@Inject
	private UserDao<User> userDao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addRightProject(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addRightProject(entity);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRightProject() throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getALLRightProject();
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getRightProjectByUsername(String username) throws DataAccessException
	{
		// TODO Auto-generated method stub
		int userId = userDao.getUserByName(username).getUserId();
		return dao.getRightProjectByUserId(userId);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getRightProjectByRightName(String rightName) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.getRightProjectByRightName(rightName);
	}
}
