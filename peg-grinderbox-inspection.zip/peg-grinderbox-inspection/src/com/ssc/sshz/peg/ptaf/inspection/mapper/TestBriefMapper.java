package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;

public interface TestBriefMapper extends SqlMapper
{
	public void addTestBrief(TestBrief breif);
	
	public TestBrief getTestBrief(TestBrief breif);
	
	public void updateTestBrief(TestBrief breif);
	
	public List<TestBrief> getAllTestBrief();
	
	public List<TestBrief> getTestBriefByPlanId(int planId);
	
	public List<TestBrief> getTestBriefByPlanIdStartTimeEndTime(TestBrief breif);
	
	public void updateTestBriefStatus(TestBrief breif);
	
	public TestBrief getTestBriefBySystemuuid(String systemuuid);
	
	public TestBrief getTestBriefByBriefId(int id);
	
	public List<TestBrief> getLatestTestBriefByExecutorId(int executorId);
	
	public int getAllTestBriefCountBySummaryId(String summaryId);
	
	public TestBrief getTestBriefWioutSummaryId(TestBrief breif);

	public List<TestBrief> getTestBriefByProjectName(String projectName);
}
