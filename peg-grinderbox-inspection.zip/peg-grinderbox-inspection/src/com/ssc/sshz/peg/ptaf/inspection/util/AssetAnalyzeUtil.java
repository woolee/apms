package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;

public class AssetAnalyzeUtil {
	
	private static final Logger logger = Logger.getLogger(AssetAnalyzeUtil.class);
	private static AssetAnalyzeUtil instance = new AssetAnalyzeUtil();
	private String rootPath;
	private AssetAnalyzeUtil(){}
	public static AssetAnalyzeUtil getInstance()
	{
		return instance;
	}
	
	public String getRootPath()
	{
		return rootPath;
	}
	public void setRootPath(String rootPath)
	{
		this.rootPath = rootPath;
	}
	public Document getDocument(String filePath) throws DocumentException{
		File f = new File(filePath);
		if( !f.exists())
			return null;
		SAXReader reader = new SAXReader();    
		Document doc = null;
		try {
			doc = reader.read(f);
		} catch (DocumentException e) {
			logger.error(e.getMessage(),e);
			throw new DocumentException(e.getMessage(), e);
		}
		
		return doc;
	}
	
	public boolean writeDocument(String filePath,Document doc) throws Exception{
		boolean operationStatus = false;
		try {
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setEncoding("UTF-8");
			XMLWriter out = new XMLWriter(new FileOutputStream(filePath),format);
			out.write(doc);
			out.close();
			operationStatus = true;
		} catch (Exception e) {
			operationStatus = false;
			throw new Exception(e.getMessage(),e);
		}
		
		return operationStatus;
	}
	public File getRunTime() throws IOException
	{
		String runTimeFilePath = null;
		try
		{
			File folder = new File(rootPath + "/config");
			File[] files = folder.listFiles(new FileFilter()
			{
				
				@Override
				public boolean accept(File pathname)
				{
					return pathname.getName().endsWith(".ptafproperties");
				}
			});
			if(files ==  null || files.length == 0)
				return null;
			runTimeFilePath = FileUtil.getInstance().getPropValue(files[0], TestAssetContants.PTAF_RUNTIME);
		}
		catch (FileNotFoundException e)
		{
			logger.error(e.getMessage(),e);
			throw new FileNotFoundException(e.getMessage());
		}
		catch (IOException e)
		{
			logger.error(e.getMessage(),e);
			throw new IOException(e.getMessage(),e);
		}
		final String runTimeFile = runTimeFilePath.substring(runTimeFilePath.lastIndexOf("/") + 1);
		String targetFolderPath = rootPath + "/runtime";
		File targetFolderFile = new File(targetFolderPath);
		File[] rtFiles = targetFolderFile.listFiles(new FileFilter()
		{
			
			@Override
			public boolean accept(File pathname)
			{
				if(pathname.getName().equalsIgnoreCase(runTimeFile) )
					return true;
				return false;
			}
		});
		return rtFiles[0];
	}
	
	public List<String> getItems(final String runTimeFile) throws Exception{
		/**
		 * get item names(in grinderbox is the term "Action")
		 * @author a554208
		 */
		List<String> itemList = new ArrayList<String>();
		String targetFolderPath = rootPath + "/runtime";
		try { 
			
				String targetRtPath = targetFolderPath + "/" + runTimeFile;
				Document rtDoc = this.getDocument(targetRtPath);
				Set<String> itemSet = new HashSet<String>();
				List<Element> agentList = rtDoc.selectNodes("/runtime/agents/agent");
				String enable = agentList.get(agentList.size() -1).attributeValue("enabled");
				if(Boolean.parseBoolean(enable))
				{
					String sceName = agentList.get(agentList.size() -1).attributeValue("scenario");
					String scePropName = null;
					File sceFolder = new File(rootPath + "/scenario/");
					File[] files = sceFolder.listFiles(new FilenameFilter() {
						
						@Override
						public boolean accept(File file, String s) {
							// TODO Auto-generated method stub
							return s.endsWith(".sce");
						}
					});
					for (File file : files) {
						Document scedoc = this.getDocument(file.getAbsolutePath());
						List<Element> sceList = scedoc.selectNodes("/tss:Scenario");
						String tempSceName = sceList.get(0).attributeValue("name");
						if(sceName.equals(tempSceName))
						{
							scePropName = file.getName();
							break;
						}
					}
					if(scePropName == null || "".equals(scePropName))
					{
						throw new FileNotFoundException("cannot find scenario named " + sceName);
					}
					String targetScePath = rootPath + "/scenario/" + scePropName ;
					Document doc = this.getDocument(targetScePath);
					List<Element> actionList = doc.selectNodes("/tss:Scenario/Session/Action");
					for(Element ele:actionList){
						itemSet.add(ele.attributeValue("class"));
					}
					Object[] itemObjArray=itemSet.toArray();
					itemSet = null;
					for(Object item:itemObjArray){
						itemList.add(item.toString());
					}
					itemObjArray = null;
				}
	 	} catch (Exception e) {    
	 		logger.error(e.getMessage(),e);
			return null;
		}
		return itemList;
	}
	
	public String getScenarioName(final String runTimeFile) throws Exception{
		/**
		 * get item names(in grinderbox is the term "Action")
		 * @author a554208
		 */
		List<String> itemList = new ArrayList<String>();
		String targetFolderPath = rootPath + "/runtime";
		String sceName = null;
		try { 
			
				String targetRtPath = targetFolderPath + "/" + runTimeFile;
				Document rtDoc = this.getDocument(targetRtPath);
				Set<String> itemSet = new HashSet<String>();
				List<Element> agentList = rtDoc.selectNodes("/runtime/agents/agent");
				String enable = agentList.get(agentList.size() -1).attributeValue("enabled");
				if(Boolean.parseBoolean(enable))
				{
					sceName = agentList.get(agentList.size() -1).attributeValue("scenario");
				}
	 	} catch (Exception e) {    
	 		logger.error(e.getMessage(),e);
			throw new Exception(e.getMessage(),e);
		}
		return sceName;
	}
	
	public boolean isCloudProject(String runtimeFile) throws DocumentException
	{
		String targetFolderPath = rootPath + "/runtime";
		String targetFilePath = targetFolderPath + "/" + runtimeFile;
		Document doc = this.getDocument(targetFilePath);
		Set<String> itemSet = new HashSet<String>();
		List<Element> agentList = doc.selectNodes("/runtime/cloud");
		String enable = agentList.get(0).attributeValue("enabled");
		return Boolean.parseBoolean(enable);
	}
	public List<Request> getAllRequests(String itemName) throws IOException{
		/**
		 * get one specific item's all requests type and URL
		 * @author a554208
		 */
		List<Request> requestsList = new ArrayList<Request>();
		String script = itemName.substring(0, itemName.indexOf("."));
		String targetFilePath = rootPath + "/scripts/" + script + ".py";
		File targetFile = new File(targetFilePath);
		long fileLength = targetFile.length();
		byte[] filecontent = new byte[(int)fileLength];
		FileInputStream in = null;
		try {
			in = new FileInputStream(targetFile);
			in.read(filecontent);
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage(),e);
			throw new FileNotFoundException(e.getMessage());
		} catch (IOException e){
			logger.error(e.getMessage(),e);
			throw new IOException(e.getMessage(), e);
		} finally{
			if(in != null)
				in.close();
		}
		String fileContent = new String(filecontent);
		//this regular expression is:     result = self.request\d*.(GET|POST)\('((.)+)'
		String reg1 = "self\\.(.*)\\s=\\sTest\\(IDFactory.nextRequestID\\(actionID,self.ActionClass\\s\\+\\s'.+','(.*)',(.+)\\),.*\\).wrap\\(.*\\)";
		
//		if(isCloud)
//			reg = "response = self\\.(.*)\\d+.(GET|POST)\\(((.)+)\\)";
//		else
//			reg = "result = self.request\\d*.(GET|POST)\\('((.)+)'";
		Pattern p = Pattern.compile(reg1);  
        Matcher m = p.matcher(fileContent);  
        
        while (m.find()) {  
        	String combineString = null;
        	String orginalURL = null;
        	Request request = new Request();
            //what we want is GET or POST,and the request URL
//        	if(isCloud)
//        		combineString = m.group(2) + "|" + m.group(1);
//        	else
//        		combineString = m.group(1) + "|" + m.group(2);
        	
        	String requestName = m.group(1);
        	String idfNum = m.group(3);
        	String reg2 = requestName + "\\s=\\sHTTPRequest\\(url=(.*), headers=.*\\)";
        	Pattern p2 = Pattern.compile(reg2);  
            Matcher m2 = p2.matcher(fileContent);  
            if(m2.find())
            {
            	String urlStr = m2.group(1);
            	String reg3 = urlStr + "\\s=\\s(.*)";
            	Pattern p3 = Pattern.compile(reg3);  
                Matcher m3 = p3.matcher(fileContent);  
            	if(m3.find())
            	{
            		String urlName = m3.group(1);
            		
            		if(urlName.contains("https://cloud") || urlName.contains("https://tde"))
            		{
            			orginalURL = urlName.substring(1, urlName.length() - 1) ;
            		}
            		else{
            			orginalURL = getURLFromGolbal(urlName);
            		}
            			
            	}
            }
            combineString = m.group(2);
            request.setRequestName(combineString);
            request.setRequestUrl(orginalURL);
            request.setItemName(itemName);
        	requestsList.add(request);
        }  
		
        getFullURLRequest(requestsList);
		return requestsList;
	}
	public List<Request> getFullURLRequest(List<Request> requestsList)
	{
		List<Request> fullURL = requestsList;
		
		return fullURL;
	}
	public String getURLFromGolbal(String name) throws IOException{
		String golbalURLPath = rootPath + "/scripts/common/Global.py";
		String url = null;
		File targetFile = new File(golbalURLPath);
		long fileLength = targetFile.length();
		byte[] filecontent = new byte[(int)fileLength];
		FileInputStream in = null;
		try {
			in = new FileInputStream(targetFile);
			in.read(filecontent);
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage(),e);
			throw new FileNotFoundException(e.getMessage());
		} catch (IOException e){
			logger.error(e.getMessage(),e);
			throw new IOException(e.getMessage(), e);
		} finally{
			if(in != null)
				in.close();
		}
		String fileContent = new String(filecontent);
		String reg = name + "\\s=\\s\"(.*)\"";
		Pattern p = Pattern.compile(reg);
		Matcher m = p.matcher(fileContent);
		if(m.find())
			url = m.group(1);
		return url;
	}
	public boolean delScriptStartTime() throws Exception{
		/**
		 * delete scenario's script start run time
		 * @author a554208
		 */
		boolean operationStatus = false;
		String targetFilePath = rootPath + "/runtime/ReplayRunTime.rt";
		Document doc = this.getDocument(targetFilePath);
		Element timeElement = (Element)doc.selectSingleNode("/runtime/timing");
		timeElement.detach();
		if(this.writeDocument(targetFilePath, doc) == true){
			operationStatus = true;
		}else{
			operationStatus = false;
		}

		return operationStatus;
	}
	
	public boolean setLiveCycles(int cycles, File runtimeFile) throws Exception{
		boolean operationStatus = false;
//		String targetFilePath = rootPath + "/runtime/ReplayRunTime.rt";
		Document doc = this.getDocument(runtimeFile.getAbsolutePath());
		Element runtimeElement = (Element)doc.selectSingleNode("/runtime");
		//timeElement.setAttributeValue("liveCycles", String.valueOf(cycles));
		runtimeElement.addAttribute("liveCycles", String.valueOf(cycles));
		if(this.writeDocument(runtimeFile.getAbsolutePath(), doc) == true){
			operationStatus = true;
		}else{
			operationStatus = false;
		}
		
		return operationStatus;
	}
	
	public boolean setThreadNumber(int threadNumber, File runtimeFile) throws Exception{
		boolean operationStatus = false;
//		String targetFilePath = rootPath + "/runtime/ReplayRunTime.rt";
		Document doc = this.getDocument(runtimeFile.getAbsolutePath());
		Element agentElement = (Element)doc.selectSingleNode("/runtime/agents/agent");
		//timeElement.setAttributeValue("liveCycles", String.valueOf(cycles));
		agentElement.addAttribute("threads", String.valueOf(threadNumber));
		if(this.writeDocument(runtimeFile.getAbsolutePath(), doc) == true){
			operationStatus = true;
		}else{
			operationStatus = false;
		}
		
		return operationStatus;
	}
	
	public boolean setAgentHostName(String agenthostName) throws Exception{
		boolean operationStatus = false;

		//set file "ReplayRunTime.rt"
		String targetFilePath = rootPath + "/runtime/ReplayRunTime.rt";
		Document doc = this.getDocument(targetFilePath);
		Element agentElement = (Element)doc.selectSingleNode("/runtime/agents/agent");
		//timeElement.setAttributeValue("liveCycles", String.valueOf(cycles));
		agentElement.addAttribute("name", agenthostName);
		if(this.writeDocument(targetFilePath, doc) == true){
			operationStatus = true;
		}else{
			operationStatus = false;
			logger.debug("setAgentHostName in " + targetFilePath + "failed!" );
		}
		
		//set file "config/*.ptafproperties"
		String targetFilePath2 = rootPath + "/config";
		File file = new File(targetFilePath2);
		for(String filename : file.list()){
			if(filename.toLowerCase().endsWith(".ptafproperties")){
				targetFilePath2 = rootPath + "/config/" + filename;
				operationStatus = true;
				break;
			}else{
				operationStatus = false;
			}
		}
		Properties prop = new Properties();     
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			fis = new FileInputStream(targetFilePath2);
			prop.load(fis);
			prop.setProperty("grinder.consoleHost", agenthostName);
			//System.out.println(prop);
			fos = new FileOutputStream(targetFilePath2);
			prop.store(fos, "modifed property:grinder.consoleHost to " + agenthostName);
			//prop.list(System.out);
		} catch (FileNotFoundException e) {
			operationStatus = false;
			logger.error(e.getMessage(),e);
			throw new FileNotFoundException(e.getMessage());
		} catch (IOException e) {    
			operationStatus = false;
			logger.error(e.getMessage(),e);
			throw new IOException(e.getMessage(), e);
		}finally{
			if(fis != null)
				fis.close();
			if(fos != null)
				fos.close();
			
		}
		
		return operationStatus;
	}

	public boolean setSessionRatio() throws Exception{
		boolean operationStatus = false;
		String targetFilePath = rootPath + "/scenario/ReplayScenario.sce";
		Document doc = this.getDocument(targetFilePath);
		int sessionCount = doc.selectNodes("/tss:Scenario/Session").size();
		String str=String.valueOf(1.0/sessionCount);
		int strLen = str.length();
		String ratio=str.substring(0, Math.min(strLen, 4));//keep 2 numbers after point
		List<Element> sessionElements = doc.selectNodes("/tss:Scenario/Session");
		for(Element session:sessionElements){
			session.addAttribute("ratio", ratio);
		}
		if(this.writeDocument(targetFilePath, doc) == true){
			operationStatus = true;
		}else{
			operationStatus = false;
		}
		
		return operationStatus;
	}	
	
}
