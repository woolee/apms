package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;


//@Component
@Entity
public class Runtime implements Serializable{
	@Override
	public String toString() {
		return "Runtime [runtimeId=" + runtimeId + ", strategyId=" + strategyId
				+ ", startTime=" + startTime + ", endTime=" + endTime
				+ ", intervalTime=" + intervalTime + ", runType=" + runType
				+ ", runtimeDescription=" + runtimeDescription + "]";
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 6422166607032230744L;
	private Integer runtimeId;
	private Integer strategyId;
	private Timestamp startTime;
	private Timestamp endTime;
	private Integer intervalTime;
	private Integer runType;
	private String runtimeDescription;
	private String runtimeUUID;
	private int repeatCount;
	public Integer getRuntimeId() {
		return runtimeId;
	}
	public void setRuntimeId(Integer runtimeId) {
		this.runtimeId = runtimeId;
	}
	public Integer getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(Integer strategyId) {
		this.strategyId = strategyId;
	}
	public Timestamp getStartTime() {
		return startTime;
	}
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	public Integer getIntervalTime() {
		return intervalTime;
	}
	public void setIntervalTime(Integer intervalTime) {
		this.intervalTime = intervalTime;
	}
	public Integer getRunType() {
		return runType;
	}
	public void setRunType(Integer runType) {
		this.runType = runType;
	}
	public String getRuntimeDescription() {
		return runtimeDescription;
	}
	public void setRuntimeDescription(String runtimeDescription) {
		this.runtimeDescription = runtimeDescription;
	}
	public Timestamp getEndTime() {
		return endTime;
	}
	public void setEndTime(Timestamp endTime) {
		this.endTime = endTime;
	}
	public String getRuntimeUUID()
	{
		return runtimeUUID;
	}
	public void setRuntimeUUID(String runtimeUUID)
	{
		this.runtimeUUID = runtimeUUID;
	}
	public int getRepeatCount()
	{
		return repeatCount;
	}
	public void setRepeatCount(int repeatCount)
	{
		this.repeatCount = repeatCount;
	}
	

	
	

}
