package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.Group;
import com.ssc.sshz.peg.ptaf.inspection.bean.GroupRight;
import com.ssc.sshz.peg.ptaf.inspection.bean.Right;

public interface UserGroupService<T>
{
	public boolean addUserGroup(T entity) throws DataAccessException;

	public void addGroupAndUserGroup(T entity, Group group, Right right, GroupRight groupRight, String username, String projectName)
			throws DataAccessException;
	
	public List<T> getUserGroupByUser(String username)throws DataAccessException;
}
