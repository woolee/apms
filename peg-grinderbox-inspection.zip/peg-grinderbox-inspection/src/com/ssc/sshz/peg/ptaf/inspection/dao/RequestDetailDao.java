package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface RequestDetailDao<T> {
	public boolean addRequestDetail(T entity) throws DataAccessException;
	public List<T> getAllRequestDetail()throws DataAccessException;
	public List<T> getAllRequestDetailByPlanId(int planId)throws DataAccessException;
	public List<T> getAllRequestDetailByRequestId(int requestId)throws DataAccessException;
	public List<T> getAllRequestDetailByRequestIdBriefId(T entity)throws DataAccessException;
	public T getRequestDetail(T entity)throws DataAccessException;
	public boolean updateRequestDetail(T entity)throws DataAccessException;
}
