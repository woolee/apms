package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeTriggerDao;
import com.ssc.sshz.peg.ptaf.inspection.service.RuntimeTriggerService;

@Service
public class RuntimeTriggerServiceImp<T extends RuntimeTrigger> implements RuntimeTriggerService<T> {
	
	@Inject
	private RuntimeTriggerDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRuntimeTrigger() throws DataAccessException
	{
		return dao.getAllRuntimeTrigger();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getRuntimeTriggerByRuntimeId(int runtimeId) throws DataAccessException
	{
		return dao.getRuntimeTriggerByRuntimeId(runtimeId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addRuntimeTrigger(T entity) throws DataAccessException
	{
		return dao.addRuntimeTrigger(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean delRuntimeTriggerByRuntimeId(int runtimeId) throws DataAccessException
	{
		return dao.delRuntimeTriggerByRuntimeId(runtimeId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateRuntimeTrigger(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.updateRuntimeTrigger(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getJobStateByUser(String username) throws DataAccessException
	{
		return dao.getJobStateByUser(username);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getJobStateByProjects(List<Project> projectList) throws DataAccessException
	{
		List<T> list = new ArrayList<T>();
		for (Project project : projectList)
		{
			list.addAll(dao.getJobStateByProjectName(project.getProjectName()));
		}
		return list;
	}
	
}
