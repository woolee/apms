package com.ssc.sshz.peg.ptaf.inspection.controller;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssc.sshz.peg.ptaf.inspection.analysis.LogAnalysisThread;
import com.ssc.sshz.peg.ptaf.inspection.analysis.QTMLogAnalysisThread;
import com.ssc.sshz.peg.ptaf.inspection.bean.QTMLogScan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Report;
import com.ssc.sshz.peg.ptaf.inspection.constants.AutoAnalysisStatus;
import com.ssc.sshz.peg.ptaf.inspection.service.QTMLogScanService;
import com.ssc.sshz.peg.ptaf.inspection.service.ReportService;
import com.ssc.sshz.peg.ptaf.inspection.util.StringHelper;

@Controller
@RequestMapping("/analyze")
public class LogAnalyzerController {

	@Inject
	ReportService<Report> reportService;

	@Inject
	QTMLogScanService<QTMLogScan> qtmLogScanService;
	
	@RequestMapping("/cloudLoganalyze")
	public String cloudLoganalyze(Model model, HttpSession session,
			HttpServletRequest httpServletRequest, Report report)
			throws ParseException {
		String date_from = httpServletRequest.getParameter("datefrom");
		String date_to = httpServletRequest.getParameter("dateto");
		String ProjectName = httpServletRequest.getParameter("ProjectName");
		String Foregroundappcode = httpServletRequest
				.getParameter("Foregroundappcode");
		String Backgroundappcode = httpServletRequest
				.getParameter("Backgroundappcode");
		String ForegroundContext = httpServletRequest
				.getParameter("ForegroundContext");
		String BackgroundContext = httpServletRequest
				.getParameter("BackgroundContext");
		String ForegroundEnv = httpServletRequest.getParameter("ForegroundEnv");
		String BackgroundEnv = httpServletRequest.getParameter("BackgroundEnv");
		String username = httpServletRequest.getParameter("Username");
		String password = httpServletRequest.getParameter("Password");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date startTime = null;
		Date endTime = null;
		try {
			startTime = sdf.parse(date_from);
			endTime = sdf.parse(date_to);
		} catch (ParseException e2) {
			e2.printStackTrace();
		}

		report.setStartTime(startTime);
		report.setEndTime(endTime);
		report.setProjectName(ProjectName);
		report.setFgSystemName(Foregroundappcode);
		report.setFgContext(ForegroundContext);
		report.setFgEnv(ForegroundEnv);
		report.setBgSystemName(Backgroundappcode);
		report.setBgContext(BackgroundContext);
		report.setBgEnv(BackgroundEnv);
		report.setAnalysisStatus(AutoAnalysisStatus.PREPARE);
		String htmlname = "des/chart_" + System.currentTimeMillis() + ".html";
		report.setReportName(htmlname);
		report.setReportUUID(UUID.randomUUID().toString());
		reportService.addReport(report);
		String htmlPath = session.getServletContext().getRealPath("/")
				+ htmlname;

		// add

		String[] args = { "${ProjectName}", ProjectName, "${ExecutorName}",
				username, "${TestStartTime}", sdf.format(startTime),
				"${TestEndTime}", sdf.format(endTime) };
		new LogAnalysisThread().doAutoAnalysis(args, htmlPath, report,
				username, password, false, true, reportService);
		return "/view/logAnanlysis.jsp";
	}

	@RequestMapping("/downloadAndCheck")
	public String downloadAndCheck(Model model,HttpServletRequest request,HttpSession session,QTMLogScan scan) throws ParseException {
		String date_from = request.getParameter("datefrom");
		String date_to = request.getParameter("dateto");
		String ProjectName = request.getParameter("ProjectName");
		String Foregroundappcode = request
				.getParameter("Foregroundappcode");
		String Backgroundappcode = request
				.getParameter("Backgroundappcode");
		String ForegroundContext = request
				.getParameter("ForegroundContext");
		String BackgroundContext = request
				.getParameter("BackgroundContext");
		String ForegroundEnv = request.getParameter("ForegroundEnv");
		String BackgroundEnv = request.getParameter("BackgroundEnv");
		String username = request.getParameter("Username");
		String password = request.getParameter("Password");
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date startTime = StringHelper.getInstance().convertStringToDateTime("yyyy-MM-dd HH:mm:ss", date_from);
		Date endTime = StringHelper.getInstance().convertStringToDateTime("yyyy-MM-dd HH:mm:ss",date_to);
//		Date startTime = sdf.parse(date_from);
//		Date endTime = sdf.parse(date_to);
		String realPath = session.getServletContext().getRealPath("/");
		
		scan.setStartTime(startTime);
		scan.setEndTime(endTime);
		scan.setProjectName(ProjectName);
		scan.setFgSystemName(Foregroundappcode);
		scan.setFgContext(ForegroundContext);
		scan.setFgEnv(ForegroundEnv);
		scan.setBgSystemName(Backgroundappcode);
		scan.setBgContext(BackgroundContext);
		scan.setBgEnv(BackgroundEnv);
		/*new QTMLogAnalysisThread().doAutoAnalysis( report,
				username, password, false, true,errorInfo);*/
		
		qtmLogScanService.addQTMLogScan(scan);
		AtomicBoolean finishScaned = new AtomicBoolean(false);
		QTMLogAnalysisThread scanRun = new QTMLogAnalysisThread(scan,username, password, false, false,finishScaned,qtmLogScanService);
		Thread thread = new Thread(scanRun);
		thread.start();
		
		List<QTMLogScan> scanList = qtmLogScanService.getAllQTMLogScan();
		model.addAttribute("scanList", scanList);
		return "../view/qtmLogAnalysis.jsp";
	}
	
	@RequestMapping("/getAllReport")
	public String getAllReport(Model model) {
		List<Report> temp = reportService.getAllReportState();
		model.addAttribute("reportList", temp);
		return "/view/showReport.jsp";
	}

	@RequestMapping("/ReportPageInint")
	public String ReportPageInint(Model model) {
		List<Report> temp = reportService.getAllReportState();
		model.addAttribute("reportList", temp);
		return "/view/showReport.jsp";
	}

	@RequestMapping("/paging")
	public String paging(HttpServletRequest request, Model model) {
		String pageNumberStr = request.getParameter("pageNumber");
		int pageNumber = 1;
		if (pageNumberStr != null && !pageNumberStr.isEmpty()) {
			pageNumber = Integer.parseInt(pageNumberStr);
		}
		int pageSize = 5;
		int totalPosts = reportService.getAllReportState().size();
		int totalPages = totalPosts / pageSize
				+ ((totalPosts % pageSize) > 0 ? 1 : 0);
		Map<String, Integer> pageparm = new HashMap<String, Integer>();
		pageparm.put("pageNumber", (pageNumber - 1) * pageSize);
		pageparm.put("pageSize", pageSize);
		List<Report> reportPagingList = reportService.getPagingReprot(pageparm);
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("totalPosts", totalPosts);
		model.addAttribute("pageNumber", pageNumber);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("reportList", reportPagingList);
		return "/view/showReport.jsp";
	}

	@RequestMapping("/scanPaging")
	public String scanPaging(HttpServletRequest request, Model model) {
		String pageNumberStr = request.getParameter("pageNumber");
		int pageNumber = 1;
		if (pageNumberStr != null && !pageNumberStr.isEmpty()) {
			pageNumber = Integer.parseInt(pageNumberStr);
		}
		int pageSize = 5;
		int totalPosts = reportService.getAllReportState().size();
		int totalPages = totalPosts / pageSize
				+ ((totalPosts % pageSize) > 0 ? 1 : 0);
		Map<String, Integer> pageparm = new HashMap<String, Integer>();
		pageparm.put("pageNumber", (pageNumber - 1) * pageSize);
		pageparm.put("pageSize", pageSize);
		List<QTMLogScan> scanList = qtmLogScanService.getAllQTMLogScan();
		model.addAttribute("pageSize", pageSize);
		model.addAttribute("totalPosts", totalPosts);
		model.addAttribute("pageNumber", pageNumber);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("scanList", scanList);
		return "/view/showLogScan.jsp";
	}
	
	@RequestMapping(value = "/getProgress", method = RequestMethod.GET)
	@ResponseBody
	public String getProgress(Model model) {
		List<Report> DownloadPercentList = reportService
				.getDownloadPercentList();
		String DealString ="";
		for (int i = 0; i < DownloadPercentList.size(); i++) {
			if (i == DownloadPercentList.size() - 1) {
				DealString = DealString
						+ DownloadPercentList.get(i).getExecutePercentage();

			} else {
				DealString = DealString
						+ DownloadPercentList.get(i).getExecutePercentage()
						+ "#";
			}
		}
		java.lang.System.out.println("DealString:"+DealString);
		return DealString;
	}
	
	@RequestMapping(value = "/getScanProgress", method = RequestMethod.GET)
	@ResponseBody
	public String getScanProgress(Model model) {
		List<QTMLogScan> DownloadPercentList = qtmLogScanService.getAllQTMLogScan();
				
		String DealString ="";
		for (int i = 0; i < DownloadPercentList.size(); i++) {
			if (i == DownloadPercentList.size() - 1) {
				DealString = DealString
						+ DownloadPercentList.get(i).getExecutePercentage();

			} else {
				DealString = DealString
						+ DownloadPercentList.get(i).getExecutePercentage()
						+ "#";
			}
		}
		return DealString;
	}
	
	@RequestMapping("/export")
	public void exportScanError(HttpServletResponse response,HttpServletRequest request) throws IOException{
		int scanId = Integer.parseInt(request.getParameter("scanId"));
		
		byte[] errorByte = qtmLogScanService.getQTMLogScanById(scanId).getErrorFile();
		response.setContentType("application/zip");
	    response.setHeader("Content-Disposition", "attachment; filename=\"error.zip\"");
	    response.setCharacterEncoding("UTF-8");
	    OutputStream out = null;
		try {
			out = response.getOutputStream();
			out.write(errorByte);
		} catch (IOException e) {
			throw e;
		}
		finally{
			if(out != null){
				out.flush();
				out.close();
		}
	    }
	}
	@RequestMapping(value = "/getProgressByuuid", method = RequestMethod.GET)
	@ResponseBody
	public String getProgressByuuid(HttpServletRequest httpServletRequest,Model model) {
		String uuid=httpServletRequest.getParameter("reportUUID");
		Report report = reportService.getReportByUUID(uuid);
		return report.getExecutePercentage()+"";
	}

	@RequestMapping("/deleteReport")
	public String deleteReport(HttpServletRequest httpServletRequest,
			HttpSession session) {
		String reportUUID = httpServletRequest.getParameter("reportUUID");
		String htmlName = httpServletRequest.getParameter("htmlName");
		String htmlPath = session.getServletContext().getRealPath("/")
				+ htmlName;
		if (reportService.deleteReportByUUID(reportUUID)) {
			File htmlFile = new File(htmlPath);
			if (htmlFile.exists())
				htmlFile.delete();
		}
		return "/view/logAnanlysis.jsp";
	}
}
