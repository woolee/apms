package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.UserRight;

public interface UserRightMapper extends SqlMapper {
	public void addUserRight(UserRight userRight);
	public List<UserRight> getUserRightByUser(int userId);
}
