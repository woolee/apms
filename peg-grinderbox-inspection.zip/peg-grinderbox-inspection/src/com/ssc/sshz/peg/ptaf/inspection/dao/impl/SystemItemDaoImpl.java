package com.ssc.sshz.peg.ptaf.inspection.dao.impl;
import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.SystemItem;
import com.ssc.sshz.peg.ptaf.inspection.dao.SystemItemDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.SystemItemMapper;

@Repository
public class SystemItemDaoImpl<T extends SystemItem> implements SystemItemDao<T>{
	 private static final Logger logger = Logger.getLogger(SystemItemDaoImpl.class);
	@Inject
	private SystemItemMapper mapper;

	@Override
	public boolean addSystemItem(T entity) throws DataAccessException {
		boolean flag = false;
		try {
			mapper.addSystemItem(entity); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while add SystemItem to database",e);
			throw new DaoException("Exception while add SystemItem to database",e);
		}
		return flag;
	}
}
