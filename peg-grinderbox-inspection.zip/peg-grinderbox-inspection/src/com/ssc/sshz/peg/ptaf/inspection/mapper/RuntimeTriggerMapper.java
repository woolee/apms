package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;

public interface RuntimeTriggerMapper extends SqlMapper{
	public List<RuntimeTrigger> getAllRuntimeTrigger(); 
	public void addRuntimeTrigger(RuntimeTrigger runtimeTrigger);
	public RuntimeTrigger getRuntimeTriggerByRuntimeId(int runtimeId);
	public void delRuntimeTriggerByRuntimeId(int runtimeId);
	public void delRuntimeTriggerByJobName(String jobName);
	public void delRuntimeTriggerByTriggerName(String triggerName);
	public void updateRuntimeTrigger(RuntimeTrigger runtimeTrigger);
	public List<RuntimeTrigger> getJobStateByUser(String username);
	public List<RuntimeTrigger> getJobStateByProjectName(String projectName);
}
