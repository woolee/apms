package com.ssc.sshz.peg.ptaf.inspection.dao;
import org.springframework.dao.DataAccessException;
public interface SystemItemDao<T> {
	public boolean addSystemItem(T entity) throws DataAccessException;
}
