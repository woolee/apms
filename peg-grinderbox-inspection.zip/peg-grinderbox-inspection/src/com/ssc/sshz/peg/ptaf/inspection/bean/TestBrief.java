package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;

@Entity
public class TestBrief implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6366276267753535719L;
	private int briefId;
	private int planId;
	private String planName;
	private Date startTime;
	private Date endTime;
	private boolean isAutomated;
	private int executorId;
	private String executorName;
	private String status;
	private boolean isPassed;
	private boolean hasError;
//	private String errorInformation;
	private String resultFolderPath;
	private String summaryId;
	public String getSummaryId() {
		return summaryId;
	}
	public void setSummaryId(String summaryId) {
		this.summaryId = summaryId;
	}
	public int getBriefId()
	{
		return briefId;
	}
	public void setBriefId(int briefId)
	{
		this.briefId = briefId;
	}
	public int getPlanId()
	{
		return planId;
	}
	public void setPlanId(int planId)
	{
		this.planId = planId;
	}
	public String getPlanName()
	{
		return planName;
	}
	public void setPlanName(String planName)
	{
		this.planName = planName;
	}
	public Date getStartTime()
	{
		return startTime;
	}
	public void setStartTime(Date startTime)
	{
		this.startTime = startTime;
	}
	public Date getEndTime()
	{
		return endTime;
	}
	public void setEndTime(Date endTime)
	{
		this.endTime = endTime;
	}
	public boolean isAutomated()
	{
		return isAutomated;
	}
	public void setAutomated(boolean isAutomated)
	{
		this.isAutomated = isAutomated;
	}
	public int getExecutorId()
	{
		return executorId;
	}
	public void setExecutorId(int executorId)
	{
		this.executorId = executorId;
	}
	public String getExecutorName()
	{
		return executorName;
	}
	public void setExecutorName(String executorName)
	{
		this.executorName = executorName;
	}
	public String getStatus()
	{
		return status;
	}
	public void setStatus(String status)
	{
		this.status = status;
	}
	public boolean isPassed()
	{
		return isPassed;
	}
	public void setPassed(boolean isPassed)
	{
		this.isPassed = isPassed;
	}
	public boolean isHasError()
	{
		return hasError;
	}
	public void setHasError(boolean hasError)
	{
		this.hasError = hasError;
	}
//	public String getErrorInformation()
//	{
//		return errorInformation;
//	}
//	public void setErrorInformation(String errorInformation)
//	{
//		this.errorInformation = errorInformation;
//	}
	public String getResultFolderPath()
	{
		return resultFolderPath;
	}
	public void setResultFolderPath(String resultFolderPath)
	{
		this.resultFolderPath = resultFolderPath;
	}
	@Override
	public String toString() {
		return "TestBrief [briefId=" + briefId + ", planId=" + planId
				+ ", planName=" + planName + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", isAutomated=" + isAutomated
				+ ", executorId=" + executorId + ", executorName="
				+ executorName + ", status=" + status + ", isPassed="
				+ isPassed + ", hasError=" + hasError 
				+ ", resultFolderPath=" + resultFolderPath
				+ ", summaryId=" + summaryId + "]";
	}
	

	
}
