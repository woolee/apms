package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestDao;
import com.ssc.sshz.peg.ptaf.inspection.service.ImportAssetService;
import com.ssc.sshz.peg.ptaf.inspection.util.AssetAnalyzeUtil;

@Service
public class ImportAssetServiceImp implements ImportAssetService
{
	@Inject
	private ItemDao<Item> itemDao;
	@Inject
	private RequestDao<Request> requestDao;
	

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<Item> getItemList(String folderPath, Item item, System system) throws Exception
	{
		List<Item> itemList = new ArrayList<Item>();
		AssetAnalyzeUtil.getInstance().setRootPath("C:/result/gb/GCtest");
		File runTime = AssetAnalyzeUtil.getInstance().getRunTime();
		List<String> itemNameList = AssetAnalyzeUtil.getInstance().getItems(runTime.getName());
		for (String itemName : itemNameList)
		{
			item.setItemName(itemName);
			item.setSystemId(system.getSystemId());
			itemDao.addItem(item);
			item = itemDao.getItemByName(itemName);
			itemList.add(item);
		}
		return itemList;
		
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public Map<Integer, List<Request>> getRequestMap(String folderPath, List<Item> itemList, Request request) throws DataAccessException, IOException
	{
		AssetAnalyzeUtil.getInstance().setRootPath("C:/result/gb/GCtest");
		Map<Integer, List<Request>> requestMapByItemId = new HashMap<Integer, List<Request>>();
		for (Item item : itemList)
			{
				List<Request> requestList = AssetAnalyzeUtil.getInstance().getAllRequests(item.getItemName());
				for (Request tempRequest : requestList)
				{
					tempRequest.setItemId(item.getItemId());
					requestDao.addRequest(tempRequest);
					request = requestDao.getRequestByRequestName(tempRequest.getRequestName());
					requestList.add(request);
				}
				requestMapByItemId.put(item.getItemId(), requestList);
			}
		return requestMapByItemId;
	}

}
