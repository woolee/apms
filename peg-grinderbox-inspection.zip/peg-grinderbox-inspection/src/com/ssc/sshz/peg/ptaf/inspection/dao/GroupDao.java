package com.ssc.sshz.peg.ptaf.inspection.dao;

import org.springframework.dao.DataAccessException;



public interface GroupDao<T> {
	public boolean addGroup(T entity) throws DataAccessException;

	public T getGroupByGroupName(String groupName) throws DataAccessException;
}
