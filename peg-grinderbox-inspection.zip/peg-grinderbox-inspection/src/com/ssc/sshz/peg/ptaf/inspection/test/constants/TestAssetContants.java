package com.ssc.sshz.peg.ptaf.inspection.test.constants;

public final class TestAssetContants
{
	public static final String SCRIPTFOLDER = "script";
	public static final String PARAMFOLDER = "param";
	
	public static final String VUCSV = "user.csv";
	public static final String GRINDER_PROPERTIES = "grinder.properties";
	public static final String SCRIPT = "grinder.py";
	public static final String INITSCRIPT = "__init__.py";
	public static final String CLDLOGINSCRIPT = "CloudLogin.py";
	public static final String LOCALLOGINSCRIPT = "LocalLogin.py";
	public static final String AUTH_CHECKER = "AuthChecker.py";

	public static final String GRINDER_THREADS = "grinder.threads";
	public static final String GRINDER_LOGDIRECTORY = "grinder.logDirectory";
	public static final String GRINDER_PROCESS = "grinder.process";
	public static final String GRINDER_RUNS = "grinder.runs";
	public static final String GRINDER_USECONSOLE = "grinder.useConsole";
	public static final String GRINDER_NUMBEROFOLDLOGS = "grinder.numberOfOldLogs";
	public static final String GRINDER_SLPTIMEVARIATION = "grinder.sleepTimeVariation";
	public static final String GRINDER_SLPTIMEFACTOR = "grinder.sleepTimeFactor";
	public static final String GRINDER_SCRIPT = "grinder.script";
	public static final String GRINDER_CONSOLEHOST = "grinder.consoleHost";
	public static final String PTAF_RUNTIME = "ptaf.runtime";
	
	public static final int PROCESSNUM = 1;
	public static final int RUNSNUM = 1;
	public static final int NUMBEROFOLDLOGS = 0;
	public static final double SLPTIMEVARIATIONNUM = 0.2; 
	public static final int SLPTIMEFACTORNUM = 1;
	public static final boolean USECONSOLE = false;
	
	public static final String GRINDER_PROPERTY_TMP = "support/tml_grinder.properties";
	public static final String GRINDER_SCRIPT_TMP = "support/grinder.py.tpl";
	public static final String IDF_SCRIPT_TMP = "support/IDF.py.tpl";
	public static final String AUTH_CHECKER_TMP = "support/AuthChecker.py.tpl";
	public static final String CLOUD_LOGIN_SCRIPT_TMP = "support/CloudLogin.py.tpl";
	public static final String LOCAL_LOGIN_SCRIPT_TMP = "support/LocalLogin.py.tpl";
	public static final String EMPTY_LOGIN_SCRIPT_TMP = "support/EmptyLogin.py.tpl";
	
	public static final String CSVEXTIONSION = "CSV";
}
