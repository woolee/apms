package com.ssc.sshz.peg.ptaf.inspection.service;


import java.util.List;

import org.springframework.dao.DataAccessException;

public interface PlanStrategyService<T>{

	public boolean addPlanStrategy(T entity) throws DataAccessException;
	public List<T> getAllPlanStrategy() throws DataAccessException;
	public T getPlanStrategyByName(String name) throws DataAccessException;
	public List<T> getPlanStrategyByPlanId(int planId) throws DataAccessException;
	public T getPlanStrategyById(int id) throws DataAccessException;
	
}
