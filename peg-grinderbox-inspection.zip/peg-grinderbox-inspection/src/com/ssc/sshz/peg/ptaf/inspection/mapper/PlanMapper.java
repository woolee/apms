package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;

public interface PlanMapper extends SqlMapper{
	public List<Plan> getAllPlan(); 
	public Plan getPlanById(Integer id);
	public Plan getPlanByName(String name);
	public Plan getPlanBySystemIdPlanName(Plan plan);
	public List<Plan> getPlanBySystemId(int systemId);
	public void addPlan(Plan plan);
//	public void editPlan(Plan plan);
	public void delPlanById(Integer id);
	public void delPlanByName(String name);
}
