package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.ResultSearchBean;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.ProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.SystemDao;
import com.ssc.sshz.peg.ptaf.inspection.service.ResultSearchService;

@Service
public class ResultSearchServiceImp implements ResultSearchService
{
	@Inject
	private ProjectDao<Project> projectDao;
	
	@Inject
	private SystemDao<System> systemDao;
	
	@Inject
	private PlanDao<Plan> planDao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<ResultSearchBean> getResultSearchByProject(List<Project> projectList, Plan plan) throws DataAccessException
	{
//		List<Project> projectList = projectDao.getAllProjectByUsername(username);
		List<ResultSearchBean> tbSearchList = new ArrayList<ResultSearchBean>();
		for (int i = 0; i < projectList.size(); i++) {
			ResultSearchBean tbSearch = new ResultSearchBean();
			Map<String, List<Plan>> planMap = new HashMap<String, List<Plan>>();
			List<System> systemList = systemDao.getSystemByProjectName(projectList.get(i).getProjectName());
			for (System system : systemList) {
				plan.setSystemId(system.getSystemId());
				List<Plan> PlanList = planDao.getPlanBySystemId(plan.getSystemId());
				planMap.put(system.getSystemId() + "", PlanList);
			}
			tbSearch.setPlan(planMap);
			tbSearch.setProjectName(projectList.get(i).getProjectName());
			tbSearch.setSystem(systemList);
			tbSearchList.add(tbSearch);
		}
		return tbSearchList;
	}
	
}
