package com.ssc.sshz.peg.ptaf.inspection.dao;
import java.util.List;

import org.springframework.dao.DataAccessException;
public interface PlanItemDao<T> {
	public boolean addPlanItem(T entity) throws DataAccessException;
	public boolean updatePlanItem(T entity)throws DataAccessException;
	public boolean deletePlanItemByPlanId(int planId)throws DataAccessException;
	public T getPlanItemByItemId(Integer id) throws DataAccessException;
	public List<T> getAllPlanItem() throws DataAccessException;
	public List<T> getAllPlanItemByPlanId(int planId) throws DataAccessException;
	public List<T> getvalidPlanItemByPlanId(int planId) throws DataAccessException;
}
