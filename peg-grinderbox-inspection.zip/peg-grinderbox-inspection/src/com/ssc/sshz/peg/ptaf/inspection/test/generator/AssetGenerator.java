package com.ssc.sshz.peg.ptaf.inspection.test.generator;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;
import com.ssc.sshz.peg.ptaf.inspection.test.exception.AssetGenerateException;
import com.ssc.sshz.peg.ptaf.inspection.test.exception.InputParamException;
import com.ssc.sshz.peg.ptaf.inspection.test.generator.bean.LoginScriptParamBean;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.FileParser;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Idf;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Inputs;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;

public class AssetGenerator
{
	private static final Logger logger = Logger.getLogger(AssetGenerator.class);
    private File outputFolder;
    private File assetFolder;
    
    
    /**
     * 
     * @param outputFolder the output folder for one test
     * @param assetFolder the asset folder for one test
     */
    public AssetGenerator(File outputFolder, File assetFolder)
    {
	this.assetFolder = assetFolder;
	this.outputFolder = outputFolder;
    }
    
    
    /**
     * filter the parameter files whose name matched the IDF number,
     * @param paramFolder the root folder of parameter files
     * @param idfs the IDF map
     * @return the matched parameter file set
     * @throws IOException IO exception occur when read parameter file header 
     * @throws InputParamException when the header of parameter file can not match the input of IDF
     */
    public Set<File> checkIDFmatchParams(File paramFolder, Map<String, Idf> idfs) throws IOException, InputParamException
    {
	Set<String> idfNums = idfs.keySet();
	
	Set<File> matchedFiles = new HashSet<File>();
	
	File[] checkedFiles = paramFolder.listFiles(new FileFilter()
	{
	    //parameter files are csv file
	    @Override
	    public boolean accept(File pathname)
	    {
		return pathname.getName().endsWith("CSV") || pathname.getName().endsWith("csv");
	    }
	});


	if(checkedFiles != null)
	{
	    for (File file : checkedFiles)
	    {
		String fileNameNoSuffix = FileUtil.getInstance().cutSuffix(file);
		//file name match the IDF number 
		if (idfNums.contains(fileNameNoSuffix))
		{
		    String header;
		    try
		    {
			header = FileUtil.getInstance().readHeader(file);
		    }
		    catch (Exception e)
		    {
		    	logger.error(e.getMessage(),e);
			e.printStackTrace();
			throw new IOException("an error occured when read header of  parameter file: " + file.getName());
		    }
		    if(!matchedInput(header, idfs.get(fileNameNoSuffix).getInputList()))
			throw new InputParamException("parameter file " + file.getName() + " is not matched the parameters of IDF " + fileNameNoSuffix);
		    matchedFiles.add(file);
		}
	    }
	}
	
	return matchedFiles;
    }
    
    
    private boolean matchedInput(String header, List<Inputs> inputs)
    {
	List<String> inputStrs = new ArrayList<String>();
	for (Inputs input : inputs)
	{
	    inputStrs.add(input.getInputName());
	}
	String[] headerInputs = header.split(",");
	if(headerInputs == null)
	    return inputStrs == null || inputStrs.size() == 0;
	return headerInputs.length == inputs.size() && inputStrs.containsAll(Arrays.asList(headerInputs));
    }
    
    /**
     * generate asset,
     * the process include:
     * generate parameters, generate test scripts for each IDF, generate __init_.py(a module description file in python)
     * generate login script, generate grinder.py script, generate grinder.properties
     * 
     * @param paramFileList the matched parameter files, always get from {@link #matchedInput(String, List)}
     * @param idfs IDF map parsed from IDF.xml
     * @param url the test URL without context
     * @param context the context of test URL
     * @param thinkTime duration between every call in a same thread
     * @param runCount total run times for each thread each IDF service
     * @param threadNum number of test thread
     * @param loginBean contains the login information used in login
     * @return the properties file 
     * @throws AssetGenerateException
     */
    public File generateAsset(Set<File> paramFileList, Map<String, Idf> idfs, String url, String context, long thinkTime, int runCount, int threadNum, LoginScriptParamBean loginBean) throws AssetGenerateException 
    {
	File propFile = null;
	try
	{
	    //param
	    ParmFileGenerator parmGenerator = new ParmFileGenerator();
	    Set<File> paramFiles = parmGenerator.generateParamFile(paramFileList, assetFolder);
	    
	    //IDFS
	    IDFScriptGenerator idfGenerator = new IDFScriptGenerator();
	    File scriptDest = new File(assetFolder, TestAssetContants.SCRIPTFOLDER);
	    Set<File> idfFiles = idfGenerator.generateIDFScript(idfs, url, context, paramFiles, scriptDest);
	    
	    Set<String> idfFileNames = new TreeSet<String>(); 
	    for (File file : idfFiles)
	    {
		idfFileNames.add(FileUtil.getInstance().cutSuffix(file));
	    }
	    
	    File scriptFolder = new File(assetFolder,TestAssetContants.SCRIPT);
	    
	    //__init__
	    ModuleInfoGenerator moduleInfo = new ModuleInfoGenerator();
	    moduleInfo.gnerateModuleInfo(new File(scriptDest, TestAssetContants.INITSCRIPT), idfFileNames);
	    
	    //user
	    VUFileGenerator uv = new VUFileGenerator();
	    uv.generateParamFile(loginBean.getUserFile(), assetFolder);
	    
	    //login
	    LoginScriptGenerator loginGenerator = new LoginScriptGenerator(assetFolder);
	    File loginScript = loginGenerator.generateLoginScript(loginBean);
	    
	    //grinder
	    GrinderScriptGenerator grinderGenerator = new GrinderScriptGenerator();
	    grinderGenerator.generateGrinderScript(scriptFolder, FileUtil.getInstance().cutSuffix(loginScript), thinkTime, runCount, idfFileNames);
	    
	    
	    //prop
	    propFile = new File(assetFolder,"grinder.properties");
	    GrinderPropGenerator propGenerator = new GrinderPropGenerator();
	    propGenerator.generateProperties(propFile, threadNum, outputFolder.getAbsolutePath());
	    
	}
	catch (IOException e)
	{
		logger.error(e.getMessage(),e);
	    e.printStackTrace();
	    throw new AssetGenerateException("an exception occured when generating asset with the message as: " + e.getMessage());
	}
	return propFile;
	
	
    }

}
