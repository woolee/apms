package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class RightNotification implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4477399466352362945L;
	private int rightNotificationId;
	private int userId;
	private String username;
	private String rightAdd;
	private String rightDelete;
	private String description;
	private boolean isApproved;
	public int getRightNotificationId()
	{
		return rightNotificationId;
	}
	public void setRightNotificationId(int rightNotificationId)
	{
		this.rightNotificationId = rightNotificationId;
	}
	public int getUserId()
	{
		return userId;
	}
	public void setUserId(int userId)
	{
		this.userId = userId;
	}
	public String getUsername()
	{
		return username;
	}
	public void setUsername(String username)
	{
		this.username = username;
	}
	public String getRightAdd()
	{
		return rightAdd;
	}
	public void setRightAdd(String rightAdd)
	{
		this.rightAdd = rightAdd;
	}
	public String getRightDelete()
	{
		return rightDelete;
	}
	public void setRightDelete(String rightDelete)
	{
		this.rightDelete = rightDelete;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	public boolean isApproved()
	{
		return isApproved;
	}
	public void setApproved(boolean isApproved)
	{
		this.isApproved = isApproved;
	}
	
}
