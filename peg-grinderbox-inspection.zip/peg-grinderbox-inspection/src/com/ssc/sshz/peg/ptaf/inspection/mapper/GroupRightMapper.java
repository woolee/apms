package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.GroupRight;

public interface GroupRightMapper extends SqlMapper
{
	public void addGroupRight(GroupRight groupRight);
	public List<GroupRight> getAllGroupRight();
	public List<GroupRight> getGroupRightByGroupName(String groupName);
}
