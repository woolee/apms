package com.ssc.sshz.peg.ptaf.inspection.constants;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class FilePathConstants
{
	private static final Logger logger = Logger.getLogger(FilePathConstants.class);
	public static final String ASSETTMEPPATH = getProperty("ci_asset_path");
	public static final String CIOUTPUTTEMPPATH = getProperty("ci_output_path");
	public static final String RESULT_UPLOAD_URL = getProperty("ci_result_upload_url");
	public static final String UPLOADPROCESSID = getProperty("ci_upload_process_id");
	public static final String UPLOADSERVER = getProperty("ci_upload_server");
	public static final String REQUEST_ID = getProperty("ci_idf_num");
	public static final String CIDEBU = getProperty("ci_debug");
	public static final String CINEEDLOGIN = getProperty("ci_need_login");
	public static final String TEMPFOLDERPATH = getProperty("test_folder_path");
	public static final String OUTPUTTEMPPATH = getProperty("test_output_path");
	public static final String DELAY_TIME = getProperty("quartz_delay_time");
	public static final String THREADNUM = getProperty("grinder_threadNum");
	public static final String RUNCOUNT = getProperty("grinder_runCount");
	public static final String THINKTIME = getProperty("grinder_thinkTime");
	public static final String CHECKINTERVAL = getProperty("server_check_interval");
	public static final String CHECKCOUNT = getProperty("server_check_count");
//	public static void main(String args[]){
//		
//		String propertyName = "TEMPFOLDERPATH";
//		System.out.println(getProperty(propertyName));
//	}
	
	
	private static String getProperty(String propertyName){
		String property = "";
		//String filePath = System.getProperty("user.dir")+"\\src\\apms.properties";
		//String filePath = new FilePathConstants().getClass().getClassLoader().getResource(".").getPath()+"\\src\\apms.properties";
		InputStream is = new FilePathConstants().getClass().getClassLoader().getResourceAsStream("./apms.properties");
		//System.out.println("getProperty:" + new FilePathConstants().getClass().getClassLoader().toString());
		Properties prop = new Properties();     
		try {
			prop.load(is);
			property = prop.getProperty(propertyName);
		} catch (FileNotFoundException e) {
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		} catch (IOException e) {    
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		prop.clear();
		
		return property;
	}
}
