package com.ssc.sshz.peg.ptaf.inspection.test.parser;

import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.test.exception.IdfFileNameException;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Idf;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;

public class IdfXmlParser {
	private final String IDFDATAPATH = "\\WEB-INF\\dat";
	private static final Logger logger = Logger.getLogger(IdfXmlParser.class);
	/**
	 * get IDF map from specify project path
	 * @param sourcePath
	 * @return IDF map, key is IDF number, value is Idf object.
	 * @throws FileNotFoundException
	 * @throws IdfFileNameException
	 */
	public Map<String,Idf> getIDFService(String sourcePath) throws FileNotFoundException, IdfFileNameException {
		
		List<File> fileList;
		try
		{
		fileList = getIdfFileList(sourcePath);
		}
		catch(FileNotFoundException e)
		{
			logger.error(e.getMessage(),e);
			throw new FileNotFoundException(e.getMessage());
		}
		Map<String,Idf> idfMap = new HashMap<String,Idf>();
		
		//get IDF objects
		for (int i = 0; i < fileList.size(); i++) {
			IdfParser idfParser = new IdfParser();
			Idf idfObj = idfParser.loadXmlFile(fileList.get(i).getAbsolutePath(), sourcePath);
			try
			{
				checkReqNum(fileList.get(i), idfObj.getReqNumber());
			}
			catch (IdfFileNameException e)
			{
				logger.error(e.getMessage(),e);
				throw new IdfFileNameException(e.getMessage());
			}
			idfMap.put(idfObj.getReqNumber(),idfObj);
		}
		return idfMap;
	}
	
	class XMLFileFilter implements FileFilter {
		@Override
		public boolean accept(File file) {
			String fileName = file.getName();
			return fileName.startsWith("IDF") && fileName.endsWith(".xml");
		}
	}

	/**
	 * get XML files from project 
	 * @param sourcePath
	 * @return XML file list
	 * @throws FileNotFoundException
	 */
	public List<File> getIdfFileList(String sourcePath) throws FileNotFoundException {
		List<File> list = new ArrayList<File>();
		File datFolder = new File(sourcePath );
		if (datFolder.exists()) {
			File[] files = datFolder.listFiles(new XMLFileFilter());
			for (File serviceFile : files) 
				list.add(serviceFile);
		}
		else {
			throw new FileNotFoundException("can not find IDF XML files with the path:"+sourcePath );
		}
		return list;
	}

	//check request number in file name and file content are consistent
	private void checkReqNum(File file, String strFromContent) throws IdfFileNameException
	{
		String strFromName = FileUtil.getInstance().subFileName(file, "IDF_", ".xml");
		String idfPath = file.getAbsolutePath() ;
		
		//if the file name is equal to request number in the file
		if( !strFromName.equalsIgnoreCase(strFromContent))
			throw new IdfFileNameException(" please check file "+ idfPath +" request number  or file name is correct!");
	}
}
