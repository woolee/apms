package com.ssc.sshz.peg.ptaf.inspection.service.impl;
import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanStrategyDao;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanStrategyService;

@Service
public class PlanStrategyServiceImp<T extends PlanStrategy> implements PlanStrategyService<T> {
	
	@Inject
	private PlanStrategyDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addPlanStrategy(T entity) throws DataAccessException {
		return dao.addPlanStrategy(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllPlanStrategy() throws DataAccessException {
		return dao.getAllPlanStrategy();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getPlanStrategyByName(String name) throws DataAccessException {
		return dao.getPlanStrategyByName(name);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getPlanStrategyByPlanId(int planId) throws DataAccessException {
		return dao.getPlanStrategyByPlanId(planId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getPlanStrategyById(int id) throws DataAccessException {
		return dao.getPlanStrategyById(id);
	}
}
