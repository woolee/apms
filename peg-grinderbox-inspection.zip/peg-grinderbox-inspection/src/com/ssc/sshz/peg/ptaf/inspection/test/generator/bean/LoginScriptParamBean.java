package com.ssc.sshz.peg.ptaf.inspection.test.generator.bean;

import java.io.File;

public class LoginScriptParamBean
{
	private File userFile;
    public File getUserFile()
	{
		return userFile;
	}
	public void setUserFile(File userFile)
	{
		this.userFile = userFile;
	}
	private String username;
    private String password;
//    private String user;
//    private String server;
    private String url;
    private String context;
    private boolean needLogin;
//    private boolean usePwMatrix;
    public String getUsername()
    {
        return username;
    }
    public void setUsername(String username)
    {
        this.username = username;
    }
    
    public LoginScriptParamBean()
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public String getUrl()
    {
        return url;
    }
    public void setUrl(String url)
    {
        this.url = url;
    }
    public String getContext()
    {
        return context;
    }
    public void setContext(String context)
    {
        this.context = context;
    }
    public String getPassword()
    {
        return password;
    }
    public void setPassword(String password)
    {
        this.password = password;
    }
//    public String getUser()
//    {
//        return user;
//    }
//    public void setUser(String user)
//    {
//        this.user = user;
//    }
//    public String getServer()
//    {
//        return server;
//    }
//    public void setServer(String server)
//    {
//        this.server = server;
//    }
    public boolean isNeedLogin()
    {
        return needLogin;
    }
    public void setNeedLogin(boolean needLogin)
    {
        this.needLogin = needLogin;
    }
//    public boolean isUsePwMatrix()
//    {
//        return usePwMatrix;
//    }
//    public void setUsePwMatrix(boolean usePwMatrix)
//    {
//        this.usePwMatrix = usePwMatrix;
//    }
    
    
}
