package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.CIScript;
import com.ssc.sshz.peg.ptaf.inspection.mapper.CIScriptMapper;

public class CIScriptQuartzService<T extends CIScript>
{
	private Logger logger = Logger.getLogger(getClass());

	// private SqlSession session = ConnectionFactory.openSession();
	// private CIScriptMapper mapper = session.getMapper(CIScriptMapper.class);

	@SuppressWarnings("unchecked")
	public List<T> getAllCIScript() throws Exception
	{
		List<T> object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIScriptMapper mapper = session.getMapper(CIScriptMapper.class);
			object = (List<T>) mapper.getAllCIScript();
		}
		catch (Exception e)
		{
			logger.error("exception while get all CIScript from databse",e);
			throw new Exception("exception while get all CIScript from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	public T getCIScript(T entity) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIScriptMapper mapper = session.getMapper(CIScriptMapper.class);
			object = (T) mapper.getCIScript(entity);
		}
		catch (Exception e)
		{
			logger.error("exception while get CIScript object from databse",e);
			throw new Exception("exception while get CIScript object from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;

	}

	public boolean addCIScript(T entity) throws Exception
	{
		boolean flag = false;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIScriptMapper mapper = session.getMapper(CIScriptMapper.class);
			mapper.addCIScript(entity);
			session.commit();
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("exception while add CIScript object to databse",e);
			throw new Exception("exception while add CIScript object to databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return flag;
	}

	@SuppressWarnings("unchecked")
	public T getCIScriptByConfigId(int id) throws Exception
	{
		T object = null;
		SqlSession session = null;
		try
		{
			session = ConnectionFactory.openSession();
			CIScriptMapper mapper = session.getMapper(CIScriptMapper.class);
			object = (T) mapper.getCIScriptByConfigId(id);
		}
		catch (Exception e)
		{
			logger.error("exception while get CIScript object by id from databse",e);
			throw new Exception("exception while get CIScript object by id from databse", e);
		}
		finally
		{
			if (session != null)
				session.close();
		}
		return object;
	}
}
