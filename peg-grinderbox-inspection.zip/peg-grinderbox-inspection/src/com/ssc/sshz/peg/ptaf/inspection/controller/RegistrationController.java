package com.ssc.sshz.peg.ptaf.inspection.controller;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.bean.UserRight;
import com.ssc.sshz.peg.ptaf.inspection.service.RegistrationService;
import com.ssc.sshz.peg.ptaf.inspection.service.UserRightService;

@Controller
@RequestMapping("/registration")
public class RegistrationController {
	private static final Logger logger = Logger
			.getLogger(RegistrationController.class);
	@Inject
	private RegistrationService<User> registrationService;

	@Inject
	private UserRightService<UserRight> userRightService;

	@RequestMapping("/CreateUser")
	public String createUser(User user, UserRight userRight, Model model) {
		registrationService.addUser(user);
		user=registrationService.getUser(user);
		userRight.setRightId(1);
		userRight.setRightName("ROLE_USER");
		userRight.setUserId(user.getUserId());
		userRight.setUserName(user.getUserName());
		userRightService.addUserRight(userRight);
		return "/view/login.jsp";
	}

	@ExceptionHandler(Exception.class)
	public String exception(Exception e, HttpServletRequest request) {
		request.setAttribute("exception", e);
		logger.error(e.getMessage(), e);
		return "/view/error.jsp";
	}
	
	@RequestMapping("/init")
	public String init(User user, UserRight userRight, Model model,HttpSession httpSession) {
		List<String> nameList = registrationService.getAllUser();
		model.addAttribute("nameList", nameList);
		return "/page/registration.jsp";
	}
}
