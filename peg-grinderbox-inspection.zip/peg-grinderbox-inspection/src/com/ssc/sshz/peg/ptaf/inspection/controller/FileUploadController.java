package com.ssc.sshz.peg.ptaf.inspection.controller;

import java.io.File;
import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.service.TestBriefService;
import com.ssc.sshz.peg.ptaf.inspection.service.UserService;
import com.ssc.sshz.peg.ptaf.inspection.util.FileZip;


@Controller
@RequestMapping("/testCall")
public class FileUploadController {
	private static final Logger logger = Logger.getLogger(FileUploadController.class);
	
	@Inject
	private UserService<User> userService;
	
	@Inject
	private TestBriefService<TestBrief> testBriefService;
	
	 @RequestMapping(value = "/CItest", method = RequestMethod.POST)
	 public ModelAndView createDocument(String name,
			@RequestParam("username") String username,
	 		@RequestParam("password") String password,
	 		@RequestParam("projectuuid") String projectuuid,
	 		@RequestParam("systemuuid") String systemuuid,
	 		@RequestParam("summaryId") String summaryId,
	 		@RequestParam("version") String version,
			@RequestParam("file") MultipartFile file, HttpServletResponse response,HttpSession httpSession,HttpServletRequest request) 
					throws IllegalStateException, IOException {
			User user = userService.getUserByName(username);
			ModelAndView view=new ModelAndView();
			if(user == null)
			{
				view.setViewName("../Error/UsernameAndPasswordError.jsp");
				return view;
			}
			String DBpassWord=user.getPassWord();
			PasswordEncoder encoder = new Md5PasswordEncoder();
			String hashedPass = encoder.encodePassword(password, null);
			logger.debug(hashedPass);
			if(!DBpassWord.equals(hashedPass)){
				view.setViewName("../Error/UsernameAndPasswordError.jsp");
				return view;  
			}  
			
			if(testBriefService.checkTestBriefExsitBySummaryId(summaryId)){
				view.setViewName("../Error/SummaryIdError.jsp");
				return view; 
			}
		    
//			String realPath = "C:/test";
			String uploadZipName = file.getOriginalFilename();
			if(!uploadZipName.toLowerCase().endsWith(".zip"))
			{
				view.setViewName("../Error/configZipError.jsp");
				return view;
			}
			long  currentTime = System.currentTimeMillis();
			File pathFile=new File(FilePathConstants.TEMPFOLDERPATH + "/" + currentTime);
			if(!pathFile.exists()){
				pathFile.mkdirs();
			}
			
			file.transferTo(new File(pathFile, uploadZipName));
				
			String zipfilepath=FilePathConstants.TEMPFOLDERPATH + "/" + currentTime + "/" + uploadZipName;
			
			String zipfileputpath =  FileZip.unzip(zipfilepath, FilePathConstants.TEMPFOLDERPATH + File.separator + currentTime);
		    
			httpSession.setAttribute("version", version);
			httpSession.setAttribute("user", user);
			httpSession.setAttribute("projectuuid", projectuuid);
			httpSession.setAttribute("systemuuid", systemuuid);
			httpSession.setAttribute("summaryId", summaryId);
		    httpSession.setAttribute("configTempPath", zipfileputpath);
		    httpSession.setAttribute("configOriginalPath", zipfilepath);
		    
			view.setViewName("/CI/checkProjectSystem.do");
			logger.info("user["+username+"] upload with projectuuid["+projectuuid+"] systemuuid ["+systemuuid+"]");
			logger.debug("username: "+username);
			logger.debug("projectuuid: "+projectuuid);
			logger.debug("systemuuid: "+systemuuid);
			return view;                          
	 }
	 
}
