package com.ssc.sshz.peg.ptaf.inspection.mapper;

import com.ssc.sshz.peg.ptaf.inspection.bean.Right;

public interface RightMapper extends SqlMapper
{
	public void addRight(Right right);
	
	public Right getRightByRightName(String rightName);
}
