package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;

public interface RuntimeMapper extends SqlMapper{
	public List<Runtime> getAllRuntime(); 
	public Runtime getRuntime(Runtime runtime);
	public Runtime getRuntimeById(Integer id);
	public Runtime getRuntimeByPlanId(Integer planid);
	public void addRuntime(Runtime runtime);
	public void editRuntime(Runtime runtime);
	public void delRuntimeById(Integer id);
	public List<Runtime> getRuntimeByStrategyId(Integer id);
	public void updateRuntime(Runtime runtime);
	public Runtime getRuntimeByUUID(String runtimeUUID);
}
