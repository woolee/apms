package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class CIScript implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1066706416018486181L;
	private int relationId;
	private int configId;
	private int scriptId;
	public int getRelationId()
	{
		return relationId;
	}
	public void setRelationId(int relationId)
	{
		this.relationId = relationId;
	}
	public int getConfigId()
	{
		return configId;
	}
	public void setConfigId(int configId)
	{
		this.configId = configId;
	}
	public int getScriptId()
	{
		return scriptId;
	}
	public void setScriptId(int scriptId)
	{
		this.scriptId = scriptId;
	}
	
}
