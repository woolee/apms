package com.ssc.sshz.peg.ptaf.inspection.quartz.listener;

import org.apache.log4j.Logger;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.SchedulerException;
import org.quartz.SchedulerListener;
import org.quartz.Trigger;
import org.quartz.TriggerKey;

import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.RuntimeTriggerQuartzService;

public class PerformanceSchedulerListener implements SchedulerListener
{

	private static Logger logger = Logger.getLogger(PerformanceSchedulerListener.class);
	
	private RuntimeTriggerQuartzService<RuntimeTrigger> serivce = new RuntimeTriggerQuartzService<RuntimeTrigger>();
	@Override
	public void jobAdded(JobDetail jobdetail)
	{
		
		logger.info("Job: " + jobdetail.getKey() + " is added to scheduler");
		
	}

	@Override
	public void jobDeleted(JobKey jobkey)
	{
		logger.info("Job: " + jobkey + " is deleted from scheduler");
		try
		{
			serivce.delRuntimeTriggerByJobName(jobkey.getName());
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
		}
	}

	@Override
	public void jobPaused(JobKey jobkey)
	{
		logger.info("Job: " + jobkey + " is paused ");
		
	}

	@Override
	public void jobResumed(JobKey jobkey)
	{
		logger.info("Job: " + jobkey + " is resumed ");
		
	}

	@Override
	public void jobScheduled(Trigger trigger)
	{
		logger.info("Trigger: " + trigger.getKey() + " is scheduled ");
		
	}

	@Override
	public void jobUnscheduled(TriggerKey triggerkey)
	{
		try
		{
			serivce.delRuntimeTriggerByTriggerName(triggerkey.getName());
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		logger.info("Trigger: " + triggerkey + " is unscheduled ");
		
	}

	@Override
	public void jobsPaused(String s)
	{
		logger.info("Jobs: " + s + " is paused ");
		
	}

	@Override
	public void jobsResumed(String s)
	{
		logger.info("Jobs: " + s + " is resumed ");
		
	}

	@Override
	public void schedulerError(String s, SchedulerException schedulerexception)
	{
		logger.error("scheduler error!");
		if(schedulerexception != null && !"".equals(schedulerexception.getMessage()))
			logger.error("Exception thrown by:" + s + "exception:" + schedulerexception.getMessage());
		
	}

	@Override
	public void schedulerInStandbyMode()
	{
		logger.info("Scheduler is in stand by mode");
		
	}

	@Override
	public void schedulerShutdown()
	{
		logger.info("Scheduler shut down");
		
	}

	@Override
	public void schedulerShuttingdown()
	{
		logger.info("Scheduler is shutting down...");
		
	}

	@Override
	public void schedulerStarted()
	{
		logger.info("Scheduler start");
		
	}

	@Override
	public void schedulerStarting()
	{
		
		logger.info("Scheduler is starting...");
	}

	@Override
	public void schedulingDataCleared()
	{
		logger.info("scheduling Data Cleared");
	}

	@Override
	public void triggerFinalized(Trigger trigger)
	{
		logger.info("Trigger:" + trigger.getKey() + " is finalized");
		String jobName = trigger.getJobKey().getName();
		try
		{
			serivce.delRuntimeTriggerByJobName(jobName);
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
		}
		
	}

	@Override
	public void triggerPaused(TriggerKey triggerkey)
	{
		logger.info("Trigger:" + triggerkey + " is paused");
		
	}

	@Override
	public void triggerResumed(TriggerKey triggerkey)
	{
		logger.info("Trigger:" + triggerkey + " is resumed");
		
	}

	@Override
	public void triggersPaused(String s)
	{
		logger.info("Triggers:" + s + " are paused");
		
	}

	@Override
	public void triggersResumed(String s)
	{
		logger.info("Triggers:" + s + " are resumed");
		
	}

}
