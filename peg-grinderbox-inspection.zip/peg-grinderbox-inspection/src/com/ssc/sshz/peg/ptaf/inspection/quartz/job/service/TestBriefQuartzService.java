package com.ssc.sshz.peg.ptaf.inspection.quartz.job.service;


import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc.ConnectionFactory;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.mapper.TestBriefMapper;
public class TestBriefQuartzService<T extends TestBrief> 
{
	private Logger logger = Logger.getLogger(getClass());
	
	@SuppressWarnings("unchecked")
	public List<T> getAllTestBreif() throws Exception 
	{
		List<T> object = null;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestBriefMapper mapper = session.getMapper(TestBriefMapper.class);
			object = (List<T>) mapper.getAllTestBrief();
		}
		catch(Exception e)
		{
			logger.error("exception while get all TestBrief from database",e);
			throw new Exception("exception while get all TestBrief from database",e);
		}finally{
			if(session != null)
				session.close();
		}
		return object;
		
	}
	@SuppressWarnings("unchecked")
	public T getTestBreif(T entity) throws Exception 
	{
		T object = null;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestBriefMapper mapper = session.getMapper(TestBriefMapper.class);
		object = (T) mapper.getTestBrief(entity);
		}
		catch(Exception e)
		{
			logger.error("exception while get TestBrief object from databse",e);
			throw new Exception("exception while get TestBrief object from databse",e);
		}finally{
			if(session != null)
				session.close();
		}
		return object;
	}

	@SuppressWarnings("unchecked")
	public T getTestBriefWioutSummaryId(T entity) throws Exception 
	{
		T object = null;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestBriefMapper mapper = session.getMapper(TestBriefMapper.class);
		object = (T) mapper.getTestBriefWioutSummaryId(entity);
		}
		catch(Exception e)
		{
			logger.error("exception while get TestBrief object from databse",e);
			throw new Exception("exception while get TestBrief object from databse",e);
		}finally{
			if(session != null)
				session.close();
		}
		return object;
	}
	
	public boolean addTestBreif(T entity) throws Exception 
	{
		boolean flag = false;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestBriefMapper mapper = session.getMapper(TestBriefMapper.class);
			mapper.addTestBrief(entity);
			session.commit();
			flag = true; 
			} 
		catch(Exception e)
		{
			flag = false;
			logger.error("exception while add TestBrief object to databse",e);
			throw new Exception("exception while add TestBrief object to databse",e);
		}finally{
			if(session != null)
				session.close();
		}
		return flag;
	}

	public boolean updateTestBreif(T entity) throws Exception 
	{
		boolean flag = false;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestBriefMapper mapper = session.getMapper(TestBriefMapper.class);
			mapper.updateTestBrief(entity);
			session.commit();
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("exception while update TestBrief to databse",e);
			throw new Exception("exception while update TestBrief to databse",e);
		}finally{
			if(session != null)
				session.close();
		}
		return flag;
	}

	public boolean updateTestBreifStatus(T entity) throws Exception 
	{
		boolean flag = false;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestBriefMapper mapper = session.getMapper(TestBriefMapper.class);
			mapper.updateTestBriefStatus(entity);
			session.commit();
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			session.rollback();
			flag = false;
			logger.error("exception while update TestBrief status to database",e);
			throw new Exception("exception while update TestBrief status to database",e);
		}
		finally{
			if(session != null)
				session.close();
		}
		return flag;
	}


	@SuppressWarnings("unchecked")
	public T getTestBriefByBriefId(int id) throws Exception 
	{
		T object = null;
		SqlSession session = null;
		try {
			session = ConnectionFactory.openSession();
			TestBriefMapper mapper = session.getMapper(TestBriefMapper.class);
			object = (T) mapper.getTestBriefByBriefId(id);
		}
		catch(Exception e)
		{
			logger.error("exception while get TestBrief object by briefId from databse",e);
			throw new Exception("exception while get TestBrief object by briefId from databse",e);
		}
		finally{
			if(session != null)
				session.close();
		}
		return object;
	}

	
}
