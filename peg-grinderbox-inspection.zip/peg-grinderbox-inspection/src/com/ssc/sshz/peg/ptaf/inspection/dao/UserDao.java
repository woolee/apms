package com.ssc.sshz.peg.ptaf.inspection.dao;


import java.util.List;

import org.springframework.dao.DataAccessException;

public interface UserDao<T> {
	public boolean addUser(T entity) throws DataAccessException;
	public T getUserByName(String name) throws DataAccessException;
	public T getUserById(int id) throws DataAccessException;
	public List<T> getAllUsers() throws DataAccessException;
	
}
