package com.ssc.sshz.peg.ptaf.inspection.test.parser;

import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Idf;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Inputs;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.bean.Outputs;

/**
 * This class is for parsing the IDF data and get the meta data information for
 * registry call for service details
 * 
 * @author p472061
 * 
 */
public class IdfParser
{


    private Document document;
    private ArrayList<String> childIdfList;
    private Idf idf = new Idf();

    private String idfCreatedBy = "";
    private String idfCreatedAt = "";
    private String reqNumber = "";
    private String reqName = "";
    private String reqCacheable = "";
    private String basicVersion = "";
    private String basicPrivate = "";
    private String basicCrud = "";
    private String dataEntitementModel = "";
    private String detailDesc = "";
    private String detailKeyWord = "";
    private String srcCode = "";
    private String srcTech = "";
    private String srcDesc = "";
    private String specialRemarks = "";
    private String appCode = "";
    private String costCenter = "";
    private String organization = "";
    private String functionGroup = "";
    private String usageConstraint = "";
    private String dependsWebServices = "";
    private String dataClassification = "";

    /**
     * @param sourcePath
     * @return
     */
    public Idf loadXmlFile(String sourcePath, String joinerPath)
    {
	DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
	try
	{
	    // Using factory get an instance of document builder
	    DocumentBuilder docBuilder = dbf.newDocumentBuilder();

	    // parse using builder to get DOM representation of the XML file
	    document = docBuilder.parse(sourcePath);
	    parseDocument(joinerPath);

	}
	catch (ParserConfigurationException pce)
	{
	}
	catch (SAXException se)
	{
	}
	catch (IOException ioe)
	{
	}

	return idf;

    }

    /**
     * Method to parse the IDF document
     * 
     */
    private void parseDocument(String joinerPath) throws ParserConfigurationException, SAXException, IOException
    {
	// get the root element
	Element rootElement = document.getDocumentElement();

	ArrayList<Inputs> inputList = populateInputList(rootElement);
	ArrayList<Outputs> outputList = populateOutputList(rootElement);
	boolean isIdfJoiner = checkForIdfJoiner(rootElement);

	if (isIdfJoiner)
	{
	    outputList.clear();
	    for (int i = 0; i < childIdfList.size(); i++)
	    {
		IdfChildParser idfChildParser = new IdfChildParser();
		ArrayList<Outputs> childOutputList = idfChildParser.getChildIdfOutputs(childIdfList.get(i), joinerPath);
		for (int j = 0; j < childOutputList.size(); j++)
		{
		    outputList.add(childOutputList.get(j));
		}
	    }
	}
	else
	{
	}

	populateIdfAttribute(rootElement);
	populateReqAttribute(rootElement);
	populateBasicAttribute(rootElement);
	populateDetailAttribute(rootElement);
	populateOwnerAttribute(rootElement);
	populateUsageAttribute(rootElement);
	populateDataAttribute(rootElement);

	idf.setInputList(inputList);
	idf.setOutputList(outputList);
	idf.setIdfCreatedAt(idfCreatedAt);
	idf.setIdfCreatedBy(idfCreatedBy);
	idf.setReqNumber(reqNumber);
	idf.setReqName(reqName);
	idf.setReqCacheable(reqCacheable);
	idf.setBasicVersion(basicVersion);
	idf.setBasicPrivate(basicPrivate);
	idf.setBasicCrud(basicCrud);
	idf.setDataEntitementModel(dataEntitementModel);
	idf.setDetailDesc(detailDesc);
	idf.setDetailKeyWord(detailKeyWord);
	idf.setSrcCode(srcCode);
	idf.setSrcTech(srcTech);
	idf.setSrcDesc(srcDesc);
	idf.setSpecialRemarks(specialRemarks);
	idf.setAppCode(appCode);
	idf.setCostCenter(costCenter);
	idf.setOrganization(organization);
	idf.setFunctionGroup(functionGroup);
	idf.setUsageConstraint(usageConstraint);
	idf.setDependsWebServices(dependsWebServices);
	idf.setAppCode(appCode);
	idf.setDataClassification(dataClassification);
    }

    /**
     * 
     * @param rootElement
     * @return
     */
    private boolean checkForIdfJoiner(Element rootElement)
    {
	String actionName = "";
	NodeList nodeList = rootElement.getElementsByTagName("action");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nodeList.item(0);
		actionName = element.getAttribute("name");
	    }
	}
	if ("com.ssc.faw.idf.mfa.IDF_Joiner".equals(actionName))
	{
	    // set child idf list
	    setChildIdfList(rootElement);
	    return true;
	}
	else
	{
	    return false;
	}
    }

    /**
     * 
     * @param rootElement
     */
    private void setChildIdfList(Element rootElement)
    {
	childIdfList = new ArrayList<String>();
	NodeList nList = rootElement.getElementsByTagName("call");
	if (nList != null && nList.getLength() > 0)
	{
	    for (int i = 0; i < nList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nList.item(i);
		if ("data".equals(element.getParentNode().getNodeName()))
		{
		    String idfName = element.getAttribute("name");
		    childIdfList.add(idfName);
		}
	    }
	}
    }

    /**
     * 
     * @param rootElement
     */
    private void populateDataAttribute(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("dataclassification");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nodeList.item(0);
		if (element.getFirstChild() != null)
		{
		    dataClassification = element.getFirstChild().getNodeValue().trim().replaceAll("\\r\\n|\\r|\\n|\\t", "")
			    .replaceAll("\\b\\s{2,}\\b", " ");
		}
	    }
	}
    }

    /**
     * @param rootElement
     */
    private void populateUsageAttribute(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("depends");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nodeList.item(0);
		usageConstraint = "";
		dependsWebServices = element.getAttribute("web-services");
	    }
	}
    }

    /**
     * @param rootElement
     */
    private void populateOwnerAttribute(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("owner");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nodeList.item(0);
		appCode = element.getAttribute("appcode");
		costCenter = element.getAttribute("costcenter");
		organization = element.getAttribute("organization");
		functionGroup = element.getAttribute("function-group");
	    }
	}
    }

    /**
     * @param rootElement
     */
    private void populateDetailAttribute(Element rootElement)
    {
	getDescription(rootElement);
	getKeywords(rootElement);
	getSrcAttribute(rootElement);
	getSpecialRemarks(rootElement);
    }

    /**
     * @param rootElement
     */
    private void getSrcAttribute(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("source");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nodeList.item(0);
		srcCode = element.getAttribute("code");
		srcTech = element.getAttribute("technology");
		if (element.getFirstChild() != null)
		{
		    srcDesc = element.getFirstChild().getNodeValue().trim();
		}
	    }
	}
    }

    /**
     * @param rootElement
     */
    private void getSpecialRemarks(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("special-remarks");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nodeList.item(0);
		if (element.getFirstChild() != null)
		{
		    // specialRemarks =
		    // element.getFirstChild().getNodeValue().trim();
		    specialRemarks = element.getFirstChild().getNodeValue().trim().replaceAll("\\r\\n|\\r|\\n|\\t", "").replaceAll(
			    "\\b\\s{2,}\\b", " ");

		}
	    }
	}
    }

    /**
     * @param rootElement
     */
    private void getKeywords(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("keywords");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nodeList.item(0);
		if (element.getFirstChild() != null)
		{
		    detailKeyWord = element.getFirstChild().getNodeValue().trim();
		}
	    }
	}

    }

    /**
     * @param rootElement
     */
    private void getDescription(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("description");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the element
		Element element = (Element) nodeList.item(0);
		if (element.getFirstChild() != null)
		{
		    // detailDesc =
		    // element.getFirstChild().getNodeValue().trim();
		    detailDesc = element.getFirstChild().getNodeValue().trim().replaceAll("\\r\\n|\\r|\\n", "").replaceAll(
			    "\\b\\s{2,}\\b", " ");

		}
	    }
	}

    }

    /**
     * @param rootElement
     */
    private void populateBasicAttribute(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("basic");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the basic element
		Element element = (Element) nodeList.item(0);
		basicVersion = element.getAttribute("version");
		basicPrivate = element.getAttribute("private");
		basicCrud = element.getAttribute("CRUD");
		dataEntitementModel = element.getAttribute("data-entitlement-model");
	    }
	}

    }

    /**
     * @param rootElement
     */
    private void populateReqAttribute(Element rootElement)
    {
	NodeList nodeList = rootElement.getElementsByTagName("request");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the request element
		Element element = (Element) nodeList.item(0);
		reqNumber = element.getAttribute("number");
		reqName = element.getAttribute("name");
		reqCacheable = element.getAttribute("cacheable");
	    }
	}
    }

    /**
     * @param rootElement
     */
    private void populateIdfAttribute(Element rootElement)
    {
	idfCreatedAt = rootElement.getAttribute("created_at");
	idfCreatedBy = rootElement.getAttribute("created_by");
    }

    /**
     * @param rootElement
     * @return
     */
    private ArrayList<Inputs> populateInputList(Element rootElement)
    {
	ArrayList<Inputs> inputsList = new ArrayList<Inputs>();
	// get a nodelist of elements
	NodeList nodeList = rootElement.getElementsByTagName("input");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the Input element
		Element element = (Element) nodeList.item(i);
		if ("inputs".equals(element.getParentNode().getNodeName()))
		{
		    // get the Input object
		    Inputs inputs = getInputs(element);
		    // add it to list
		    inputsList.add(inputs);
		}
	    }
	}
	return inputsList;
    }

    /**
     * @param element
     * @return
     */
    private Inputs getInputs(Element element)
    {
	Inputs inputs = new Inputs();
	inputs.setInputName(element.getAttribute("name"));
	inputs.setInputType(element.getAttribute("type"));
	inputs.setInputOptional(element.getAttribute("optional"));
	if (element.getFirstChild() != null)
	{
	    inputs.setInputDesc(element.getFirstChild().getNodeValue().trim());
	}
	return inputs;
    }

    /**
     * @param rootElement
     * @return
     */
    private ArrayList<Outputs> populateOutputList(Element rootElement)
    {
	ArrayList<Outputs> outputsList = new ArrayList<Outputs>();
	// get a nodelist of elements
	NodeList nodeList = rootElement.getElementsByTagName("output");
	if (nodeList != null && nodeList.getLength() > 0)
	{
	    for (int i = 0; i < nodeList.getLength(); i++)
	    {
		// get the Output element
		Element element = (Element) nodeList.item(i);
		if ("outputs".equals(element.getParentNode().getNodeName()))
		{
		    // get the Input object
		    Outputs outputs = getOutputs(element);
		    // add it to list
		    outputsList.add(outputs);
		}
	    }
	}
	return outputsList;
    }

    /**
     * @param element
     * @return
     */
    private Outputs getOutputs(Element element)
    {
	Outputs outputs = new Outputs();
	outputs.setOutputName(element.getAttribute("name"));
	outputs.setOutputType(element.getAttribute("type"));
	if (element.getFirstChild() != null)
	{
	    outputs.setOutputDesc(element.getFirstChild().getNodeValue().trim());
	}
	return outputs;
    }

}
