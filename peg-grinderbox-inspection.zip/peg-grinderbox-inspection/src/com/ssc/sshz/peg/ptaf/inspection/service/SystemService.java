package com.ssc.sshz.peg.ptaf.inspection.service;


import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ssc.sshz.peg.ptaf.inspection.bean.System;

public interface SystemService<T>
{
	public boolean addSystem(T entity) throws DataAccessException;
	public T getSystem(Integer id) throws DataAccessException;
	public T getSystemByName(String name) throws DataAccessException;
	public T getSystemById(int Id) throws DataAccessException;
	public T getSystemByuuid(String Id) throws DataAccessException;
	public T getSystemByNameVersionEnv(System system) throws DataAccessException;
	public boolean delSystem(T entity) throws DataAccessException;
	public List<T> getAllSystem()  throws DataAccessException;
	public List<T> getSystemByProjectName(String name)  throws DataAccessException;
	public List<T> getSystemByProjectId(int id)  throws DataAccessException;
	public T getSystemByPlanId(int planId) throws DataAccessException;
}
