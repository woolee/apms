package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Report;
import com.ssc.sshz.peg.ptaf.inspection.dao.ReportDao;
import com.ssc.sshz.peg.ptaf.inspection.service.ReportService;

@Service
public class ReportServiceImp<T extends Report> implements ReportService<T> {

	@Inject
	private ReportDao<T> reportStateDao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllReportState() throws DataAccessException {

		return reportStateDao.getAllReport();

	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addReport(T entity) throws DataAccessException {

		return reportStateDao.addReport(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updateByStatus(Report report) throws DataAccessException {

		return reportStateDao.updateStatus(report);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean deleteReportByUUID(String reportUUID)
			throws DataAccessException {
		return reportStateDao.deleteReportByUUID(reportUUID);
	}

	@Override
	public List<Report> getPagingReprot(Map<String, Integer> pageparm) {
		return (List<Report>) reportStateDao.getPagingReprot(pageparm);
	}

	@Override
	public boolean updateExecutePercent(Report report)
			throws DataAccessException {

		return reportStateDao.updateExecutePercent(report);
	}

	@Override
	public List<Report> getDownloadPercentList() {
		return reportStateDao.getDownloadPercentList();
	}

	@Override
	public Report getReportByUUID(String reportUUID) throws DataAccessException {
		return reportStateDao.getReportByUUID(reportUUID);
	}
	
}
