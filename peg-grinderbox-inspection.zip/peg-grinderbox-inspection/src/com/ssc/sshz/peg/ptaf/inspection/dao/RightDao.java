package com.ssc.sshz.peg.ptaf.inspection.dao;

import org.springframework.dao.DataAccessException;



public interface RightDao<T> {
	public boolean addRight(T entity) throws DataAccessException;

	public T getRightByRightName(String rightName) throws DataAccessException;
}
