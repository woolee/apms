package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;


public class ReadXMLUtil{
	private static final Logger logger = Logger.getLogger(ReadXMLUtil.class);
	
	public List<String> getAppcode(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		logger.debug("targetFilePath:"+targetFilePath);
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam");
		for(Element ele:actionList){	
			itemList.add(ele.attributeValue("appcode"));
		}
		return itemList;
	}

	
	public Document getDocument(String filePath) throws DocumentException {
		File f = new File(filePath);
		SAXReader reader = new SAXReader();    
		Document doc = null;
		try {
			doc = reader.read(f);
		} catch (DocumentException e) {
			logger.error(e.getMessage(),e);
			throw e;
		}
		
		return doc;
	}

	
	public List<String> getVersion(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam");
		for(Element ele:actionList){	
			itemList.add(ele.attributeValue("version"));
		}
		return itemList;
	}

	
	public List<String> getEnv(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam");
		for(Element ele:actionList){	
			itemList.add(ele.attributeValue("env"));
		}
		return itemList;
	}

	
	public List<String> getRequestURL(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam/url");
		for(Element ele:actionList){
			itemList.add(ele.getStringValue());
		}
		return itemList;
	}

	
	public List<String> getRequestName(String filePath) {
	   // File file=new File("C:\\test\\ciconfig");
		  File file=new File(filePath);
		  String test[];
		  test=file.list();
		  List<String> itemList = new ArrayList<String>();
		  for(int i=0;i<test.length;i++)
		  {  
		   if(test[i].split("_")[0].equals("IDF")){
			   itemList.add((test[i].split("_")[1]).split("\\.")[0]);
		   }
		  }
		  return itemList;
		}


	
	public List<String> getUsername(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam/username");
		for(Element ele:actionList){
			itemList.add(ele.getStringValue());
		}
		return itemList;
	}

	
	public List<String> getPassword(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam/password");
		for(Element ele:actionList){
			itemList.add(ele.getStringValue());
		}
		return itemList;
	}

	
	public List<String> getSummaryId(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam/summary_id");
		for(Element ele:actionList){
			itemList.add(ele.getStringValue());
		}
		return itemList;
	}

	
	public List<String> getProjectName(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam/project_name");
		for(Element ele:actionList){
			itemList.add(ele.getStringValue());
		}
		return itemList;
	}

	public List<String> getThreadNum(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam/thread_num");
		for(Element ele:actionList){
			itemList.add(ele.getStringValue());
		}
		return itemList;
	}
	
	public List<String> getRunCount(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam/run_count");
		for(Element ele:actionList){
			itemList.add(ele.getStringValue());
		}
		return itemList;
	}
	
	public List<String> getThinkTime(String filePath) throws DocumentException {
		String targetFilePath=filePath+"/performanceTestParam.xml";
		Document doc = this.getDocument(targetFilePath);
		List<String> itemList = new ArrayList<String>();
		@SuppressWarnings("unchecked")
		List<Element> actionList = doc.selectNodes("/performanceTestParam/think_time");
		for(Element ele:actionList){
			itemList.add(ele.getStringValue());
		}
		return itemList;
	}
}
