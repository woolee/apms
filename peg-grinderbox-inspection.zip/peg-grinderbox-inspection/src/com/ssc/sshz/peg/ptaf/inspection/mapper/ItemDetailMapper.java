package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.ItemDetail;

public interface ItemDetailMapper extends SqlMapper
{
	public void addItemDetail(ItemDetail detail);
	
	public ItemDetail getItemDetail(ItemDetail detail);
	
	public void updateItemDetail(ItemDetail detail);
	
	public List<ItemDetail> getAllItemDetail();
	
	public List<ItemDetail> getAllItemDetailByPlanId(int planId);
	
	public List<ItemDetail> getAllItemDetailByItemId(int itemId);
	
	public List<ItemDetail> getAllItemDetailByItemIdAndBriefId(ItemDetail ItemDetail);
}
