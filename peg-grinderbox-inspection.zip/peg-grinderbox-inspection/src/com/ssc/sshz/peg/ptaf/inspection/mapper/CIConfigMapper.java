package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.CIConfig;

public interface CIConfigMapper extends SqlMapper
{
	public List<CIConfig> getAllCIConfig();
	
	public CIConfig getCIConfig(CIConfig config);
	
	public CIConfig getCIConfigById(int  id);
	
	public CIConfig getCIConfigBySystemuuid(String  uuid);
	
	public void addCIConfig(CIConfig config);
	
	public void delCIConfig(CIConfig config);
	
	public void delCIConfigById(int id);
	
	public void updateCIConfig(CIConfig config);
	
	public int getCIConfigCount(CIConfig config);
	
	public CIConfig getCIConfigByMD5(CIConfig config);
	
	public int getCIConfigCountByMD5(CIConfig config);
	
}
