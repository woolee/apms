package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.ssc.sshz.peg.ptaf.inspection.bean.QTMLogScan;
import com.ssc.sshz.peg.ptaf.inspection.dao.QTMLogScanDao;
import com.ssc.sshz.peg.ptaf.inspection.service.QTMLogScanService;
@Service
public class QTMLogScanServiceImp<T extends QTMLogScan> implements QTMLogScanService<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private QTMLogScanDao<T> dao;
	@Override
	public List<T> getAllQTMLogScan() {
		return dao.getAllQTMLogScan();
	}
	@Override
	public T getQTMLogScanById(int id) {
		return dao.getQTMLogScanById(id);
	}
	@Override
	public boolean addQTMLogScan(T scan) {
		return dao.addQTMLogScan(scan);
	}
	@Override
	public boolean delQTMLogScanById(int id) {
		return dao.delQTMLogScanById(id);
	}
	@Override
	public boolean updateQTMLogScanFile(byte[] errorFile, int scanId) {
		return dao.updateQTMLogScanFile(errorFile, scanId);
	}
	@Override
	public boolean updateQTMLogScanProgress(int executePercentage, int scanId) {
		// TODO Auto-generated method stub
		return dao.updateQTMLogScanProgress(executePercentage, scanId);
	}
	
	
}
