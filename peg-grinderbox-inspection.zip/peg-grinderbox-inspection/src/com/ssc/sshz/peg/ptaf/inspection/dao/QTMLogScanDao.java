package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;



public interface QTMLogScanDao<T> {
	public List<T> getAllQTMLogScan();
	
	public T getQTMLogScanById(int  id);
	
	public boolean addQTMLogScan(T scan);
	
	public boolean delQTMLogScanById(int id);
	
	public boolean updateQTMLogScanFile(byte[] errorFile,int scanId);
	
	public boolean updateQTMLogScanProgress(int executePercentage, int scanId);
}
