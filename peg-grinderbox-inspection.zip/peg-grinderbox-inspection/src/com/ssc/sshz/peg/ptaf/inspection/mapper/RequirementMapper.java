package com.ssc.sshz.peg.ptaf.inspection.mapper;

import com.ssc.sshz.peg.ptaf.inspection.bean.Requirement;

public interface RequirementMapper extends SqlMapper {
	public boolean addRequirement(Requirement requirement);
	public Requirement getRequirementByItemId(int itemId);
}
