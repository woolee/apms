package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.Element;

public class FileUtil
{
    private static FileUtil instance = new FileUtil();
    private static final Logger logger = Logger.getLogger(FileUtil.class);
    private FileUtil()
    {
    }

    public static FileUtil getInstance()
    {
	return instance;
    }

    /**
     * check the File is a directory or not,
     * if not, the program attempt to create a new folder
     * @param file the file to be checked
     * @throws IOException when the file name is not a dir or can not create the specify dir
     */
    public void checkAndCreateFolder(File file) throws IOException
    {
	if (file.exists())
	{
	    if (!file.isDirectory())
	    {
		throw new IOException(file.getAbsolutePath() + " is not a direacoty");
	    }
	}
	else
	{
	    if (!file.mkdirs())
	    {
		throw new IOException("can not create folder with path: " + file.getAbsolutePath());
	    }
	}
    }

    /**
     * change the file name to contains the localhost name
     * @param file
     * @return
     * @throws UnknownHostException
     */
    public File changeToLocalHost(File file) throws UnknownHostException
    {
    	String localhostName = null;
		try
		{
			localhostName = InetAddress.getLocalHost().getHostName();
		}
		catch (UnknownHostException e)
		{
//			logger.error(e.getMessage(), e);
			throw new UnknownHostException("Unknown host of " + localhostName);
		}
    	File nameChangeFile = new File(file.getParent() + File.separator + localhostName + ".ptafproperties");
    	file.renameTo(nameChangeFile);
    	
    	return nameChangeFile;
    }
    /**
     * copy the src file to dest file
     * @param src file to be copied
     * @param dest file copied
     * @throws IOException
     */
    public void copyFile(File src, File dest) throws IOException
    {
	FileInputStream fileIn = new FileInputStream(src);
	copyFile(fileIn, dest);
    }

    
    public void copyFile(InputStream in, File dest) throws IOException
    {
	FileOutputStream fileOut = new FileOutputStream(dest);

	byte[] buffer = new byte[256];
	int len;

	try
	{
	    while ((len = in.read(buffer)) != -1)
	    {
		fileOut.write(buffer, 0, len);
	    }
	}
	catch (IOException e)
	{
	    throw e;
	}
	finally
	{
	    if(in != null)
		in.close();
	    if(fileOut != null)
		fileOut.close();
	}
    }

    /**
     * 
     * @param varMap the variables to be replaced in the script template file
     * @param in the template input stream
     * @param outputFile the destination file
     * @throws IOException
     */
    public void createScriptContents(Map<String, String> varMap, InputStream in, File outputFile) throws IOException
    {
	Set<String> varKeys = varMap.keySet();

	BufferedReader reader = null;
	BufferedWriter writer = null;
	try
	{
	    reader = new BufferedReader(new InputStreamReader(in));
	    writer = new BufferedWriter(new FileWriter(outputFile));

	    String line;
	    while ((line = reader.readLine()) != null)
	    {
		if (varKeys != null)
		{
		    for (String varkey : varKeys)
		    {
			if (line.contains(varkey))
			    line = line.replace(varkey, varMap.get(varkey));
		    }
		}
		writer.write(line);
		writer.newLine();
	    }
	}
	catch (IOException e)
	{
	    throw e;
	}
	finally
	{
	    if (reader != null)
		reader.close();
	    if (writer != null)
		writer.close();
	}
    }
    
    /**
     * replace "\" to "\\"
     * 
     * change str to "str" (wrapped by quotes)
     * 
     * @param str
     * @return
     */
    public String quot(String str)
    {
	if (str == null)
	    str = "";
	else if (str.indexOf("\\") != -1)
	    str = str.replace("\\", "\\\\");
	return "\"" + str + "\"";
    }
    
    /**
     * change space to %20
     * @param str
     * @return
     */
    public String getStringNoSpace(String str) {
        if(str!=null && !"".equals(str)) {
            Pattern p = Pattern.compile("\\s|\t|\r|\n");
            Matcher m = p.matcher(str);
            String strNoSpace = m.replaceAll("%20");
            return strNoSpace;
        }else {
            return str;
        }
    }
    
    public String getStringWithSpace(String str) {
        if(str!=null && !"".equals(str)) {
            Pattern p = Pattern.compile("\\+");
            Matcher m = p.matcher(str);
            String strNoSpace = m.replaceAll(" ");
            return strNoSpace;
        }else {
            return str;
        }
    }
    
    public String getStringWithSeparator(String str) {
        if(str!=null && !"".equals(str)) {
            Pattern p = Pattern.compile("%2F");
            Matcher m = p.matcher(str);
            String strNoSpace = m.replaceAll("/");
            return strNoSpace;
        }else {
            return str;
        }
    }
    
    /**
     * cut the suffix of a file name
     * @param file the file to be cut suffix
     * @return the file name without suffix
     */
    public String cutSuffix(File file)
    {
	if(file == null)
	    return "";
	String fileName = file.getName();
	int suffixIndex = fileName.lastIndexOf(".");
	if(suffixIndex > 0 )	
	    fileName = fileName.substring(0, suffixIndex);
	return fileName;
    }
    
    /**
     * delete all files inside the folder and delete the folder 
     * @param folder
     * @return
     */
    public boolean delFolder(File folder)
    {
    	boolean flag = false;
    	if(delAllFile(folder.getAbsolutePath()))
    		flag = folder.delete();
    	return flag;
    }
    
    /**
     * delete all files inside the folder
     * @param path
     * @return
     */
    public boolean delAllFile(String path)
    {
	boolean flag = false;
	File file = new File(path);
	if (!file.exists())
	{
	    return flag;
	}
	if (!file.isDirectory())
	    return flag;
	String[] tempList = file.list();
	if(tempList.length == 0)
		return true;
	File temp = null;
	for (int i = 0; i < tempList.length; i++)
	{
	    if (path.endsWith(File.separator))
	    {
		temp = new File(path + tempList[i]);
	    }
	    else
	    {
		temp = new File(path + File.separator + tempList[i]);
	    }
	    if (temp.isDirectory())
	    {
		flag = delFolder(temp);
	    }
	    else
	    {
		flag = temp.delete();
	    }
	}
	return flag;
    }

    
    /**
     * read the first line of a csv file
     * @param csvFile
     * @return
     * @throws IOException
     */
    public String readHeader(File csvFile) throws IOException
    {
	String firstLine;
	RandomAccessFile reader = null;
	try
	{
	    reader = new RandomAccessFile(csvFile, "r");
	    firstLine = reader.readLine();
	}
	catch (IOException e)
	{
	    throw e;
	}
	finally
	{
	    if(reader != null) 
		reader.close();
	}
	return firstLine;
    }
    
    /**
     * intercept file's name;
     * @param file
     * @param startString
     * @param endString
     * @return
     */
    public String subFileName(File file, String startString, String endString)
    {
    	String fileName = file.getName();
    	int startIndex = fileName.indexOf(startString) + startString.length();
    	int endIndex = fileName.lastIndexOf(endString);
    	return fileName.substring(startIndex, endIndex);
    	
    }
    
    /**
	 * generate file and write string to file
	 * @param xml
	 * @param folder
	 * @return
	 * @throws IOException
	 */
	public boolean generateFile(String str, File folder, String filename) throws IOException
	{
		File xmlFile = new File(folder, filename);
		boolean isGenerated = false;
		BufferedWriter writer = null;
		try
		{
			writer = new BufferedWriter(new FileWriter(xmlFile));
			writer.write(str);
			isGenerated = true;
		}
		catch (IOException e)
		{
			throw new IOException(e.getMessage(), e);
		}
		finally
		{
			if (writer != null)
				writer.close();
		}
		return isGenerated;
	}
	
	/**
	 * set the specify prop value
	 * @param file
	 * @param propKey
	 * @param destVaule
	 * @return
	 * @throws IOException
	 */
	public boolean changePropValue(File file, String propKey, String destVaule) throws IOException
	{
		boolean flag = false;
		Properties prop = new Properties();
		FileOutputStream out = null;
		File outputFile = file;
		FileInputStream in = null;
		try
		{
			in = new FileInputStream(file);
			prop.load(in);
			out = new FileOutputStream(outputFile);
			prop.setProperty(propKey, destVaule);
			prop.store(out, propKey + " change");
			flag = true;
		}
		catch (IOException e)
		{
			flag = false;
			throw e;
		}
		finally{
			if(in != null)
				in.close();
			if(out != null)
				out.close();
		}
		
		return flag;
	}
	
	/**
	 * 
	 * @param file
	 * @param propKey
	 * @return
	 * @throws IOException
	 */
	public String getPropValue(File file, String propKey) throws IOException
	{
		String value = null;
		Properties prop = new Properties();
		FileInputStream in = null;
		try
		{
			in = new FileInputStream(file);
			prop.load(in);
			value = prop.getProperty(propKey);
		}
		catch (IOException e)
		{
			throw e;
		}
		finally{
			if(in != null)
				in.close();
		}
		return value;
	}
	
	/**
	 * 
	 * @param file
	 * @param node
	 * @param attribute
	 * @return
	 * @throws Exception
	 */
	public String getAttributeValue(File file, String node, String attribute) throws Exception
	{
		String value = null;
		try { 
			
				Document rtDoc = AssetAnalyzeUtil.getInstance().getDocument(file.getAbsolutePath());
				List<Element> agentList = rtDoc.selectNodes(node);
				value = agentList.get(agentList.size() -1).attributeValue(attribute);
	 	} catch (Exception e) {    
	 		logger.error(e.getMessage(),e);
			throw new Exception(e.getMessage(), e);
		}
		return value;
	}
	
	public boolean changeAttributeValue(File file, String node, String attribute, String destValue) throws Exception
	{
		boolean flag = false;
		try { 
			
			Document doc = AssetAnalyzeUtil.getInstance().getDocument(file.getAbsolutePath());
			List<Element> agentList = doc.selectNodes(node);
			agentList.get(agentList.size() -1).addAttribute(attribute, destValue);
			if(AssetAnalyzeUtil.getInstance().writeDocument(file.getAbsolutePath(), doc) == true){
				flag = true;
			}else{
				flag = false;
			}
		} catch (Exception e) {    
			flag = false;
			logger.error(e.getMessage(),e);
			throw new Exception(e.getMessage(), e);
		}
		return flag;
		
	}
	
	/**
	 * List all the child file or directory in the parent directory.
	 * Child files or directories match the file filter.
	 * @param fileDirecotry
	 * @param filefilter
	 * @return
	 */
	public static List<File> listFiles(String fileDirecotryPath, FileFilter filefilter){
		File fileDirecotry = new File(fileDirecotryPath);
		
		return listFiles(fileDirecotry, filefilter);
	}
	
	/**
	 * List all child file or directory in the parent directory.
	 * Child files or directories match the file filter. 
	 * @param fileDirecotry
	 * @param filefilter
	 * @return
	 */
	public static List<File> listFiles(File fileDirecotry, FileFilter filefilter){
		List<File> fileList = new ArrayList<File>();
//		if(fileDirecotry.isDirectory()){
//			File [] files = fileDirecotry.listFiles(filefilter);
//			for (File file : files) {
//				fileList.add(file);
//			}
//		}
		listAllFiles(fileDirecotry, filefilter, fileList);
		return fileList;
	}
	
	private static void listAllFiles(File fileDirecotry,FileFilter filefilter,List<File> fileList) 
	{
		if(fileDirecotry.isDirectory()){
			File [] filterFiles = fileDirecotry.listFiles(filefilter);
			for (File file : filterFiles) {
					fileList.add(file);
				}
			File [] allDirectories = fileDirecotry.listFiles(new FileFilter() {
				
				@Override
				public boolean accept(File pathname) {
					// TODO Auto-generated method stub
					return pathname.isDirectory();
				}
			});	
			for(File file : allDirectories){
				listAllFiles(file, filefilter, fileList);
			}
		}
	}
//	public boolean changeGrinderPropMainScriptPath(File file) throws IOException
//	{
//		boolean flag = false;
//		Properties prop = new Properties();
//		FileOutputStream out = null;
//		File outputFile = file;
//		FileInputStream in = null;
//		try
//		{
//			in = new FileInputStream(file);
//			prop.load(in);
//			out = new FileOutputStream(outputFile);
//			prop.setProperty(TestAssetContants.GRINDER_SCRIPT, "../scripts/Main.py");
//			prop.store(out, "output change");
//			flag = true;
//		}
//		catch (IOException e)
//		{
//			flag = false;
//			throw e;
//		}
//		finally{
//			in.close();
//			out.close();
//		}
//		
//		return flag;
//	}
}
