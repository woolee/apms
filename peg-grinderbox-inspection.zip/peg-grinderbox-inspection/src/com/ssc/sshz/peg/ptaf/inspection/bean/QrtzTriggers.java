package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class QrtzTriggers implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5111944523680455410L;
	
	private String schedName;
	private String triggerName;
	private String triggerGroup;
	private String jobName;
	private String jobGroup;
	private String description;
	private long nextFireTime;
	private long prevFireTime;
	private int priority;
	private String triggerState;
	private String triggerType;
	private long startTime;
	private long endTime;
	private String calendarName;
	private int misfireInstr;
	private byte[] jobData;
	public String getSchedName()
	{
		return schedName;
	}
	public void setSchedName(String schedName)
	{
		this.schedName = schedName;
	}
	public String getTriggerName()
	{
		return triggerName;
	}
	public void setTriggerName(String triggerName)
	{
		this.triggerName = triggerName;
	}
	public String getTriggerGroup()
	{
		return triggerGroup;
	}
	public void setTriggerGroup(String triggerGroup)
	{
		this.triggerGroup = triggerGroup;
	}
	public String getJobName()
	{
		return jobName;
	}
	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}
	public String getJobGroup()
	{
		return jobGroup;
	}
	public void setJobGroup(String jobGroup)
	{
		this.jobGroup = jobGroup;
	}
	public String getDescription()
	{
		return description;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	public long getNextFireTime()
	{
		return nextFireTime;
	}
	public void setNextFireTime(long nextFireTime)
	{
		this.nextFireTime = nextFireTime;
	}
	public long getPrevFireTime()
	{
		return prevFireTime;
	}
	public void setPrevFireTime(long prevFireTime)
	{
		this.prevFireTime = prevFireTime;
	}
	public int getPriority()
	{
		return priority;
	}
	public void setPriority(int priority)
	{
		this.priority = priority;
	}
	public String getTriggerState()
	{
		return triggerState;
	}
	public void setTriggerState(String triggerState)
	{
		this.triggerState = triggerState;
	}
	public String getTriggerType()
	{
		return triggerType;
	}
	public void setTriggerType(String triggerType)
	{
		this.triggerType = triggerType;
	}
	public long getStartTime()
	{
		return startTime;
	}
	public void setStartTime(long startTime)
	{
		this.startTime = startTime;
	}
	public long getEndTime()
	{
		return endTime;
	}
	public void setEndTime(long endTime)
	{
		this.endTime = endTime;
	}
	public String getCalendarName()
	{
		return calendarName;
	}
	public void setCalendarName(String calendarName)
	{
		this.calendarName = calendarName;
	}
	public int getMisfireInstr()
	{
		return misfireInstr;
	}
	public void setMisfireInstr(int misfireInstr)
	{
		this.misfireInstr = misfireInstr;
	}
	public byte[] getJobData()
	{
		return jobData;
	}
	public void setJobData(byte[] jobData)
	{
		this.jobData = jobData;
	}
	
	
}
