package com.ssc.sshz.peg.ptaf.inspection.quartz.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScheduleRuntime
{
	private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
	private Date startTime;
	private Date endTime;
	private int intervalInSecond;
	private int repeatCount;
	public int getIntervalInSecond()
	{
		return intervalInSecond;
	}
	public void setIntervalInSecond(int intervalInSecond)
	{
		this.intervalInSecond = intervalInSecond;
	}
	public Date getStartTime()
	{
		return startTime;
	}
	public void setStartTime(Date startTime)
	{
		this.startTime = startTime;
	}
	public Date getEndTime()
	{
		return endTime;
	}
	public void setEndTime(Date endTime)
	{
		this.endTime = endTime;
	}
	public int getRepeatCount()
	{
		return repeatCount;
	}
	public void setRepeatCount(int repeatCount)
	{
		this.repeatCount = repeatCount;
	}
	public ScheduleRuntime()
	{
		super();
	}
	public ScheduleRuntime(Date startTime, Date endTime, int intervalInSecond, int repeatCount) throws ParseException
	{
		this.startTime = startTime;
		this.endTime = endTime;
		this.intervalInSecond = intervalInSecond;
		this.repeatCount = repeatCount;
	}
	
}
