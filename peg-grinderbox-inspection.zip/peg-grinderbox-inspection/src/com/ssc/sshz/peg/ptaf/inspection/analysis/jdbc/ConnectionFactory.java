package com.ssc.sshz.peg.ptaf.inspection.analysis.jdbc;

import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.log4j.Logger;

public class ConnectionFactory
{
	private static final Logger logger = Logger.getLogger(ConnectionFactory.class);
	private static SqlSessionFactory sqlMapper;
	private static Reader reader;
	private static SqlSession session;
	
		    static{
		        try{
		            reader    = Resources.getResourceAsReader("mybatis-quartz.xml");
		            sqlMapper = new SqlSessionFactoryBuilder().build(reader);
		        }catch(Exception e){
		        	logger.error(e.getMessage(),e);
		        	e.printStackTrace();
	        }
		    }
	 
	    public static SqlSessionFactory getSession(){
	        return sqlMapper;
	   }
	    
	    public static SqlSession openSession()
	    {
			session = sqlMapper.openSession(); 
			return session;
	    }
	    
	    public static void closeSession()
	    {
	    	session.close();
	    }
}
