package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class RequestStatistics implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8466683755789191679L;
	private int summaryId;
	private int requestId;
	private String requestName;
	private int itemId;
	private String itemName;
	private int briefId;
	private int planId;
	private int executionCount;
	private int minResponseTime;
	private int ninetyResponseTime;
	private double avgResponseTime; 
	private int maxResponseTime;
	private double stdResponseTime;
	private int errorCount;
	private double errorRate;
	public int getMinResponseTime()
	{
		return minResponseTime;
	}
	public void setMinResponseTime(int minResponseTime)
	{
		this.minResponseTime = minResponseTime;
	}
	public int getSummaryId()
	{
		return summaryId;
	}
	public void setSummaryId(int summaryId)
	{
		this.summaryId = summaryId;
	}
	public int getRequestId()
	{
		return requestId;
	}
	public void setRequestId(int requestId)
	{
		this.requestId = requestId;
	}
	public String getRequestName()
	{
		return requestName;
	}
	public void setRequestName(String requestName)
	{
		this.requestName = requestName;
	}
	public int getItemId()
	{
		return itemId;
	}
	public void setItemId(int itemId)
	{
		this.itemId = itemId;
	}
	public String getItemName()
	{
		return itemName;
	}
	public void setItemName(String itemName)
	{
		this.itemName = itemName;
	}
	public int getBriefId()
	{
		return briefId;
	}
	public void setBriefId(int briefId)
	{
		this.briefId = briefId;
	}
	public int getPlanId()
	{
		return planId;
	}
	public void setPlanId(int planId)
	{
		this.planId = planId;
	}
	public int getExecutionCount()
	{
		return executionCount;
	}
	public void setExecutionCount(int executionCount)
	{
		this.executionCount = executionCount;
	}
	public int getMaxResponseTime()
	{
		return maxResponseTime;
	}
	public void setMaxResponseTime(int maxResponseTime)
	{
		this.maxResponseTime = maxResponseTime;
	}
	public double getAvgResponseTime()
	{
		return avgResponseTime;
	}
	public void setAvgResponseTime(double avgResponseTime)
	{
		this.avgResponseTime = avgResponseTime;
	}
	public int getErrorCount()
	{
		return errorCount;
	}
	public void setErrorCount(int errorCount)
	{
		this.errorCount = errorCount;
	}
	public double getErrorRate()
	{
		return errorRate;
	}
	public void setErrorRate(double errorRate)
	{
		this.errorRate = errorRate;
	}
	public int getNinetyResponseTime()
	{
		return ninetyResponseTime;
	}
	public void setNinetyResponseTime(int ninetyResponseTime)
	{
		this.ninetyResponseTime = ninetyResponseTime;
	}
	public double getStdResponseTime()
	{
		return stdResponseTime;
	}
	public void setStdResponseTime(double stdResponseTime)
	{
		this.stdResponseTime = stdResponseTime;
	}
	
	
}
