package com.ssc.sshz.peg.ptaf.inspection.dao;
import java.util.List;

import org.springframework.dao.DataAccessException;
public interface ItemDao<T> {
	public boolean addItem(T entity) throws DataAccessException;
	public T getItemByName(String name) throws DataAccessException;
	public T getItemBySystemIdItemName(T entity) throws DataAccessException;
	public T getItemById(int id) throws DataAccessException;
	public List<T> getAllItem() throws DataAccessException;
	public List<T> getItemBySystemId(int sysId) throws DataAccessException;
}
