package com.ssc.sshz.peg.ptaf.inspection.test.parser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.DataRow;

public class FileParser {
		private static final Logger logger = Logger.getLogger(FileParser.class);
		/**
		 * parse data file to several DataRow objects. One object denote a data line in file. List stores all DataRow objects.
		 * @param dataFile
		 * @return DataRow map with key testId 
		 * @throws IOException
		 */
	   public List<Map<Integer, List<DataRow>>> parseDataFile(File dataFile) throws IOException 
	    {
		   List<Map<Integer, List<DataRow>>> DataMapWithDifKey = new ArrayList<Map<Integer,List<DataRow>>>();
		   Map<Integer, List<DataRow>> dataMap = new HashMap<Integer, List<DataRow>> ();
		   Map<Integer, List<DataRow>> dataMapByThread = new HashMap<Integer, List<DataRow>> ();
		   FileOperator operator;
			try
			{
				operator = new FileOperator(dataFile);
			}
			catch (FileNotFoundException e)
			{
				logger.error(e.getMessage(),e);
				throw new FileNotFoundException("log data file is not found");
			}
		
		String[] attributesName = getHeaders(operator);
		
		
		while (operator.hasNextLine())
		{
			HashMap<String, String> rowsMap = new HashMap<String, String>();
		    String[] values = operator.readNextLine();
		    for (int i = 0; i < attributesName.length; i++)
		    {
		    	rowsMap.put(attributesName[i], values[i]);
		    }
		    DataRow row = new DataRow(rowsMap);
		    int testId = row.getTest();
		    int thread = row.getThread();
		    if(dataMap.containsKey(testId))
		    {
		    	dataMap.get(testId).add(row);
		    	
		    }
		    else
		    {
		    	List<DataRow> rows = new ArrayList<DataRow>();
		    	rows.add(row);
		    	dataMap.put(testId, rows);
		    }
		    if(dataMapByThread.containsKey(thread))
		    {
		    	dataMapByThread.get(thread).add(row);
		    	
		    }
		    else
		    {
		    	List<DataRow> rows = new ArrayList<DataRow>();
		    	rows.add(row);
		    	dataMapByThread.put(thread, rows);
		    }
		}
		operator.close();
		DataMapWithDifKey.add(dataMap);
		DataMapWithDifKey.add(dataMapByThread);
		return DataMapWithDifKey;
	    }
	
	   public Map<Integer,List<String>> parseLog(File logFile) throws IOException{
		   String reg = "\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2},\\d{3}\\sINFO.*thread-(\\d{1,3})\\s\\[\\srun-\\d{1,3},\\stest-\\d+\\s\\]:\\s(.*)\\s->.*";
			Pattern p = Pattern.compile(reg);
			Map<Integer, List<String>> threadRequestURL = new HashMap<Integer, List<String>>();
			try
			{
				BufferedReader reader = new BufferedReader(new FileReader(logFile));
				String line;
				line = reader.readLine();
				while(line != null && !line.isEmpty())
				{
					
					Matcher m = p.matcher(line);
					if(m.find())
					{
						int thread = Integer.parseInt(m.group(1));
						String url = m.group(2);
						if(threadRequestURL.containsKey(thread))
						{
							threadRequestURL.get(thread).add(url);
						}
						else{
							List<String> urlList = new ArrayList<String>();
							urlList.add(url);
							threadRequestURL.put(thread, urlList);
						}
					}
					line = reader.readLine();
					
				}
			}
			catch (IOException e)
			{
				logger.error(e.getMessage(),e);
				throw new IOException("Exception while read grinder log",e);
			}
			return threadRequestURL;
	   }
	   /**
	    * 
	    * @param operator
	    * @return 
	    * @throws IOException
	    */
	   public String[] getHeaders(FileOperator operator) throws IOException
	   {
		   String[] attributesName = null;
			try
			{
				attributesName = operator.getAttributesName();
			}
			catch (IOException e)
			{
				logger.error(e.getMessage(),e);
				throw new IOException("headers read error in log data file",e);
			}
			return attributesName;
	   }
	   
}
