package com.ssc.sshz.peg.ptaf.inspection.service;


import java.util.List;

import org.springframework.dao.DataAccessException;

public interface RegistrationService<T>{
	
	public boolean addUser(T entity) throws DataAccessException;
	public T getUser(T entity) throws DataAccessException;
	public List<String> getAllUser() throws DataAccessException;
}
