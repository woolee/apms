package com.ssc.sshz.peg.ptaf.inspection.dao;


import java.util.List;

import org.springframework.dao.DataAccessException;

public interface PlanStrategyDao<T> {
	public boolean addPlanStrategy(T entity) throws DataAccessException;
	public List<T> getAllPlanStrategy() throws DataAccessException;
	public T getPlanStrategyByName(String name) throws DataAccessException;
	public List<T> getPlanStrategyByPlanId(int id) throws DataAccessException;
	public T getPlanStrategyById(int id) throws DataAccessException;
}
