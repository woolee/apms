package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Group;
import com.ssc.sshz.peg.ptaf.inspection.bean.GroupRight;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Right;
import com.ssc.sshz.peg.ptaf.inspection.bean.RightProject;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.bean.UserRight;
import com.ssc.sshz.peg.ptaf.inspection.dao.ProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserRightDao;
import com.ssc.sshz.peg.ptaf.inspection.service.UserRightService;

@Service

public class UserRightServiceImp<T extends UserRight> implements
		UserRightService<T> {

	@Inject
	private UserRightDao<T> dao;

	@Inject
	private RightDao<Right> rightDao;
	
	@Inject
	private RightProjectDao<RightProject> rightProjectDao;
	
	@Inject
	private ProjectDao<Project> projectDao;
	
	@Inject
	private UserDao<User> userDao;
	
	private String GROUP_NAME_POSTFIX = "_ADMIN";
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addUserRight(T entity) throws DataAccessException {
		return dao.addUserRight(entity);
	}

	@Override
	public List<T> getUserRightByUserId(int userId) throws DataAccessException
	{
		return dao.getUserRightByUserId(userId);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public void addRightAndUserRight(T entity,Right right,UserRight userRight, RightProject rightProject,String username,String projectName) throws DataAccessException
	{
		String rightName = projectName + GROUP_NAME_POSTFIX;
		right.setRightName(rightName);
		rightDao.addRight(right);
		right = rightDao.getRightByRightName(rightName);
		
//		group.setGroupName(groupName);
//		groupDao.addGroup(group);
//		group = groupDao.getGroupByGroupName(groupName);
//		
//		right.setRightName(groupName);
//		rightDao.addRight(right);
//		right = rightDao.getRightByRightName(groupName);
		
//		groupRight.setGroupId(group.getGroupId());
//		groupRight.setGroupName(group.getGroupName());
//		groupRight.setRightId(right.getRightId());
//		groupRight.setRightName(right.getRightName());
//		groupRightDao.addGroupRight(groupRight);
		Project project = projectDao.getProjectByName(projectName);
		rightProject.setProjectId(project.getProjectId());
		rightProject.setProjectName(projectName);
		rightProject.setRightId(right.getRightId());
		rightProject.setRightName(rightName);
		rightProjectDao.addRightProject(rightProject);
		
		User user = userDao.getUserByName(username);
		entity.setRightId(right.getRightId());
		entity.setRightName(rightName);
		entity.setUserId(user.getUserId());
		entity.setUserName(username);
		dao.addUserRight(entity);
		
		
	}

}
