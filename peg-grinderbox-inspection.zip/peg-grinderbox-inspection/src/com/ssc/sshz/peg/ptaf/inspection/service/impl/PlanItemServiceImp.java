package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanItemDao;
import com.ssc.sshz.peg.ptaf.inspection.service.PlanItemService;

@Service

public class PlanItemServiceImp<T extends PlanItem> implements PlanItemService<T> {
	
	@Inject
	private PlanItemDao<T> dao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addPlanItem(T entity) throws DataAccessException {
		return dao.addPlanItem(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean updatePlanItem(T entity) throws DataAccessException {
		return dao.updatePlanItem(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean DeletePlanItemByPlanId(int planId)
			throws DataAccessException {
		return dao.deletePlanItemByPlanId(planId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getPlanItemByItemId(Integer id) throws DataAccessException {
		return dao.getPlanItemByItemId(id);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllPlanItem() throws DataAccessException {
		return dao.getAllPlanItem();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllPlanItemByPlanId(int planId)
			throws DataAccessException {
		return dao.getAllPlanItemByPlanId(planId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getvalidPlanItemByPlanId(int planId)
			throws DataAccessException {
		return dao.getvalidPlanItemByPlanId(planId);
	}}
