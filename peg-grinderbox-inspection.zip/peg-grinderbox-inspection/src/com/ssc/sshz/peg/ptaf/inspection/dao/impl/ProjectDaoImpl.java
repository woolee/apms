package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.dao.ProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ProjectMapper;

@Repository
public class ProjectDaoImpl<T extends Project> implements ProjectDao<T>{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private ProjectMapper mapper;

	@SuppressWarnings("unchecked")
	@Override
	public T getProjectById(Integer id) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getProjectById(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get project from database",e);
			throw new DaoException("Exception while get project from database",e);
		}
		return entity;
	}
	
	@Override
	public boolean addProject(T entity) throws DataAccessException {

		boolean flag = false;
		try {
			mapper.addProject(entity); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while add proejct to database",e);
			throw new DaoException("Exception while add proejct to database",e);
		}
		return flag;
	
	}

    @Override
	public boolean delProjectById(Integer id) throws DataAccessException {

		boolean flag = false;
		try {
			mapper.delProject(id); 
			flag = true; 
			} 
		catch(DataAccessException e)
		{
			flag = false;
			logger.error("Exception while delete project from database",e);
			throw new DaoException("Exception while delete project frmo database",e);
		}
		return flag;
	
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getProjectByName(String name) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getProjectByName(name);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get project by name from database",e);
			throw new DaoException("Exception while get project by name from database",e);
		}
		return entity;
	}

	@Override
	public boolean delProjectByName(String name) throws DataAccessException {
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllProject() throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllProject();
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all project from database",e);
			throw new DaoException("Exception while get all project from database",e);
		}
		return entity;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getProjectByuuid(String id) throws DataAccessException {
		T entity = null;
		try{ 
			entity = (T) mapper.getProjectByuuid(id);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get project by uuid from database",e);
			throw new DaoException("Exception while get project by uuid from database",e);
		}
		return entity;
	}

	@Override
	public List<T> getAllProjectByUsername(String userName) throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllProjectByUsername(userName);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get all project from database",e);
			throw new DaoException("Exception while get all project from database",e);
		}
		return entity;
		
	}
	

}
