package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.UserGroup;

public interface UserGroupMapper extends SqlMapper
{
	public void addUserGroup(UserGroup userGroup);
	public List<UserGroup> getUserGroupByUserId(int userId);
}
