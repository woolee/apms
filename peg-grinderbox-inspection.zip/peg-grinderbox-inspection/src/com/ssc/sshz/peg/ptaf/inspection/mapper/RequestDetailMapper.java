package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.RequestDetail;

public interface RequestDetailMapper extends SqlMapper
{
	public void addRequestDetail(RequestDetail detail);
	
	public RequestDetail getRequestDetail(RequestDetail detail);
	
	public void updateRequestDetail(RequestDetail detail);
	
	public List<RequestDetail> getAllRequestDetail();
	
	public List<RequestDetail> getAllRequestDetailByPlanId(int planId);
	
	public List<RequestDetail> getAllRequestDetailByRequestId(int requestId);
	
	public List<RequestDetail> getAllRequestDetailByRequestIdBriefId(RequestDetail detail);
	
	public RequestDetail getRequestDetailBySystemuuid(String systemuuid);
}
