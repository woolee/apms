package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;
import org.springframework.dao.DataAccessException;

public interface TestErrorService<T>
{
	public boolean addTestError(T entity) throws DataAccessException;
	public List<T> getAllTestError() throws DataAccessException;
	public T getTestError(T entity)throws DataAccessException;
	public List<T> getTestErrorByBriefId(int briefId)throws DataAccessException;
	public List<T> getTestErrorByBriefAndType(T entity)throws DataAccessException;
}
