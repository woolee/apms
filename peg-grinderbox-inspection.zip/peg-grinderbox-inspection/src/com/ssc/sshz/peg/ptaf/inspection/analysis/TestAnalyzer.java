package com.ssc.sshz.peg.ptaf.inspection.analysis;

import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.DataRow;
import com.ssc.sshz.peg.ptaf.inspection.bean.ItemStatistics;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.constants.TestBriefStatusConstants;

public class TestAnalyzer
{
	private static final Logger logger = Logger.getLogger(TestAnalyzer.class);
	
	private List<ItemStatistics> itemSummaryList;
	private Map<Integer, List<DataRow>> itemDataMap;
	private TestBrief testBrief;
	private String outputFolder;

	public TestAnalyzer(){}
	public TestAnalyzer(Map<Integer, List<DataRow>> rowDataMap, List<ItemStatistics> itemSummaryList, TestBrief testBrief,
			String outputFolder)
	{
		this.itemDataMap = rowDataMap;
		this.itemSummaryList = itemSummaryList;
		this.testBrief = testBrief;
		this.outputFolder = outputFolder;
	}

	/**
	 * analyze itemDataMap, so set itemDataMap first
	 * @return
	 */
	public long getTestStartTime()
	{
		Set<Integer> testIds = itemDataMap.keySet();
		long startTime = 0;
		int count = 0;
		for (Integer testId : testIds)
		{
			count ++;
			List<DataRow> rows = itemDataMap.get(testId );
			DataRow row = Collections.min(rows, new Comparator<DataRow>()
			{

				@Override
				public int compare(DataRow o1, DataRow o2)
				{
					// TODO Auto-generated method stub
					return (int) (o1.getStartTime() - o2.getStartTime());
				}
			});
			if(count == 1)
				startTime = row.getStartTime();
			if(row.getStartTime() < startTime)
				startTime = row.getStartTime();
		}
		return startTime;
	}
	
	/**
	 * analyze itemDataMap, so set itemDataMap first
	 * @return
	 */
	public long getTestEndTime()
	{
		Set<Integer> testIds = itemDataMap.keySet();
		long endTime = 0;
		for (Integer testId : testIds)
		{
			List<DataRow> rows = itemDataMap.get(testId );
			DataRow row = Collections.max(rows, new Comparator<DataRow>()
			{

				@Override
				public int compare(DataRow o1, DataRow o2)
				{
					// TODO Auto-generated method stub
					return (int) (o1.getStartTime()+o1.getTestTime() - o2.getStartTime() -o2.getTestTime());
				}
			});
			if((row.getStartTime() + row.getTestTime())> endTime)
				endTime = row.getStartTime() + row.getTestTime();
		}
		return endTime;
	}

	/**
	 * analyze itemSummaryList, so set itemSummaryList first
	 * @return
	 */
	public boolean isPassed()
	{
		boolean isPassed = false;
		for (ItemStatistics summary : itemSummaryList)
		{
			isPassed = summary.getIsPassed();
		}
		return isPassed;
	}

	/**
	 * analyze itemSummaryList, so set itemSummaryList first
	 * @return
	 */
	public boolean hasError()
	{
		boolean hasError = false;
		for (ItemStatistics summary : itemSummaryList)
		{
			hasError = summary.getErrorCount() > 0;
		}
		return hasError;
	}

	public TestBrief getTestBrief()
	{
		boolean isPassed = isPassed();
		boolean hasError = hasError();

		logger.debug("test start time :" + getTestStartTime());
		logger.debug("test end time:" + getTestEndTime());
		testBrief.setStartTime(new Date(getTestStartTime()));
		testBrief.setEndTime(new Date(getTestEndTime()));
		testBrief.setPassed(isPassed);
		testBrief.setHasError(hasError);
		testBrief.setResultFolderPath(outputFolder);
		testBrief.setStatus(TestBriefStatusConstants.ANALYZEOVER);
		return testBrief;
	}

	public List<ItemStatistics> getItemSummaryList()
	{
		return itemSummaryList;
	}

	public void setItemSummaryList(List<ItemStatistics> itemSummaryList)
	{
		this.itemSummaryList = itemSummaryList;
	}

	public Map<Integer, List<DataRow>> getItemDataMap()
	{
		return itemDataMap;
	}

	public void setItemDataMap(Map<Integer, List<DataRow>> itemDataMap)
	{
		this.itemDataMap = itemDataMap;
	}

	public String getOutputFolder()
	{
		return outputFolder;
	}

	public void setOutputFolder(String outputFolder)
	{
		this.outputFolder = outputFolder;
	}

	public void setTestBrief(TestBrief testBrief)
	{
		this.testBrief = testBrief;
	}
	
	
}
