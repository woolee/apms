package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.Requirement;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequirementDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.RequirementMapper;
import com.ssc.sshz.peg.ptaf.inspection.mapper.UserMapper;

@Repository
public class RequirementDaoImpl<T extends Requirement> implements
		RequirementDao<T> {
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RequirementMapper mapper;

	@Override
	public boolean addRequirement(T entity) throws DataAccessException {
		return mapper.addRequirement(entity);

	}

	@Override
	public T getRequirementByItemId(int itemId) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return (T) mapper.getRequirementByItemId(itemId);
	}

}
