package com.ssc.sshz.peg.ptaf.inspection.mapper;


import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.System;

public interface SystemMapper extends SqlMapper{
	public void addSystem(System system);
	public System getSystemById(Integer id);
	public System getSystemByuuid(String id);
	public System getSystemByName(String name);
	public System getSystemByNameVersionEnv(System system);
	public  List<System>  getSystemByProjectName(String name);
	public  List<System>  getSystemByProjectId(int id);
	public void delSystem(int id);
	public List<System> getAllSystem(); 
}
