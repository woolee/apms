/**
 * ErrorAnalysis.java
 * 
 * Copyright (c) 2006 State Street Bank and Trust Corp.
 * 225 Franklin Street, Boston, MA 02110, U.S.A.
 * All rights reserved.
 *
 * "com.ssc.sstz.peg.ptaf.analysis.grinder is the copyrighted,
 * proprietary property of State Street Bank and Trust Company and its
 * subsidiaries and affiliates which retain all right, title and interest
 * therein."
 * 
 * Revision History
 *
 * Date            Programmer              Notes
 * ---------    ---------------------  --------------------------------------------
 * Mar 4, 2013		a525883				  initial
 */
package com.ssc.sshz.peg.ptaf.inspection.data;


/**
 * @author a525883
 *
 */
public class ErrorCount {
	private String requestName;
	private int totalCount;
	private int errorCount;
	private int failureCount;
	private int emptyCount;
	private int otherCount;
	
	public String getRequestName() {
		return requestName;
	}
	public void setRequestName(String requestName) {
		this.requestName = requestName;
	}
	public int getErrorCount() {
		return errorCount;
	}
	public void setErrorCount(int errorCount) {
		this.errorCount = errorCount;
	}
	public int getFailureCount() {
		return failureCount;
	}
	public void setFailureCount(int failureCount) {
		this.failureCount = failureCount;
	}
	public int getEmptyCount() {
		return emptyCount;
	}
	public void setEmptyCount(int emptyCount) {
		this.emptyCount = emptyCount;
	}
	public int getOtherCount() {
		return otherCount;
	}
	public void setOtherCount(int otherCount) {
		this.otherCount = otherCount;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
}
