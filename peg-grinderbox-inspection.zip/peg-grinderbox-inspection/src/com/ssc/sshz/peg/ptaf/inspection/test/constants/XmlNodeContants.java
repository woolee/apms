package com.ssc.sshz.peg.ptaf.inspection.test.constants;

public class XmlNodeContants
{
	public static final String PERFORMANCETEST = "performanceTest";
	public static final String SUMMARYID = "summaryId";
	public static final String STARTTIME = "startTime";
	public static final String FINISHTIME = "finishTime";
	public static final String TOTALCOUNT = "totalCount";
	public static final String FAILCOUNT = "failCount";
	public static final String AVGRESPONSE = "avgResponse";
	public static final String MAXRESPONSE = "maxResponse";
	public static final String MINRESPONSE = "minResponse";
	public static final String SERVICES = "services";
	public static final String SERVICE = "service";
	public static final String SERVICENUMBER = "number";
}
