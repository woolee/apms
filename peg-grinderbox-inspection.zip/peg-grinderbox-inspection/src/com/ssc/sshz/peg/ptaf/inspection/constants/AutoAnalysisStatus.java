package com.ssc.sshz.peg.ptaf.inspection.constants;

public class AutoAnalysisStatus
{
	public static final String PREPARE = "preparing";
	public static final String DOWNLOAD = "downloading";
	public static final String ANALYZE = "analying";
	public static final String COMPLETE = "completed";
	public static final String EXCEPTION = "error";
}	
