package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class GroupRight implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7899797639323695343L;
	private int groupRightId;
	private String groupRightName;
	private int groupId;
	private String groupName;
	private int rightId;
	private String rightName;
	private String groupRightDescription;
	public int getGroupRightId()
	{
		return groupRightId;
	}
	public void setGroupRightId(int groupRightId)
	{
		this.groupRightId = groupRightId;
	}
	public String getGroupRightName()
	{
		return groupRightName;
	}
	public void setGroupRightName(String groupRightName)
	{
		this.groupRightName = groupRightName;
	}
	public int getGroupId()
	{
		return groupId;
	}
	public void setGroupId(int groupId)
	{
		this.groupId = groupId;
	}
	public String getGroupName()
	{
		return groupName;
	}
	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}
	public int getRightId()
	{
		return rightId;
	}
	public void setRightId(int rightId)
	{
		this.rightId = rightId;
	}
	public String getRightName()
	{
		return rightName;
	}
	public void setRightName(String rightName)
	{
		this.rightName = rightName;
	}
	public String getGroupRightDescription()
	{
		return groupRightDescription;
	}
	public void setGroupRightDescription(String groupRightDescription)
	{
		this.groupRightDescription = groupRightDescription;
	}
	
}
