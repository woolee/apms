package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Entity;


//@Component
@Entity
public class Project implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1950942933102670929L;
	private Integer projectId;
	private String projectName;
	private Integer projectCreatorId;
	private String projectCreatorName;
	private Timestamp CreateTime;
	private String projectDescription;
	private String projectuuid;

	
	public String getProjectuuid() {
		return projectuuid;
	}
	public void setProjectuuid(String projectuuid) {
		this.projectuuid = projectuuid;
	}
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public Integer getProjectCreatorId() {
		return projectCreatorId;
	}
	public void setProjectCreatorId(Integer projectCreatorId) {
		this.projectCreatorId = projectCreatorId;
	}
	public String getProjectCreatorName() {
		return projectCreatorName;
	}
	public void setProjectCreatorName(String projectCreatorName) {
		this.projectCreatorName = projectCreatorName;
	}
	public Timestamp getCreateTime() {
		return CreateTime;
	}
	public void setCreateTime(Timestamp createTime) {
		CreateTime = createTime;
	}
	public String getProjectDescription() {
		return projectDescription;
	}
	public void setProjectDescription(String projectDescription) {
		this.projectDescription = projectDescription;
	}
	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectName="
				+ projectName + ", projectCreatorId=" + projectCreatorId
				+ ", projectCreatorName=" + projectCreatorName
				+ ", CreateTime=" + CreateTime + ", projectDescription="
				+ projectDescription + "]";
	}

	
	

}
