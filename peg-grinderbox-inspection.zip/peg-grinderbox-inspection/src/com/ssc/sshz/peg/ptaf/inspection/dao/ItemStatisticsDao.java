package com.ssc.sshz.peg.ptaf.inspection.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;



public interface ItemStatisticsDao<T> {
	public boolean addItemStatistics(T entity) throws DataAccessException;
	public List<T> getAllItemStatistics()throws DataAccessException;
	public List<T> getAllItemStatisticsByBriefId(int briefId)throws DataAccessException;
	public List<T> getAllItemStatisticsByPlanIdAndItemId(T entity)throws DataAccessException;
	public T getItemStatistics(T entity)throws DataAccessException;
	public boolean updateItemStatistics(T entity)throws DataAccessException;
}
