package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

import javax.persistence.Entity;

//@Component
@Entity
public class SystemItem implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5836406190858611552L;
	private Integer relationId;
	private Integer systemId;
	private String systemName;
	public Integer getRelationId() {
		return relationId;
	}
	public void setRelationId(Integer relationId) {
		this.relationId = relationId;
	}
	public Integer getSystemId() {
		return systemId;
	}
	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	public Integer getItemId() {
		return itemId;
	}
	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	@Override
	public String toString() {
		return "SystemItem [relationId=" + relationId + ", systemId="
				+ systemId + ", systemName=" + systemName + ", itemId="
				+ itemId + ", itemName=" + itemName + "]";
	}
	private Integer itemId;
	private String itemName;
}
