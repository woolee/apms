package com.ssc.sshz.peg.ptaf.inspection.test.exception;

public class PerformanRunException extends Exception
{
	public PerformanRunException(String mesg)
	{
		super(mesg);
	}
	public PerformanRunException(String mesg, Throwable e)
	{
		super(mesg, e);
	}
}
