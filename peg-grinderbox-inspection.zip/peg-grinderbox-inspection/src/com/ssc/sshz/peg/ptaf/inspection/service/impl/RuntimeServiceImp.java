package com.ssc.sshz.peg.ptaf.inspection.service.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.quartz.SchedulerException;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.ScheduleData;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.constants.StrategyType;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanStrategyDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RuntimeTriggerDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.quartz.QuartzManager;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.service.RuntimeService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;

@Service
public class RuntimeServiceImp<T extends Runtime> implements RuntimeService<T>
{

	@Inject
	private RuntimeDao<T> dao;

	@Inject
	private RuntimeTriggerDao<RuntimeTrigger> rtTriggerDao;

	@Inject
	private PlanStrategyDao<PlanStrategy> planStrategyDao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getAllRuntime() throws DataAccessException
	{
		return dao.getAllRuntime();
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getRuntime(T entity) throws DataAccessException
	{
		return dao.getRuntime(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addRuntime(T entity) throws DataAccessException
	{
		return dao.addRuntime(entity);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean delRuntimeById(int id) throws DataAccessException
	{
		return dao.delRuntimeById(id);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean delRtAndRtTriggerByRuntimeId(int runtimeId) throws DataAccessException, SchedulerException
	{
		RuntimeTrigger rt = rtTriggerDao.getRuntimeTriggerByRuntimeId(runtimeId);
		if (rt != null)
		{
			List<RuntimeTrigger> runtimeTriggerList = new ArrayList<RuntimeTrigger>();
			runtimeTriggerList.add(rt);
			QuartzManager.getQuartzManager().deleteJobs(runtimeTriggerList);
			rtTriggerDao.delRuntimeTriggerByRuntimeId(runtimeId);
		}
		return dao.delRuntimeById(runtimeId);

	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getRuntimeByPlanId(int planId) throws DataAccessException
	{
		return dao.getRuntimeByPlanId(planId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getRuntimeStrategyID(int strategyId) throws DataAccessException
	{
		return dao.getRuntimeByStrategyId(strategyId);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getRuntimeById(int id) throws DataAccessException
	{
		return dao.getRuntimeById(id);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getRuntimeByUUID(String uuid) throws DataAccessException
	{

		return dao.getRuntimeByUUID(uuid);
	}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean createRuntime(User user, RuntimeTrigger rt, Project project, System system, Plan plan, T runtime,
			RuntimeTrigger runtimeTrigger, int runType, JobData jobData, TestBeanCollection collection, String intervalTime,
			String timeUnit, String strategyName, String date_from, String date_to, String repeatStr
			) throws Exception
	{
		boolean flag = false;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		// add collection

		ScheduleData scheduleData = new ScheduleData();
		QuartzManager quartzManager = QuartzManager.getQuartzManager();
		switch (StrategyType.values()[runType - 1])
		{
		case Infinite:
		{
			int tempintervaltime = Integer.parseInt(intervalTime);
			int intervaltimeUnit = Integer.parseInt(timeUnit);
			int strategyId = planStrategyDao.getPlanStrategyByName(strategyName).getStrategyId();
			String runtimeUUID = UUID.randomUUID().toString();
			runtime.setStartTime(Timestamp.valueOf(date_from));
			runtime.setRunType(runType);
			runtime.setIntervalTime(tempintervaltime * intervaltimeUnit);
			runtime.setStrategyId(strategyId);
			runtime.setRuntimeUUID(runtimeUUID);
			dao.addRuntime(runtime);
			int runtimeId = dao.getRuntimeByUUID(runtimeUUID).getRuntimeId();
			rt.setRuntimeId(runtimeId);

			scheduleData.setStartTime(sdf.parse(date_from));
			scheduleData.setEndTime(null);
			scheduleData.setData(jobData);
			scheduleData.setIntervalSeconds(tempintervaltime * intervaltimeUnit);
			scheduleData.setRepeatTime(-1);
			scheduleData.setStartNow(false);
			scheduleData.setServiceCall(false);
			scheduleData.setTestBeanCollection(collection);
			scheduleData.setRuntimeTrigger(rt);
			rt = quartzManager.addNewRuntime(scheduleData);
			break;
		}
		case Once:
		{
			// String date_from = request.getParameter("date_from");
			// add runtime
			runtime.setStartTime(Timestamp.valueOf(date_from));
			runtime.setRunType(runType);
			int strategyId = planStrategyDao.getPlanStrategyByName(strategyName).getStrategyId();
			runtime.setStrategyId(strategyId);
			String runtimeUUID = UUID.randomUUID().toString();
			runtime.setRuntimeUUID(runtimeUUID);
			dao.addRuntime(runtime);
			int runtimeId = dao.getRuntimeByUUID(runtimeUUID).getRuntimeId();
			rt.setRuntimeId(runtimeId);

			scheduleData.setStartTime(sdf.parse(date_from));
			scheduleData.setEndTime(null);
			scheduleData.setData(jobData);
			scheduleData.setIntervalSeconds(0);
			scheduleData.setRepeatTime(0);
			scheduleData.setStartNow(false);
			scheduleData.setServiceCall(false);
			scheduleData.setTestBeanCollection(collection);
			scheduleData.setRuntimeTrigger(rt);
			rt = quartzManager.addNewRuntime(scheduleData);
			break;
		}
		case Sometime:
		{
			// String date_from = request.getParameter("date_from");
			// String date_to = request.getParameter("date_to");
			int tempintervaltime = Integer.parseInt(intervalTime);
			int intervaltimeUnit = Integer.parseInt(timeUnit);
			// String repeat = request.getParameter("repeat");
			String endTime = null;
			int repeat = 0;
			if (date_to.equalsIgnoreCase(""))
			{
				endTime = null;
				runtime.setEndTime(null);
				scheduleData.setEndTime(null);
			}
			else
			{
				endTime = date_to;
				runtime.setEndTime(Timestamp.valueOf(endTime));
				scheduleData.setEndTime(sdf.parse(endTime));
			}

			if (repeatStr.equalsIgnoreCase(""))
			{
				repeat = 0;
			}
			else
			{
				repeat = Integer.parseInt(repeatStr);
				scheduleData.setRepeatTime(repeat);
			}
			// add runtime
			runtime.setStartTime(Timestamp.valueOf(date_from));
			runtime.setRunType(runType);
			runtime.setIntervalTime(tempintervaltime * intervaltimeUnit);
			int strategyId = planStrategyDao.getPlanStrategyByName(strategyName).getStrategyId();
			runtime.setStrategyId(strategyId);
			String runtimeUUID = UUID.randomUUID().toString();
			runtime.setRuntimeUUID(runtimeUUID);
			dao.addRuntime(runtime);
			int runtimeId = dao.getRuntimeByUUID(runtimeUUID).getRuntimeId();
			rt.setRuntimeId(runtimeId);

			scheduleData.setStartTime(sdf.parse(date_from));
			scheduleData.setData(jobData);
			scheduleData.setIntervalSeconds(tempintervaltime * intervaltimeUnit);
			scheduleData.setStartNow(false);
			scheduleData.setServiceCall(false);
			scheduleData.setTestBeanCollection(collection);
			scheduleData.setRuntimeTrigger(rt);
			rt = quartzManager.addNewRuntime(scheduleData);
			break;
		}

		}
		if (rt != null)
		{
			rtTriggerDao.addRuntimeTrigger(rt);
		}
		flag = true;
		return flag;
	}
}
