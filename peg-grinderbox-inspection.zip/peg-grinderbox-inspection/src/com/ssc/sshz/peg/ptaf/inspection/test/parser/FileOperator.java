package com.ssc.sshz.peg.ptaf.inspection.test.parser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

public class FileOperator
{
    public static final String DEFAULT_SEPARATOR = ",";
    private static final Logger logger = Logger.getLogger(FileOperator.class);
    public Scanner scanner ;
    public FileReader reader ;
    private File file;
    private HashMap<String, HashMap<String, String>> rowsMap = null;

    /**
     * initiate the file, reader, and scanner
     * @param file
     * @throws FileNotFoundException
     */
    public FileOperator(File file) throws FileNotFoundException
    {
	    this.file = file;
	    this.reader = new FileReader(file);
	    this.scanner = new Scanner(this.reader);
    }
    

    /**
     * get next line 
     * @return next line 
     */
    public String getNextLine()
    {
	if (hasNextLine())
	    return scanner.nextLine();
	else
	    return null;
    }

    /**
     * 
     * @return if it has next line
     */
    public boolean hasNextLine()
    {
	return scanner.hasNextLine();
    }

    /**
     * read all content from the scanner
     * @return
     * @throws IOException
     */
    public List<String[]> readAll() throws IOException
    {
	if (reader != null)
	{
	    reader.close();
	    reader = new FileReader(file);
	}
	List<String[]> value = new ArrayList<String[]>();
	while (hasNextLine())
	{
	    value.add(readNextLine());
	}
	return value;
    }
    
    /**
     * read the next line from the file
     * @return
     */
    public String[] readNextLine()
    {
	return parseLine(getNextLine());
    }

    /**
     *  parse the input str's content
     * @param str
     * @return
     */
    private String[] parseLine(String str)
    {
	if (str != null)
	{
		String [] strs = str.split(DEFAULT_SEPARATOR);
		return arrayTrim(strs);
	}
	else
	    return null;
    }

    /**
     * return all the attributes,actually the first line's content. Need to
     * close the reader.
     * 
     * @return Attributes
     * @throws IOException
     */
    public String[] getAttributesName() throws IOException
    {
	if (reader != null)
	{
	    scanner.close();
	    reader.close();
	    scanner = null;
	    reader = null;
	    reader = new FileReader(file);
	}
	scanner = new Scanner(reader);
	return readNextLine();
    }

    /**
     * This API return all the rows map, while the key is the first column's
     * value Don't need to close the reader after call this Method.
     * 
     * @return HashMap
     * @throws IOException
     */
    public HashMap<String, HashMap<String, String>> getRowsMap() throws IOException
    {
	HashMap<String, HashMap<String, String>> rowsMap = new HashMap<String, HashMap<String, String>>();
	String[] attributesName = getAttributesName();
	while (scanner.hasNextLine())
	{
	    HashMap<String, String> rowValue = new HashMap<String, String>();
	    String[] values = readNextLine();
	    for (int i = 0; i < attributesName.length; i++)
	    {
		rowValue.put(attributesName[i], values[i]);
	    }
	    rowsMap.put(values[0], rowValue);
	}
	scanner.close();
	reader.close();
	return rowsMap;
    }
      
    
    /**
     * This method enables you get a certain attribute's value. For Example:
     * user, password 1, 123456 get user 1's password by using
     * getAttributeValue("1","password") The first param determine a certain
     * row. The second param is the attribute you want to get.
     * 
     * @param key
     * @param attribute
     * @return
     * @throws IOException
     */
    public String getAttributeValue(String key, String attribute) throws IOException
    {
	if (this.rowsMap == null)
	    this.rowsMap = getRowsMap();
	return rowsMap.get(key).get(attribute);
    }

    /**
     * CLOSE the csv reader
     * 
     * @throws IOException
     */
    public void close() throws IOException
    {
	try {
		scanner.close();
		reader.close();
	} catch (IOException e) {
		logger.error(e.getMessage(),e);
		throw new IOException(e.getMessage(), e);
	}
    }

    /**
     * each element take out blank in the beginning and the end use method trim() to 
     * @param strs
     * @return
     */
    public String[] arrayTrim(String[] strs)
    {
    	List<String> list = new ArrayList<String>();
		for (int i = 0; i < strs.length; i++)
		{
			list.add(strs[i].trim());
		}
		return list.toArray(new String[list.size()]);
    }
}
