package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.PlanDisplayBean;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanScript;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanStrategy;
import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;

public interface PlanDisplayBeanService<T>
{
	public List<PlanDisplayBean> getPlanBySystem(int systemId,PlanStrategy planStrategy,PlanScript planScript,Runtime runtime) throws Exception;


}
