package com.ssc.sshz.peg.ptaf.inspection.mapper;
import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
public interface RequestMapper extends SqlMapper{
	public void addRequest(Request request);
	public Request getRequestByRequestId(int requestId);
	public Request getRequestByRequestName(String requestName);
	public List<Request> getRequestByItemIdAndPlanId(Request request);
	public List<Request> getRequestsByItemId(int id); 
	public List<Request> getRequestsByPlanId(int planId);
	public void updateRequest(Request request);
}
