package com.ssc.sshz.peg.ptaf.inspection.analysis;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.DataRow;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.ItemDetail;
import com.ssc.sshz.peg.ptaf.inspection.bean.ItemStatistics;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestDetail;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestError;
import com.ssc.sshz.peg.ptaf.inspection.constants.ErrorType;
import com.ssc.sshz.peg.ptaf.inspection.constants.TestBriefStatusConstants;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.ItemDetailQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.ItemStatisticsQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.RequestDetailQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.RequestStatisticsQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.TestBriefQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.TestErrorQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;
import com.ssc.sshz.peg.ptaf.inspection.test.parser.FileParser;

public class AnalyzeManager
{
	private TestBriefQuartzService<TestBrief> testBriefService = new TestBriefQuartzService<TestBrief>();
	private TestErrorQuartzService<TestError> testErrorService = new TestErrorQuartzService<TestError>();
	private ItemStatisticsQuartzService<ItemStatistics> itemStatisticsSerice = new ItemStatisticsQuartzService<ItemStatistics>();
	private ItemDetailQuartzService<ItemDetail> itemDetailService = new ItemDetailQuartzService<ItemDetail>();
	private RequestStatisticsQuartzService<RequestStatistics> requestStatisticsService = new RequestStatisticsQuartzService<RequestStatistics>();
	private RequestDetailQuartzService<RequestDetail> requestDetailService = new RequestDetailQuartzService<RequestDetail>();

	private static final Logger logger = Logger.getLogger(AnalyzeManager.class);

	// private static AnalyzeManager instance = new AnalyzeManager();

	private static final Pattern ERROR_PATTERN = Pattern
			.compile("^(\\d{4}\\-\\d{2}\\-\\d{2}\\s\\d{2}\\:\\d{2}\\:\\d{2}\\,\\d{3}\\sERROR).*");

	private static final Pattern INFO_PATTERN = Pattern
			.compile("^(\\d{4}\\-\\d{2}\\-\\d{2}\\s\\d{2}\\:\\d{2}\\:\\d{2}\\,\\d{3}\\sINFO).*");

	private static final Pattern STATISTIC_PATTERN = Pattern.compile("\\s*Tests\\s*Errors\\s*Mean Test.*");

	private String warnMsg = null;
	File dataFile = null;
	File logFile = null;
	File consoleOut = null;

	public AnalyzeManager()
	{

	}

	/**
	 * 
	 * @return AnalyzManager instance
	 */
	// public static AnalyzeManager getInstance()
	// {
	// return instance;
	// }

	/**
	 * get data, log, consoleOut file from parameter outputFolder. Scan files,
	 * if exist error message, return message, else analyze data file and
	 * generate result file in parameter xmlRootFolder.
	 * 
	 * @param resultFolder
	 * @param summaryId
	 * @param xmlRootfolder
	 * @return error message, if doesn't occur error, return null
	 * @throws Exception
	 */
	public String doAnalyze(File outputFolder, boolean isServiceCall, TestBeanCollection collection) throws Exception
	{
		TestBrief testBrief = collection.getTestBrief();
		String errorMsg = null;

		// Project project = collection.getProject();
		// System system = collection.getSystem();
		Plan plan = collection.getPlan();
		List<Item> items = collection.getItemList();
//		Map<Integer, List<Request>> requestListByItemIdMap = collection.getRequestMapByItemId();
		
		/*--------------update test brief with output folder path---------------*/
		testBrief.setResultFolderPath(outputFolder.getAbsolutePath());
		testBriefService.updateTestBreif(testBrief);
		/*---------------------------------------------------------------------*/
		
		errorMsg = getErrorMsg(outputFolder, testBrief);
		if (errorMsg != null && !errorMsg.isEmpty())
			return errorMsg;
		FileParser parser = new FileParser();

		List<Map<Integer, List<DataRow>>> list = parser.parseDataFile(dataFile);
		Map<Integer, List<DataRow>> rowDataMap = list.get(0);
		Map<Integer, List<DataRow>> rowDataMapByThreadId = list.get(1);
		Map<Integer, List<String>> threadRequestURL = parser.parseLog(logFile);
		
		
		/*---- set the start time and end time, update the test brief---- */
		TestAnalyzer testAnalyzer = new TestAnalyzer();
		testAnalyzer.setItemDataMap(rowDataMap);
		testBrief.setStartTime(new Date(testAnalyzer.getTestStartTime()));
		testBrief.setEndTime(new Date(testAnalyzer.getTestEndTime()));
		testBriefService.updateTestBreif(testBrief);
		/*------------------------------------------------------------- */
		
		
		RequestAnalyzer requestAnalyzer = new RequestAnalyzer(rowDataMap, collection, rowDataMapByThreadId, threadRequestURL);
		// get request statistics list
		logger.debug("start request summary");
		List<RequestStatistics> requestSummaryList = requestAnalyzer.getRequestSummaryList();

		for (RequestStatistics requestStatistics : requestSummaryList)
		{
			Request request = requestAnalyzer.getRequestByTestId().get(Integer.parseInt(requestStatistics.getRequestName()));
			RequestStatistics rsClone = cloneRequestStac(requestStatistics);
			rsClone.setRequestName(request.getRequestName());
			rsClone.setItemName(request.getItemName());
			logger.debug(rsClone);
			requestStatisticsService.addRequestStatistics(rsClone);
		}

		// get requet detail list
		logger.debug("start request detail");
		List<RequestDetail> requestDetailList = requestAnalyzer.getRequestDetailList();
		for (RequestDetail requestDetail : requestDetailList)
		{
			Request request = requestAnalyzer.getRequestByTestId().get(Integer.parseInt(requestDetail.getRequestName()));
			RequestDetail rdClone = cloneRequestDetail(requestDetail);
			rdClone.setRequestName(request.getRequestName());
			rdClone.setItemName(request.getItemName());
			logger.debug(rdClone);
			requestDetailService.addRequestDetail(rdClone);
		}

		ItemAnalyzer itemAnalyzer = new ItemAnalyzer(rowDataMap, requestSummaryList, collection,rowDataMapByThreadId, isServiceCall);
		// get item summary list
		List<ItemStatistics> itemSummaryList = itemAnalyzer.getItemSummaryList();
		logger.debug("start item summary");
		for (ItemStatistics itemStatistics : itemSummaryList)
		{
			String itemName = itemAnalyzer.getItemNameByTestId().get(Integer.parseInt(itemStatistics.getItemName()));
			ItemStatistics isClone = cloneItemStatistics(itemStatistics);
			isClone.setItemName(itemName);
			logger.debug(isClone);
			itemStatisticsSerice.addItemStatistics(isClone);
		}

		logger.debug("start item detail");
		// get item detail list
		List<ItemDetail> itemDetailList = itemAnalyzer.getItemDetailList();
		for (ItemDetail itemDetail : itemDetailList)
		{
			String itemName = itemAnalyzer.getItemNameByTestId().get(Integer.parseInt(itemDetail.getItemName()));
			ItemDetail idClone = cloneItemDetail(itemDetail);
			idClone.setItemName(itemName);
			logger.debug(idClone);
			itemDetailService.addItemDetail(idClone);
		}

//		TestAnalyzer testAnalyzer = new TestAnalyzer(rowDataMap, itemSummaryList, testBrief, outputFolder.getAbsolutePath());
		testAnalyzer.setItemSummaryList(itemSummaryList);
		testAnalyzer.setOutputFolder(outputFolder.getAbsolutePath());
		testAnalyzer.setTestBrief(testBrief);
		TestBrief testBriefWithResult = testAnalyzer.getTestBrief();

		logger.debug(testBriefWithResult);

		testBriefService.updateTestBreif(testBriefWithResult);

		return errorMsg;
	}

	private boolean isEmptyData(File dataFile) throws IOException
	{
		RandomAccessFile rf = null;
		String secondLine = null;
		try
		{
			rf = new RandomAccessFile(dataFile, "r");
			rf.readLine();// skip the first line
			secondLine = rf.readLine();
		}
		catch (IOException e)
		{
			throw e;
		}
		finally
		{
			if (rf != null)
				rf.close();
		}
		return secondLine == null || secondLine.isEmpty();
	}

	private String readContents(File fileName) throws IOException
	{
		StringBuilder contents = new StringBuilder();
		char[] buffer = new char[128];
		FileReader reader = null;
		try
		{
			reader = new FileReader(fileName);

			while (-1 != reader.read(buffer))
				contents.append(buffer);
		}
		catch (IOException e)
		{
			logger.error(e.getMessage(), e);
			throw new IOException(e.getMessage(), e);
		}
		finally
		{
			if (reader != null)
				reader.close();
		}

		return contents.toString();
	}

	private String scanErrorLog(File logFile, boolean breakOnFind) throws Exception
	{
		StringBuilder sb = new StringBuilder();
		RandomAccessFile rf = null;
		String line = "";
		boolean isFirstError = true;
		try
		{
			rf = new RandomAccessFile(logFile, "r");
			while ((line = rf.readLine()) != null)
			{
				if (isErrorLog(line))// error log start
				{
					if (isFirstError)
					{
						isFirstError = false;
					}
					else
					{
						if (breakOnFind)
							break;
					}

				}
				else if ((line.startsWith("\t") || isInfoLog(line)) || isFirstError)// error
																					// detail
																					// or
																					// info
																					// log,
																					// needless
					continue;
				else if (isStatisticStart(line))// statistic start, we need not
												// to go on
					break;
				sb.append(line);
				sb.append("\n");
			}
		}
		catch (Exception e)
		{
			logger.error(e.getMessage(), e);
			throw new Exception(e.getMessage(), e);
		}
		return sb.toString();
	}

	public String getErrorMsg(File outputFolder, TestBrief testBrief) throws Exception
	{
		File[] files = outputFolder.listFiles();
		for (File file : files)
		{
			if (file.getName().endsWith("-0-data.log"))
			{
				dataFile = file;

			}
			if (file.getName().endsWith("-0.log"))
			{
				logFile = file;
			}
			// TODO use constants
			if ("console.out".equals(file.getName()))
			{
				consoleOut = file;
			}
		}

		assert consoleOut != null;

		// must be some fatal error, cause the engine failed to start the only
		// log we can get is from console.out
		String errorMsg = null;
		if (dataFile == null || logFile == null)
		{
			errorMsg = readContents(consoleOut);
			int briefId = testBrief.getBriefId();
			TestError error = new TestError();
			error.setBriefId(briefId);
			error.setErrorDetail(errorMsg);
			error.setErrorType(ErrorType.OUTSIDE);
			error.setErrorMessage(errorMsg);
			testErrorService.addTestError(error);
			testBrief.setStatus(TestBriefStatusConstants.TESTEXCEPTION);
			testBriefService.updateTestBreif(testBrief);
			return errorMsg;
		}

		// engine start and run the script, but no performance data has been
		// recorded
		// we need to scan the log and find errors
		if (isEmptyData(dataFile))
		{
			errorMsg = scanErrorLog(logFile, true);
			int briefId = testBrief.getBriefId();
			TestError error = new TestError();
			error.setBriefId(briefId);
			error.setErrorDetail(errorMsg);
			error.setErrorType(ErrorType.OUTSIDE);
			error.setErrorMessage(errorMsg);
			testErrorService.addTestError(error);
			testBrief.setStatus(TestBriefStatusConstants.TESTEXCEPTION);
			testBriefService.updateTestBreif(testBrief);
		}
		return errorMsg;
	}
	
	public String getErrorMsg(File outputFolder) throws Exception{
		File[] files = outputFolder.listFiles();
		for (File file : files)
		{
			if (file.getName().endsWith("-0-data.log"))
			{
				dataFile = file;

			}
			if (file.getName().endsWith("-0.log"))
			{
				logFile = file;
			}
			// TODO use constants
			if ("console.out".equals(file.getName()))
			{
				consoleOut = file;
			}
		}

		assert consoleOut != null;

		// must be some fatal error, cause the engine failed to start the only
		// log we can get is from console.out
		String errorMsg = null;
		if (dataFile == null || logFile == null)
		{
			errorMsg = readContents(consoleOut);
			return errorMsg;
		}

		// engine start and run the script, but no performance data has been
		// recorded
		// we need to scan the log and find errors
		if (isEmptyData(dataFile))
		{
			errorMsg = scanErrorLog(logFile, true);
		}
		return errorMsg;
	}

	/**
	 * 
	 * @param str
	 * @return
	 */
	public boolean isErrorLog(String str)
	{
		Matcher matcher = ERROR_PATTERN.matcher(str);
		return matcher.matches();
	}

	/**
	 * 
	 * @param str
	 * @return
	 */
	public boolean isInfoLog(String str)
	{
		Matcher matcher = INFO_PATTERN.matcher(str);
		return matcher.matches();
	}

	/**
	 * 
	 * @param str
	 * @return
	 */
	public boolean isStatisticStart(String str)
	{
		Matcher matcher = STATISTIC_PATTERN.matcher(str);
		return matcher.matches();
	}

	/**
	 * 
	 * @param appAnalyzer
	 * @return
	 */
	public String getWarnMesg()
	{
		return warnMsg;
	}

	private RequestStatistics cloneRequestStac(RequestStatistics rs)
	{
		RequestStatistics rsClone = new RequestStatistics();

		rsClone.setAvgResponseTime(rs.getAvgResponseTime());
		rsClone.setBriefId(rs.getBriefId());
		rsClone.setErrorCount(rs.getErrorCount());
		rsClone.setErrorRate(rs.getErrorRate());
		rsClone.setExecutionCount(rs.getExecutionCount());
		rsClone.setItemId(rs.getItemId());
		rsClone.setItemName(rs.getItemName());
		rsClone.setMaxResponseTime(rs.getMaxResponseTime());
		rsClone.setMinResponseTime(rs.getMinResponseTime());
		rsClone.setNinetyResponseTime(rs.getNinetyResponseTime());
		rsClone.setPlanId(rs.getPlanId());
		rsClone.setRequestId(rs.getRequestId());
		rsClone.setRequestName(rs.getRequestName());
		rsClone.setStdResponseTime(rs.getStdResponseTime());

		return rsClone;
	}

	private RequestDetail cloneRequestDetail(RequestDetail rd)
	{
		RequestDetail rdClone = new RequestDetail();
		rdClone.setBodySize(rd.getBodySize());
		rdClone.setBriefId(rd.getBriefId());
		rdClone.setError(rd.isError());
		rdClone.setItemId(rd.getItemId());
		rdClone.setItemName(rd.getItemName());
		rdClone.setPlanId(rd.getPlanId());
		rdClone.setRequestId(rd.getRequestId());
		rdClone.setRequestName(rd.getRequestName());
		rdClone.setRequestURL(rd.getRequestURL());
		rdClone.setResponseTime(rd.getResponseTime());
		rdClone.setReturnCode(rd.getReturnCode());
		rdClone.setStartTime(rd.getStartTime());
		rdClone.setThread(rd.getThread());
		rdClone.setVuId(rd.getVuId());

		return rdClone;

	}

	private ItemStatistics cloneItemStatistics(ItemStatistics is)
	{
		ItemStatistics isClone = new ItemStatistics();
		isClone.setAvgResponseTime(is.getAvgResponseTime());
		isClone.setBriefId(is.getBriefId());
		isClone.setErrorCount(is.getErrorCount());
		isClone.setErrorRate(is.getErrorRate());
		isClone.setExecutionCount(is.getExecutionCount());
		isClone.setItemId(is.getItemId());
		isClone.setItemName(is.getItemName());
		isClone.setMaxResponseTime(is.getMaxResponseTime());
		isClone.setMinResponseTime(is.getMinResponseTime());
		isClone.setNinetyResponseTime(is.getNinetyResponseTime());
		isClone.setPassed(is.getIsPassed());
		isClone.setPlanId(is.getPlanId());
		isClone.setRequestCount(is.getRequestCount());
		isClone.setRequirementId(is.getRequirementId());
		isClone.setStdResponseTime(is.getStdResponseTime());
		return isClone;

	}

	private ItemDetail cloneItemDetail(ItemDetail id)
	{
		ItemDetail idClone = new ItemDetail();
		idClone.setBriefId(id.getBriefId());
		idClone.setItemId(id.getItemId());
		idClone.setItemName(id.getItemName());
		idClone.setPlanId(id.getPlanId());
		idClone.setResponseTime(id.getResponseTime());
		idClone.setStartTime(id.getStartTime());
		idClone.setThread(id.getThread());
		idClone.setVuId(id.getVuId());
		return idClone;

	}
}
