package com.ssc.sshz.peg.ptaf.inspection.test.generator;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;
import com.ssc.sshz.peg.ptaf.inspection.test.generator.bean.LoginScriptParamBean;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;

public class LoginScriptGenerator
{

    private File assetFolder;

    public LoginScriptGenerator(File assetFolder)
    {
	this.assetFolder = assetFolder;
    }

    /**
     * 
     * @param loginBean
     * @return the generated file
     * @throws IOException
     */
    public File generateLoginScript(LoginScriptParamBean loginBean) throws IOException
    {
	File loginScript = null;

	String url = loginBean.getUrl();
	String context = loginBean.getContext();

	if (!loginBean.isNeedLogin())
	{
	    loginScript = new File(assetFolder, "EmptyLogin.py");
	    generateEmptyLogin(loginScript);
	    return loginScript;
	}
	else
	{
	    Map<String, String> loginParamMap = new HashMap<String, String>();
	    loginParamMap.put("${url}", FileUtil.getInstance().quot(url));
	    loginParamMap.put("${context}", FileUtil.getInstance().quot(context));
//	    if (loginBean.isUsePwMatrix())
//	    {
//		loginParamMap.put("${importPwMatrix}", "from Matrix import PwMatrix");
//		String server = FileUtil.getInstance().quot(loginBean.getServer());
//		String user = FileUtil.getInstance().quot(loginBean.getUser());
//		loginParamMap.put("${username}", user);
//		loginParamMap.put("${password}", "PwMatrix.getPassword(" +server+ ", " + user + ")");
//	    }
//	    else
//	    {
		loginParamMap.put("${importPwMatrix}", "");
//		loginParamMap.put("${vuFile}", FileUtil.getInstance().quot(assetFolder + File.separator + loginBean.getUserFile().getName()));
		loginParamMap.put("${vuFile}", FileUtil.getInstance().quot(loginBean.getUserFile().getName()));
		loginParamMap.put("${username}", FileUtil.getInstance().quot(loginBean.getUsername()));
		loginParamMap.put("${password}", FileUtil.getInstance().quot(loginBean.getPassword()));
//	    }
	    if (isCloudURL(url))
	    {
		loginScript = new File(assetFolder, "CloudLogin.py");
		generateCloudLogin(loginScript, loginParamMap);
	    }
	    else
	    {
		loginScript = new File(assetFolder, "LocalLogin.py");
		generateLocalLogin(loginScript, loginParamMap);
	    }

	    return loginScript;
	}

    }

    private boolean isCloudURL(String url)
    {
//	String regex = "https://cloud-?.*\\.statestr\\.com/?.*";
//	return Pattern.matches(regex, url);
    	String regex1 = "https://cloud-?.*\\.statestr\\.com/?.*";
    	String regex2 = "https://tde-?.*\\.statestr\\.com/?.*";
    	return Pattern.matches(regex1, url) || Pattern.matches(regex2, url);
    }

    public void generateCloudLogin(File loginFile, Map<String, String> varMap) throws IOException
    {
	InputStream in = LoginScriptGenerator.class.getResourceAsStream(TestAssetContants.CLOUD_LOGIN_SCRIPT_TMP);
	FileUtil.getInstance().createScriptContents(varMap, in, loginFile);
    }

    public void generateLocalLogin(File loginFile, Map<String, String> varMap) throws IOException
    {
	InputStream in = LoginScriptGenerator.class.getResourceAsStream(TestAssetContants.LOCAL_LOGIN_SCRIPT_TMP);
	FileUtil.getInstance().createScriptContents(varMap, in, loginFile);
    }

    private void generateEmptyLogin(File loginFile) throws IOException
    {
	InputStream in = LoginScriptGenerator.class.getResourceAsStream(TestAssetContants.EMPTY_LOGIN_SCRIPT_TMP);
	FileUtil.getInstance().copyFile(in, loginFile);
    }
}
