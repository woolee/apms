package com.ssc.sshz.peg.ptaf.inspection.analysis.data.bean;

public class GbService
{
	private int serviceNumber;
	private int requestId;
	public int getServiceNumber()
	{
		return serviceNumber;
	}
	public void setServiceNumber(int serviceNumber)
	{
		this.serviceNumber = serviceNumber;
	}
	public int getRequestId()
	{
		return requestId;
	}
	public void setRequestId(int requestId)
	{
		this.requestId = requestId;
	}
	public GbService(int serviceNumber, int requestId)
	{
		super();
		this.serviceNumber = serviceNumber;
		this.requestId = requestId;
	}
	

}
