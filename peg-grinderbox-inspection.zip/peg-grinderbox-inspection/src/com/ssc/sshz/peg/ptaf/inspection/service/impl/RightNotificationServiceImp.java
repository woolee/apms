package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.RightNotification;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightNotificationDao;
import com.ssc.sshz.peg.ptaf.inspection.service.RightNotificationService;
@Service
public class RightNotificationServiceImp<T extends RightNotification> implements RightNotificationService<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private RightNotificationDao<T> dao;
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addRightNotification(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return dao.addRightNotification(entity);
	}


	
}
