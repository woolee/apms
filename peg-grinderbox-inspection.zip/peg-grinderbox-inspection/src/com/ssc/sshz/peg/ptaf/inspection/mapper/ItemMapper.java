package com.ssc.sshz.peg.ptaf.inspection.mapper;
import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
public interface ItemMapper extends SqlMapper{
	public void addItem(Item item);
	public Item getItemByName(String name);
	public Item getItemBySystemIdItemName(Item item);
	public Item getItemById(int id);
	public List<Item> getAllItem();
	public List<Item> getItemBySystemId(int sysId);
}
