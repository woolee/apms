package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.mybatis.generator.api.MyBatisGenerator;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.xml.ConfigurationParser;
import org.mybatis.generator.exception.InvalidConfigurationException;
import org.mybatis.generator.exception.XMLParserException;
import org.mybatis.generator.internal.DefaultShellCallback;

import com.ssc.sshz.peg.ptaf.inspection.analysis.AnalyzeManager;

public class MybatisGenerator {
	 private static final Logger logger = Logger.getLogger(MybatisGenerator.class);
	public static void main(String[] args){
		if(mabatisGenerator()){
			System.out.println("mybatis successes to auto generate your bean.java, mapper.xml,mapper.java !");
			logger.debug("mybatis successes to auto generate your bean.java, mapper.xml,mapper.java !");
		}else{
			System.out.println("mybatis fails to auto generate your bean.java, mapper.xml,mapper.java !");
			logger.debug("mybatis fails to auto generate your bean.java, mapper.xml,mapper.java !");
		}
	}
	
	public static boolean mabatisGenerator(){
		
		boolean returnFlag = true;
		List<String> warnings = new ArrayList<String>();
		boolean overwrite = true;
		
		//System.out.println(System.getProperty("user.dir"));
		String mybatisGeneratorFilePath = System.getProperty("user.dir")+"\\src\\mybatis-generator.xml";
		File configFile = new File(mybatisGeneratorFilePath);
		ConfigurationParser cp = new ConfigurationParser(warnings);
		Configuration config = null;
		try {
			config = cp.parseConfiguration(configFile);
		} catch (IOException e) {
			returnFlag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		} catch (XMLParserException e) {
			returnFlag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		DefaultShellCallback callback = new DefaultShellCallback(overwrite);
		MyBatisGenerator myBatisGenerator = null;
		try {
			myBatisGenerator = new MyBatisGenerator(config, callback, warnings);
		} catch (InvalidConfigurationException e) {
			returnFlag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		try {
			myBatisGenerator.generate(null);
		} catch (SQLException e) {
			returnFlag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		} catch (IOException e) {
			returnFlag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		} catch (InterruptedException e) {
			returnFlag = false;
			logger.error(e.getMessage(),e);
			e.printStackTrace();
		}
		
		return returnFlag;
		
	}

}
