package com.ssc.sshz.peg.ptaf.inspection.dao;


import java.util.List;

import org.springframework.dao.DataAccessException;

public interface UserRightDao<T> {
	
	public boolean addUserRight(T entity) throws DataAccessException;
	
	public List<T> getUserRightByUserId(int userId) throws DataAccessException;
}
