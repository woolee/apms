package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.UserGroup;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserGroupDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.UserGroupMapper;

@Repository
public class UserGroupDaoImpl<T extends UserGroup> implements UserGroupDao<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private UserGroupMapper mapper;


	@Override
	public boolean addUserGroup(T entity) throws DataAccessException
	{
		boolean flag = false;
		try
		{
			mapper.addUserGroup(entity);
			flag = true;
		}
		catch (Exception e)
		{
			flag = false;
			logger.error("Exception while add userGroup to database",e);
			throw new DaoException("Exception while add userGroup to database",e);
		}
		return flag;
	}


	@Override
	public List<T> getUserGroupByUserId(int userId) throws DataAccessException
	{
		List<T> list = null;
		try
		{
			list = (List<T>) mapper.getUserGroupByUserId(userId);
		}
		catch (Exception e)
		{
			logger.error("Exception while get userGroup by userId to database",e);
			throw new DaoException("Exception while get userGroup by userId to database",e);
		}
		return list;
	}

}
