package com.ssc.sshz.peg.ptaf.inspection.test.generator;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import com.ssc.sshz.peg.ptaf.inspection.test.constants.TestAssetContants;
import com.ssc.sshz.peg.ptaf.inspection.util.FileUtil;

public class ParmFileGenerator
{

    /**
     * 
     * @param source the file names need to be generated
     * @param paramFolder from
     * @param assetFolder to 
     * @return the generated files
     * @throws IOException
     */
    public Set<File> generateParamFile(Set<File> source, File assetFolder) throws IOException
    {

	Set<File> paramFiles = new HashSet<File>();
	
	File paramDest = new File(assetFolder, TestAssetContants.PARAMFOLDER);
	FileUtil.getInstance().checkAndCreateFolder(paramDest);

	for (File file : source)
	{
	    File destFile = new File(paramDest, file.getName());
	    FileUtil.getInstance().copyFile(file, destFile);
	    paramFiles.add(destFile);
	    
	}

	return paramFiles;

    }

}
