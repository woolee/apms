package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.service.RegistrationService;

@Service
public class RegistrationServiceImp<T extends User> implements RegistrationService<T> {
	
	@Inject
	private UserDao<T> userDao;

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addUser(T entity) throws DataAccessException {
		return userDao.addUser(entity);
		}

	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public T getUser(T entity) throws DataAccessException {
		return userDao.getUserByName(entity.getUserName());
	}
	
	/**
	 * get all users in database and return the  list of username
	 * @return 
	 * @throws DataAccessException
	 */
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<String> getAllUser() throws DataAccessException {
		List<User> users = (List<User>) userDao.getAllUsers();
		List<String> nameList = new ArrayList<String>();
		for (User user : users)
		{
			nameList.add(user.getUserName());
		}
		return nameList;
	}
	
}
