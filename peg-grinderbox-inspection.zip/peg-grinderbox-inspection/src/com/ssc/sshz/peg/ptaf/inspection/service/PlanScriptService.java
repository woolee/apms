package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import org.springframework.dao.DataAccessException;


public interface PlanScriptService<T>{
	
	public boolean addPlanScript(T entity) throws DataAccessException;
	public List<T> getAllPlanScript()throws DataAccessException;
	public T getPlanScript(T entity)throws DataAccessException;
	public T getPlanScriptByPlanId(int PlanId)throws DataAccessException;
	
}
