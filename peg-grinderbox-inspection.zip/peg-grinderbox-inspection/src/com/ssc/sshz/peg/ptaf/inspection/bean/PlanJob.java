package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

public class PlanJob implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1311311282545739268L;
	private int PlanJobId;
	private int planId;
	private String schedulerInsName;
	private String groupName;
	private String jobName;
	private String triggerName;
	public String getJobName()
	{
		return jobName;
	}
	public void setJobName(String jobName)
	{
		this.jobName = jobName;
	}
	public String getSchedulerInsName()
	{
		return schedulerInsName;
	}
	public void setSchedulerInsName(String schedulerInsName)
	{
		this.schedulerInsName = schedulerInsName;
	}
	public String getGroupName()
	{
		return groupName;
	}
	public void setGroupName(String groupName)
	{
		this.groupName = groupName;
	}
	public int getPlanJobId()
	{
		return PlanJobId;
	}
	public void setPlanJobId(int planJobId)
	{
		PlanJobId = planJobId;
	}
	public int getPlanId()
	{
		return planId;
	}
	public void setPlanId(int planId)
	{
		this.planId = planId;
	}
	public String getTriggerName()
	{
		return triggerName;
	}
	public void setTriggerName(String triggerName)
	{
		this.triggerName = triggerName;
	}
}
