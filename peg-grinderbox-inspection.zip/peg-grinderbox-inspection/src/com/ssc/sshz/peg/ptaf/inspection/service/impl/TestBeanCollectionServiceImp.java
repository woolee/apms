package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Requirement;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.dao.ItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.PlanItemDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.ProjectDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequestDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RequirementDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.SystemDao;
import com.ssc.sshz.peg.ptaf.inspection.service.TestBeanCollectionService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;

@Service
public class TestBeanCollectionServiceImp<T> implements TestBeanCollectionService<T>
{
	
	@Inject
	private PlanItemDao<PlanItem> planItemDao;
	
	@Inject
	private ItemDao<Item> itemDao;
	
	@Inject
	private RequestDao<Request> requestDao;
	
	@Inject
	private SystemDao<System> systemDao;
	
	@Inject
	private PlanDao<Plan> planDao;
	
	@Inject
	private ProjectDao<Project> projectDao;
	
	@Inject
	private RequirementDao<Requirement> requirementDao;
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public TestBeanCollection setCollectionWithPlanId(int planId) throws DataAccessException
	{
		TestBeanCollection collection = new TestBeanCollection();
		Map<Integer, List<Request>> requestMapByItemId = new HashMap<Integer, List<Request>>();
		List<PlanItem> planItemList = planItemDao.getAllPlanItemByPlanId(planId);
		List<Item> itemList = new ArrayList<Item>();
		for (int i = 0; i < planItemList.size(); i++) {
			itemList.add(itemDao.getItemById(planItemList.get(i).getItemId()));
			Request r = new Request();
			r.setPlanId(planId);
			r.setItemId(planItemList.get(i).getItemId());
			List<Request> requestList = requestDao.getRequestByItemIdAndPlanId(r);
			requestMapByItemId.put(planItemList.get(i).getItemId(), requestList);
		}
		
		Map<Integer,Requirement> requirementByItemId = new HashMap<Integer, Requirement>();
		for (Item item : itemList)
		{
			Requirement require = requirementDao.getRequirementByItemId(item.getItemId());
			requirementByItemId.put(item.getItemId(), require);
		}
	    //get plan
	    Plan plan= planDao.getPlanById(planId);
	    //get system
	    System system=systemDao.getSystemById(plan.getSystemId());
	    //get project
	    Project project=projectDao.getProjectById(system.getProjectId());
	    
		collection.setProject(project);
		collection.setSystem(system);
		collection.setPlan(plan);
		collection.setItemList(itemList);
		collection.setRequestMapByItemId(requestMapByItemId);
		
		return collection;
	}
}
