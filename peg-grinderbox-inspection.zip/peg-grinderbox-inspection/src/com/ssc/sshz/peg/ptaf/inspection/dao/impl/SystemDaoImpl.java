package com.ssc.sshz.peg.ptaf.inspection.dao.impl;

import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.dao.SystemDao;
import com.ssc.sshz.peg.ptaf.inspection.exception.DaoException;
import com.ssc.sshz.peg.ptaf.inspection.mapper.SystemMapper;

@Repository
public class SystemDaoImpl<T extends System> implements SystemDao<T>{

	 private static final Logger logger = Logger.getLogger(SystemDaoImpl.class);
	 
	@Inject
	private SystemMapper mapper;

	@Override
	public boolean addSystem(T entity) throws DataAccessException {

		boolean flag = false;
		try {
			mapper.addSystem(entity); 
			flag = true; 
			} 
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while add system to database",e);
			throw new DaoException("Exception while add system to database",e);
		}
		return flag;
	
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getSystemById(Integer id) throws DataAccessException {
		T entity=null;
		try{ 
			entity = (T) mapper.getSystemById(id);
			}
		catch(Exception e)
		{
			logger.error("Exception while get system by id from database",e);
			throw new DaoException("Exception while get system by id from database",e);
		}
		return entity;
	}

	@Override
	public boolean delSystemById(Integer id) throws DataAccessException {

		boolean flag = false;
		try {
			mapper.delSystem(id); 
			flag = true; 
			} 
		catch(Exception e)
		{
			flag = false;
			logger.error("Exception while delete system by id from database",e);
			throw new DaoException("Exception while delete system by id from database",e);
		}
		return flag;
	
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllSystem() throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getAllSystem();
			}
		catch(Exception e)
		{
			logger.error("Exception while get all system from database",e);
			throw new DaoException("Exception while get all system from database",e);
		}
		return entity;
		}

	@SuppressWarnings("unchecked")
	@Override
	public T getSystemByName(String name) throws DataAccessException {
		T entity=null;
		try{ 
			entity = (T) mapper.getSystemByName(name);
			}
		catch(DataAccessException e)
		{
			logger.error("Exception while get system by name from database",e);
			throw new DaoException("Exception while get system by name from database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<T> getSystemByProjectName(String name) throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getSystemByProjectName(name);
			}
		catch(Exception e)
		{
			logger.error("Exception while get system by project name from database",e);
			throw new DaoException("Exception while get system by project name from database",e);
		}
		return entity;
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getSystemByNameVersionEnv(System system)
			throws DataAccessException {
		T entity=null;
		try{ 
			entity = (T) mapper.getSystemByNameVersionEnv(system);
			}
		catch(Exception e)
		{
			logger.error("Exception while get system by name, version and env from database",e);
			throw new DaoException("Exception while get system by name, version and env from database",e);
		}
		return entity;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T getSystemByuuid(String id) throws DataAccessException {
		T entity=null;
		try{ 
			entity = (T) mapper.getSystemByuuid(id);
			}
		catch(Exception e)
		{
			logger.error("Exception while get system by uuid from database",e);
			throw new DaoException("Exception while get system by uuid from database",e);
		}
		return entity;
	}

	@Override
	public List<T> getSystemByProjectId(int id) throws DataAccessException {
		List<T> entity = null;
		try{ 
			entity = (List<T>) mapper.getSystemByProjectId(id);
			}
		catch(Exception e)
		{
			logger.error("Exception while get system by project name from database",e);
			throw new DaoException("Exception while get system by project id from database",e);
		}
		return entity;
		
	}



}
