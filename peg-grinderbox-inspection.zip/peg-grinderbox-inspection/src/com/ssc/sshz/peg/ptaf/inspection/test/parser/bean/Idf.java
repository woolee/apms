package com.ssc.sshz.peg.ptaf.inspection.test.parser.bean;

import java.util.ArrayList;


/**
 * This class has getters and setters for IDF parameters
 * 
 * @author p472061
 * 
 */
public class Idf
{

    private String idfCreatedBy;
    private String idfCreatedAt;
    private String reqNumber;
    private String reqName;
    private String reqCacheable;
    private String basicVersion;
    private String basicPrivate;
    private String basicCrud;
    private String dataEntitementModel;
    private String detailDesc;
    private String detailKeyWord;
    private String srcCode;
    private String srcTech;
    private String srcDesc;
    private String specialRemarks;
    private String appCode;
    private String costCenter;
    private String organization;
    private String functionGroup;
    private String usageConstraint;
    private String dependsWebServices;
    private String dataClassification;
    private ArrayList<Inputs> inputList = new ArrayList<Inputs>();
    private ArrayList<Outputs> outputList = new ArrayList<Outputs>();

    /**
     * @return the idfCreatedBy
     */
    public String getIdfCreatedBy()
    {
	return idfCreatedBy;
    }

    /**
     * @param idfCreatedBy
     *                the idfCreatedBy to set
     */
    public void setIdfCreatedBy(String idfCreatedBy)
    {
	this.idfCreatedBy = idfCreatedBy;
    }

    /**
     * @return the idfCreatedAt
     */
    public String getIdfCreatedAt()
    {
	return idfCreatedAt;
    }

    /**
     * @param idfCreatedAt
     *                the idfCreatedAt to set
     */
    public void setIdfCreatedAt(String idfCreatedAt)
    {
	this.idfCreatedAt = idfCreatedAt;
    }

    /**
     * @return the reqNumber
     */
    public String getReqNumber()
    {
	return reqNumber;
    }

    /**
     * @param reqNumber
     *                the reqNumber to set
     */
    public void setReqNumber(String reqNumber)
    {
	this.reqNumber = reqNumber;
    }

    /**
     * @return the reqName
     */
    public String getReqName()
    {
	return reqName;
    }

    /**
     * @param reqName
     *                the reqName to set
     */
    public void setReqName(String reqName)
    {
	this.reqName = reqName;
    }

    /**
     * @return the reqCacheable
     */
    public String getReqCacheable()
    {
	return reqCacheable;
    }

    /**
     * @param reqCacheable
     *                the reqCacheable to set
     */
    public void setReqCacheable(String reqCacheable)
    {
	this.reqCacheable = reqCacheable;
    }

    /**
     * @return the basicVersion
     */
    public String getBasicVersion()
    {
	return basicVersion;
    }

    /**
     * @param basicVersion
     *                the basicVersion to set
     */
    public void setBasicVersion(String basicVersion)
    {
	this.basicVersion = basicVersion;
    }

    /**
     * @return the basicPrivate
     */
    public String getBasicPrivate()
    {
	return basicPrivate;
    }

    /**
     * @param basicPrivate
     *                the basicPrivate to set
     */
    public void setBasicPrivate(String basicPrivate)
    {
	this.basicPrivate = basicPrivate;
    }

    /**
     * @return the basicCrud
     */
    public String getBasicCrud()
    {
	return basicCrud;
    }

    /**
     * @param basicCrud
     *                the basicCrud to set
     */
    public void setBasicCrud(String basicCrud)
    {
	this.basicCrud = basicCrud;
    }

    /**
     * @return the dataEntitementModel
     */
    public String getDataEntitementModel()
    {
	return dataEntitementModel;
    }

    /**
     * @param dataEntitementModel
     *                the dataEntitementModel to set
     */
    public void setDataEntitementModel(String dataEntitementModel)
    {
	this.dataEntitementModel = dataEntitementModel;
    }

    /**
     * @return the detailDesc
     */
    public String getDetailDesc()
    {
	return detailDesc;
    }

    /**
     * @param detailDesc
     *                the detailDesc to set
     */
    public void setDetailDesc(String detailDesc)
    {
	this.detailDesc = detailDesc;
    }

    /**
     * @return the detailKeyWord
     */
    public String getDetailKeyWord()
    {
	return detailKeyWord;
    }

    /**
     * @param detailKeyWord
     *                the detailKeyWord to set
     */
    public void setDetailKeyWord(String detailKeyWord)
    {
	this.detailKeyWord = detailKeyWord;
    }

    /**
     * @return the srcCode
     */
    public String getSrcCode()
    {
	return srcCode;
    }

    /**
     * @param srcCode
     *                the srcCode to set
     */
    public void setSrcCode(String srcCode)
    {
	this.srcCode = srcCode;
    }

    /**
     * @return the srcDesc
     */
    public String getSrcDesc()
    {
	return srcDesc;
    }

    /**
     * @param srcDesc
     *                the srcDesc to set
     */
    public void setSrcDesc(String srcDesc)
    {
	this.srcDesc = srcDesc;
    }

    /**
     * @return the srcTech
     */
    public String getSrcTech()
    {
	return srcTech;
    }

    /**
     * @param srcTech
     *                the srcTech to set
     */
    public void setSrcTech(String srcTech)
    {
	this.srcTech = srcTech;
    }

    /**
     * @return the specialRemarks
     */
    public String getSpecialRemarks()
    {
	return specialRemarks;
    }

    /**
     * @param specialRemarks
     *                the specialRemarks to set
     */
    public void setSpecialRemarks(String specialRemarks)
    {
	this.specialRemarks = specialRemarks;
    }

    /**
     * @return the appCode
     */
    public String getAppCode()
    {
	return appCode;
    }

    /**
     * @param appCode
     *                the appCode to set
     */
    public void setAppCode(String appCode)
    {
	this.appCode = appCode;
    }

    /**
     * @return the costCenter
     */
    public String getCostCenter()
    {
	return costCenter;
    }

    /**
     * @param costCenter
     *                the costCenter to set
     */
    public void setCostCenter(String costCenter)
    {
	this.costCenter = costCenter;
    }

    /**
     * @return the organization
     */
    public String getOrganization()
    {
	return organization;
    }

    /**
     * @param organization
     *                the organization to set
     */
    public void setOrganization(String organization)
    {
	this.organization = organization;
    }

    /**
     * @return the functionGroup
     */
    public String getFunctionGroup()
    {
	return functionGroup;
    }

    /**
     * @param functionGroup
     *                the functionGroup to set
     */
    public void setFunctionGroup(String functionGroup)
    {
	this.functionGroup = functionGroup;
    }

    /**
     * @return the usageConstraint
     */
    public String getUsageConstraint()
    {
	return usageConstraint;
    }

    /**
     * @param usageConstraint
     *                the usageConstraint to set
     */
    public void setUsageConstraint(String usageConstraint)
    {
	this.usageConstraint = usageConstraint;
    }

    /**
     * @return the dependsWebServices
     */
    public String getDependsWebServices()
    {
	return dependsWebServices;
    }

    /**
     * @param dependsWebServices
     *                the dependsWebServices to set
     */
    public void setDependsWebServices(String dependsWebServices)
    {
	this.dependsWebServices = dependsWebServices;
    }

    /**
     * @return the inputList
     */
    public ArrayList<Inputs> getInputList()
    {
	return inputList;
    }

    /**
     * @param inputList
     *                the inputList to set
     */
    public void setInputList(ArrayList<Inputs> inputList)
    {
	this.inputList = inputList;
    }

    /**
     * @return the outputList
     */
    public ArrayList<Outputs> getOutputList()
    {
	return outputList;
    }

    /**
     * @param outputList
     *                the outputList to set
     */
    public void setOutputList(ArrayList<Outputs> outputList)
    {
	this.outputList = outputList;
    }

    /**
     * @return the dataClassification
     */
    public String getDataClassification()
    {
	return dataClassification;
    }

    /**
     * @param dataClassification the dataClassification to set
     */
    public void setDataClassification(String dataClassification)
    {
	this.dataClassification = dataClassification;
    }
}
