package com.ssc.sshz.peg.ptaf.inspection.service.impl;


import java.util.List;

import javax.inject.Inject;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ssc.sshz.peg.ptaf.inspection.bean.Group;
import com.ssc.sshz.peg.ptaf.inspection.bean.GroupRight;
import com.ssc.sshz.peg.ptaf.inspection.bean.Right;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.bean.UserGroup;
import com.ssc.sshz.peg.ptaf.inspection.dao.GroupDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.GroupRightDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.RightDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserDao;
import com.ssc.sshz.peg.ptaf.inspection.dao.UserGroupDao;
import com.ssc.sshz.peg.ptaf.inspection.service.UserGroupService;
@Service
public class UserGroupServiceImp<T extends UserGroup> implements UserGroupService<T>
{
	Logger logger = Logger.getLogger(getClass());
	@Inject
	private UserGroupDao<T> userGroupDao;
	
	@Inject
	private GroupDao<Group> groupDao;
	
	@Inject
	private RightDao<Right> rightDao;
	
	@Inject
	private GroupRightDao<GroupRight> groupRightDao;
	
	@Inject
	private UserDao<User> userDao;
	
	public static final String GROUP_NAME_POSTFIX = "_ADMIN";
	
	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public boolean addUserGroup(T entity) throws DataAccessException
	{
		// TODO Auto-generated method stub
		return userGroupDao.addUserGroup(entity);
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public void addGroupAndUserGroup(T entity,Group group,Right right,GroupRight groupRight,String username,String projectName) throws DataAccessException
	{
		String groupName = projectName + GROUP_NAME_POSTFIX;
		group.setGroupName(groupName);
		groupDao.addGroup(group);
		group = groupDao.getGroupByGroupName(groupName);
		
		right.setRightName(groupName);
		rightDao.addRight(right);
		right = rightDao.getRightByRightName(groupName);
		
		groupRight.setGroupId(group.getGroupId());
		groupRight.setGroupName(group.getGroupName());
		groupRight.setRightId(right.getRightId());
		groupRight.setRightName(right.getRightName());
		groupRightDao.addGroupRight(groupRight);
		
		User user = userDao.getUserByName(username);
		entity.setGroupId(group.getGroupId());
		entity.setGroupName(group.getGroupName());
		entity.setUserId(user.getUserId());
		entity.setUsername(user.getUserName());
		userGroupDao.addUserGroup(entity);
		
		
	}


	@Override
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED)
	public List<T> getUserGroupByUser(String username) throws DataAccessException
	{
		User user = userDao.getUserByName(username);
		int userId = user.getUserId();
		List<T> list = userGroupDao.getUserGroupByUserId(userId);
		return list;
	}
}
