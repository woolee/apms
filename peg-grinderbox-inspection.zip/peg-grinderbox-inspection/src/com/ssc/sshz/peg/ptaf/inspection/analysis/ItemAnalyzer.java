package com.ssc.sshz.peg.ptaf.inspection.analysis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ssc.sshz.peg.ptaf.inspection.analysis.bean.DataRow;
import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.ItemDetail;
import com.ssc.sshz.peg.ptaf.inspection.bean.ItemStatistics;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.RequestStatistics;
import com.ssc.sshz.peg.ptaf.inspection.bean.Requirement;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.ItemQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;

public class ItemAnalyzer
{
	private ItemQuartzService<Item> itemService = new ItemQuartzService<Item>();
	private Map<Integer, List<DataRow>> itemDataMap;
	private Map<String,List<RequestStatistics> > requestSummaryMapByItemName;
	private Map<String, Item> itemMap;
	private Map<Integer,String> itemNameByTestId = new HashMap<Integer, String>();
	private Map<Integer, List<DataRow>> rowDataMapByThreadId ;
	private Map<Integer, Requirement> requirementMapByItemId;
	private Plan plan;
	private TestBrief testBrief;
	private boolean isServiceCall;
	
	public ItemAnalyzer(Map<Integer, List<DataRow>> rowDataMap, List<RequestStatistics> requestSummaryList,TestBeanCollection collection,Map<Integer, List<DataRow>> rowDataMapByThreadId, boolean isServiceCall)
	{
		this.requestSummaryMapByItemName = getRequestSummaryMap(requestSummaryList);
		this.rowDataMapByThreadId = rowDataMapByThreadId;
		this.itemDataMap = rowDataMap;
		this.itemMap = getItemMap(collection.getItemList());
		this.testBrief = collection.getTestBrief();
		this.plan = collection.getPlan();
		this.requirementMapByItemId = collection.getRequirementMapByItemid();
		this.isServiceCall = isServiceCall;
	}
	
	
	
	private Map<String,List<RequestStatistics> > getRequestSummaryMap(List<RequestStatistics> requestSummaryList)
    {
    	Map<String, List<RequestStatistics> > requestSummaryMap = new HashMap<String,List<RequestStatistics> >();
    	for (RequestStatistics summary : requestSummaryList)
		{
    		String itemName = summary.getItemName();
    		if( requestSummaryMap.containsKey(itemName))
    		{
    			requestSummaryMap.get(itemName).add(summary);
    		}
    		else 
    		{
    			List<RequestStatistics> list = new ArrayList<RequestStatistics>();
    			list.add(summary);
    			requestSummaryMap.put(itemName, list);
    		}
		}
    	return requestSummaryMap;
    }
	
    private Map<String,Item> getItemMap(List<Item> itemList)
    {
    	Map<String, Item> itemtMap = new HashMap<String, Item>();
    	for (Item item : itemList)
		{
    		itemtMap.put(item.getItemName(), item);
		}
    	return itemtMap;
    }
    
	private Map<Integer, Integer> getItemMaxResponseTime()
	{
		Map<Integer, Integer> maxResponTimeMap = new HashMap<Integer, Integer>();
		Set<Integer> testIds = itemDataMap.keySet();
		for (Integer testId : testIds)
		{
			List<DataRow> rows = itemDataMap.get(testId);
			DataRow row = Collections.max(rows, new Comparator<DataRow>()
			{

				@Override
				public int compare(DataRow data1, DataRow data2)
				{
					return data1.getTestTime() - data2.getTestTime();
				}
			});
			maxResponTimeMap.put(testId, row.getTestTime());
		}
		return maxResponTimeMap;
	}

	private Map<Integer, Integer> getItemMinResponseTime()
	{
		Map<Integer, Integer> minResponTimeMap = new HashMap<Integer, Integer>();
		Set<Integer> testIds = itemDataMap.keySet();
		for (Integer testId : testIds)
		{
			List<DataRow> rows = itemDataMap.get(testId);
			DataRow row = Collections.min(rows, new Comparator<DataRow>()
			{

				@Override
				public int compare(DataRow data1, DataRow data2)
				{
					return data1.getTestTime() - data2.getTestTime();
				}
			});
			minResponTimeMap.put(testId, row.getTestTime());
		}
		return minResponTimeMap;
	}

	private Map<Integer, Double> getItemAvgResponseTime()
	{
		Map<Integer, Double> avgResponTimeMap = new HashMap<Integer, Double>();
		Set<Integer> testIds = itemDataMap.keySet();
		for (Integer testId : testIds)
		{
			double sum = 0;
			int count = 0;
			List<DataRow> rows = itemDataMap.get(testId);
			for (DataRow dataRow : rows)
			{
				sum = sum + dataRow.getTestTime();
				count++;
			}
			avgResponTimeMap.put(testId, sum / count);
		}
		return avgResponTimeMap;
	}

	private Map<Integer, Integer> getItemExecuCount()
	{
		Map<Integer, Integer> totalCount = new HashMap<Integer, Integer>();

		Set<Integer> testIds = itemDataMap.keySet();

		for (Integer testId : testIds)
		{
			List<DataRow> list = itemDataMap.get(testId);
			totalCount.put(testId, list.size());
		}

		return totalCount;
	}
	private Map<Integer, Integer> getItemErrorCount()
    {
		
		Map<Integer, Integer> failrequestDataMap = new HashMap<Integer, Integer>();
		if(isServiceCall)
		{
    		Set<String> itemNames = requestSummaryMapByItemName.keySet();
    		for (String itemName : itemNames)
    		{
    			int sumFailed = 0;
    			 List<RequestStatistics> requestSummaryList = requestSummaryMapByItemName.get(itemName);
    			 for (RequestStatistics requestStatistics : requestSummaryList)
    			{
    				 if(requestStatistics.getErrorCount()>0)
    				 {
    					 if(requestStatistics.getErrorCount() > sumFailed)
    					 sumFailed = requestStatistics.getErrorCount();
    				 }
    			}
    			 failrequestDataMap.put(Integer.parseInt(itemName), sumFailed);
    		}
		}
		else
		{
			Set<Integer> threads = rowDataMapByThreadId.keySet();
			for (Integer thread : threads)
			{
				List<DataRow> list = rowDataMapByThreadId.get(thread);
				int errorCount = 0;
				for (int i = 0; i < list.size(); i++)
				{
					int testId = list.get(i).getTest();
					if(!itemMap.containsKey(""+testId) && list.get(i).getHttpResponseErrors() == 1)
						errorCount = 1;
					else if(itemMap.containsKey(""+testId))
					{
						if(failrequestDataMap.containsKey(testId))
							failrequestDataMap.put(testId, failrequestDataMap.get(testId) + errorCount);
						else
							failrequestDataMap.put(testId, errorCount);
						errorCount = 0;
					}
				}
			}
		}

	return failrequestDataMap;
    }
    
    public Map<Integer, Double> getItemErrorRate()
    {
    	
	Map<Integer, Integer> failrequestDataMap = getItemErrorCount();
	Map<Integer, Integer> totalCountMap = getItemExecuCount();
	
	Map<Integer, Double> errorRateMap = new HashMap<Integer, Double>();
	Set<Integer> testIds = failrequestDataMap.keySet();
	for (Integer testId : testIds)
	{
	    int failCount = failrequestDataMap.get(testId);
	    int totalCount = totalCountMap.get(testId);
	    errorRateMap.put(testId, (double)failCount/totalCount);
	}

	return errorRateMap;
    }
    
    /**
     * get the 90th response time of the requests
     * @return
     */
    public Map<Integer, Integer> getItem90thRespTime()
    {
	Map<Integer, Integer> ninetyRespMap = new HashMap<Integer, Integer>();
	Set<Integer> testIds = itemDataMap.keySet();
	for (Integer testId : testIds)
	{
	    List<DataRow> dataRows = itemDataMap.get(testId);
	    Collections.sort(dataRows, new Comparator<DataRow>()
		{

			@Override
			public int compare(DataRow o1, DataRow o2)
			{
				
				return o1.getTestTime() - o2.getTestTime();
			}
		});
	    int index = (int) Math.round(0.9 * dataRows.size());
	    
	    int ninetiethTime = dataRows.get(index - 1).getTestTime();
	    ninetyRespMap.put(testId, ninetiethTime);

	}
	return ninetyRespMap;
    }
    
    public Map<Integer, Double> getItemVarianceRps()
    {
	Map<Integer, Double> variance = new HashMap<Integer, Double>();
	Set<Integer> keys = itemDataMap.keySet();
	for (Integer key : keys)
	{
		double sum = 0;
	    double average = getItemAvgResponseTime().get(key);
	    List<DataRow> list = itemDataMap.get(key);
	    for (int i = 0; i < list.size(); i++)
	    {
		int value = list.get(i).getTestTime();
		sum = sum + Math.pow((average - value), 2);
	    }
	    variance.put(key, sum / list.size());
	}
	return variance;
    }
    
    public Map<Integer, Double> getItemStdRps()
    {
	Map<Integer, Double> variance = new HashMap<Integer, Double>();
	Set<Integer> keys = itemDataMap.keySet();
	for (Integer key : keys)
	{
		double sum = 0;
	    double average = getItemAvgResponseTime().get(key);
	    List<DataRow> list = itemDataMap.get(key);
	    for (int i = 0; i < list.size(); i++)
	    {
		int value = list.get(i).getTestTime();
		sum = sum + Math.pow((average - value), 2);
	    }
	    variance.put(key, Math.sqrt(Math.abs(sum / list.size())));
	}
	return variance;
    }
    
	public List<ItemStatistics>  getItemSummaryList() throws Exception
	{
		Map<Integer, Integer> maxRpsMap = getItemMaxResponseTime();
    	Map<Integer, Integer> minRpsMap = getItemMinResponseTime();
    	Map<Integer, Double> avgRpsMap = getItemAvgResponseTime();
    	Map<Integer, Integer> totalCountMap = getItemExecuCount();
    	Map<Integer, Integer> errorCountmap = getItemErrorCount();
    	Map<Integer, Double> errorRateMap = getItemErrorRate();
    	Map<Integer, Integer> nintiethRspMap = getItem90thRespTime();
    	Map<Integer, Double> stdRpsMap = getItemStdRps();
    	
		List<ItemStatistics> itemSummaryList = new ArrayList<ItemStatistics>();

		Set<Integer> testIds = maxRpsMap.keySet();
		for (Integer testId : testIds)
		{
			if(!itemMap.containsKey(testId+""))
				continue;
			Item item = itemMap.get(testId+"");
			int itemId = item.getItemId();
			String itemName = testId + "";
			setItemNameByTestId(testId, itemId);
			
			int briefId = testBrief.getBriefId();
			int requestCount = requestSummaryMapByItemName.get(testId+"").size();
			int execuCount = totalCountMap.get(testId);
			int errorCount = errorCountmap.get(testId) ;
			double errorRate = errorRateMap.get(testId);
			double avgTime = avgRpsMap.get(testId);
			int nintiethRsp = nintiethRspMap.get(testId);
			double stdRps = stdRpsMap.get(testId);
			int maxTime = maxRpsMap.get(testId);
			int minTime = minRpsMap.get(testId);
			boolean isPassed = false;
			if(requirementMapByItemId == null || requirementMapByItemId.get(itemId) == null)
				isPassed = errorCount == 0;
			else
			{
				if(errorCount == 0)
				{
					isPassed = avgTime <= ((double)requirementMapByItemId.get(itemId).getAvgResponseTime() * 1000d);
				}
				else 
					isPassed = false;
			}
			int planId = plan.getPlanId();
			
			ItemStatistics itemSummary = new ItemStatistics();
			itemSummary.setItemId(itemId);
			itemSummary.setItemName(itemName);
			itemSummary.setPlanId(planId);
			itemSummary.setBriefId(briefId);
			itemSummary.setMaxResponseTime(maxTime);
			itemSummary.setMinResponseTime(minTime);
			itemSummary.setAvgResponseTime(avgTime);
			itemSummary.setExecutionCount(execuCount);
			itemSummary.setErrorCount(errorCount);
			itemSummary.setErrorRate(errorRate);
			itemSummary.setRequestCount(requestCount);
			itemSummary.setPassed(isPassed);
			itemSummary.setNinetyResponseTime(nintiethRsp);
			itemSummary.setStdResponseTime(stdRps);
			
			itemSummaryList.add(itemSummary);
		}
		return itemSummaryList;
	}

	
	public List<ItemDetail>  getItemDetailList() throws Exception
	{
		List<ItemDetail> itemDetailList = new ArrayList<ItemDetail>();

		Set<Integer> testIds = itemDataMap.keySet();
		for (Integer testId : testIds)
		{
			
			List<DataRow> rows = itemDataMap.get(testId);
			
			for (DataRow dataRow : rows)
			{
				
				double responseTime = dataRow.getTestTime();
				Date startTime = new Date(dataRow.getStartTime());
				int thread = dataRow.getThread();
				String itemName = testId + "";

				if(!itemMap.containsKey(itemName))
					continue;
				Item item = itemMap.get(itemName);
				int itemId = item.getItemId();
				setItemNameByTestId(testId, itemId);
				
				ItemDetail itemDetail = new ItemDetail();
				itemDetail.setResponseTime(responseTime);
				itemDetail.setBriefId(testBrief.getBriefId());
				itemDetail.setItemId(itemId);
				itemDetail.setItemName(itemName);
				itemDetail.setPlanId(plan.getPlanId());
				itemDetail.setStartTime(startTime);
				itemDetail.setThread(thread);
				
				itemDetailList.add(itemDetail);
			}
		}
		return itemDetailList;
	}
	private void setItemNameByTestId(int testId, int itemId) throws Exception
	{
		String itemName = "";
		if(itemNameByTestId.containsKey(testId))
		{
			itemName = itemNameByTestId.get(testId);
		}
		else{
			itemName = itemService.getItemByItemId(itemId).getItemName();
			itemNameByTestId.put(testId, itemName);
		}
	}

	public Map<Integer,String> getItemNameByTestId()
	{
		return itemNameByTestId;
	}

}
