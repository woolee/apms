package com.ssc.sshz.peg.ptaf.inspection.constants;

public enum TestType
{
	New,
	Update, 
	Remain,
	Exception
}
