package com.ssc.sshz.peg.ptaf.inspection.service;

import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.PlanItem;

public interface ScriptUploadService
{
	public List<Item> upload(int systemId, Plan plan,String zipfileputpath, Item item, PlanItem planItem) throws Exception;
}
