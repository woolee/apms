package com.ssc.sshz.peg.ptaf.inspection.bean;

import java.io.Serializable;

public class PlanScript implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2320417397455062077L;
	private int relationId;
	private int planId;
	private String planName;
	private int scriptId;
	private String scriptName;
	public int getRelationId()
	{
		return relationId;
	}
	public void setRelationId(int relationId)
	{
		this.relationId = relationId;
	}
	public int getPlanId()
	{
		return planId;
	}
	public void setPlanId(int planId)
	{
		this.planId = planId;
	}
	public String getPlanName()
	{
		return planName;
	}
	public void setPlanName(String planName)
	{
		this.planName = planName;
	}
	public int getScriptId()
	{
		return scriptId;
	}
	public void setScriptId(int scriptId)
	{
		this.scriptId = scriptId;
	}
	public String getScriptName()
	{
		return scriptName;
	}
	public void setScriptName(String scriptName)
	{
		this.scriptName = scriptName;
	}

}
