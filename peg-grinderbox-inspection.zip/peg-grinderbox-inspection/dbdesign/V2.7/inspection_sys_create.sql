﻿DROP DATABASE IF EXISTS `inspection_sys`;
CREATE DATABASE `inspection_sys`;
USE `inspection_sys`;

CREATE TABLE `project` (
  `project_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `project_name` VARCHAR(50) CHARACTER SET UTF8 NOT NULL,
  `project_creator_id` INTEGER NOT NULL,
  `project_creator_name` VARCHAR(50) CHARACTER SET UTF8,
  `create_time` DATETIME,
  `project_description` VARCHAR(500) CHARACTER SET UTF8,
  `project_uuid` VARCHAR(50) CHARACTER SET UTF8
);

CREATE TABLE `plan` (
  `plan_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `plan_name` VARCHAR(50) CHARACTER SET UTF8 NOT NULL,
  `system_id` INTEGER NOT NULL,
  `plan_creator_id` INTEGER NOT NULL,
  `is_enabled` BOOLEAN NOT NULL,
  `last_executor_id` INTEGER,
  `last_executor_name` VARCHAR(50) CHARACTER SET UTF8,
  `last_execution_time` DATETIME,
  `execution_count` INTEGER,
  `is_deleted` BOOLEAN NOT NULL,
  `delete_time` DATETIME,
  `plan_description` VARCHAR(500) CHARACTER SET UTF8
);

CREATE TABLE `script` (
  `script_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `script_name` VARCHAR(50) CHARACTER SET UTF8,
  `config_file` LONGBLOB,
  `script_file` LONGBLOB,
  `is_valid` BOOLEAN,
  `upload_time` DATETIME,
  `uploader_id` INTEGER NOT NULL,
  `uploader_name` VARCHAR(50) CHARACTER SET UTF8,
  `script_description` VARCHAR(500) CHARACTER SET UTF8
);

CREATE TABLE `plan_script` (
  `relation_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `plan_id` INTEGER NOT NULL,
  `plan_name` VARCHAR(50) CHARACTER SET UTF8,
  `script_id` INTEGER NOT NULL,
  `script_name` VARCHAR(50) CHARACTER SET UTF8
);

CREATE TABLE `test_brief` (
  `brief_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `plan_id` INTEGER NOT NULL,
  `plan_name` VARCHAR(50) CHARACTER SET UTF8,
  `start_time` DATETIME,
  `end_time` DATETIME,
  `is_automated` BOOLEAN,
  `executor_id` INTEGER NOT NULL,
  `executor_name` VARCHAR(50) CHARACTER SET UTF8,
  `status` VARCHAR(50),
  `is_passed` BOOLEAN,
  `has_error` BOOLEAN,
  `error_information` VARCHAR(500),
  `result_folder_path` VARCHAR(500),
  `summary_id` VARCHAR(50)
);

CREATE TABLE `test_error` (
  `error_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `error_type` VARCHAR(50) CHARACTER SET UTF8,
  `error_name` VARCHAR(50) CHARACTER SET UTF8,
  `error_message` VARCHAR(500) CHARACTER SET UTF8,
  `error_detail` VARCHAR(500) CHARACTER SET UTF8,
  `brief_id` INTEGER NOT NULL
);

CREATE TABLE `plan_strategy` (
  `strategy_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `strategy_name` VARCHAR(50) CHARACTER SET UTF8,
  `plan_id` INTEGER NOT NULL,
  `plan_name` VARCHAR(50) CHARACTER SET UTF8,
  `strategy_load` INTEGER,
  `loop_count` INTEGER,
  `strategy_description` VARCHAR(500) CHARACTER SET UTF8
);

CREATE TABLE `runtime` (
  `runtime_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `strategy_id` INTEGER NOT NULL,
  `run_type` INTEGER,
  `start_time` DATETIME,
  `end_time` DATETIME,
  `interval_time` INTEGER,
  `runtime_description` VARCHAR(500) CHARACTER SET UTF8
);


CREATE TABLE `system` (
  `system_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `system_name` VARCHAR(50) CHARACTER SET UTF8,
  `system_version` VARCHAR(10) CHARACTER SET UTF8,
  `system_env` VARCHAR(20) CHARACTER SET UTF8,
  `project_id` INTEGER NOT NULL,
  `project_name` VARCHAR(50) CHARACTER SET UTF8,
  `system_description` VARCHAR(500) CHARACTER SET UTF8,
  `system_uuid` VARCHAR(50) CHARACTER SET UTF8
);

CREATE TABLE `item` (
  `item_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `item_name` VARCHAR(50) CHARACTER SET UTF8,
  `item_description` VARCHAR(500) CHARACTER SET UTF8,
  `is_deleted` BOOLEAN,
  `delete_time` DATETIME,
  `system_id` INTEGER NOT NULL
);

CREATE TABLE `requirement` (
  `requirement_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `plan_id` INTEGER NOT NULL,
  `item_id` INTEGER NOT NULL,
  `avg_response_time_threshold` INTEGER
);

CREATE TABLE `item_statistics` (
	`statistics_id`	INTEGER PRIMARY KEY AUTO_INCREMENT,
	`item_id`	INTEGER NOT NULL,
	`item_name`	VARCHAR(50) CHARACTER SET UTF8,
	`brief_id`	INTEGER NOT NULL,
	`plan_id`	INTEGER NOT NULL,
	`requirement_id`	INTEGER,
	`execution_count`	INTEGER,
	`min_response_time`	FLOAT,
	`avg_response_time`	FLOAT,
	`90th_response_time` FLOAT,
	`max_response_time`	FLOAT,
	`std_response_time`	FLOAT,
	`is_passed`	BOOLEAN,
	`request_count`	INTEGER,
	`error_count`	INTEGER,
	`error_rate`	FLOAT
);

CREATE TABLE `item_detail` (
	`detail_id`	INTEGER PRIMARY KEY AUTO_INCREMENT,
	`item_id`	INTEGER NOT NULL,
	`item_name`	VARCHAR(50) CHARACTER SET UTF8,
	`brief_id`	INTEGER NOT NULL, 
	`plan_id`	INTEGER NOT NULL,
	`response_time`	FLOAT,
	`vu_id`	INTEGER,
	`start_time` DATETIME,
	`thread` INTEGER
);

CREATE TABLE `request` (
	`request_id`	INTEGER PRIMARY KEY AUTO_INCREMENT,
	`request_name` VARCHAR(50) CHARACTER SET UTF8,
	`plan_id`	INTEGER NOT NULL,
	`item_id`	INTEGER NOT NULL,
	`item_name`	VARCHAR(50),
	`request_url`	VARCHAR(500),
	`request_data` TEXT CHARACTER SET UTF8 
);

CREATE TABLE `request_statistics` (
	`statistics_id`	INTEGER PRIMARY KEY AUTO_INCREMENT,
	`request_id`	INTEGER NOT NULL,
	`request_name`	VARCHAR(50) CHARACTER SET UTF8,
	`item_id`	INTEGER NOT NULL,
	`item_name`	VARCHAR(50) CHARACTER SET UTF8,
	`brief_id`	INTEGER NOT NULL,
	`plan_id`	INTEGER NOT NULL,
	`execution_count`	INTEGER,
	`min_response_time`	FLOAT,
	`avg_response_time`	FLOAT,
	`90th_response_time` FLOAT,
	`max_response_time`	FLOAT,
	`std_response_time`	FLOAT,
	`error_count`	INTEGER,
	`error_rate`	FLOAT,
	`start_time` DATETIME,
	`thread` INTEGER
);

CREATE TABLE `request_detail` (
	`detail_id`	INTEGER PRIMARY KEY AUTO_INCREMENT,
	`request_id`	INTEGER NOT NULL,
	`request_url`	VARCHAR(500) CHARACTER SET UTF8,
	`request_name`	VARCHAR(50) CHARACTER SET UTF8,
	`item_id`	INTEGER NOT NULL,
	`item_name`	VARCHAR(50) CHARACTER SET UTF8,
	`brief_id`	INTEGER NOT NULL,
	`plan_id`	INTEGER NOT NULL,
	`vu_id`	INTEGER,
	`response_time`	FLOAT,
	`return_code`	INTEGER,
	`body_size`	INTEGER,
	`is_error`	BOOLEAN
);

CREATE TABLE `plan_item` (
  `relation_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `plan_id` INTEGER NOT NULL,
  `plan_name` VARCHAR(50) CHARACTER SET UTF8,
  `item_id` INTEGER NOT NULL,
  `item_name` VARCHAR(50) CHARACTER SET UTF8,
  `item_isvalid` BOOLEAN
);

/*
CREATE TABLE `system_item` (
  `relation_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `system_id` INTEGER NOT NULL,
  `system_name` VARCHAR(50) CHARACTER SET UTF8,
  `item_id` INTEGER NOT NULL,
  `item_name` VARCHAR(50) CHARACTER SET UTF8
);
*/

CREATE TABLE `inspection_user` (
  `user_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `username` VARCHAR(50) CHARACTER SET UTF8 NOT NULL,
  `password` VARCHAR(100) CHARACTER SET UTF8 NOT NULL,
  `real_name` VARCHAR(100) CHARACTER SET UTF8,
  `telephone_primary` VARCHAR(20) CHARACTER SET UTF8,
  `telephone_second` VARCHAR(20) CHARACTER SET UTF8,
  `email` VARCHAR(50) CHARACTER SET UTF8,
  `create_time` DATETIME,
  `last_login_time` DATETIME,
  `last_login_ip` VARCHAR(16) CHARACTER SET UTF8,
  `login_count` INTEGER
);

CREATE TABLE `inspection_right` (
  `right_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `right_name` VARCHAR(50) CHARACTER SET UTF8,
  `right_description` VARCHAR(200) CHARACTER SET UTF8
);

CREATE TABLE `user_right` (
  `relation_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `user_id` INTEGER NOT NULL,
  `username` VARCHAR(50) CHARACTER SET UTF8,
  `right_id` INTEGER NOT NULL,
  `right_name` VARCHAR(50) CHARACTER SET UTF8,
  `relation_description` VARCHAR(500) CHARACTER SET UTF8
);

CREATE TABLE `inspection_log` (
  `log_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `monitored_user_id` INTEGER NOT NULL,
  `monitored_user_name` VARCHAR(50) CHARACTER SET UTF8,
  `operation_time` DATETIME,
  `right_id` INTEGER NOT NULL,
  `right_name` VARCHAR(50) CHARACTER SET UTF8,
  `operation_description` VARCHAR(500) CHARACTER SET UTF8
);

CREATE TABLE `inspection_group` (
  `group_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `group_name` VARCHAR(50) CHARACTER SET UTF8,
  `group_email`	VARCHAR(50),
  `group_description` VARCHAR(500) CHARACTER SET UTF8
);

CREATE TABLE `user_group` (
  `relation_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `user_id` INTEGER NOT NULL,
  `user_name` VARCHAR(50) CHARACTER SET UTF8,
  `group_id` INTEGER NOT NULL,
  `group_name` VARCHAR(50) CHARACTER SET UTF8,
  `relation_description` VARCHAR(500) CHARACTER SET UTF8
);

CREATE TABLE `group_right` (
  `group_right_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `group_right_name` VARCHAR(50) CHARACTER SET UTF8,
  `group_id` INTEGER NOT NULL,
  `group_name` VARCHAR(50) CHARACTER SET UTF8,
  `right_id` INTEGER NOT NULL,
  `right_name` VARCHAR(50) CHARACTER SET UTF8,
  `grout_right_description` VARCHAR(500) CHARACTER SET UTF8
);

CREATE TABLE `ci_config` (
  `config_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `config_file_name` VARCHAR(50) CHARACTER SET UTF8,
  `config_file_md5` VARCHAR(50),
  `config_file` LONGBLOB,
  `created_by` INTEGER,
  `create_time` DATETIME,
  `summary_id` VARCHAR(50)
);

CREATE TABLE `ci_script` (
  `relation_id` INTEGER PRIMARY KEY AUTO_INCREMENT,
  `config_id` INTEGER,
  `script_id` INTEGER
);



-- create index for relative tables' fields
CREATE INDEX `idx_project_creator_id` ON `project` (`project_creator_id`);
CREATE INDEX `idx_plan_project_id` ON `plan` (`system_id`);
CREATE INDEX `idx_plan_creator_id` ON `plan` (`plan_creator_id`);
CREATE INDEX `idx_plan_last_executor_id` ON `plan` (`last_executor_id`);
CREATE INDEX `idx_script_uploader_id` ON `script` (`uploader_id`);
CREATE INDEX `idx_plan_script_plan_id` ON `plan_script` (`plan_id`);
CREATE INDEX `idx_plan_script_script_id` ON `plan_script` (`script_id`);
CREATE INDEX `idx_test_brief_plan_id` ON `test_brief` (`plan_id`);
CREATE INDEX `idx_test_brief_executor_id` ON `test_brief` (`executor_id`);
CREATE INDEX `idx_test_error_brief_id` ON `test_error` (`brief_id`);
CREATE INDEX `idx_plan_strategy_plan_id` ON `plan_strategy` (`plan_id`);
CREATE INDEX `idx_runtime_strategy_id` ON `runtime` (`strategy_id`);
CREATE INDEX `idx_system_project_id` ON `system` (`project_id`);
CREATE INDEX `idx_item_system_id` ON `item` (`system_id`);
CREATE INDEX `idx_requirement_plan_id` ON `requirement` (`plan_id`);
CREATE INDEX `idx_requirement_item_id` ON `requirement` (`item_id`);
CREATE INDEX `idx_item_statistics_item_id` ON `item_statistics` (`item_id`);
CREATE INDEX `idx_item_statistics_brief_id` ON `item_statistics` (`brief_id`);
CREATE INDEX `idx_item_statistics_plan_id` ON `item_statistics` (`plan_id`);
CREATE INDEX `idx_item_statistics_requirement_id` ON `item_statistics` (`requirement_id`);
CREATE INDEX `idx_item_detail_item_id` ON `item_detail` (`item_id`);
CREATE INDEX `idx_item_detail_brief_id` ON `item_detail` (`brief_id`);
CREATE INDEX `idx_item_detail_plan_id` ON `item_detail` (`plan_id`);
CREATE INDEX `idx_request_item_id` ON `request` (`item_id`);
CREATE INDEX `idx_request_plan_id` ON `request` (`plan_id`);
CREATE INDEX `idx_request_statistics_request_id` ON `request_statistics` (`request_id`);
CREATE INDEX `idx_request_statistics_item_id` ON `request_statistics` (`item_id`);
CREATE INDEX `idx_request_statistics_brief_id` ON `request_statistics` (`brief_id`);
CREATE INDEX `idx_request_statistics_plan_id` ON `request_statistics` (`plan_id`);
CREATE INDEX `idx_request_detail_request_id` ON `request_detail` (`request_id`);
CREATE INDEX `idx_request_detail_item_id` ON `request_detail` (`item_id`);
CREATE INDEX `idx_request_detail_brief_id` ON `request_detail` (`brief_id`);
CREATE INDEX `idx_request_detail_plan_id` ON `request_detail` (`plan_id`);
CREATE INDEX `idx_plan_item_plan_id` ON `plan_item` (`plan_id`);
CREATE INDEX `idx_plan_item_item_id` ON `plan_item` (`item_id`);
CREATE INDEX `idx_user_right_user_id` ON `user_right` (`user_id`);
CREATE INDEX `idx_user_right_right_id` ON `user_right` (`right_id`);
CREATE INDEX `idx_log_monitored_user_id` ON `inspection_log` (`monitored_user_id`);
CREATE INDEX `idx_log_right_id` ON `inspection_log` (`right_id`);
CREATE INDEX `idx_user_group_user_id` ON `user_group` (`user_id`);
CREATE INDEX `idx_user_group_group_id` ON `user_group` (`group_id`);
CREATE INDEX `idx_group_right_group_id` ON `group_right` (`group_id`);
CREATE INDEX `idx_group_right_right_id` ON `group_right` (`right_id`);
CREATE INDEX `idx_ci_config_created_by` ON `ci_config` (`created_by`);
CREATE INDEX `idx_ci_script_config_id` ON `ci_script` (`config_id`);
CREATE INDEX `idx_ci_script_script_id` ON `ci_script` (`script_id`);



-- add foreign key constraints on tables
ALTER TABLE `project` ADD CONSTRAINT `fk_project_creator_id` FOREIGN KEY (`project_creator_id`) REFERENCES `inspection_user` (`user_id`) ON UPDATE CASCADE;
ALTER TABLE `plan` ADD CONSTRAINT `fk_plan_system_id` FOREIGN KEY (`system_id`) REFERENCES `system` (`system_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `plan` ADD CONSTRAINT `fk_plan_creator_id` FOREIGN KEY (`plan_creator_id`) REFERENCES `inspection_user` (`user_id`) ON UPDATE CASCADE;
ALTER TABLE `plan` ADD CONSTRAINT `fk_plan_last_executor_id` FOREIGN KEY (`last_executor_id`) REFERENCES `inspection_user` (`user_id`) ON UPDATE CASCADE;
ALTER TABLE `script` ADD CONSTRAINT `fk_script_uploader_id` FOREIGN KEY (`uploader_id`) REFERENCES `inspection_user` (`user_id`) ON UPDATE CASCADE;
ALTER TABLE `plan_script` ADD CONSTRAINT `fk_plan_script_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE;
ALTER TABLE `plan_script` ADD CONSTRAINT `fk_plan_script_script_id` FOREIGN KEY (`script_id`) REFERENCES `script` (`script_id`) ON UPDATE CASCADE;
ALTER TABLE `test_brief` ADD CONSTRAINT `fk_test_brief_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE;
ALTER TABLE `test_brief` ADD CONSTRAINT `fk_test_brief_executor_id` FOREIGN KEY (`executor_id`) REFERENCES `inspection_user` (`user_id`) ON UPDATE CASCADE;
ALTER TABLE `test_error` ADD CONSTRAINT `fk_test_error_brief_id` FOREIGN KEY (`brief_id`) REFERENCES `test_brief` (`brief_id`) ON UPDATE CASCADE;
ALTER TABLE `plan_strategy` ADD CONSTRAINT `fk_plan_strategy_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `runtime` ADD CONSTRAINT `fk_runtime_strategy_id` FOREIGN KEY (`strategy_id`) REFERENCES `plan_strategy` (`strategy_id`) ON UPDATE CASCADE;
ALTER TABLE `system` ADD CONSTRAINT `fk_system_project_id` FOREIGN KEY (`project_id`) REFERENCES `project` (`project_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `item` ADD CONSTRAINT `fk_item_system_id` FOREIGN KEY (`system_id`) REFERENCES `system` (`system_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `requirement` ADD CONSTRAINT `fk_requirement_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `requirement` ADD CONSTRAINT `fk_requirement_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `item_statistics` ADD CONSTRAINT `fk_item_statistics_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `item_statistics` ADD CONSTRAINT `fk_item_statistics_brief_id` FOREIGN KEY (`brief_id`) REFERENCES `test_brief` (`brief_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `item_statistics` ADD CONSTRAINT `fk_item_statistics_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `item_statistics` ADD CONSTRAINT `fk_item_statistics_requirement_id` FOREIGN KEY (`requirement_id`) REFERENCES `requirement` (`requirement_id`) ON UPDATE CASCADE;
ALTER TABLE `item_detail` ADD CONSTRAINT `fk_item_detail_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `item_detail` ADD CONSTRAINT `fk_item_detail_brief_id` FOREIGN KEY (`brief_id`) REFERENCES `test_brief` (`brief_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `item_detail` ADD CONSTRAINT `fk_item_detail_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE;
ALTER TABLE `request` ADD CONSTRAINT `fk_request_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `request` ADD CONSTRAINT `fk_request_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `request_statistics` ADD CONSTRAINT `fk_request_statistics_request_id` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `request_statistics` ADD CONSTRAINT `fk_request_statistics_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `request_statistics` ADD CONSTRAINT `fk_request_statistics_brief_id` FOREIGN KEY (`brief_id`) REFERENCES `test_brief` (`brief_id`) ON UPDATE CASCADE;
ALTER TABLE `request_statistics` ADD CONSTRAINT `fk_request_statistics_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE;
ALTER TABLE `request_detail` ADD CONSTRAINT `fk_request_detail_request_id` FOREIGN KEY (`request_id`) REFERENCES `request` (`request_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `request_detail` ADD CONSTRAINT `fk_request_detail_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `request_detail` ADD CONSTRAINT `fk_request_detail_brief_id` FOREIGN KEY (`brief_id`) REFERENCES `test_brief` (`brief_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `request_detail` ADD CONSTRAINT `fk_request_detail_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `plan_item` ADD CONSTRAINT `fk_plan_item_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plan` (`plan_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `plan_item` ADD CONSTRAINT `fk_plan_item_item_id` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`) ON UPDATE CASCADE;
ALTER TABLE `user_right` ADD CONSTRAINT `fk_user_right_user_id` FOREIGN KEY (`user_id`) REFERENCES `inspection_user` (`user_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `user_right` ADD CONSTRAINT `fk_user_right_right_id` FOREIGN KEY (`right_id`) REFERENCES `inspection_right` (`right_id`) ON UPDATE CASCADE;
ALTER TABLE `inspection_log` ADD CONSTRAINT `fk_log_monitored_user_id` FOREIGN KEY (`monitored_user_id`) REFERENCES `inspection_user` (`user_id`) ON UPDATE CASCADE;
ALTER TABLE `inspection_log` ADD CONSTRAINT `fk_log_right_id` FOREIGN KEY (`right_id`) REFERENCES `inspection_right` (`right_id`) ON UPDATE CASCADE;
ALTER TABLE `user_group` ADD CONSTRAINT `fk_user_group_user_id` FOREIGN KEY (`user_id`) REFERENCES `inspection_user` (`user_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `user_group` ADD CONSTRAINT `fk_user_group_group_id` FOREIGN KEY (`group_id`) REFERENCES `inspection_group` (`group_id`) ON UPDATE CASCADE;
ALTER TABLE `group_right` ADD CONSTRAINT `fk_group_right_group_id` FOREIGN KEY (`group_id`) REFERENCES `inspection_group` (`group_id`) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE `group_right` ADD CONSTRAINT `fk_group_right_right_id` FOREIGN KEY (`right_id`) REFERENCES `inspection_right` (`right_id`) ON UPDATE CASCADE;
ALTER TABLE `ci_config` ADD CONSTRAINT `fk_ci_config_created_by` FOREIGN KEY (`created_by`) REFERENCES `inspection_user` (`user_id`) ON UPDATE CASCADE;
ALTER TABLE `ci_script` ADD CONSTRAINT `fk_ci_script_config_id` FOREIGN KEY (`config_id`) REFERENCES `ci_config` (`config_id`) ON UPDATE CASCADE;
ALTER TABLE `ci_script` ADD CONSTRAINT `fk_ci_script_script_id` FOREIGN KEY (`script_id`) REFERENCES `script` (`script_id`) ON UPDATE CASCADE;

