package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.File;
public class IterateLib {
 public static void main(String[] args) throws Exception {
	  //递归显示lib下所有文件夹�?�其中文件
	  File root = new File("C:\\Workspace\\peg-grinderbox-inspection\\WebContent\\WEB-INF\\lib");
	  showAllFiles(root);
 }
 
 final static void showAllFiles(File dir) throws Exception{
	  File[] fs = dir.listFiles();
	  for(int i=0; i<fs.length; i++){
		   //System.out.println(fs[i].getAbsolutePath());
		   System.out.println(fs[i].getName());
		   if(fs[i].isDirectory()){
			    try{
			    	showAllFiles(fs[i]);
			    }catch(Exception e){
			    	e.printStackTrace();
			    }
		   }
	  }
 }
 
 
}
