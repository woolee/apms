package com.ssc.sshz.peg.ptaf.inspection.service;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.dao.impl.SystemDaoImpl;
import com.ssc.sshz.peg.ptaf.inspection.service.impl.SystemServiceImp;


@org.junit.runner.RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext-*.xml")
public class SystemServiceImpTest extends AbstractTransactionalJUnit4SpringContextTests
{ 
	@Autowired(required = true)
	private SystemServiceImp systemserviceimpl; 
	@Autowired(required = true)
	private SystemDaoImpl systemdaoimpl; 
	
	private System system = null;
	
	@Before
	public void prepareTestData(){
		system = new System();
		system.setSystemId(10);
		system.setSystemName("tan");
		system.setSystemVersion("tan");
		system.setSystemEnv("enviroment");
		system.setProjectId(2);
		system.setProjectName("JARS");
		system.setSystemDescription("here is the description");
		
		systemdaoimpl.addSystem(system);
	}

	@Test
	public void testAddProject() {
		System sys = new System();
		sys.setSystemId(11);
		sys.setSystemName("tan");
		sys.setSystemVersion("tan");
		sys.setSystemEnv("enviroment");
		sys.setProjectId(2);
		sys.setProjectName("JARS");
		sys.setSystemDescription("here is the description");
		
		systemserviceimpl.addSystem(sys);
	}
	
	@Test
	public void testDelSystem(){
		systemserviceimpl.delSystem(system);
	}
	
	@Test
	public void testGetSystem(){
		System s = systemserviceimpl.getSystem((Integer)10);
		assertEquals("tan",s.getSystemName());
	}
}

