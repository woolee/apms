package com.ssc.sshz.peg.ptaf.analysis;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.junit.Test;

import com.ssc.peg.cnav.analysis.AnalyzerManager;
import com.ssc.peg.cnav.analysis.bean.AnalysisProperty;
import com.ssc.peg.cnav.analysis.bean.AnalysisResult;
import com.ssc.peg.cnav.analysis.generator.HTMLGenerator;
import com.ssc.peg.cnav.analysis.graph.GraphDataCollection;
import com.ssc.peg.cnav.analysis.util.PropertyGenerator;
import com.statestr.gcth.cloud.deploy.tool.AutoDeploymentTool;

public class AnalysisTest
{
	@Test
	public void testLogAnalysis() throws IOException
	{
		SimpleDateFormat sdf = new  SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String startTime = "2014-08-29 18:21:07";
		String endTime = "2014-08-29 18:25:01";
		
		long current = System.currentTimeMillis();
		/*
		 * foreground 
		 */
		String fgLogPath = "C:/log/" + current + "test/fg/";
		String[] args1 = {"--Fetch","Y","--appCode","CNAWEB90992","--Context","cnafgctde","--env","UA1","--Path",fgLogPath,"--LogName","FAW_l4j","--Approvers","-P","a549324/ASDfgh[0"};
		/*
		 * background
		 */
		String bgLogPath = "C:/log" + current + "/test/bg/";
		String[] args = {"--Fetch","Y","--appCode","CNABAK90993","--Context","cnabgcuat","--env","UA1","--Path",bgLogPath,"--LogName","FAW_l4j","--Approvers","-P","a549324/ASDfgh[0"};
		
		/*
		 * cpu
		 */
		String cpuLogPath = "C:/log/" + current + "cpu/";
		String[] cpuArgs = {"--Fetch","Y","--appCode","CNABAK90993","--Context","cnabgcuat","--env","UA1","--Path",cpuLogPath,"--Approvers","-P","a549324/ASDfgh[0"};
		try
		{
			AutoDeploymentTool.fetchLogs(args1,true,false, sdf.parse(startTime ), sdf.parse(endTime));
			AutoDeploymentTool.fetchLogs(args,true,false, sdf.parse( startTime), sdf.parse(endTime));
			Date endDate = sdf.parse(endTime);
			endDate.setDate(endDate.getDate() + 1);
			AutoDeploymentTool.fetchCPULog(cpuArgs,sdf.parse(startTime), endDate);
			
//			String tempPath = "C:/cnav_analysis/" + current ;
//			String propPath = tempPath + "/analysis.properties";
////			String propPath = "C:\\cnav_analysis\\1409020513271\\analysis.properties";
//			
//			AnalysisProperty propValues = new AnalysisProperty();
//			propValues.setFgLogFolderPath(fgLogPath);
//			propValues.setBgLogFolderPath(bgLogPath);
//			propValues.setCpuLog(cpuLogPath);
//			propValues.setRowDatapath(tempPath + "/data.csv");
//			propValues.setRowDataBKPath(tempPath + "/data_bk.csv");
//			propValues.setSummaryPath(tempPath + "/summary.csv");
//			propValues.setTempFolderPath(tempPath);
//			propValues.setRuntimeStart(startTime);
//			propValues.setRuntimeEnd(endTime);
//			
//			PropertyGenerator.createProperties(propPath, propValues);
//			
//			AnalyzerManager la = new AnalyzerManager();
//			la.doAnalyze(propPath);
//			
//			//---- get all analysis result
//			AnalysisResult ar = la.getResult();
//			//--------------------------
//			
//			 Map<String, String[]>  map = null;
//				try
//				{
//					map = GraphDataCollection.getInstance().getDataCollectionStr(tempPath + "/summary.csv",2);
//				}
//				catch (IOException e)
//				{
//					e.printStackTrace();
//				}
//				String dataset = GraphDataCollection.getInstance().showResTimeRateDataStr(map);
//				String loadVar = GraphDataCollection.getInstance().showLoadVarStr(map);
//				String barName = GraphDataCollection.getInstance().showBarName();
//				String funcName = GraphDataCollection.getInstance().showFunctionName();
//				String barColor = GraphDataCollection.getInstance().showBarColor();
//				String tabledata = GraphDataCollection.getInstance().showTableDataStr(map, tempPath + "/summary.csv");
//				
//				File desFile = new File("C:\\htmlfile\\des\\chart_"+ System.currentTimeMillis() +".html");
//				new HTMLGenerator().generateHTML(barName, dataset, loadVar, funcName, barColor, tabledata, desFile);
				    }
		catch (ParseException e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		catch (Exception e1)
		{
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
	
}
