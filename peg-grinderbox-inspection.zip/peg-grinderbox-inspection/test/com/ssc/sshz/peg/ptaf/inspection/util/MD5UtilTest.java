package com.ssc.sshz.peg.ptaf.inspection.util;

import com.ssc.sshz.peg.ptaf.inspection.util.MD5Util;

public class MD5UtilTest {

	public static void main(String[] args) {
		String filePath = "C:\\work\\mylog.log";
		MD5Util mD5Tool = new MD5Util();
		System.out.println(mD5Tool.fileMD5CheckSum(filePath));
		System.out.println(mD5Tool.fileMD5CheckSum(filePath).length());
	}

}
