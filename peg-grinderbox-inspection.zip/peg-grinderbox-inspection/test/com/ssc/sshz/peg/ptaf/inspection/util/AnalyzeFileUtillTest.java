package com.ssc.sshz.peg.ptaf.inspection.util;

import java.io.File;
import java.util.List;

import com.ssc.sshz.peg.ptaf.inspection.bean.Request;



public class AnalyzeFileUtillTest {

	public static void main(String[] args) throws Exception {
		String rootPath = "C:/test";
		AssetAnalyzeUtil.getInstance().setRootPath(rootPath);
		File runTime = AssetAnalyzeUtil.getInstance().getRunTime();
		List<String> itemList = AssetAnalyzeUtil.getInstance().getItems(runTime.getName());
		for (String item : itemList)
		{
			System.out.println(item);
			List<Request>   requests = AssetAnalyzeUtil.getInstance().getAllRequests(item);
			for (Request request : requests)
			{
				System.out.println(request.getRequestName() + " " + request.getRequestUrl());
			}
		}
		
		
	}

}
