package com.ssc.sshz.peg.ptaf.inspection.service;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ssc.sshz.peg.ptaf.inspection.bean.Runtime;
import com.ssc.sshz.peg.ptaf.inspection.dao.impl.ProjectDaoImpl;
import com.ssc.sshz.peg.ptaf.inspection.dao.impl.RuntimeDaoImpl;
import com.ssc.sshz.peg.ptaf.inspection.service.impl.ProjectServiceImp;
import com.ssc.sshz.peg.ptaf.inspection.service.impl.RuntimeServiceImp;


@org.junit.runner.RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext-*.xml")
public class RuntimeServiceImpTest extends AbstractTransactionalJUnit4SpringContextTests
{ 
	@Autowired(required = true)
	private RuntimeServiceImp runtimeserviceimp; 
	@Autowired(required = true)
	private RuntimeDaoImpl runtimedao;
	
	private Runtime runtime = null;

	@Before
	public void prepareTestData(){
		runtime = new Runtime();
		runtime.setRuntimeId(10);
		runtime.setStrategyId(1);
		runtime.setStartTime(new Timestamp(System.currentTimeMillis()));
		runtime.setEndTime(new Timestamp(System.currentTimeMillis()));
		runtime.setIntervalTime(100);
		runtime.setRunType(1);		
		runtime.setRuntimeDescription("here is the description");		
		runtimedao.addRuntime(runtime);
	}
	@Test
	public void testGetRuntime(){
		Runtime r = runtimeserviceimp.getRuntime(runtime);
		assertEquals((Integer)1,r.getStrategyId());
	}
	@Test
	public void testDelRuntimeById() {
		runtimeserviceimp.delRuntimeById(runtime.getRuntimeId());
	}
	
	@Test
	public void testAddRuntime() {
		Runtime runtime = new Runtime();
		runtime.setRuntimeId(11);
		runtime.setStrategyId(1);
		runtime.setStartTime(new Timestamp(System.currentTimeMillis()));
		runtime.setEndTime(new Timestamp(System.currentTimeMillis()));
		runtime.setIntervalTime(100);
		runtime.setRunType(1);		
		runtime.setRuntimeDescription("here is the description");
		runtimeserviceimp.addRuntime(runtime);
	}
	
	@Test
	public void testGetAllRuntime(){
		List<Runtime> list = runtimeserviceimp.getAllRuntime();
		Runtime r = list.get(list.size()-1);
		assertEquals((Integer)1,r.getRunType());
	}
}

