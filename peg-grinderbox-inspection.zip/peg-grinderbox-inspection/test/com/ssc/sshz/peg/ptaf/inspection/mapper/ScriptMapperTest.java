package com.ssc.sshz.peg.ptaf.inspection.mapper;


import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ssc.sshz.peg.ptaf.inspection.bean.Script;
import com.ssc.sshz.peg.ptaf.inspection.mapper.ScriptMapper;


@org.junit.runner.RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext-*.xml")
public class ScriptMapperTest extends AbstractJUnit4SpringContextTests
{ 
	@Resource
	private ScriptMapper mapper; 
	
	@Test
	public void testGetScriptById() {
		Script returnScript = mapper.getScriptById(1);
		System.out.println(returnScript);
	}
	
	@Test
	public void testGetPlanByName() {
		Script returnScript = mapper.getScriptByName("script1");
		System.out.println(returnScript);
		
	}
	
/*	@Test
	public void testAddScript() {
		Script script = new Script();
		script.setScriptId(1);
		script.setScriptName("script1");
		script.setScriptFilePath("C/A/B/C/D/E/F.zip");
		script.setValid(true);
		script.setUploadTime(new Timestamp(System.currentTimeMillis()));
		script.setUploaderId(1);
		script.setUploaderName("user1");
		script.setScriptDescription("this is script1");

		mapper.addScript(script);
		
		//System.out.println(mapper.getPlanByName("plan1").getPlanId());
		
	}*/
}

