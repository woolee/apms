package com.ssc.sshz.peg.ptaf.inspection.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RequestURLTest
{
	private String a;
	private String b;
	
	public RequestURLTest(String a, String b)
	{
		super();
		this.a = a;
		this.b = b;
	}
	
	public String getA()
	{
		return a;
	}

	public void setA(String a)
	{
		this.a = a;
	}

	public String getB()
	{
		return b;
	}

	public void setB(String b)
	{
		this.b = b;
	}

	@Override
	public boolean equals(Object obj)
	{
		return this.a.equals(((RequestURLTest)obj).getA()) && this.b.equals(((RequestURLTest)obj).getB());
	}

	@Override
	public int hashCode()
	{
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	public static void main(String[] args) throws IOException 
	{
		String reg = "\\d{4}-\\d{2}-\\d{2}\\s\\d{2}:\\d{2}:\\d{2},\\d{3}\\sINFO.*thread-(\\d{1,3})\\s\\[\\srun-\\d{1,3},\\stest-\\d+\\s\\]:\\s(.*)\\s->.*";
		Pattern p = Pattern.compile(reg);
		Map<Integer, List<String>> threadRequestURL = new HashMap<Integer, List<String>>();
		try
		{
			BufferedReader reader = new BufferedReader(new FileReader(new File("C:/CN-PC-HZ3037-0.log")));
			String line;
			line = reader.readLine();
			while(line != null && !line.isEmpty())
			{
				
				Matcher m = p.matcher(line);
				if(m.find())
				{
					int thread = Integer.parseInt(m.group(1));
					String url = m.group(2);
					if(threadRequestURL.containsKey(thread))
					{
						threadRequestURL.get(thread).add(url);
					}
					else{
						List<String> urlList = new ArrayList<String>();
						urlList.add(url);
						threadRequestURL.put(thread, urlList);
					}
				}
				line = reader.readLine();
				
			}
		}
		catch (IOException e)
		{
			throw new IOException("Exception while read grinder log",e);
		}
		Set<Integer> set = threadRequestURL.keySet();
		for (Integer thread : set)
		{
			List<String> list = threadRequestURL.get(thread);
			for (String url : list)
			{
				System.out.println(thread + ":" + url);
			}
		}
		RequestURLTest test1 = new RequestURLTest("a","b");
		RequestURLTest test2 = new RequestURLTest("a","b");
		System.out.println(test1.equals(test2));
		
	}
}
