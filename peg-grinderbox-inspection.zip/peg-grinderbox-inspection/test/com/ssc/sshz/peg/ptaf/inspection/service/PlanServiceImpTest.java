package com.ssc.sshz.peg.ptaf.inspection.service;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.dao.impl.PlanDaoImpl;
import com.ssc.sshz.peg.ptaf.inspection.service.impl.PlanServiceImp;
import com.ssc.sshz.peg.ptaf.inspection.service.impl.ProjectServiceImp;


@org.junit.runner.RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext-*.xml")
public class PlanServiceImpTest extends AbstractTransactionalJUnit4SpringContextTests
{ 
	@Autowired(required = true)
	private PlanServiceImp planserviceimp; 
	@Autowired(required = true)
	private PlanDaoImpl plandao;
	
	private Plan plan = null;

	@Before
	public void prepareTestData(){
		plan = new Plan();
		plan.setPlanId(10);
		plan.setPlanName("tan");
		plan.setSystemId(1);
		plan.setPlancreatorId(1);
		plan.setEnabled(true);
		plan.setLastExecutorId(1);
		plan.setLastExecutorName("user1");
		plan.setLastExecutionTime(new Timestamp(System.currentTimeMillis()));
		plan.setExecutionCount(10);
		plan.setDeleted(false);
		plan.setDeleteTime(null);
		plan.setPlanDescription("here is the description");		
		plandao.addPlan(plan);
	}
	@Test
	public void testGetPlan(){
		Plan p = (Plan) planserviceimp.getPlan(plan);
		assertEquals("tan",p.getPlanName());
	}

	@Test
	public void testGetAllPlan(){
		List<Plan> list = planserviceimp.getAllPlan();
		Plan p = list.get(list.size()-1);
		assertEquals("tan",p.getPlanName());
	}
	
	@Test
	public void testDelPlan() {
		planserviceimp.delPlan(plan);
	}
	
	@Test
	public void testAddPlan() {
		Plan plan = new Plan();
		plan.setPlanId(11);
		plan.setPlanName("tan");
		plan.setSystemId(1);
		plan.setPlancreatorId(1);
		plan.setEnabled(true);
		plan.setLastExecutorId(1);
		plan.setLastExecutorName("user1");
		plan.setLastExecutionTime(new Timestamp(System.currentTimeMillis()));
		plan.setExecutionCount(10);
		plan.setDeleted(false);
		plan.setDeleteTime(null);
		plan.setPlanDescription("here is the description");
		
		planserviceimp.addPlan(plan);

	}
	

}

