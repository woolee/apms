package com.ssc.sshz.peg.ptaf.inspection.file;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.util.AssetAnalyzeUtil;
import com.ssc.sshz.peg.ptaf.inspection.util.FileZip;

public class AnalysisScript{
	
	@Test
	public void testAnalysisScript() throws Exception
	{
//		String zipfilepath=FilePathConstants.TEMPFOLDERPATH + "/" + file.getOriginalFilename();
		String zipfilepath = "C:\\test\\TestQTM2.zip";
		String zipfileputpath =  FileZip.unzip(zipfilepath, "C:\\test");
		
	     
		//List sumlist=ReadXMLWriteToDB(zipfileputpath, item, system, planItem, request);
		
			AssetAnalyzeUtil util =AssetAnalyzeUtil.getInstance();
			util.setRootPath(zipfileputpath);
			List<Item> DisplayItemlist = new ArrayList<Item>();
			File runtimeFile = util.getRunTime();
			if(runtimeFile == null)
				System.out.println("runtime file is null");
			List<String> itemNameList = util.getItems(util.getRunTime().getName());
			if(itemNameList == null || itemNameList.size() == 0)
				System.out.println("item list is null");
			for (int j = 0; j < itemNameList.size(); j++){
				Item tempitem=new Item();
				tempitem.setItemName(itemNameList.get(j));
				DisplayItemlist.add(tempitem);
			}
	}
}
