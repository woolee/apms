package com.ssc.sshz.peg.ptaf.inspection.test.generator;

import java.io.File;
import java.io.IOException;

import org.junit.Test;

public class TestVUFileGenerator
{
	@Test
	public void testVUFileCopy() 
	{
		VUFileGenerator vufg = new VUFileGenerator();
		try
		{
			vufg.generateParamFile(new File("C:\\test\\PerformanceTestNew\\PerformanceTest\\user.csv"), new File("C:\\test\\PerformanceTestNew"));
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
