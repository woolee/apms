package com.ssc.sshz.peg.ptaf.inspection.file;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.ssc.sshz.peg.ptaf.inspection.file.FileUploadClient;


public class fileUploadTest {

	public static void main(String[] args) throws IOException {
//      FileUploadClient fileUpload = new FileUploadClient();
//      
//      String username = "user1";
//      String password = "abcdef";
//      String projectName = "project001";
//      String systemName = "system001";
//      String filePath = "C:\\workfolder\\documents\\CNAV2-Sol9.docx.zip";
//      
//      System.out.println(fileUpload.upload(username,password,projectName,systemName,filePath));
//      //fileUpload.getPostUrl();

      
		String url = "http://localhost:8080/peg-grinderbox-inspection/xml?__request=910800701&SUMMARY_ID=1&PROJECT_NAME=abc&FINISH_TIME=2011-11-11%2011:11:11&TOTAL_SERVICE_NUM=1&PASSED_SERVICE_NUM=2&FAILED_SERVICE_NUM=3&PASSED_RATE=0.44&COMPLETION_TIME=2011-11-11%2011:11:11&ERROR_MESSAGE=aa";
		HttpGet httpget = new HttpGet(url);
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpResponse response = null;
		try {
			response = httpClient.execute(httpget);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		HttpEntity httpEntity = response.getEntity();
		String returnString = null;
		try {
			returnString = EntityUtils.toString(httpEntity);
			System.out.println("server return String: \n"+returnString);
		} catch (ParseException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		String positiveFlag = "FLAG=\"1\"";
		if(returnString.contains(positiveFlag)){
			System.out.println("positive flag");
		}else{
			System.out.println("negative flag");
		}
		
		System.out.println("the end!");
      
      
	}


}
