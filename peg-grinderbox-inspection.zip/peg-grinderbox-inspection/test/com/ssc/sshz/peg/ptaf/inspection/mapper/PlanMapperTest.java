package com.ssc.sshz.peg.ptaf.inspection.mapper;

import java.sql.Timestamp;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.mapper.PlanMapper;


@org.junit.runner.RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext-*.xml")
public class PlanMapperTest extends AbstractJUnit4SpringContextTests
{ 
//	@Inject
//	@Named("planMapper")
	@Resource
	private PlanMapper mapper; 
/*	@Test
	public void testGetPlanById() {
		System.out.println(mapper.getPlanById(1).getPlanName());
	}
	*/
	@Test
	public void testGetPlanByName() {
		System.out.println(mapper.getPlanByName("plan1").getPlanId());
		
	}
	
	@Test
	public void testAddPlan() {
		Plan plan = new Plan();
		plan.setPlanId(2);
		plan.setPlanName("plan2");
		plan.setSystemId(1);
		plan.setPlancreatorId(1);
		plan.setEnabled(true);
		plan.setLastExecutorId(1);
		plan.setLastExecutorName("user1");
		plan.setExecutionCount(2);
		plan.setDeleted(false);
		plan.setDeleteTime(new Timestamp(System.currentTimeMillis()));
		plan.setPlanDescription("222222");
		mapper.addPlan(plan);
		
		//System.out.println(mapper.getPlanByName("plan1").getPlanId());
		
	}
}

