package com.ssc.sshz.peg.ptaf.inspection.service;

import static org.junit.Assert.*;
import java.sql.Timestamp;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.dao.impl.ProjectDaoImpl;
import com.ssc.sshz.peg.ptaf.inspection.service.impl.ProjectServiceImp;


@org.junit.runner.RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext-*.xml")
public class ProjectServiceImpTest extends AbstractTransactionalJUnit4SpringContextTests
{ 
	@Autowired(required = true)
	private ProjectServiceImp projectserviceimp; 
	@Autowired(required = true)
	private ProjectDaoImpl projectdao;
	
	private Project project = null;

	@Before
	public void prepareTestData(){
		project = new Project();
		project.setProjectId(10);
		project.setProjectName("tan");
		project.setProjectCreatorId(1);
		project.setProjectCreatorName("user1");
		project.setCreateTime(new Timestamp(System.currentTimeMillis()));
		project.setProjectDescription("here is the description");		
		projectdao.addProject(project);
	}
	@Test
	public void testGetProject(){
		Project p = (Project) projectserviceimp.getProject(project);
		assertEquals("tan",p.getProjectName());
	}
	@Test
	public void testDelProject() {
		projectserviceimp.delProject(project);
	}
	
	@Test
	public void testAddProject() {
		Project project = new Project();
		project.setProjectId(14);
		project.setProjectName("tan");
		project.setProjectCreatorName("tan");
		project.setProjectCreatorId(1);
		project.setCreateTime(new Timestamp(System.currentTimeMillis()));
		project.setProjectDescription("here is the description");
		
		projectserviceimp.addProject(project);

	}
	
	@Test
	public void testGetAllProject(){
		List<Project> list = projectserviceimp.getAllProject();
		Project p = list.get(list.size()-1);
		assertEquals("tan",p.getProjectName());
	}
}

