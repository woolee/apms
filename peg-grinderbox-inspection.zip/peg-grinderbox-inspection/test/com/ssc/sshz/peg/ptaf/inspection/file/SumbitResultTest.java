package com.ssc.sshz.peg.ptaf.inspection.file;

import java.io.IOException;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.junit.Test;

import com.ssc.cloud.Client;
import com.ssc.cloud.Column;
import com.ssc.cloud.MetadataFetchException;
import com.ssc.cloud.ProcessException;
import com.ssc.cloud.ResultSet;
import com.ssc.cloud.ResultSetException;
import com.ssc.cloud.SignOnException;
import com.ssc.faw.util.GenException;
import com.ssc.faw.util.PwMatrixUtil;
import com.ssc.sshz.peg.ptaf.inspection.constants.FilePathConstants;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.SubmitResultService;

public class SumbitResultTest {

/*	public static void main(String[] args) {
		SumbitResultTest sumbitResultTest = new SumbitResultTest();
		System.out.println(sumbitResultTest.submitResult());

	}*/
	
	public boolean submitResult(String systemuuid,int briefId) throws Exception{
		SubmitResultService submitResultService = new SubmitResultService();
		String projectName = submitResultService.getProjectName(systemuuid);
		String summaryId = submitResultService.getSummaryId(systemuuid);
		Date endTime = submitResultService.getEndTime(systemuuid);
		Map<String,String> statisticMap  = submitResultService.getReturnStatistics(briefId);
//		String projectName = submitResultService.getProjectName("d900c033-4e5e-1032-95a9-8e580b32d69f");
//		String summaryId = submitResultService.getSummaryId("1ea513a2-4e5f-1032-95a9-8e580b32d69e");
//		Date endTime = submitResultService.getEndTime("1ea513a2-4e5f-1032-95a9-8e580b32d69e");
//		Map<String,String> statisticMap  = submitResultService.getReturnStatistics("1ea513a2-4e5f-1032-95a9-8e580b32d69e");
		//System.out.println("TOTAL_SERVICE_NUM= " + statisticMap.get("TOTAL_SERVICE_NUM"));
		//System.out.println("PASSED_SERVICE_NUM= " + statisticMap.get("PASSED_SERVICE_NUM"));
		//System.out.println("FAILED_SERVICE_NUM= " + statisticMap.get("FAILED_SERVICE_NUM"));
		//System.out.println("PASSED_RATE= " + statisticMap.get("PASSED_RATE"));
		
		String requestId = "910800701";
		//String SUMMARY_ID = summaryId;
		String SUMMARY_ID = "1234576";
		String PROJECT_NAME = projectName;
			DateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
			DateFormat dateFormat2 = new SimpleDateFormat("yyyy:MM:dd");
		String FINISH_TIME = dateFormat1.format(endTime)+"%"+dateFormat2.format(endTime);
		String TOTAL_SERVICE_NUM = statisticMap.get("TOTAL_SERVICE_NUM");
		String PASSED_SERVICE_NUM = statisticMap.get("PASSED_SERVICE_NUM");
		String FAILED_SERVICE_NUM = statisticMap.get("FAILED_SERVICE_NUM");
		String PASSED_RATE = statisticMap.get("PASSED_RATE");
		String COMPLETION_TIME = FINISH_TIME;
		String ERROR_MESSAGE = "demo_message";
		//System.out.println("FINISH_TIME="+COMPLETION_TIME);
		//System.out.println("COMPLETION_TIME=" + COMPLETION_TIME);
		statisticMap = null;
	
		//String url= "http://10.248.66.141:8888/xml?__request="+requestId
		String url= "http://localhost:8080/xml?__request="+requestId
				+"&SUMMARY_ID="+SUMMARY_ID
				+"&PROJECT_NAME="+PROJECT_NAME
				+"&FINISH_TIME="+FINISH_TIME
				+"&TOTAL_SERVICE_NUM="+TOTAL_SERVICE_NUM
				+"&PASSED_SERVICE_NUM="+PASSED_SERVICE_NUM
				+"&FAILED_SERVICE_NUM="+FAILED_SERVICE_NUM
				+"&PASSED_RATE="+PASSED_RATE
				+"&COMPLETION_TIME="+COMPLETION_TIME
				+"&ERROR_MESSAGE="+ERROR_MESSAGE;
		HttpGet httpget = new HttpGet(url);
		System.out.println(httpget.getURI());

		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpResponse response = null;
		try {
			response = httpClient.execute(httpget);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		HttpEntity httpEntity = response.getEntity();
		String returnString = null;
		try {
			returnString = EntityUtils.toString(httpEntity);
			System.out.println("returnString: "+returnString);
		} catch (ParseException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		String positiveFlag = "FLAG=\"1\"";
		if(returnString.contains(positiveFlag)){
			System.out.println("positive flag");
			return true;
		}else{
			System.out.println("negative flag");
			return false;
		}
		
//		String statusCode = String.valueOf(response.getStatusLine().getStatusCode());
//	    if((statusCode.substring(0,2).equals("20")) | (statusCode.substring(0,2).equals("30"))){
//	    	try {
//				httpClient.close();
//				System.out.println("upload success!\n statusCode: " + statusCode);
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//	    	return true;
//	    }else{
//	    	System.out.println("upload failed!\n statusCode: " + statusCode);
//	    	try {
//				httpClient.close();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//	    	return false;
//	    }
		
		//return true;
	}
	
	@Test
	public void testProcessId()
	{
		String processId = FilePathConstants.UPLOADPROCESSID;
		String server = FilePathConstants.UPLOADSERVER;
		PwMatrixUtil pwmUtil = new PwMatrixUtil(server, processId);
		String password;
		try
		{
			password = pwmUtil.getPassword();
			Client client = new Client(FilePathConstants.RESULT_UPLOAD_URL);
			client.signOn(processId, password);
			ResultSet rs = client.process("__request=" + FilePathConstants.REQUEST_ID + "&SUMMARY_ID=" + 11
					+ "&PROJECT_NAME=" + "a" + "&ERROR_MESSAGE=" + "");
//			for (Column c : rs.getColumns())
//			{
//				System.out.println(c.getName());
//			}
			while (rs.next()) {
				System.out.println(rs.getString("FLAG"));
			}

		}
		catch (GenException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (MalformedURLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SignOnException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (ProcessException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		catch (MetadataFetchException e)
//		{
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		catch (ResultSetException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
