package com.ssc.sshz.peg.ptaf.inspection.quartz;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ssc.sshz.peg.ptaf.inspection.bean.Item;
import com.ssc.sshz.peg.ptaf.inspection.bean.Plan;
import com.ssc.sshz.peg.ptaf.inspection.bean.Project;
import com.ssc.sshz.peg.ptaf.inspection.bean.Request;
import com.ssc.sshz.peg.ptaf.inspection.bean.RuntimeTrigger;
import com.ssc.sshz.peg.ptaf.inspection.bean.System;
import com.ssc.sshz.peg.ptaf.inspection.bean.TestBrief;
import com.ssc.sshz.peg.ptaf.inspection.bean.User;
import com.ssc.sshz.peg.ptaf.inspection.constants.TestBriefStatusConstants;
import com.ssc.sshz.peg.ptaf.inspection.quartz.bean.JobData;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.ItemQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.RequestQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.quartz.job.service.TestBriefQuartzService;
import com.ssc.sshz.peg.ptaf.inspection.test.bean.TestBeanCollection;
import com.ssc.sshz.peg.ptaf.inspection.util.AssetAnalyzeUtil;

public class JDBCJobRunnerTest
{
	public static void main(String[] args) throws Exception
	{
//		JDBCJobStoreRunner runner = JDBCJobStoreRunner.getInstance();
		JDBCJobStoreRunner.init();
		Date startTime = new Date(java.lang.System.currentTimeMillis() + 20000);
		Date endTime = null;
		int intervalSeconds = 10;
		int repeatTime = 1;
		boolean isServiceCall = false;
		JobData data = new JobData();
		String asset= "C:/testCI/InspectionTest";
		data.setAsset(asset);
		String output = "C:/testCI/output";
		data.setOutput(output);
		data.setIsServiceRequest("false");
		TestBeanCollection collection = new TestBeanCollection();
		System system = new System();
		system.setProjectId(1);
		system.setProjectName("CI001");
		system.setSystemId(1);
		system.setSystemName("CNAWEB90992");
		system.setSystemuuid("1ea513a2-4e5f-1032-95a9-8e580b32d69e");
		collection.setSystem(system);
		Project project = new Project();
		project.setProjectId(1);
		project.setProjectName("CI001");
		project.setProjectuuid("d900c033-4e5e-1032-95a9-8e580b32d69e");
		collection.setProject(project);
		User user = new User();
		user.setUserId(2);
		user.setUserName("a123456");
//		collection.setUser(user);
		Plan plan = new Plan();
		plan.setPlanId(33);
		plan.setPlanName("planName1405999488629");
		plan.setSystemId(1);
		collection.setPlan(plan);
		TestBrief tempTestBrief = new TestBrief();
		TestBriefQuartzService<TestBrief> service = new TestBriefQuartzService<TestBrief>();
		tempTestBrief.setStartTime(startTime);
		tempTestBrief.setExecutorId(user.getUserId());
		tempTestBrief.setResultFolderPath(output);
		tempTestBrief.setPlanId(plan.getPlanId());
		tempTestBrief.setPlanName("planName1405999488629");
		tempTestBrief.setStatus(TestBriefStatusConstants.PREPARERUN);
		tempTestBrief.setSummaryId("1295");
		service.addTestBreif(tempTestBrief);
		TestBrief testBrief = service.getTestBreif(tempTestBrief);
		collection.setTestBrief(testBrief);
		List<Item> itemList = new ArrayList<Item>();
		ItemQuartzService<Item> itemService = new ItemQuartzService<Item>();
		RequestQuartzService<Request> requestService = new RequestQuartzService<Request>();
		//get items
		AssetAnalyzeUtil.getInstance().setRootPath(asset);
		List<String> itemNameList = AssetAnalyzeUtil.getInstance().getItems(AssetAnalyzeUtil.getInstance().getRunTime().getName());
		Item tempItem = new Item();
		Item item = null;
		Map<Integer, List<Request>> requestMapByItemId = new HashMap<Integer, List<Request>>();
		for (String itemName : itemNameList)
		{
			tempItem.setItemName(itemName);
			tempItem.setDeleted(false);
			tempItem.setSystemId(system.getSystemId());
			boolean addSc = itemService.addItem(tempItem);
			item = itemService.getItemBySystemIdItemName(tempItem);
			itemList.add(item);
			List<Request> requestList = AssetAnalyzeUtil.getInstance().getAllRequests(itemName);
//			Request tempRequest = new Request();
			Request request = null;
//			List<Request> requestList = new ArrayList<Request>();
			for (Request tempRequest : requestList)
			{
				
				tempRequest.setItemId(item.getItemId());
				requestService.addRequest(tempRequest);
				request = (Request) requestService.getRequestByRequestName(tempRequest.getRequestName());
				requestList.add(request);
			}
			requestMapByItemId.put(item.getItemId(), requestList);
		}
		collection.setItemList(itemList);
		//get reuqests 
		collection.setRequestMapByItemId(requestMapByItemId);
		
		try
		{
			JDBCJobStoreRunner.schedule(startTime, endTime, intervalSeconds, repeatTime, data, isServiceCall, collection,false,new RuntimeTrigger());
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
