function loadPlot_tps(data_tps) {
	// Memory chart
	var plot_tps = $.jqplot('tps', [ data_tps ], {
		title : "Transaction Persec",
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},
		seriesDefaults : {
			lineWidth : 1,
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true
		}
	});
}

function loadPlot_response(data_res) {
	// response
	var plot_response = $.jqplot('response', [ data_res ], {
		title : 'Response Time',
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				pad : 1,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},
		seriesDefaults : {
			lineWidth : 1,
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true
		}
	});
}
function loadPlot_memory(data_mem) {
	// Memory chart
	var plot_mem = $.jqplot('memory', data_mem, {
		title : "Memory Usage",
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},
		seriesDefaults : {
			lineWidth : 1,
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true
		},
		series : [ {
			label : 'Free'
		}, {
			label : 'Used'
		}, {
			label : 'Buffer'
		} ],
		legend : {
			show : true,
			location : 'ne'
		}
	});
}
function loadPlot_network(data_net) {
	// Network
	var plot_net = $.jqplot('network', data_net, {
		title : 'Network Traffic Packets',
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},
		seriesDefaults : {
			lineWidth : 1,
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true
		},
		series : [ {
			label : 'Receive/s'
		}, {
			label : 'Trans/s'
		} ],
		legend : {
			show : true,
			location : 'ne'
		}
	});
}
function loadPlot_cpu(data_cpu) {
	// cpu chart
	$.jqplot.config.enablePlugins = true;
	var plot_cpu = $.jqplot('cpu', data_cpu, {
		title : "CPU Usage",
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},
		seriesDefaults : {
			lineWidth : 1,
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true
		},
		series : [ {
			label : 'Total'
		}, {
			label : 'User'
		}, {
			label : 'System'
		} ],
		legend : {
			show : true,
			location : 'ne'
		}
	});
}
function loadPlot_disk(data_disk) {
	// Disk_transaction
	$.jqplot.config.enablePlugins = true;
	var plot_disk = $.jqplot('disk', data_disk, {
		title : "Disk Transaction",
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},
		seriesDefaults : {
			lineWidth : 1,
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true
		},
		series : [ {
			label : 'Trans/s'
		}, {
			label : 'Read/s'
		}, {
			label : 'Write/s'
		} ],
		legend : {
			show : true,
			location : 'ne'
		}
	});
}
function loadPlot_vuser(data_vuser) {
	// Run_Vuser chart
	$.jqplot.config.enablePlugins = true;
	var vuser = $.jqplot('vuser', [ data_vuser ], {
		title : "Run VUser",
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},
		seriesDefaults : {
			lineWidth : 1,
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true
		}
	});
}

function loadPlot_transRequests(data_trans, requirement) {
	alert(1);
	// Memory chart
	$.jqplot.config.enablePlugins = true;
	var plot_trans = $.jqplot('trans', [ data_trans ], {
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				label : 'Response Time(ms)',
				pad : 1,
				rendererOptions : {
					labelRenderer : $.jqplot.CanvasAxisLabelRenderer,
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},
		canvasOverlay : {
			show : true,
			objects : [ {
				horizontalLine : {
					name : 'pebbles',
					y : 20,
					lineWidth : 3,
					xOffset : 0,
					color : 'rgb(89, 198, 154)',
					shadow : false
				}
			} ]
		},
		seriesDefaults : {
			showLine : false,
			markerOptions : {
				size : 6
			},
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true,
			showTooltip : false
		},
	});
}

function loadPlot_transRequests(data_trans) {
	// Memory chart
	$.jqplot.config.enablePlugins = true;
	var plot_trans = $.jqplot('trans', [ data_trans ], {
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				label : 'Response Time(ms)',
				pad : 1,
				rendererOptions : {
					labelRenderer : $.jqplot.CanvasAxisLabelRenderer,
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},
		seriesDefaults : {
			showLine : false,
			markerOptions : {
				size : 6
			},
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true,
			showTooltip : false
		},
	});
}

function loadPlot_RequestDetail(data_trans) {
	// Memory chart
	$.jqplot.config.enablePlugins = true;
	var plot_trans = $.jqplot('requestDetail', [ data_trans ], {
		axes : {
			xaxis : {
				renderer : $.jqplot.DateAxisRenderer,
				rendererOptions : {
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					formatString : '%H:%M:%S',
					fontSize : '8pt',
					fontFamily : 'Tahoma',
					angle : -30
				}
			},
			yaxis : {
				label : 'Response Time(ms)',
				pad : 1,
				rendererOptions : {
					labelRenderer : $.jqplot.CanvasAxisLabelRenderer,
					tickRenderer : $.jqplot.CanvasAxisTickRenderer
				},
				tickOptions : {
					fontSize : '10pt',
					fontFamily : 'Tahoma',
					angle : 0
				}
			}
		},

		seriesDefaults : {
			showLine : false,
			markerOptions : {
				size : 8
			},
			pointLabels : {
				show : false
			}
		},
		cursor : {
			show : true,
			zoom : true,
			looseZoom : true,
			showTooltip : false
		},
	});
}
function load_Plot_error(Errordata, Rightdata, Otherdata, Otherdata1,
		Otherdata2, labelbottom) {
	// var randomScalingFactor = function(){ return
	// Math.round(Math.random()*100)};

	var barChartData = {
		labels : labelbottom,
		datasets : [ {
			fillColor : "rgba(220,220,220,1)",
			strokeColor : "rgba(220,220,220,1)",
			highlightFill : "rgba(220,220,220,1)",
			highlightStroke : "rgba(220,220,220,1)",
			data : Errordata
		}, {
			fillColor : "rgba(151,187,205,1)",
			strokeColor : "rgba(151,187,205,1)",
			highlightFill : "rgba(151,187,205,1)",
			highlightStroke : "rgba(151,187,205,1)",
			data : Rightdata
		}, {
			fillColor : "rgba(221,160,221,1)",
			strokeColor : "rgba(221,160,221,1)",
			highlightFill : "rgba(221,160,221,1)",
			highlightStroke : "rgba(221,160,221,1)",
			data : Otherdata
		}, {
			fillColor : "rgba(132,112,255,1)",
			strokeColor : "rgba(132,112,255,1)",
			highlightFill : "rgba(132,112,255,1)",
			highlightStroke : "rgba(132,112,255,1)",
			data : Otherdata1
		}, {
			fillColor : "rgba(102,205,00,1)",
			strokeColor : "rgba(102,205,00,1)",
			highlightFill : "rgba(102,205,00,1)",
			highlightStroke : "rgba(102,205,00,1)",
			data : Otherdata2
		} ]

	}

	var ctx = document.getElementById("canvas").getContext("2d");

	window.myBar = new Chart(ctx).Bar(barChartData, {
		responsive : true
	});
}