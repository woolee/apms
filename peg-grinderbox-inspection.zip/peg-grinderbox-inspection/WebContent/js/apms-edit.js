
	var tabProduct = document.getElementById("tabProduct");        
    EditTables(tabProduct);  
	
	   /**   
    * EditTables(tb1,tb2,tb2,......); 
    * Create by Senty at 2008-04-12 
    **/  
    function EditTables(){  
		for(var i=0;i<arguments.length;i++){  
		   SetTableCanEdit(arguments[i]);  
		}  
    }  
      
    function SetTableCanEdit(table){  
		for(var i=1;i<table.rows.length;i++){
		   SetRowCanEdit(table.rows[i]);
		}  
    }  
     
    function SetRowCanEdit(row){  
		for(var j=0;j<row.cells.length; j++){  
		   var editType = row.cells[j].getAttribute("EditType");  
		   if(!editType){ 
			editType = row.parentNode.rows[0].cells[j].getAttribute("EditType");  
		   }  
		   if(editType){  
			row.cells[j].onclick = function (){  
			 EditCell(this);  
			}  
		   }  
		}     
    }  
	
    function EditCell(element, editType){  
      var editType = element.getAttribute("EditType");  
		if(!editType){  
		editType = element.parentNode.parentNode.rows[0].cells[element.cellIndex].getAttribute("EditType");  
		}  
      
		switch(editType){  
		   case "TextBox":  
			CreateTextBox(element, element.innerHTML);  
			break; 
			case "TextBox_2":  
			CreateTextBox(element, element.innerHTML);  
			break;  
		   case "DropDownList":  
			CreateDropDownList(element);  
			break;  
		   default:  
			break;  
		}  
    }  

    function CreateTextBox(element, value){  
		var editState = element.getAttribute("EditState");  
		if(editState != "true"){  
			var textBox = document.createElement("INPUT");  
			textBox.type = "text";  
			textBox.className="EditCell_TextBox";  
			if(!value){  
				value = element.getAttribute("Value");  
			}    
			textBox.value = value;   
			textBox.onblur = function (){  
			CancelEditCell(this.parentNode, this.value);  
			}  
			ClearChild(element);  
			element.appendChild(textBox);  
			textBox.focus();  
			textBox.select();   
			element.setAttribute("EditState", "true");  
			element.parentNode.parentNode.setAttribute("CurrentRow", element.parentNode.rowIndex);  
		}       
    }  

    function CancelEditCell(element, value, text){  
		element.setAttribute("Value", value);  
		if(text){  
		   element.innerHTML = text;  
		}else{  
		   element.innerHTML = value;  
		}  
		element.setAttribute("EditState", "false");  
	 
		CheckExpression(element.parentNode);  
    }  
 
    function ClearChild(element){
		element.innerHTML = "";  
    }  

    function GetTableData(table){  
		var tableData = new Array();  
		alert("has saved");  
		for(var i=1; i<table.rows.length;i++){  
		   tableData.push(GetRowData(tabProduct.rows[i]));  		   
		}  
      
		return tableData;       
    } 

    function GetRowData(row){  
		var rowData = {};  
		for(var j=0;j<row.cells.length; j++){  
		   name = row.parentNode.rows[0].cells[j].getAttribute("Name");  
		   if(name){  
			var value = row.cells[j].getAttribute("Value");  
			if(!value){  
			 value = row.cells[j].innerHTML;  
			}  
			 
			rowData[name] = value;  
		   }  
		}  
		return rowData;      
    }  		
		