/**
 * @author Administrator
 */
function initValidator(base){
	
	$("#thisForm").validate({
		onkeyup:false,
		rules: {
			"userName": {
				required: true,
				userNameCheck: true,
				existCheck:true
			},
			"passWord": {
				required: true,
				minlength: [6]
			},
			"passWordAgain": {
				required: true,
				minlength: [6],
				equalTo: "#passWord"
			},
			"realName": {
				required: true
			},
			"telephonePrimary": {
				required: true,
				isMobile: true
			},"telephoneSecond": {
				required: true,
				isMobile: true
			},
			"email": {
				required: true,
				isEmail: true
			}
		},
		messages: {
			"userName": {
				required: "You can't leave this empty.",
				userNameCheck: "Please use between 4 and 20 characters and start with letter.",
				existCheck:"Someone already has that username. Try another?"
			},
			"passWord": {
				required: "You can't leave this empty.",
				minlength: "Try one with at least 6 characters."
			},
			"passWordAgain": {
				required: "You can't leave this empty.",
				minlength: "Try one with at least 6 characters.",
				equalTo: "These passwords don't match. Try again?"
			},
			"realName": {
				required: "You can't leave this empty."
			},
			"telephonePrimary": {
				required: "You can't leave this empty.",
				isMobile: "Please use vaild mobile."
			},
			"telephoneSecond": {
				required: "You can't leave this empty.",
				isMobile: "Please use vaild mobile."
			},
			"email": {
				required: "You can't leave this empty.",
				isEmail: "enter email with correct format."
			}
		},
		errorElement:"font",
		errorPlacement: function(error, element){
			error.appendTo(element.parent().find(".tipinfo"));
		},success:"valid"
	});

}
